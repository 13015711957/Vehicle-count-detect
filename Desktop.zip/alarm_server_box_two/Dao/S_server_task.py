from SYS import db_util
from datetime import datetime
from SYS import conf


def insert_server_task(server_id,task_id, state=1):
    try:
        db_util.check_reconnect()
        sql = "insert into S_server_task (server_id,task_id,create_time,update_time,state)" \
              " VALUES ('{}', '{}', '{}', '{}', '{}')".format(
            server_id,task_id, datetime.now(), datetime.now(), state)
        res = db_util.dml(sql)
        return res
    except Exception as e:
        import traceback
        traceback.print_exc()


def update_server_task_state(server_id, state):
    try:
        db_util.check_reconnect()
        sql = "UPDATE S_server_task SET state = {} WHERE server_id = '{}'".format(
            state, server_id)
        res = db_util.dml(sql)
        return res
    except Exception as e:
        import traceback
        traceback.print_exc()

def update_task_state(task_id, state):
    try:
        db_util.check_reconnect()
        sql = "UPDATE S_server_task SET state = {} WHERE task_id = '{}'".format(
            state, task_id)
        res = db_util.dml(sql)
        return res
    except Exception as e:
        import traceback
        traceback.print_exc()


def update_server_task_time(server_id):
    try:
        db_util.check_reconnect()
        sql = "UPDATE S_server_task SET update_time = '{}' WHERE server_id = '{}'".format(
            datetime.now(), server_id)
        print(sql)
        res = db_util.dml(sql)
        return res
    except Exception as e:
        import traceback
        traceback.print_exc()

def delete_server_task(server_id):
    try:
        db_util.check_reconnect()
        sql = "DELETE FROM S_server_task WHERE server_id = '{}'".format(server_id)
        res = db_util.dml(sql)
        return res
    except Exception as e:
        import traceback
        traceback.print_exc()

def delete_server_task_id(task_id):
    try:
        db_util.check_reconnect()
        sql = "DELETE FROM S_server_task WHERE task_id = '{}'".format(task_id)
        res = db_util.dml(sql)
        return res
    except Exception as e:
        import traceback
        traceback.print_exc()

def select_server_task_state(state):
    try:
        db_util.check_reconnect()
        sql = "SELECT * FROM S_server_task WHERE state = '{}'".format(state)
        res = db_util.query(sql, 'all_dict')
        return res
    except Exception as e:
        import traceback
        traceback.print_exc()

def select_server_task_serverid(server_id):
    try:
        db_util.check_reconnect()
        sql = "SELECT * FROM S_server_task WHERE server_id = '{}'".format(server_id)
        res = db_util.query(sql, 'all_dict')
        return res
    except Exception as e:
        import traceback
        traceback.print_exc()

def select_server_task_taskid(task_id):
    try:
        db_util.check_reconnect()
        sql = "SELECT * FROM S_server_task WHERE task_id = '{}'".format(task_id)
        res = db_util.query(sql, 'all_dict')
        return res
    except Exception as e:
        import traceback
        traceback.print_exc()

if __name__ == '__main__':
    server_id = '1234'
    # insert_server_task(server_id)
    # update_server_task_state(server_id,1)
    # update_server_task_time(server_id)
    # delete_server_task(server_id)
    #
    # if select_server_task_state(1):
    #     print(111)
    r=select_server_task_serverid('1234')
    print(r)