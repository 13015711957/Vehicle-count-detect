from SYS import db_util,alarm_loop
from datetime import datetime
from SYS import conf
save_img=int(conf.get('global', 'save_img'))

def insert_t_alarminfo(task_id, alarm_id, alarm_type, alarm_time, camera_id, image, objectId, alarm_action_type, bbox,
                       object_image, eventType, alarm_message):
    try:
        if not save_img:
            image=''
            object_image=''
        db_util.check_reconnect()
        sql = "insert into T_alarminfo (task_id, alarm_id, alarm_type,alarm_time,camera_id, image,objectId," \
              "alarm_action_type,bbox,object_image,eventType, alarm_message, create_time,update_time)" \
              " VALUES ('{}', '{}', '{}', '{}', '{}', '{}', '{}','{}','{}','{}','{}','{}','{}','{}')".format(
            task_id, alarm_id, alarm_type, alarm_time, camera_id, image, objectId, alarm_action_type, bbox,
            object_image, eventType, alarm_message, datetime.now(), datetime.now())
        # print("sql:", sql)
        res = db_util.dml(sql)
        return res
    except Exception as e:
        import traceback
        traceback.print_exc()

async def insert_t_alarminfo_async(task_id, alarm_id, alarm_type, alarm_time, camera_id, image, objectId, alarm_action_type, bbox,
                       object_image, eventType, alarm_message):

    try:
        if not save_img:
            image=''
            object_image=''
        # db_util.check_reconnect()
        sql = "insert into T_alarminfo (task_id, alarm_id, alarm_type,alarm_time,camera_id, image,objectId," \
              "alarm_action_type,bbox,object_image,eventType, alarm_message, create_time,update_time)" \
              " VALUES ('{}', '{}', '{}', '{}', '{}', '{}', '{}','{}','{}','{}','{}','{}','{}','{}')".format(
            task_id, alarm_id, alarm_type, alarm_time, camera_id, image, objectId, alarm_action_type, bbox,
            object_image, eventType, alarm_message, datetime.now(), datetime.now())
        print("sql:", sql)
        await alarm_loop.db_util.execute(sql)
    except Exception as e:
        import traceback
        traceback.print_exc()

async def insert_t_alarminfo_many(param):
    try:
        if not save_img:
            image = ''
            object_image = ''
        sql = "insert into T_alarminfo (task_id, alarm_id, alarm_type,alarm_time,camera_id, image,objectId," \
              "alarm_action_type,bbox,object_image,eventType, alarm_message, create_time,update_time)" \
              " VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"

        await alarm_loop.db_util.do_insertmany(sql, param)
    except Exception as e:
        import traceback
        traceback.print_exc()


if __name__ == '__main__':
    import time

    taskUUID = '1'
    alarm_Id = '1'
    camera_id = '1'
    timestamp = 1654483499
    alarm_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(timestamp))
    scene_url = '1'
    object_url = '1'
    featureId = '1'
    name_type = '1'
    alarm_message = '人员告警'
    hasMask = 1
    image = 'abc' * 20000
    object_image = image
    bbox = [1, 2, 3, 4]
    is_alarm = True
    insert_t_alarminfo(taskUUID, alarm_Id, alarm_time, image, object_image, bbox, is_alarm)
