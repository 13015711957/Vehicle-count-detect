from SYS import db_util
from datetime import datetime
import json

def insert_t_task_info(taskUUID, userId, seqid, event_type, event_define_massage, result_receiver, camera_config,
        event_config, threshold, alarm_rate):
    try:
        db_util.check_reconnect()
        sql = """insert into T_task_info (taskUUID, userId, seqid, event_type, event_define_massage, result_receiver, camera_config, 
        event_config, threshold, alarm_rate, create_time, update_time) 
                VALUES ('{}', '{}', '{}', '{}', '{}', '{}', '{}', '{}', '{}', '{}', '{}', '{}')""".format(
            taskUUID, userId, seqid, event_type, json.dumps(event_define_massage), json.dumps(result_receiver),
            json.dumps(camera_config), json.dumps(event_config), threshold, alarm_rate, datetime.now(),datetime.now())
        print("sql:",sql)
        res = db_util.dml(sql)
        return res
    except Exception as e:
        import traceback
        traceback.print_exc()

def select_t_task_info(taskUUID):
    try:
        db_util.check_reconnect()
        sql = "select * from T_task_info where taskUUID='{}'".format(taskUUID)
        res = db_util.query(sql, 'all_dict')
        return res
    except Exception as e:
        import traceback
        traceback.print_exc()


def delete_t_task_info(taskUUID):
    try:
        db_util.check_reconnect()
        sql = "delete from T_task_info where taskUUID='{}' ".format(taskUUID)
        res = db_util.dml(sql)
        return res
    except Exception as e:
        import traceback
        traceback.print_exc()


if __name__ == '__main__':
    # insert_t_task_info('1', '2', {'uri':'???'}, '4', '5', '6','7')
    # res = select_t_task_info('1')
    # print(res)
    # delete_t_task_info('1')
    taskUUID ='1'
    search_res = select_t_task_info(taskUUID)
    result_receiver = search_res[0]['result_receiver']
    result_receiver = json.loads(result_receiver)
    returnUrl = result_receiver['uri']
    print(returnUrl)
