from SYS import db_util
from datetime import datetime
from SYS import conf

save_img = conf.get('global', 'save_img')


def insert_server_online(server_id, state=1):
    try:
        db_util.check_reconnect()
        sql = "insert into S_server_online (server_id,create_time,update_time,state)" \
              " VALUES ('{}', '{}', '{}', '{}')".format(
            server_id, datetime.now(), datetime.now(), state)
        res = db_util.dml(sql)
        return res
    except Exception as e:
        import traceback
        traceback.print_exc()


def update_server_online_state(server_id, state):
    try:
        db_util.check_reconnect()
        sql = "UPDATE S_server_online SET state = {} WHERE server_id = '{}'".format(
            state, server_id)
        res = db_util.dml(sql)
        return res
    except Exception as e:
        import traceback
        traceback.print_exc()


def update_server_online_time(server_id):
    try:
        db_util.check_reconnect()
        sql = "UPDATE S_server_online SET update_time = '{}' WHERE server_id = '{}'".format(
            datetime.now(), server_id)
        print(sql)
        res = db_util.dml(sql)
        return res
    except Exception as e:
        import traceback
        traceback.print_exc()


def delete_server_online(server_id):
    try:
        db_util.check_reconnect()
        sql = "DELETE FROM S_server_online WHERE server_id = '{}'".format(server_id)
        res = db_util.dml(sql)
        return res
    except Exception as e:
        import traceback
        traceback.print_exc()


def select_server_online_state(state):
    try:
        db_util.check_reconnect()
        sql = "SELECT * FROM S_server_online WHERE state = '{}'".format(state)
        res = db_util.query(sql, 'all_dict')
        # print(res)
        return res
    except Exception as e:
        import traceback
        traceback.print_exc()

def select_server_online_serverid(server_id):
    try:
        db_util.check_reconnect()
        sql = "SELECT * FROM S_server_online WHERE server_id = '{}'".format(server_id)
        res = db_util.query(sql, 'all_dict')
        print(res)
        return res
    except Exception as e:
        import traceback
        traceback.print_exc()


if __name__ == '__main__':
    # server_id = '1234'
    # insert_server_online(server_id)
    # update_server_online_state(server_id,1)
    # update_server_online_time(server_id)
    # delete_server_online(server_id)

    # select_server_online_state(1)
    select_server_online_serverid('900132088575919')
