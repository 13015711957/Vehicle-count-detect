from SYS import db_util
from datetime import datetime


def insert_t_task_info_detail(taskUUID, userId, task_id, task_type, url):
    try:
        db_util.check_reconnect()
        sql = '''insert into T_task_info_detail (taskUUID, userId, task_id, task_type, url, create_time) 
                VALUES ("{}", "{}", "{}", "{}", "{}", "{}")'''.format(
            taskUUID, userId, task_id, task_type, url, datetime.now())
        print("sql:",sql)
        res = db_util.dml(sql)
        return res
    except Exception as e:
        import traceback
        traceback.print_exc()

def select_t_task_inf_detail(taskUUID):
    try:
        db_util.check_reconnect()
        sql = "select * from T_task_info_detail where taskUUID='{}'".format(taskUUID)
        res = db_util.query(sql, 'all_dict')
        return res
    except Exception as e:
        import traceback
        traceback.print_exc()

def select_t_task_inf_detail_v2(task_id):
    try:
        db_util.check_reconnect()
        sql = "select * from T_task_info_detail where task_id='{}'".format(task_id)
        res = db_util.query(sql, 'all_dict')
        return res
    except Exception as e:
        import traceback
        traceback.print_exc()

def delete_t_task_info_detail(taskUUID):
    try:
        db_util.check_reconnect()
        sql = "delete from T_task_info_detail where taskUUID='{}' ".format(taskUUID)
        res = db_util.dml(sql)
        return res
    except Exception as e:
        import traceback
        traceback.print_exc()


if __name__ == '__main__':
    insert_t_task_info_detail('1', '2', '3', '4', '5')
    # res = select_t_task_info('1')
    # print(res)
    # delete_t_task_info('1')
    taskUUID ='1'
    search_res = select_t_task_inf_detail_v2(taskUUID)
    # result_receiver = search_res[0]['result_receiver']
    # result_receiver = eval(result_receiver)
    # returnUrl = result_receiver['uri']
    # print(returnUrl)
