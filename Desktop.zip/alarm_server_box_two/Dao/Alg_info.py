from SYS import db_util
from datetime import datetime
from SYS import conf


def select_alg_info():
    try:
        db_util.check_reconnect()
        sql = "SELECT * FROM Alg_info "
        res = db_util.query(sql, 'all_dict')
        print(res)
        return res
    except Exception as e:
        import traceback
        traceback.print_exc()

if __name__ == '__main__':
    select_alg_info()