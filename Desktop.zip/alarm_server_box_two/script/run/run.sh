#!/bin/bash

now=`date "+%Y%m%d"`

PY_CMD='python'
UVICORN_CMD='uvicorn'
EXE_DIR='/project/box_alarm_server_new'

start()
{
    cd ${EXE_DIR}
    ($UVICORN_CMD Job.Stream_API_main:app --host=0.0.0.0 --port=7001 &>>log/Stream_API.log &)
    ($UVICORN_CMD Job.Alarm_API_main:app --host=0.0.0.0 --port=7002 &>>log/Alarm_API.log &)
    ($PY_CMD -u Job/mock_alarm_grpc_server.py &>>log/BOX_callback_API_main.log &)
#    ($UVICORN_CMD Job.Alg_server_API_main:app --host=0.0.0.0 --port=7005 &>>log/Alg_server_API.log &)
#    ($PY_CMD -u Job/BOX_callback_API_main.py &>>log/BOX_callback_API_main.log &)
#    ($PY_CMD -u Job/update_server_state.py &>>log/update_server_state.log &)

    cd - &>/dev/null
}

kill_keywork_process()
{  key_work=$1
  for t_pid in `ps xf|grep -E ${key_work} |grep -v grep|awk '{print $1}'`
  do
    kill -9 ${t_pid}
  done
}

stop()
{
    list='Job.Alarm_API_main:app BOX_callback_API_main Stream_API_main Alg_server_API_main mock_alarm_grpc_server'
    for t in $list
    do
        kill_keywork_process $t
    done

    cd - &>/dev/null
}

restart_api()
{
  stop
  sleep 1
  start_api
}

restart()
{
  stop
  sleep 1
  start
}


case "$1" in
  start_api)
    start_api
    ;;
  start)
    start
    ;;
  stop)
    stop
    ;;
  restart_api)
    restart_api
    ;;
  restart)
    restart
    ;;
  *)
    echo $"Usage: $0 {start|stop|restart}"
    exit 2
esac

exit $?

