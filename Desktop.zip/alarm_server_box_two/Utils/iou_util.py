# -*- coding: utf-8 -*-

'''
@project : AIGateWay
@FileName: iou_util
@Author  :linych 
@Time    :2020/12/11 11:12
@Desc  : 
'''
import numpy as np
import shapely
from shapely.errors import TopologicalError
from shapely.geometry import Polygon, MultiPoint
from skimage.draw import polygon


def compute_IOU(rec1, rec2):
    """
    计算两个矩形框的交并比。
    :param rec1: [x0,y0,W,H]      (x0,y0)代表矩形左上的顶点，（x1,y1）代表矩形右下的顶点。下同。
    :param rec2: [x0,y0,W,H]
    :return: 交并比IOU.
    """

    rec1[2] += rec1[0]
    rec1[3] += rec1[1]
    print(rec1)
    rec2[2] += rec2[0]
    rec2[3] += rec2[1]
    print(rec2)

    left_column_max = max(rec1[0], rec2[0])
    right_column_min = min(rec1[2], rec2[2])
    up_row_max = max(rec1[1], rec2[1])
    down_row_min = min(rec1[3], rec2[3])

    # 两矩形无相交区域的情况
    if left_column_max >= right_column_min or down_row_min <= up_row_max:
        return 0
    # 两矩形有相交区域的情况
    else:
        S1 = (rec1[2] - rec1[0]) * (rec1[3] - rec1[1])
        S2 = (rec2[2] - rec2[0]) * (rec2[3] - rec2[1])
        S_cross = (down_row_min - up_row_max) * (right_column_min - left_column_max)
        return S_cross / (S1 + S2 - S_cross)


def cal_iou(box1, box2):
    """
    :param box1: = [xmin1, ymin1, xmax1, ymax1]
    :param box2: = [xmin2, ymin2, xmax2, ymax2]
    :return:
    """
    # box1[2] += box1[0]
    # box1[3] += box1[1]
    # box2[2] += box2[0]
    # box2[3] += box2[1]

    xmin1, ymin1, xmax1, ymax1 = box1
    xmin2, ymin2, xmax2, ymax2 = box2
    # 计算每个矩形的面积
    s1 = (xmax1 - xmin1) * (ymax1 - ymin1)  # b1的面积
    s2 = (xmax2 - xmin2) * (ymax2 - ymin2)  # b2的面积

    # 计算相交矩形
    xmin = max(xmin1, xmin2)
    ymin = max(ymin1, ymin2)
    xmax = min(xmax1, xmax2)
    ymax = min(ymax1, ymax2)

    w = max(0, xmax - xmin)
    h = max(0, ymax - ymin)
    a1 = w * h  # C∩G的面积
    a2 = s1 + s2 - a1
    # iou = a1 / a2  # iou = a1/ (s1 + s2 - a1)
    if a1 == 0 or s1 == 0:
        return 0
    iou = a1 / s1  # 计算物品面积占比
    return iou


def overlap(bbox, area):
    # [x1 y1 x2 y2]
    center_x = (bbox[0] + bbox[2]) / 2
    center_y = (bbox[1] + bbox[3]) / 2
    print(center_x, center_y)
    if (area[0] <= center_x <= area[2]) and (area[1] <= center_y <= area[3]):
        return True
    else:
        return False


def overlap_wh(bbox, area):
    # bbox [x,y,w,h]
    # area [x1 y1 x2 y2]
    center_x = bbox[0] + (bbox[2]) / 2
    center_y = bbox[1] + (bbox[3]) / 2
    print(center_x, center_y)
    if (area[0] <= center_x <= area[2]) and (area[1] <= center_y <= area[3]):
        return True
    else:
        return False


def is_in_poly(p, area):
    """
    # 计算中心点是否在区域内

    :param p: 中心点或矩形框 [x, y] or [x, y, w, h]
    :param area: 多边形同方向顶点 [{'x':x, 'y':y}, {...}, ...]
    :return: 中心点是否在范围内 True or False
    """
    if len(p) == 2:
        px, py = p
    elif len(p) == 4:
        px = int(p[0] + p[2] / 2)
        py = int(p[1] + p[3] / 2)
    else:
        return False
    poly = []
    for each in area:
        poly.append([each['x'], each['y']])
    is_in = False
    for i, corner in enumerate(poly):
        next_i = i + 1 if i + 1 < len(poly) else 0
        x1, y1 = corner
        x2, y2 = poly[next_i]
        if (x1 == px and y1 == py) or (x2 == px and y2 == py):  # if point is on vertex
            is_in = True
            break
        if min(y1, y2) < py <= max(y1, y2):  # find horizontal edges of polygon
            x = x1 + (py - y1) * (x2 - x1) / (y2 - y1)
            if x == px:  # if point is on edge
                is_in = True
                break
            elif x > px:  # if point is on left-side of line
                is_in = not is_in
    return is_in


def to_polygon(quadrilateral):
    """
    :param quadrilateral: 四边形四个点坐标的一维数组表示，[x,y,x,y....]

    :return: 四边形二维数组, Polygon四边形对象
    """
    # 四边形二维数组表示
    quadrilateral_array = np.array(quadrilateral).reshape(4, 2)
    # Polygon四边形对象，会自动计算四个点，最后四个点顺序为：左上 左下  右下 右上 左上
    quadrilateral_polygon = Polygon(quadrilateral_array).convex_hull

    return quadrilateral_array, quadrilateral_polygon


def iou_in_poly(bbox, area):
    """
    :param bbox: 矩形框 [x, y, w, h]

    :param area: 四边形同方向顶点 [{'x':x, 'y':y}, {...}, ...]

    :return:
    """
    if len(bbox) != 4 or len(area) != 4:
        return 0
    actual_quadrilateral = [bbox[0], bbox[1], bbox[0] + bbox[2], bbox[1], bbox[0] + bbox[2], bbox[1] + bbox[3], bbox[0],
                            bbox[1] + bbox[3]]
    predict_quadrilateral = []
    for each in area:
        predict_quadrilateral.append(each['x'])
        predict_quadrilateral.append(each['y'])

    actual_quadrilateral_array, actual_quadrilateral_polygon = to_polygon(actual_quadrilateral)
    predict_quadrilateral_array, predict_quadrilateral_polygon = to_polygon(predict_quadrilateral)

    # 合并两个box坐标，变为8*2 便于后面计算并集面积
    union_poly = np.concatenate((actual_quadrilateral_array, predict_quadrilateral_array))

    # 两两四边形是否存在交集
    inter_status = actual_quadrilateral_polygon.intersects(predict_quadrilateral_polygon)

    if inter_status:
        try:
            inter_area = actual_quadrilateral_polygon.intersection(predict_quadrilateral_polygon).area

            # 并集面积 计算方式一
            # union_area = poly1.area + poly2.area - inter_area
            # 并集面积 计算方式二
            # union_area = MultiPoint(union_poly).convex_hull.area

            if inter_area == 0:
                iou = 0
            else:
                iou = float(inter_area) / actual_quadrilateral_polygon.area
        except shapely.errors.TopologicalError:
            iou = 0
    else:
        iou = 0

    return iou


def polygon_IOU(bbox, warning_area):
    """
    计算两个多边形的IOU
    :param bbox: [x1,y1,x2,y2]
    :param warning_area: [{'x':x, 'y':y}, {...}, ...]
    :return:
    """
    polygon_1 = np.array([
        [bbox[0], bbox[1]],
        [bbox[2], bbox[1]],
        [bbox[2], bbox[3]],
        [bbox[0], bbox[3]]
    ])
    temp_area=[]
    for point in warning_area:
        temp_area.append([point['x'],point['y']])
    polygon_2 = np.array(temp_area)



    rr1, cc1 = polygon(polygon_2[:, 0], polygon_2[:, 1])
    rr2, cc2 = polygon(polygon_1[:, 0], polygon_1[:, 1])

    try:
        r_max = max(rr1.max(), rr2.max()) + 1
        c_max = max(cc1.max(), cc2.max()) + 1
    except:
        return 0

    canvas = np.zeros((r_max, c_max))
    canvas[rr1, cc1] += 1
    canvas[rr2, cc2] += 1
    union = np.sum(canvas > 0)
    if union == 0:
        return 0
    intersection = np.sum(canvas == 2)


    return intersection / union


if __name__ == '__main__':
    # 测试样例1
    # r1 = [851, 99, 934, 191]
    # r2 = [354, 0, 1594, 1296]
    # IOU = cal_iou(r1, r2)
    # print("测试样例1，IOU：%f" % IOU)
    # # 测试样例2
    # r1 = (2, 2, 4, 4)
    # r2 = (3, 3, 5, 5)
    # IOU = compute_IOU(r1, r2)
    # print("测试样例2，IOU：%f" % IOU)
    bbox = [60, 25, 70, 75]
    area = [{
        "x": 60,
        "y": 25
    }, {
        "x": 70,
        "y": 25
    }, {
        "x": 80,
        "y": 50
    }, {
        "x": 70,
        "y": 75
    }, {
        "x": 60,
        "y": 75
    }, {
        "x": 50,
        "y": 50
    }]
    iou = polygon_IOU(bbox, area)
    print(iou)
