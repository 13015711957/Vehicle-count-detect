#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2021/5/6 10:45
# @Author  : lx-rookie
# @File    : base64_to_img.py
import base64
import numpy as np
import cv2
import os


def base64_to_img(ori_img):
    """
        将base64位数据转为cv2读取得到的图片
    :param ori_img:
    :return:
    """

    base64Image = ori_img.replace("%2B", "+").replace("%3D", "=").replace("%2F", "/")
    img = base64.b64decode(base64Image)
    img_array = np.frombuffer(img, np.uint8)
    ori_img = cv2.imdecode(img_array, -1)
    if len(ori_img.shape) == 2:
        # 单通道转三通道
        ori_img = cv2.cvtColor(ori_img, cv2.COLOR_GRAY2BGR)
    elif len(ori_img.shape) == 3:
        h_, w_, c_ = ori_img.shape
        if c_ == 4:
            ori_img = rgba2rgb(ori_img)
        # else:
        #     ori_img = cv2.cvtColor(ori_img, cv2.COLOR_RGB2BGR)

    return ori_img


def rgba2rgb(rgba, background=(255, 255, 255)):
    row, col, ch = rgba.shape
    if ch == 3:
        return rgba
    assert ch == 4, 'RGBA image has 4 channel'
    # 生成一个三维画布图片
    rgb = np.zeros((row, col, 3), dtype='float32')
    # 获取图片每个通道数据
    r, g, b, a = rgba[:, :, 0], rgba[:, :, 1], rgba[:, :, 2], rgba[:, :, 3]
    # 把 alpha 通道的值转换到 0-1 之间
    a = np.asarray(a, dtype='float32') / 255.0
    # 得到想要生成背景图片每个通道的值
    R, G, B = background
    # 将图片 a 绘制到另一幅图片 b 上，如果有 alpha 通道，那么最后覆盖的结果值将是 c = a * alpha + b * (1 - alpha)
    rgb[:, :, 0] = r * a + (1.0 - a) * R
    rgb[:, :, 1] = g * a + (1.0 - a) * G
    rgb[:, :, 2] = b * a + (1.0 - a) * B
    # 把最终数据类型转换成 uint8
    return np.asarray(rgb, dtype='uint8')


if __name__ == '__main__':
    path = r"E:\TIM接收文件\营业执照图片编码"
    import os
    import cv2


    with open(r'D:\qq\消息\1071328513\FileRecv\111.txt', 'r') as f:
        ori_img = f.readline()
    ori_img = base64_to_img(ori_img)
    cv2.imwrite('0720.jpg', ori_img)
#     # for txt in os.listdir(path):
#     #     print(txt)
#     #     txt_path = path + '/' +txt
#     #     pic_path = path + '/' + txt.split('.')[0] + '.jpg'
#     #     base_64 = open(txt_path)
#     #     line = base_64.readline()
#     #     # print(line)
#     #     img = base64_to_img(line)
#     #     cv2.namedWindow('1', 0)
#     #     cv2.imshow('1', img)
#     #     cv2.waitKey(0)
#     #     cv2.imencode('.jpg',img)[1].tofile(pic_path)
