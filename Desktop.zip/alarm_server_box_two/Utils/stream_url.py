# -*- encoding: utf-8 -*-
"""
@Project : AIStreamPlatform
@FileName: stream_url
@Time    : 2022/1/12 14:55 
@Author  : zhangec
@Desc    :
"""
import requests
import json
from SYS import conf

stream_url = 'http://{}:{}{}'.format(conf.get('get_video_url', 'host'), conf.get('get_video_url', 'port'),
                                     conf.get('get_video_url', 'stream'))


def get_streamUrl(DID):
    headers = {"Content-Type": "application/json"}
    req_data = {
        "url1": "https://ai.ehome.21cn.com/dvj/url/getDeviceMediaUrlReal",
        "mobileName": '18888888888',
        "deviceCode": DID,
        "mediaType": "0"
    }
    # 发起请求
    response = requests.post(url=stream_url, data=json.dumps(req_data), headers=headers)
    print(f"获取视频url返回结果：{response.text}")
    res = json.loads(response.text)

    rtsp_uri = res['data'].get('urlNormal', '')
    return rtsp_uri
