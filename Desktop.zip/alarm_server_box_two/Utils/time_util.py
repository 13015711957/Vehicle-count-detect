# -*- encoding: utf-8 -*-
"""
@Project : AIStreamPlatform
@FileName: time_util
@Time    : 2021/12/16 10:22 
@Author  : zhangec
@Desc    :
"""
import time
import datetime


def timestamp_to_date(timestamp):
    """
    timestamp: seconds
    :return: date
    """
    kk = time.localtime(timestamp)
    date = time.strftime('%Y-%m-%d %H:%M:%S', kk)
    return date


if __name__ == '__main__':
    test = timestamp_to_date(1639621308.928)
    print(test)
