# -*- coding: utf-8 -*-

'''
@project : SmartTravel
@FileName: t1
@Author  :linych
@Time    :2021/4/2 16:29
@Desc  :
'''
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import boto3
from SYS import conf
from botocore.client import Config

# 配置AccessKey和SecretKey, Endpoint和Region根据实际情况填写
AccessKey = conf.get('s3', 'AccessKey')
SecretKey = conf.get('s3', 'SecretKey')
edpoint = conf.get('s3', 'edpoint')
region = conf.get('s3', 'region')
config = Config(connect_timeout=30, read_timeout=30)
s3_client = boto3.client(
    's3', aws_access_key_id=AccessKey, aws_secret_access_key=SecretKey,
    endpoint_url=edpoint, use_ssl=False, config=config)


def upload_object_by_presigned_url(name, data):
    bucket = conf.get('s3', 'bucket')

    resp = s3_client.put_object(
        Bucket=bucket,
        Key=name,
        Body=data
    )

    url = s3_client.generate_presigned_url(
        ClientMethod='get_object',
        Params={'Bucket': bucket, 'Key': name},
        ExpiresIn=24*3600)

    return url


def create_bucket(bucket):
    res = s3_client.create_bucket(bucket)
    print(res)


if __name__ == '__main__':
    bucket = conf.get('s3', 'bucket')
    #create_bucket(bucket)
    url = upload_object_by_presigned_url('test','111')
    print(url)
