#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2021/5/6 17:23
# @Author  : lx-rookie
# @File    : logging_util.py
import os
import logging.handlers
import datetime
import sys

sys.path.append("..")


class LoggingUtil(object):
    '''
    classdocs
    '''
    logger = logging.getLogger()  # 初始化

    def __init__(self, name):
        self.name = name
        self.logFileInit()

    def logFileInit(self):
        modulePath = os.path.dirname(os.path.dirname(__file__))
        # print("路径：", modulePath)
        today = datetime.date.today()
        if not os.path.exists(modulePath + '/log/' + self.name):
            os.makedirs(modulePath + '/log/' + self.name)
        logName = self.name + '_' + str(today) + '.log'
        LOG_FILE = modulePath + '/log/' + self.name + '/' + logName
        handler = logging.handlers.RotatingFileHandler(LOG_FILE, maxBytes=1024 * 1024, backupCount=5,
                                                       encoding='utf-8')  # 实例化handler
        fmt = '%(asctime)s - %(levelname)s - %(message)s'

        formatter = logging.Formatter(fmt)  # 实例化formatter
        handler.setFormatter(formatter)  # 为handler添加formatter

        self.handler = handler

        self.logger = logging.getLogger('compact')  # 获取名为tst的logger
        self.logger.addHandler(self.handler)  # 为logger添加handler
        self.logger.setLevel(logging.DEBUG)

    def info(self, msg):
        # self.logFileInit()
        self.logger.info(msg)
        self.handler.close()

    def error(self, contractError):
        self.logFileInit()
        self.logger.error(contractError.errorInfo)
        self.saveErrorLog(contractError)
        self.handler.close()

    def debug(self, msg):
        self.logFileInit()
        self.logger.debug(msg)
        self.handler.close()

    def printError(self, e):
        print(e)


if __name__ == '__main__':
    # pass
    loggingUtil = LoggingUtil('Test')
    error = '文本检测错误'
    loggingUtil.info(error)