# -*- coding: utf-8 -*-

'''
@project : AIGateWay
@FileName: alg_track_util
@Author  :xiedx
@Time    :2022/4/8 14:07
@Desc  :
'''

from functools import reduce
from collections import Counter
from Common.RedisClient.redis_connecter import redis_TRACK
from Common.RedisClient.redis_connecter import redis_TRACK

def get_track_io_state(io_list):
    '''
    判断人员进出状态
    '''
    T_index = []
    F_index = []
    for index, value in enumerate(io_list):
        if int(value):
            T_index.append(index)
        else:
            F_index.append(index)
    # print(T_index, F_index)
    T = reduce(lambda x, y: x + y, T_index) if len(T_index) > 0 else 0
    T = T / len(T_index) if T > 0 else 0
    F = reduce(lambda x, y: x + y, F_index) if len(F_index) > 0 else 0
    F = F / len(F_index) if F > 0 else 0
    if F >= T and T > 0:
        io_state = -1  # 进门
    elif T > F and F > 0:
        io_state = -2  # 出门
    else:
        io_state = -3
    # print('-------------------')
    # print(io_state)
    # print(io_list, T, F)
    return io_state

def get_door_io(camera_id, track_id, start=0, end=-1):
    """
    # 根据camera_id和track_id从redis获取人体是否在门禁框内结果列表
    """
    return redis_TRACK.lrange('door_track_io_{}_{}'.format(camera_id, track_id), start, end)

def rpush_area_io(camera_id, track_id, value, expire_time = 60*10):
    """
    将人体是否在门禁框内结果保存到redis
    """
    rds_key = 'area_track_io_{}_{}'.format(camera_id, track_id)
    redis_TRACK.rpush(rds_key, value)
    redis_TRACK.expire(rds_key, expire_time)

def get_door_feature_result(camera_id, track_id, start=0, end=-1):
    """
    # 根据camera_id和track_id从redis获取feature_id列表
    """
    return redis_TRACK.lrange('door_track_feature_id_{}_{}'.format(camera_id, track_id), start, end)

def rpush_door_feature_result(camera_id, track_id, value, expire_time = 60*10):
    """
    将feature id保存到redis
    """
    rds_key = 'door_track_feature_id_{}_{}'.format(camera_id, track_id)
    redis_TRACK.rpush(rds_key, value)
    redis_TRACK.expire(rds_key, expire_time)

def hget_door_frame_result(camera_id, track_id, key):
    """
    # 根据camera_id和track_id从redis获取帧信息
    """
    return redis_TRACK.hget('door_frame_{}_{}'.format(camera_id, track_id), key)

def hset_door_frame_key(camera_id, track_id, key, value):
    """
    将帧数据保存到redis
    """
    rds_key = 'door_frame_{}_{}'.format(camera_id, track_id)
    redis_TRACK.hset(rds_key, key, value)

def hset_door_frame_result(camera_id, track_id, data, expire_time = 60*10):
    """
    将最优帧信息保存到redis
    """
    rds_key = 'door_frame_{}_{}'.format(camera_id, track_id)
    for k, v in data.items():
        hset_door_frame_key(camera_id, track_id, k, v)
    redis_TRACK.expire(rds_key, expire_time)

def hexist_door_frame_result(camera_id, track_id, key):
    """
    判断redis中是否存在key
    """
    rds_key = 'door_frame_{}_{}'.format(camera_id, track_id)
    return redis_TRACK.hexists(rds_key, key)

def transform_feature(feature_id):
    """
    将feature_id转换为数字，便于判断
    """
    if feature_id == '-2':
        return -2
    elif feature_id == '-1':
        return -1
    else:
        return 0

def get_most_common(data, frame_count = 0, repeat=1, limit=60, frame_threshold=60, finish=True,min_frame=5):
    """
    返回列表中出现次数最多的元素
    finish: 表示是否结束
    """
    counter = Counter(data)
    feature_id_most = counter.most_common()

    most = None
    max_most_transformation = -2
    if len(data)<=min_frame:
        return most
    for i in feature_id_most:
        repeat_id = i[0]
        if i[1] >= repeat:
            # 具体人员
            most_transformation = transform_feature(repeat_id)
            if most_transformation > max_most_transformation:
                max_most_transformation = most_transformation
                most = repeat_id
    if finish:
        most = '-2' if most is None else most
        return most
    if most is None and (len(data) >= limit or frame_count > frame_threshold):
        most = '-2'

    return most

def face_reason_map(face_code):
    FaceReasonMap = {
        # 10～19 人脸质量存在问题
        11: '人脸上存在遮挡物',
        12: '人脸过于靠近边界',
        13: '检测到的人脸面积太小',
        14: '人脸姿态过大',
        15: '人脸侧脸角度过大',
        16: '2d人脸姿态过大',
        17: '检测置信度过低',
        18: '对齐图片异常',
        # 20～29 模型运行错误错误
        20: '人脸特征提取失败',
        21: '人脸检测失败',
    }
    return FaceReasonMap.get(face_code, None)

def bbox_to_area(bbox):
    """
    将bbox格式[x1,y1,x2,y2]转换成[{'x':x1,'y': y1},{'x':x2,'y': y1},{'x':x2,'y': y2},{'x':x1,'y': y2}]
    """
    if len(bbox) < 3:
        return []
    x1, y1, x2, y2 = bbox[0], bbox[1], bbox[2], bbox[3]
    return [{'x':x1,'y': y1},{'x':x2,'y': y1},{'x':x2,'y': y2},{'x':x1,'y': y2}]

# 保存track的第一次出现时间
def hset_track_start_time(camera_id, track_id, value, key='track_start_time', expire_time = 60*5):
    """
    将每个跟踪提的出现时间保存到redis
    """
    rds_key = 'door_track_time_{}_{}'.format(camera_id, track_id)
    redis_TRACK.hset(rds_key, key, value)
    redis_TRACK.expire(rds_key, expire_time)

def hexist_track_start_time(camera_id, track_id, key='track_start_time'):
    rds_key = 'door_track_time_{}_{}'.format(camera_id, track_id)
    return redis_TRACK.hexists(rds_key, key)

def hget_track_start_time(camera_id, track_id, key='track_start_time'):
    return redis_TRACK.hget('door_track_time_{}_{}'.format(camera_id, track_id), key)


if __name__ == '__main__':
    io_list = [False,False,True, True,True,True,False,False,False,False]
    get_track_io_state(io_list)
