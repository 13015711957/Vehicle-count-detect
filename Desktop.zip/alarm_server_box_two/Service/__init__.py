# -*- coding: utf-8 -*-

'''
@project : AIGateWay
@FileName: __init__.py
@Author  :linych 
@Time    :2020/11/26 14:38
@Desc  : 
'''

from fastapi import FastAPI

app = FastAPI()
