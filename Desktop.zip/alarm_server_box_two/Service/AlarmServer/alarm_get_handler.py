# -*-coding:utf-8 -*-

"""
# Project    : AIStreamPlatform
# File       : alarm_get_handler.py
# Time       ：2021/8/23 17:29
# Author     ：zhengqx
# Description：
"""
import time
import json
import datetime
import ailog
from pydantic import BaseModel

from Business.AlarmManager.AlarmSearch import AlarmSearch
# from Dao.t_log_dao import insert_log
from SYS import SYS_CODE, mysql_log_loop
#from Utils.prometheus_util import prometheus_util
from Business.ALL_BUISS_CODE import INTERFACE_TYPE, QUEUE_TYPE


class AlarmGetItem(BaseModel):
    userId: str = None
    secretId: str = None
    timestamp: str = None
    seqid: str = None
    taskId: str = None


class AlarmGethandler():
    name = 'AlarmGet'

    @classmethod
    def response_error(cls, seqid, code, message='', flag=0):
        res = {}
        res['seqid'] = seqid
        res['code'] = code
        res['message'] = message
        res['flag'] = flag
        # res = json.dumps(res, ensure_ascii=False)
        return res

    @classmethod
    def response_res(cls, res):
        # ailog.info('result : {}'.format(res))

        # res = json.dumps(res, ensure_ascii=False)
        return res

    @classmethod
    def check_args(cls, req_item):

        args_dict = {}
        args_list = {
            'userId': True,
            'secretId': True,
            'timestamp': True,
            'seqid': True,
            'taskId': True
        }

        for k, v in args_list.items():
            if v:
                val = getattr(req_item, k, None)
                if val is None:
                    cls.response_error(getattr(req_item, 'seqid', ''),
                                       SYS_CODE.RESPCODE.KEYERROR,
                                       '服务必填参数[%s]缺失或未填写' % (k)
                                       )
                    return None
                else:
                    args_dict[k] = val
            else:
                args_dict[k] = getattr(req_item, k, None)

        return args_dict

    @classmethod
    #@prometheus_util(project='AIStreamPlatform', name='AlarmGet', success_code='10000', code_name='code')
    async def post(cls, item: AlarmGetItem):
        accept_time = int(time.time())
        try:

            args_dict = cls.check_args(item)
            print("args_dict", args_dict)
            if args_dict is None:
                post_data = str(item)
                ailog.warning('#error post_data: {}'.format(post_data))
                return cls.response_error(getattr(item, 'seqid', ''),
                                          SYS_CODE.RESPCODE.KEYERROR,
                                          '服务必填参数缺失或未填写'
                                          )
            args_dict['accept_time'] = accept_time
            data = AlarmSearch.run(args_dict)

            res = {'seqid': args_dict.get('seqid', ''),
                   'code': '10000',
                   'message': 'ok',
                   'flag': 1,
                   'data': data
                   }

        except Exception as e:
            import traceback
            traceback.print_exc()
            res = {'seqid': args_dict.get('seqid', ''),
                   'code': '10903',
                   'message': '{}'.format(e),
                   'flag': 0,
                   'data': {}
                   }

        return cls.response_res(res)
