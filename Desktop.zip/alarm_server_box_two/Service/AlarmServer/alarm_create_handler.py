import datetime
import json
import time
import ailog
from Common.RabbitMQClient.mq_producer import common_to_mq
from SYS import conf
from pydantic import BaseModel
# from Business.VerifyManager.user_verify_main import user_verify
from Business.AlarmManager.AlarmCreate import AlarmCreate
# from Dao.t_log_dao import insert_log
from SYS import SYS_CODE, mysql_log_loop
# from Utils.prometheus_util import prometheus_util
from Business.ALL_BUISS_CODE import QUEUE_TYPE, INTERFACE_TYPE


class AlarmCreateItem(BaseModel):
    userId: str = None
    secretId: str = None
    timestamp: str = None
    seqid: str = None
    taskId: str = None
    event_type: str = None
    event_define_massage: dict = {}
    result_receiver: dict = {}
    camera_config: dict = {}
    event_config: dict = {}
    threshold: float = 0.0
    alarm_rate: int = 10


class AlarmCreatehandler():
    name = 'AlarmCreate'

    @classmethod
    def response_error(cls, seqid, code, message='', flag=0):
        res = {}
        res['seqid'] = seqid
        res['code'] = code
        res['message'] = message
        res['flag'] = flag
        return res

    @classmethod
    def response_res(cls, res):
        return res

    @classmethod
    def check_args(cls, req_item):

        args_dict = {}
        args_list = {
            'userId': True,
            'secretId': True,
            'timestamp': True,
            'seqid': True,
            'taskId': True,
            'event_type': True,
            'event_define_massage': True,
            # 'alarm_start_time': False,
            # 'alarm_end_time': False,
            'result_receiver': False,
            # 'type': True,
            # 'uri': True,
            # 'method': True,
            'camera_config': True,
            # 'camera_id': True,
            # 'camera_uri': True,
            'event_config': True,
            'threshold': False,
            'alarm_rate': False
        }

        for k, v in args_list.items():
            if v:
                val = getattr(req_item, k, None)
                if val is None:
                    cls.response_error(getattr(req_item, 'seqid', ''),
                                       SYS_CODE.RESPCODE.KEYERROR,
                                       '服务必填参数[%s]缺失或未填写' % (k)
                                       )
                    return None
                else:
                    args_dict[k] = val
            else:
                args_dict[k] = getattr(req_item, k, None)

        return args_dict

    @classmethod
    # @prometheus_util(project='AIStreamPlatform', name='AlarmCreate', success_code='10000', code_name='code')
    async def post(cls, item: AlarmCreateItem):
        accept_time = int(time.time())
        try:
            interface_type = INTERFACE_TYPE.ALARM_CREATE
            queue_type = QUEUE_TYPE.CREATE_TASK
            args_dict = cls.check_args(item)
            print("args_dict", args_dict)
            if args_dict is None:
                post_data = str(item)
                ailog.warning('#error post_data: {}'.format(post_data))
                return cls.response_error(getattr(item, 'seqid', ''),
                                          SYS_CODE.RESPCODE.KEYERROR,
                                          '服务必填参数缺失或未填写'
                                          )
            # verify_result = user_verify(args_dict)
            # if verify_result["code"] == "10000":
            #     if verify_result['data'].get('proxy', 'no') == 'yes':
            #         args_dict['proxy'] = True
            #     else:
            #         args_dict['proxy'] = False
            #     args_dict['accept_time'] = accept_time
            #     args_dict['interface_type'] = interface_type
            #     args_dict['queue_type'] = queue_type

            # host = conf.get('MQ', 'url')
            # username = conf.get('MQ', 'username')
            # pwd = conf.get('MQ', 'pwd')
            # queue = conf.get('MQ', 'queue_task_merge')
            # port = conf.get('MQ', 'port')

            result = AlarmCreate.run(args_dict)
            print(result)
            if result and result['code'] == 0:
                res = {'seqid': args_dict.get('seqid', ''),
                       'code': '10000',
                       'message': 'ok',
                       'flag': 1,
                       'data': {}
                       }
            else:
                res = {'seqid': args_dict.get('seqid', ''),
                       'code': '10903',
                       'message': result.get("message", ""),
                       'flag': 0,
                       'data': {}
                       }
            # else:
            #     res = verify_result

        except Exception as e:
            import traceback
            traceback.print_exc()
            res = {'seqid': args_dict.get('seqid', ''),
                   'code': '10903',
                   'message': '{}'.format(e),
                   'flag': 0,
                   'data': {}
                   }
        # try:
        #     mysql_log_loop.run(insert_log(
        #         url='',
        #         seqid=args_dict.get('seqid', ""),
        #         task_id=args_dict.get('taskId', ""),
        #         user_id=args_dict.get('userId', ""),
        #         method=cls.name,
        #         args=json.dumps(args_dict, ensure_ascii=False),
        #         output=json.dumps(res, ensure_ascii=False),
        #         code=res.get('code', ''),
        #         use_time=time.time() - accept_time,
        #         create_time=datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        #     ))
        # except Exception as e:
        #     print('log error : {}'.format(e))
        return cls.response_res(res)
