# -*-coding:utf-8 -*-

"""
# Project    : AIStreamPlatform
# File       : alarm_get_handler.py
# Time       ：2021/8/23 17:29
# Author     ：zhengqx
# Description：
"""
import time
import json
import datetime
import ailog
from pydantic import BaseModel

from Business.AlgServerManager.GetVersion import GetVersion
from SYS import SYS_CODE



class GetVersionItem(BaseModel):
    timestamp: str = None
    seqid: str = None


class GetVersionhandler():
    name = 'GetVersion'

    @classmethod
    def response_error(cls, seqid, code, message='', flag=0):
        res = {}
        res['seqid'] = seqid
        res['code'] = code
        res['message'] = message
        res['flag'] = flag
        # res = json.dumps(res, ensure_ascii=False)
        return res

    @classmethod
    def response_res(cls, res):
        # ailog.info('result : {}'.format(res))

        # res = json.dumps(res, ensure_ascii=False)
        return res

    @classmethod
    def check_args(cls, req_item):

        args_dict = {}
        args_list = {
            'timestamp': False,
            'seqid': False,
        }

        for k, v in args_list.items():
            if v:
                val = getattr(req_item, k, None)
                if val is None:
                    cls.response_error(getattr(req_item, 'seqid', ''),
                                       SYS_CODE.RESPCODE.KEYERROR,
                                       '服务必填参数[%s]缺失或未填写' % (k)
                                       )
                    return None
                else:
                    args_dict[k] = val
            else:
                args_dict[k] = getattr(req_item, k, None)

        return args_dict

    @classmethod
    async def post(cls, item: GetVersionItem):
        try:

            args_dict = cls.check_args(item)
            print("args_dict", args_dict)
            if args_dict is None:
                post_data = str(item)
                ailog.warning('#error post_data: {}'.format(post_data))
                return cls.response_error(getattr(item, 'seqid', ''),
                                          SYS_CODE.RESPCODE.KEYERROR,
                                          '服务必填参数缺失或未填写'
                                          )
            result = GetVersion.run(args_dict)
            # print(result)

            res = {'seqid': args_dict.get('seqid', ''),
                   'code': '10000',
                   'message': 'ok',
                   'flag': 1,
                   'data': result
                   }

        except Exception as e:
            import traceback
            traceback.print_exc()
            res = {'seqid': args_dict.get('seqid', ''),
                   'code': '10903',
                   'message': '{}'.format(e),
                   'flag': 0,
                   'data': {}
                   }

        return cls.response_res(res)
