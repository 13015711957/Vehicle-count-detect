import datetime
import json
import time
import ailog
from Common.RabbitMQClient.mq_producer import common_to_mq
from SYS import conf
from pydantic import BaseModel
from Business.AlgServerManager.Register import Register
from SYS import SYS_CODE



class RegisterItem(BaseModel):
    code: str = None
    data: dict = None



class Registerhandler():
    name = 'Register'

    @classmethod
    def response_error(cls, seqid, code, message='', flag=0):
        res = {}
        res['seqid'] = seqid
        res['code'] = code
        res['message'] = message
        res['flag'] = flag
        return res

    @classmethod
    def response_res(cls, res):
        return res

    @classmethod
    def check_args(cls, req_item):

        args_dict = {}
        args_list = {
            'code': True,
            'data': True,

        }

        for k, v in args_list.items():
            if v:
                val = getattr(req_item, k, None)
                if val is None:
                    cls.response_error(getattr(req_item, 'seqid', ''),
                                       SYS_CODE.RESPCODE.KEYERROR,
                                       '服务必填参数[%s]缺失或未填写' % (k)
                                       )
                    return None
                else:
                    args_dict[k] = val
            else:
                args_dict[k] = getattr(req_item, k, None)

        return args_dict

    @classmethod
    async def post(cls, item: RegisterItem):
        accept_time = int(time.time())
        try:
            args_dict = cls.check_args(item)
            print("args_dict", args_dict)
            if args_dict is None:
                post_data = str(item)
                ailog.warning('#error post_data: {}'.format(post_data))
                return cls.response_error(getattr(item, 'seqid', ''),
                                          SYS_CODE.RESPCODE.KEYERROR,
                                          '服务必填参数缺失或未填写'
                                          )
            res = Register.run(args_dict)
        except Exception as e:
            import traceback
            traceback.print_exc()
            res = {"code": 0, "data": str(e)}

        return cls.response_res(res)
