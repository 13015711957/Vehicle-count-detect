# -*- coding: utf-8 -*-

'''
@project : ComplaintsAnalysis
@FileName: sys_code_config
@Desc  : 
'''


class STATUS():
    """
    任务状态  0：未开始  1：开始  2：运行中  3：失败  4：重复  5：成功',
    """
    SUCCESS = 10000  # 成功
    FLAG_SUCCESS = 1  # 业务成功
    FLAG_FAIL = 0  # 业务失败
    FAIL = 5003  #服务执行失败

    ABILITY_SUCCESS = 0


class RESPCODE():

    SUCCESS = 10000  # 成功
    FLAG_SUCCESS = 1  # 业务成功
    FLAG_FAIL = 0  # 业务失败
    FAIL = 10903  # 服务执行失败
    KEYERROR = 10301  # 缺少参数
    PARAM_ERROR = 10304 #请求参数格式错误
    IMAGE_ERROR = 5002 #图片拉取失败

    msg = {
        FAIL: '服务执行失败',
        KEYERROR: '缺少参数',
        PARAM_ERROR: '请求参数格式错误',
        IMAGE_ERROR:'图片拉取失败',
        SUCCESS:'服务执行成功'
    }

    @classmethod
    def get_msg(cls, code):
        try:
            return cls.msg[code]
        except:
            return ''
