# -*-coding:utf-8 -*-

"""
# Project    : AIStreamPlatform
# File       : __init__.py.py
# Time       ：2021/8/16 17:40
# Author     ：linych
# version    ：python 3.7
# Description：
"""

