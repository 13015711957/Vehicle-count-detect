import json

from Common.HttpClient.asyn_request import AsynClient
from Core import conf

faiss_url_host = conf.get('faiss_url', 'host')
faiss_url_port = conf.get('faiss_url', 'port')
faiss_url_add = conf.get('faiss_url', 'faiss_feature_add')
url = "http://" + faiss_url_host + ":" + faiss_url_port + faiss_url_add
ac = AsynClient(retry=1)


async def add_faiss(faiss_data):
    faiss_res = await ac.post(url=url, body=json.dumps(faiss_data, ensure_ascii=False).encode('utf-8'))

    try:
        res_json = json.loads(faiss_res)
        if res_json.get('code') != 1:
            raise Exception('faiss server error')
    except Exception as e:
        import traceback
        traceback.print_exc()
