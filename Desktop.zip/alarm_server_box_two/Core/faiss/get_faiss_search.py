import json

from Common.HttpClient.asyn_request import AsynClient
from SYS import conf


faiss_url_host = conf.get('faiss_url', 'host')
faiss_url_port = conf.get('faiss_url', 'port')
faiss_url_search = conf.get('faiss_url', 'faiss_feature_search')
url = "http://" + faiss_url_host + ":" + faiss_url_port + faiss_url_search
ac = AsynClient(retry=1)


def get_faiss_search(faiss_data):
    faces_result = []
    faiss_res = await ac.post(url=url, body=json.dumps(faiss_data, ensure_ascii=False).encode('utf-8'))
    try:
        res_json = json.loads(faiss_res)

    except Exception as e:
        print(e)
        return faces_result

    if res_json.get('code') != 1:
        return faces_result
    data = res_json.get('data')
    if not data:
        return faces_result
    face_ids = data.get('userCode')
    I = data.get('I')
    D = data.get('D')
    if not face_ids:
        return faces_result
    index = 0
    for face_id in face_ids:
        faces_result.append({
            'face_id': face_id,
            'score': (2.0 - D[0][index]) / 2,
        })
        index += 1
    return faces_result
