import uuid
import json
import time

from Core.faiss.add_faiss_feature import add_faiss
from Core.faiss.get_face_feature_v2 import get_face_feature_v2
from Core.faiss.get_face_quality import get_face_quality
from Core.faiss.get_faiss_search import get_faiss_search
from Core.faiss.get_reid_feature import get_reid_feature
from Dao.t_faiss_embedding_dao import insert_faiss_embedding
from Dao.t_object_feature_dao import select_object_id, insert_object_feature
from Dao.t_person_info_dao import insert_person_info
from Utils.image_util import base64_to_array, img_cut_resize


class ImgStrangeRecogTask(object):

    @classmethod
    async def run(cls, cut_base64, id, is_create):
        print("-------图片识别开始-------")
        # 获取人脸<512维>及人体<2048维>特征
        # face_data = await get_face_feature(image_data=cut_base64)
        now_time = time.time()
        face_data = await get_face_feature_v2(image_data=cut_base64)
        print(f"脸部特征获取耗时：{time.time()-now_time}")
        face_feature = face_data.get('embedding')
        face_score = face_data.get('score')
        face_angle = face_data.get('face_angle')
        # is_face = True if face_feature and face_score > 0.8 and abs(face_angle) < 20 else False
        is_face = True if face_feature else False

        face_info = dict(bbox=face_data.get('bbox'), score=face_score, angle=face_angle)
        # face_feature = []

        reid_time = time.time()
        reid_feature = await get_reid_feature(image_data=cut_base64)
        print(f"人体特征获取耗时：{time.time()-reid_time}")
        # print(f"获取人体特征耗时：{time.time()-now_time}")

        # 获取faiss_search结果,eg:{'face_id': 1, 'score': 0.7}
        faiss_time = time.time()
        face_faiss = await cls.get_faiss_res(group_id=1, top_n=1, threshold=0.4, feature_data=face_feature)
        print(f"人脸faiss比对结果：{face_faiss}")
        print(f"人脸faiss比对耗时：{time.time()-faiss_time}")
        # print(f"faiss比对耗时：{time.time()-now_time}")

        # # score验证获取person_id
        # person_id = await cls.get_person_by_score_check(faiss_search_res=face_faiss, group_id=1,
        #                                                 feature_data=face_feature, feature_type=0,
        #                                                 comparison_score=0.7, id=id, is_create=is_create,
        #                                                 is_face=is_face)
        # if person_id != -1:
        #     # return {'person_id': person_id, 'is_face': True, 'face_info': {}}
        #     return {'person_id': person_id, 'is_face': True, 'face_info': face_info}
        #
        # person_id = await cls.get_person_by_score_check(faiss_search_res=reid_faiss, group_id=2,
        #                                                 feature_data=reid_feature, feature_type=1,
        #                                                 comparison_score=0.99, id=id, is_create=is_create,
        #                                                 is_face=is_face)
        search_time = time.time()
        reid_faiss = False
        person_id, is_build = await cls.create_search_person(face_faiss, reid_faiss, face_feature,
                                                             reid_feature, is_create, is_face, id,
                                                             cut_base64, face_info.get('bbox'))
        print(f"search_person耗时：{time.time()-search_time}")
        print("-------图片识别结束-------")
        return {'person_id': person_id, 'is_face': is_face, 'face_info': face_info, 'is_build': is_build}

    @classmethod
    async def create_search_person(cls, face_faiss, reid_faiss, face_feature, reid_feature,
                                   is_create, is_face, id, cut_base64, bbox):

        person_id = -1
        face_group_id = 1
        reid_group_id = 2
        is_build = False

        if face_faiss:
            print("-------人脸逻辑-------")
            feature_id = face_faiss[0].get('face_id')
            face_score = face_faiss[0].get('score')
            # 查表获取person_id并返回
            res = select_object_id(feature_id=feature_id)
            person_id = res[0]
            print(f"person_id: {person_id}, face_score: {face_score}, group_id: {face_group_id}, face_id: {feature_id}, id: {id}")
            return person_id, is_build

        if reid_faiss:
            print("-------人体逻辑-------")
            feature_id = reid_faiss[0].get('face_id')
            reid_score = reid_faiss[0].get('score')
            # 查表获取person_id并返回
            res = select_object_id(feature_id=feature_id)
            person_id = res[0]
            print(f"person_id: {person_id}, face_score: {reid_score}, group_id: {face_group_id}, face_id: {feature_id}, id: {id}")
            return person_id, is_build

        # todo 都未匹配<is_create暂时不用>
        if is_face:
            cut_array = base64_to_array(cut_base64)
            face_array = img_cut_resize(cut_array, bbox, 0.3)
            face_quality = await get_face_quality(img=face_array.tolist())
            face_quality_score = face_quality.get('score', 0)
            print(f"face_score: {face_quality_score}")
            if face_quality_score > 0.1:
                print("-------建档-------")
                # 满足条件
                person_id = cls.get_new_person()
                # 创建人脸
                await cls.insert_data(person_id=person_id, group_id=face_group_id,
                                      feature_data=face_feature, feature_type=0)
                # 创建人体
                # await cls.insert_data(person_id=person_id, group_id=reid_group_id,
                #                       feature_data=reid_feature, feature_type=1)
                is_build = True
                return person_id, is_build
        print(f"都未匹配--is_create:{is_create}, is_face: {is_face}")
        return person_id, is_build

    @classmethod
    async def get_faiss_res(cls, group_id, top_n, threshold, feature_data):
        """
        获取faiss_search返回结果
        :param group_id: 人脸1 人体2
        :param top_n: 取top1数据
        :param threshold: 阈值
        :param feature_data: 特征向量
        :return: faiss_res
        """
        if not feature_data:
            return []
        data = dict(groupId=group_id, top_n=top_n, threshold=threshold, embedding=json.dumps(feature_data))
        faiss_res = get_faiss_search(data)
        return faiss_res

    # @classmethod
    # async def get_person_by_score_check(cls, faiss_search_res, group_id, feature_data, feature_type,
    #                                     comparison_score, id, is_create, is_face):
    #     """
    #     score验证（faiss_search返回结果）
    #     :param faiss_search_res: 人脸或人体调用faiss_search返回结果
    #     :param group_id: 人脸1 人体2
    #     :param feature_data: 人脸特征向量或人体特征向量
    #     :param feature_type: 人脸0 人体1
    #     :param comparison_score: 人脸score=0.7 人体score=0.95
    #     :param id: 唯一识别
    #     :param is_create: 是否建档
    #     :return: person_id
    #     """
    #     person_id = -1
    #     if not faiss_search_res:
    #         if feature_data and is_create and is_face:
    #             person_id = cls.insert_data(group_id=group_id, feature_data=feature_data,
    #                                         feature_type=feature_type)
    #         return person_id
    #
    #     feature_id = faiss_search_res[0].get('face_id')
    #     face_score = faiss_search_res[0].get('score')
    #
    #     # if (face_score < comparison_score) and is_create and is_face:
    #     #     print(f"face_score: {face_score}, comparison_score: {comparison_score}, id: {id}")
    #     #     person_id = cls.insert_data(group_id=group_id, feature_data=feature_data, feature_type=feature_type)
    #     #     return person_id
    #
    #     print(f"face_score: {face_score}, group_id: {group_id}, face_id: {feature_id}, id: {id}")
    #     # 查表获取person_id并返回
    #     res = select_object_id(feature_id=feature_id)
    #     person_id = res[0] if res else -1
    #     return person_id

    @staticmethod
    async def insert_data(person_id, group_id, feature_data, feature_type):
        """
        统一插入数据
        :param group_id: 人脸1 人体2
        :param feature_data: 人脸特征向量或人体特征向量
        :param feature_type: 人脸0 人体1
        """
        new_feature_id = str(uuid.uuid5(uuid.uuid4(), 'faiss'))
        insert_faiss_embedding(group_id=group_id, feature_id=new_feature_id, embedding=json.dumps(feature_data))
        insert_object_feature(object_id=person_id, feature_id=new_feature_id, feature_type=feature_type)
        # 更新faiss
        dim = 512
        await add_faiss(dict(groupId=group_id, embedding=json.dumps(feature_data), faceId=new_feature_id, dim=dim))

    @staticmethod
    def get_new_person():
        person_id = insert_person_info()
        return person_id
