import json

from Common.HttpClient.asyn_request import AsynClient
from Core import conf


reid_feature_host = conf.get('reid_feature', 'host')
reid_feature_port = conf.get('reid_feature', 'port')
reid_feature_post = conf.get('reid_feature', 'url_post')
ac = AsynClient(retry=1)
url = "http://" + reid_feature_host + ":" + reid_feature_port + reid_feature_post


async def get_reid_feature(image_data):
    feature_data = []
    reid_data = dict(image_base64=image_data)
    reid_res = await ac.post(url=url, body=json.dumps(reid_data, ensure_ascii=False).encode('utf-8'))

    try:
        res_json = json.loads(reid_res)
    except Exception as e:
        print(e)
        print('#WARN:返回结果有误:{}'.format(reid_res))
        return feature_data
    if res_json.get('code') == 10000:
        feature_data = res_json.get('data')
    else:
        print('#WARN:返回ReidFeature有误:{}'.format(res_json))
    return feature_data