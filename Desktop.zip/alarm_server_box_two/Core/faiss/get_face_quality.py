import json

from Common.HttpClient.asyn_request import AsynClient
from Core import conf


face_quality_host = conf.get('FaceQuality_url', 'host')
face_quality_port = conf.get('FaceQuality_url', 'port')
face_quality_post = conf.get('FaceQuality_url', 'url_FQ')
url = "http://" + face_quality_host + ":" + face_quality_port + face_quality_post
ac = AsynClient(retry=1)


async def get_face_quality(img):
    result = {}
    data = dict(img=img)
    res = await ac.post(url=url, body=json.dumps(data))

    try:
        res_json = json.loads(res)
    except Exception as e:
        print(e)
        print('#WARN:返回结果有误:{}'.format(res))
        return result
    result = res_json.get('data')
    return result