# -*-coding:utf-8 -*-

"""
# Project    : AIStreamPlatform
# File       : __init__.py.py
# Time       ：2021/7/31 23:21
# Author     ：linych
# version    ：python 3.7
# Description：
"""

import os
import sys

import Core.sys_code_config as SYS_CODE
from Core.config_util import ConfigUtil
from Core.mysql_connecter import mysql_connecter
from Core.AsyncThreadLoop import AsyncThreadLoop
from Core.AsyncMysqlLoop import AsyncMysqlThreadLoop

__all__ = ['conf', 'SYS_CODE']
# __all__ = ['conf', 'db_util', 'SYS_CODE', 'root_path', 'log_path', 'db_util_log']
config_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

if os.path.exists(r'/opt/config/config.ini'):
    config_path = r'/opt/config/'

config_path = r'F:\ffcs\AISP\config'
print("config_path: ", config_path)
try:
    conf = ConfigUtil(config_path=os.path.join(config_path, 'config.ini'))
except Exception as e:
    print('config read error : {}'.format(e))

mysql_config = {
    'user': conf.get(section='Mysql', option='user'),
    'passwd': conf.get(section='Mysql', option='password'),
    'db': conf.get(section='Mysql', option='db'),
    'host': conf.get(section='Mysql', option='host'),
    'port': conf.get(section='Mysql', option='port'),
    'minsize': conf.get(section='Mysql', option='minsize'),
    'maxsize': conf.get(section='Mysql', option='maxsize'),

}


db_util = mysql_connecter(db_cfg=mysql_config)
db_util.set_transaction_isolation_read_committed()
# # lock_db_util = mysql_connecter(db_cfg=mysql_config)
# mysql_config_log = mysql_config
# mysql_config_log['db'] = conf.get(section='Mysql', option='db_audit')
# db_util_log = mysql_connecter(db_cfg=mysql_config)
# db_util_log.set_transaction_isolation_read_committed()
# root_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
#
# mysql_config_log = mysql_config
# mysql_config_log['db'] = conf.get(section='Mysql', option='db_log')
# create_face_loop = AsyncThreadLoop()
# create_index_loop = AsyncThreadLoop()
# mysql_log_loop = AsyncMysqlThreadLoop(conf=mysql_config)
# mysql_ailog_loop = AsyncMysqlThreadLoop(conf=mysql_config)
#
# try:
#     dir_name = conf.get(section='logging', option='dir')
# except:
#     dir_name = 'log'
# log_path = os.path.join(root_path, dir_name)
#
# NODE = conf.get('global', 'node')
