'''
人员越线
'''
import os
import time
import uuid

import cv2

from Common.RedisClient.redis_connecter import redis_DATA
from Utils.image_util import img_cut, base64toarray, img_arry_cut_to_base64
from numpy import dot
from numpy.linalg import norm


def cross(p1, p2, p3):  # 叉积判定
    x1 = p2[0] - p1[0]
    y1 = p2[1] - p1[1]
    x2 = p3[0] - p1[0]
    y2 = p3[1] - p1[1]
    return x1 * y2 - x2 * y1


def segment(p1, p2, p3, p4):  # 判断两线段是否相交
    # 矩形判定，以l1、l2为对角线的矩形必相交，否则两线段不相交
    if (max(p1[0], p2[0]) >= min(p3[0], p4[0])  # 矩形1最右端大于矩形2最左端
            and max(p3[0], p4[0]) >= min(p1[0], p2[0])  # 矩形2最右端大于矩形1最左端
            and max(p1[1], p2[1]) >= min(p3[1], p4[1])  # 矩形1最高端大于矩形2最低端
            and max(p3[1], p4[1]) >= min(p1[1], p2[1])):  # 矩形2最高端大于矩形1最低端
        if (cross(p1, p2, p3) * cross(p1, p2, p4) <= 0
                and cross(p3, p4, p1) * cross(p3, p4, p2) <= 0):
            D = 1
        else:
            D = 0
    else:
        D = 0
    return D


def check(l1, l2, sq):
    # step 1 check if end point is in the square
    if (l1[0] >= sq[0] and l1[1] >= sq[1] and l1[0] <= sq[2] and l1[1] <= sq[3]) or (
            l2[0] >= sq[0] and l2[1] >= sq[1] and l2[0] <= sq[2] and l2[1] <= sq[3]):
        return 1
    else:
        # step 2 check if diagonal cross the segment
        p1 = [sq[0], sq[1]]
        p2 = [sq[2], sq[3]]
        p3 = [sq[2], sq[1]]
        p4 = [sq[0], sq[3]]
        if segment(l1, l2, p1, p2) or segment(l1, l2, p3, p4):
            return 1
        else:
            return 0


def check_isinline(mid_point, line):
    x1, y1, x2, y2 = line
    x3, y3 = mid_point
    s = (x1 - x3) * (y2 - y3) - (y1 - y3) * (x2 - x3)
    if s == 0 and y1 <= y3 <= y2 and x1 <= x3 <= x2:
        return 1
    else:
        return 0


def cross_borer_handle(data, task_args):
    alarm_detail = []
    event_type = task_args.get('event_type')
    detection = data['detections']
    event_config = task_args.get('event_config')
    camera_config = task_args.get('camera_config')
    camera_id = camera_config.get('camera_id')
    for item in detection:
        x0, y0, x1, y1 = item['box']
        bbox = [x0, y0, x1 - x0, y1 - y0]
        smallImage = item['smallImage']
        attrs = item['attrs']
        trackId = item['trackId']
        classId = -1
        score = 1
        for attr in attrs:
            classId = attr['classId']
            score = attr['score']

        if classId == 1 and trackId != -1:
            line = event_config.get('line', [0, 0, 0, 0])
            arrow = event_config.get('arrow', [0, 0, 0, 0])

            p3 = [line[0], line[1]]
            p4 = [line[2], line[3]]
            mid_point = [x0 + (x1 - x0) / 2, y0 + (y1 - y0) / 2]
            # pre_mid_p = redis_DATA.hget('cross_line_track', '{}_{}'.format(camera_id, trackId))
            pre_mid_p = redis_DATA.hget('{}_{}'.format(camera_id, event_type), 'cross_line_track_{}'.format(trackId))

            is_cross = 0
            cosin = 0
            if pre_mid_p:
                pre_mid_p = eval(pre_mid_p)
                is_cross = segment(pre_mid_p, mid_point, p3, p4)
                # 判断余弦值
                List1 = [arrow[2] - arrow[0], arrow[3] - arrow[1]]
                List2 = [mid_point[0] - pre_mid_p[0], mid_point[1] - pre_mid_p[1]]
                cosin = dot(List1, List2) / (norm(List1) * norm(List2))
                print('line:{} arrow:{} 人体轨迹线:{} 轨迹线与判定线是否相交:{} 轨迹线与箭头余弦值:{}'.format(
                    line, arrow, [pre_mid_p, mid_point], is_cross, cosin
                ))

            if is_cross and 0 < cosin <= 1:

                alarm_detail.append({
                    "arrowedLine": [int(pre_mid_p[0]), int(pre_mid_p[1]), int(mid_point[0]), int(mid_point[1])],
                    "objectId": str(uuid.uuid4()),
                    "alarm_action_type": event_type,
                    "bbox": bbox,
                    "score": score,
                    "object_image": smallImage,
                    "eventType": event_type,
                    "alarm_message": '人员越线告警', })
            # redis_DATA.hset('cross_line_track', '{}_{}'.format(camera_id, trackId), str(mid_point))
            redis_DATA.hset('{}_{}'.format(camera_id, event_type), 'cross_line_track_{}'.format(trackId),
                            str(mid_point))
    return alarm_detail


if __name__ == '__main__':
    # res=check((1,1),(1,10),(192,108,1280,720))
    res = segment((396, 345), (870, 999), (534, 231), (534, 912))
    print(res)
