# -*-coding:utf-8 -*-

"""
# Project    : AIStreamPlatform
# File       : __init__.py.py
# Time       ：2021/7/27 16:55
# Author     ：linych
# version    ：python 3.7
# Description：
"""

