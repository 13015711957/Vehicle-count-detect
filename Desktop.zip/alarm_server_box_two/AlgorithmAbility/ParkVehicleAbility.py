import time
import uuid

from Common.RedisClient.redis_connecter import redis_DATA
from Utils.iou_util import  is_in_poly

'''
车辆违停
'''

alarm_num = 6



def park_vehicle_handle(data, task_args):
    alarm_detail = []
    event_type = task_args.get('event_type')
    detection = data['detections']
    event_config = task_args.get('event_config')
    warning_time = event_config.get('warning_time', 5 * 60)
    warning_area = event_config.get('warning_area', None)
    camera_config = task_args.get('camera_config')
    camera_id = camera_config.get('camera_id')

    for item in detection:
        x0, y0, x1, y1 = item['box']
        bbox = [x0, y0, x1 - x0, y1 - y0]
        smallImage = item['smallImage']
        attrs = item['attrs']
        trackId = item['trackId']
        alarm_count = redis_DATA.hget('{}_{}'.format(camera_id, event_type),
                                      'park_vehicle_track_{}'.format(camera_id, trackId))
        first_time = redis_DATA.hget('{}_{}'.format(camera_id, event_type), '{}_{}'.format(camera_id, trackId))

        now_time = time.time()
        if not first_time:
            first_time = str(time.time())
            redis_DATA.hset('{}_{}'.format(camera_id, event_type), '{}_{}'.format(camera_id, trackId), first_time)

        if not alarm_count:
            alarm_count = 0
        else:
            alarm_count = int(alarm_count)

        for attr in attrs:
            classId = int(attr['classId'])
            score = attr['score']
            print('车辆违停:{} {}'.format(classId, score))
            if classId in [1, 2]:
                print('告警区域{} 车辆框{}'.format(warning_area, bbox))
                if not warning_area or is_in_poly(bbox, warning_area):
                    alarm_count += 1
            print('违停帧数:{} 违停时间:{}'.format(alarm_count, abs(now_time - eval(first_time))))
            if alarm_count >= alarm_num and abs(now_time - eval(first_time)) >= warning_time:
                alarm_detail.append({
                    "objectId": str(uuid.uuid4()),
                    "alarm_action_type": event_type,
                    "bbox": bbox,
                    "score": score,
                    "object_image": smallImage,
                    "eventType": event_type,
                    "alarm_message": '车辆违停告警', })

        redis_DATA.hset('{}_{}'.format(camera_id, event_type),
                        'park_vehicle_track_{}'.format(camera_id, trackId),alarm_count)
    return alarm_detail
