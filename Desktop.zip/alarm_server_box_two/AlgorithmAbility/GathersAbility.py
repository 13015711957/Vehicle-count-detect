import uuid

from Utils.iou_util import is_in_poly

'''
人群聚集
'''


def gathers_handle(data, task_args):
    alarm_detail = []
    event_type = task_args.get('event_type')
    detection = data['detections']
    event_config = task_args.get('event_config')
    warning_area = event_config.get('warning_area', None)
    max_num = event_config.get('warning_num_threshold', 2)
    threshold = event_config.get('threshold', 0)
    crow_num = []
    for item in detection:
        x0, y0, x1, y1 = item['box']
        bbox = [x0, y0, x1 - x0, y1 - y0]
        smallImage = item['smallImage']
        attrs = item['attrs']
        classId = -1
        score = 1
        for attr in attrs:
            classId = attr['classId']
            score = attr['score']

        if classId == 1 and score * 100 >= threshold:
            x, y, w, h = bbox
            foot_point = [x + w / 2, y + h]  # 脚底中心点
            if not warning_area or is_in_poly(bbox, warning_area) or \
                    is_in_poly(foot_point, warning_area):
                crow_num.append(bbox)
    print('聚集人数:{}'.format(len(crow_num)))
    if len(crow_num) >= max_num:
        alarm_detail.append({
            "objectId": str(uuid.uuid4()),
            "alarm_action_type": event_type,
            "score": 1,
            "personNums": len(crow_num),
            "eventType": event_type,
            "alarm_message": '人群聚集', })
    return alarm_detail
