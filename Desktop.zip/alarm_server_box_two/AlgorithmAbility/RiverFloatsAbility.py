import uuid

from Utils.image_util import img_cut, img_arry_cut_to_base64

'''
河道漂浮
'''
def river_floats_handle(data, task_args):
    alarm_detail = []
    event_type = task_args.get('event_type')
    detection = data['detections']
    for item in detection:
        x0, y0, x1, y1 = item['box']
        bbox = [x0, y0, x1 - x0, y1 - y0]
        smallImage = item['smallImage']
        attrs = item['attrs']
        for attr in attrs:
            classId = int(attr['classId'])
            score = attr['score']
            print('河道漂浮:{} {}'.format(classId,score))

            alarm_detail.append({
                "objectId": str(uuid.uuid4()),
                "alarm_action_type": event_type,
                "bbox": bbox,
                "score": score,
                "object_image": smallImage,
                "eventType": event_type,
                "alarm_message": '河道漂浮告警', })

    return alarm_detail
