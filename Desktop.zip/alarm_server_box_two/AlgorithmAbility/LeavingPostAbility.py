import time
import uuid

from Common.RedisClient.redis_connecter import redis_DATA
from Utils.iou_util import is_in_poly

'''
人员离岗
'''


def leaving_post_handle(data, task_args):
    alarm_detail = []
    event_type = task_args.get('event_type')
    detection = data['detections']
    event_config = task_args.get('event_config')
    camera_config = task_args.get('camera_config')
    camera_id = camera_config.get('camera_id')

    warning_area = event_config.get('warning_area', None)
    warning_time = event_config.get('warning_time', 10)
    threshold = event_config.get('threshold', 0)
    now = time.time()
    leave_time = redis_DATA.hget('{}_{}'.format(camera_id, event_type), '{}_leavetime'.format(camera_id))
    if not leave_time:
        leave_time = now
    else:
        leave_time = eval(leave_time)
    flag = True
    for item in detection:
        x0, y0, x1, y1 = item['box']
        bbox = [x0, y0, x1 - x0, y1 - y0]
        smallImage = item['smallImage']
        attrs = item['attrs']
        classId = -1
        score = 1
        for attr in attrs:
            classId = attr['classId']
            score = attr['score']

        if classId == 1 and score * 100 >= threshold:
            x, y, w, h = bbox
            foot_point = [x + w / 2, y + h]  # 脚底中心点
            if not warning_area or is_in_poly(bbox, warning_area) or \
                    is_in_poly(foot_point, warning_area):
                flag = False
                break
    if not flag:
        leave_time = now
    print('离岗时间:{}'.format(now - leave_time))

    if (now - leave_time) >= int(warning_time):
        alarm_detail.append({
            "objectId": str(uuid.uuid4()),
            "alarm_action_type": event_type,
            "score": 1,
            "eventType": event_type,
            "alarm_message": '人员离岗', })
    return alarm_detail
