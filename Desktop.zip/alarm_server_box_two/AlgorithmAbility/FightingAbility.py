import json
import uuid

from Common.RedisClient.redis_connecter import redis_DATA

'''
打架斗殴
'''


def fighting_handle(data, task_args):
    alarm_detail = []
    event_type = task_args.get('event_type')
    detection = data['detections']
    event_config = task_args.get('event_config')
    camera_config = task_args.get('camera_config')
    camera_id = camera_config.get('camera_id')
    base_w = data['baseWidth']
    base_h = data['baseHeight']
    if not event_config:
        event_config = {}
    threshold = event_config.get('threshold', 0)
    alarm_lis = redis_DATA.hget('{}_{}'.format(camera_id, event_type), 'TRACK_{}_{}'.format(camera_id, event_type))

    if not alarm_lis:
        alarm_lis = []
    else:
        alarm_lis = json.loads(alarm_lis)
    alarm = 0
    item = detection[0]
    x0, y0, x1, y1 = item['box']
    bbox = [x0, y0, x1 - x0, y1 - y0]
    smallImage = item['smallImage']
    attrs = item['attrs']
    for attr in attrs:
        classId = int(attr['classId'])
        score = attr['score']
        if score * 100 > threshold:
            alarm = 1
    alarm_lis.append(alarm)
    redis_DATA.hset('{}_{}'.format(camera_id, event_type), 'TRACK_{}_{}'.format(camera_id, event_type), json.dumps(alarm_lis),
                    ex=10 * 60)
    print("alarm_lis", alarm_lis)
    alarm_lis_ = alarm_lis[-3:]

    if alarm_lis_.count(1) > 1 and alarm == 1:
        alarm_detail.append({
            "objectId": str(uuid.uuid4()),
            "alarm_action_type": event_type,
            "bbox": bbox,
            "score": 1,
            "object_image": smallImage,
            "eventType": event_type,
            "alarm_message": '打架斗殴告警', })

    return alarm_detail
