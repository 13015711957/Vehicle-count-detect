import time
import uuid

from Common.RedisClient.redis_connecter import redis_DATA
from Utils.image_util import img_cut, img_arry_cut_to_base64


def fire_handle(data, task_args):
    alarm_detail = []
    event_type = task_args.get('event_type')
    detection = data['detections']
    event_config = task_args.get('event_config')
    warning_time = event_config.get('warning_time', 10)
    camera_config = task_args.get('camera_config')
    camera_id = camera_config.get('camera_id')
    first_time = redis_DATA.hget('{}_{}'.format(camera_id, event_type), '{}_fire'.format(camera_id))
    now_time = time.time()
    if not first_time:
        first_time = str(now_time)
    for item in detection:
        x0, y0, x1, y1 = item['box']
        bbox = [x0, y0, x1 - x0, y1 - y0]
        smallImage = item['smallImage']
        attrs = item['attrs']
        for attr in attrs:
            classId = int(attr['classId'])
            score = attr['score']
            if classId == 0:

                if abs(now_time - eval(first_time)) >= warning_time:
                    alarm_detail.append({
                        "objectId": str(uuid.uuid4()),
                        "alarm_action_type": event_type,
                        "bbox": bbox,
                        "score": score,
                        "object_image": smallImage,
                        "eventType": event_type,
                        "alarm_message": '火焰告警', })
            else:
                first_time = str(now_time)


    redis_DATA.hset('{}_{}'.format(camera_id, event_type), '{}_fire'.format(camera_id),first_time)

    return alarm_detail
