import uuid

from Common.RedisClient.redis_connecter import redis_DATA
'''
持刀持械
'''

def weapons_handle(data, task_args):
    alarm_detail = []
    event_type = task_args.get('event_type')
    detection = data['detections']
    event_config = task_args.get('event_config')
    threshold = event_config.get('threshold', 0)
    camera_config = task_args.get('camera_config')
    camera_id = camera_config.get('camera_id')
    # 过滤出持械对象
    weapon_obj_list = []
    for item in detection:
        x0 = float(item['x'])
        y0 = float(item['y'])
        x1 = float(item['x1'])
        y1 = float(item['y1'])
        classId = int(item['classId'])
        model_type = str(item['taskType'])
        className = item['className']
        bbox = [x0, y0, x1 - x0, y1 - y0]
        smallImage = item['smallImage']
        score = item.get('score', 1)
        trackId = item.get('trackId')
        print(classId, model_type)
        if classId == 1 and score*100 > threshold:
            weapon_obj_list.append({
                "bbox": bbox,
                "score": score,
                "object_image": smallImage,
                "label": "dgrs_armed",
                "track_id": trackId,
                "smallImage": smallImage
            })

    # 是否有多个持械对象
    frame_count = redis_DATA.hget('{}_{}'.format(camera_id, event_type), '{}_weapon_frame'.format(camera_id))
    if not frame_count:
        frame_count = 1
    else:
        frame_count = int(frame_count)
        frame_count += 1
    if len(weapon_obj_list) > 1:
        for weapon_obj in weapon_obj_list:
            track_id = weapon_obj['track_id']
            alarm_detail.append({
                "objectId": "{}_{}_{}".format(camera_id, track_id, event_type),
                "alarm_action_type": event_type,
                "bbox": weapon_obj['bbox'],
                "score": weapon_obj['score'],
                "object_image": weapon_obj['smallImage'],
                "eventType": event_type,
                "alarm_message": "持刀持械告警"
            })
    # 只有一个持械对象
    elif len(weapon_obj_list) == 1:
        for weapon_obj in weapon_obj_list:
            track_id = weapon_obj['track_id']

            alarm_count = redis_DATA.hget('{}_{}'.format(camera_id, event_type), '{}_weapon'.format(camera_id))

            if not alarm_count:
                alarm_count = 1
            else:
                alarm_count = int(alarm_count)
                alarm_count += 1
            print(f"单个持械对象，这是第{alarm_count}帧")
            redis_DATA.hset('{}_{}'.format(camera_id, event_type), '{}_weapon'.format(camera_id), alarm_count)
            if int(alarm_count) == 3:
                alarm_detail.append({
                    "objectId": "{}_{}_{}".format(camera_id, track_id, event_type),
                    "alarm_action_type": event_type,
                    "bbox": weapon_obj['bbox'],
                    "score": weapon_obj['score'],
                    "object_image": weapon_obj['smallImage'],
                    "eventType": event_type,
                    "alarm_message": "持刀持械告警"
                })
    if frame_count >= 10 or alarm_detail:
        frame_count = 0
        redis_DATA.hset('{}_{}'.format(camera_id, event_type), '{}_weapon_frame'.format(camera_id), frame_count)
        alarm_count = 0
        redis_DATA.hset('{}_{}'.format(camera_id, event_type), '{}_weapon'.format(camera_id), alarm_count)
    else:
        redis_DATA.hset('{}_{}'.format(camera_id, event_type), '{}_weapon_frame'.format(camera_id), frame_count)


    return alarm_detail
