from AlgorithmAbility.CallingAbility import calling_handle
from AlgorithmAbility.CarVendorAbility import car_vendor_handle
from AlgorithmAbility.CityWastebinAbility import city_waste_bin_handle

from AlgorithmAbility.FaceAbility import face_handle
from AlgorithmAbility.FallDownAbility import falldown_handle
from AlgorithmAbility.FightingAbility import fighting_handle
from AlgorithmAbility.FireAbility import fire_handle
from AlgorithmAbility.GarbageDetectAbility import garbage_detect_handle
from AlgorithmAbility.GathersAbility import gathers_handle
from AlgorithmAbility.LeavingPostAbility import leaving_post_handle
from AlgorithmAbility.OccupyFirelaneAbility import occupy_firelane_handle
from AlgorithmAbility.ParkVehicleAbility import park_vehicle_handle
from AlgorithmAbility.RiverFloatsAbility import river_floats_handle
from AlgorithmAbility.SmogAbility import smog_handle
from AlgorithmAbility.SmokingAbility import smoking_handle
from AlgorithmAbility.VehicleAbility import vehicle_handle
from AlgorithmAbility.WeaponsAbility import weapons_handle
from AlgorithmAbility.CrossBorderAbility import cross_borer_handle
from AlgorithmAbility.IntrusionAbility import intrusion_handle
from AlgorithmAbility.MaskAbility import mask_handle
from AlgorithmAbility.SafetyHatAbility import safety_hat_handle


def alg_manager_handle(data, task_args):
    event_type = task_args.get('event_type')
    alarm_detail = None
    print(event_type)
    if event_type == '1001':
        # todo
        # 人脸静态检索
        pass
    elif event_type == '2001':
        # todo
        # 机动车结构化
        pass
    elif event_type == '3001':
        # 打架斗殴
        alarm_detail = fighting_handle(data, task_args)

    elif event_type == '3002':
        # 人员跌倒
        alarm_detail = falldown_handle(data, task_args)

    elif event_type == '4001':
        # 人员越线检测
        alarm_detail = cross_borer_handle(data, task_args)

    elif event_type == '4002':
        # 区域入侵
        alarm_detail = intrusion_handle(data, task_args)
    elif event_type == '4003':
        # 持刀持械
        alarm_detail = weapons_handle(data, task_args)
    elif event_type == '4004':

        # 人员离岗
        alarm_detail = leaving_post_handle(data, task_args)
    elif event_type == '4005':
        # 人员聚集
        alarm_detail = gathers_handle(data, task_args)
    elif event_type == '4006':
        # 车辆违停
        alarm_detail = park_vehicle_handle(data, task_args)
    elif event_type == '4007':
        # 消防通道占用
        alarm_detail = occupy_firelane_handle(data, task_args)
    elif event_type == '5001':
        # 口罩识别
        alarm_detail = mask_handle(data, task_args)
    elif event_type == '5002':
        # 吸烟
        alarm_detail = smoking_handle(data, task_args)
    elif event_type == '5003':
        # 打电话
        alarm_detail = calling_handle(data, task_args)
    elif event_type == '5004':
        # 安全帽识别
        alarm_detail = safety_hat_handle(data, task_args)

    elif event_type == '7100':
        # 占道经营
        alarm_detail = car_vendor_handle(data, task_args)
    elif event_type == '7101':
        # 垃圾满溢
        alarm_detail = city_waste_bin_handle(data, task_args)
    elif event_type == '7102':
        # 暴露垃圾
        alarm_detail = garbage_detect_handle(data, task_args)
    elif event_type == '7103':
        # 河道漂浮
        alarm_detail = river_floats_handle(data, task_args)
    elif event_type == '7104':
        # 烟雾检测
        alarm_detail = smog_handle(data, task_args)

    elif event_type == '7105':
        # 火焰检测
        alarm_detail = fire_handle(data, task_args)

    elif event_type == '8001':
        # 人车非
        alarm_detail = vehicle_handle(data, task_args)
    elif event_type == '9001':
        # 人脸
        alarm_detail = face_handle(data, task_args)


    return alarm_detail
