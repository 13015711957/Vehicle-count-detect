import uuid

'''
人车非
'''


def vehicle_handle(data, task_args):
    alarm_detail = []
    event_type = task_args.get('event_type')
    detection = data['detections']
    event_config = task_args.get('event_config')
    sub_event_type = event_config.get('sub_event_type', None)
    for item in detection:
        x0, y0, x1, y1 = item['box']
        bbox = [x0, y0, x1 - x0, y1 - y0]
        smallImage = item['smallImage']
        attrs = item['attrs']
        attribute = []
        score = 0.8
        for attr in attrs:
            classId = int(attr['classId'])
            temp_score = attr['score']
            className = attr['className']
            value = classId
            if className == 'VehicleClass':
                event_type = str(classId)
                score = temp_score
            if className == 'LicensePlateRecognition':
                value = attr.get('resultStr', '')
            attribute.append({'key': className, 'value': value})

        if event_type == '8001':
            event_type = '80011'
        if sub_event_type and (event_type not in sub_event_type):
            print(sub_event_type)
            continue

        alarm_detail.append({
            "objectId": str(uuid.uuid4()),
            "alarm_action_type": event_type,
            "score": score,
            "bbox": bbox,
            "object_image": smallImage,
            "eventType": event_type,
            "alarm_message": '人车非解析',
            'attribute': attribute
        })
    return alarm_detail


if __name__ == '__main__':
    sub_event_type = ['80010', '80011']
    s = ['80010', '80011', '80012', '80010']
    for event_type in s:

        if sub_event_type and (event_type not in sub_event_type):
            continue
        print(event_type)
