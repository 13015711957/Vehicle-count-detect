#!/usr/bin/env python3

################################################################################
# Copyright (c) 2020, NVIDIA CORPORATION. All rights reserved.
#
# Permission is hereby granted, free of charge, to any person obtaining a
# copy of this software and associated documentation files (the "Software"),
# to deal in the Software without restriction, including without limitation
# the rights to use, copy, modify, merge, publish, distribute, sublicense,
# and/or sell copies of the Software, and to permit persons to whom the
# Software is furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
# DEALINGS IN THE SOFTWARE.
################################################################################

import sys
import numpy as np
import cv2

sys.path.append('../')
from common.utils import long_to_int
import gi

gi.require_version('Gst', '1.0')
gi.require_version('GstRtspServer', '1.0')
from gi.repository import GObject, Gst, GstRtspServer
from common.is_aarch_64 import is_aarch64
import configparser
from multiprocessing import Queue, Process
import pyds
import random

fps_streams = {}
MAX_DISPLAY_LEN = 64
MUXER_OUTPUT_WIDTH = 1920
MUXER_OUTPUT_HEIGHT = 1080
MUXER_BATCH_TIMEOUT_USEC = 4000000
TILED_OUTPUT_WIDTH = 1920
TILED_OUTPUT_HEIGHT = 1080
GST_CAPS_FEATURES_NVMM = "memory:NVMM"
OSD_PROCESS_MODE = 0
OSD_DISPLAY_TEXT = 0

import redis
import time
config = configparser.ConfigParser()
config.read('/opt/config.ini')
Task_host = config.get('REDIS', 'host')
Task_port = int(config.get('REDIS', 'port'))
Task_password = config.get('REDIS', 'password')
TASK_NAME = 'TASK_VIDEOSHOW'
TASK_DB = int(config.get('REDIS', 'task_db'))
PARME_DB = int(config.get('REDIS', 'param_db'))
protect_uri = 'file:///opt/nvidia/deepstream/deepstream-5.0/samples/streams/sample_1080p_h265.mp4'
#protect_uri = 'file:///opt/videos/0603.mp4'

MAX_NUM_SOURCES = 200
#frame_sent_rate
CAP_RATE = int(config.get('FRAME', 'cap'))
drop_frame_interval = int(config.get('FRAME', 'drop'))

TASK_DICT = {0: 0}
LAST_KEY_DICT = {}
QUEUE_DICT = {}
g_num_sources = 0
g_source_id_list = [0] * MAX_NUM_SOURCES
g_eos_list = [False] * MAX_NUM_SOURCES
g_source_enabled = [False] * MAX_NUM_SOURCES
g_source_bin_list = [None] * MAX_NUM_SOURCES


loop = None
pipeline = None
streammux = None



image_list = Queue()


class_names = ['person']

VIDEO_INFO = {}

def loop_to_redis(queue):
    global VIDEO_INFO

    try:

        TASK_pool = redis.ConnectionPool(host=Task_host, port=Task_port, decode_responses=True, db=TASK_DB,
                                         password=Task_password)
        redis_Task = redis.StrictRedis(connection_pool=TASK_pool)

        Param_pool = redis.ConnectionPool(host=Task_host, port=Task_port, decode_responses=True, db=PARME_DB,
                                          password=Task_password)
        redis_Param = redis.StrictRedis(connection_pool=Param_pool)
    except:
        import traceback
        traceback.print_exc()
        print('redis connect fail....')

    while True:

        try:

            try:
                print('Queue  size : {}'.format(queue.qsize()))
                queue_data = queue.get()
            except Exception as e:
                print(e)
                queue_data = None

            if queue_data is None:
                print('wait~~~~~~~~~~~~~!!!!!!!!!!!!!!!!!!!!!!')
                time.sleep(0.1)
                continue

            img_key, n_frame, result,lask_key,Task_queue = queue_data

            result['img_width'] = list(n_frame.shape)[1]
            result['img_height'] = list(n_frame.shape)[0]
            result['timestamp'] = int(time.time()*1000)
            import base64


            image_base64 = cv2.imencode('.jpg', n_frame)[1].tostring()
            image_base64 = base64.b64encode(image_base64)
            image_base64 = str(image_base64)[2:-1]
            pic_str = image_base64

            # pic_str = pic_str.decode()
            print(len(pic_str))
            import json

            task_key = '{}#{}'.format(lask_key,img_key)
            #result['img_key'] = task_key


            result = json.dumps(result)
            print(result, n_frame.shape)

            # to_redis

            redis_Task.set(img_key, pic_str)
            redis_Task.expire(img_key, 2 * 60)
            redis_Param.set(img_key, result)
            redis_Param.expire(img_key, 2 * 60)




            redis_Task.rpush(Task_queue, task_key)

            print('to redis success ',Task_queue)
        except:
            import traceback
            traceback.print_exc()


# tiler_sink_pad_buffer_probe  will extract metadata received on OSD sink pad
# and update params for drawing rectangle, object information etc.
def tiler_src_pad_buffer_probe(pad, info, u_data):
    global image_list,TASK_DICT,LAST_KEY_DICT
    tttt = time.time()
    frame_number = 0
    num_rects = 0
    gst_buffer = info.get_buffer()
    if not gst_buffer:
        print("Unable to get GstBuffer ")
        return
    #print('=======================')
    # Retrieve batch metadata from the gst_buffer
    # Note that pyds.gst_buffer_get_nvds_batch_meta() expects the
    # C address of gst_buffer as input, which is obtained with hash(gst_buffer)
    batch_meta = pyds.gst_buffer_get_nvds_batch_meta(hash(gst_buffer))
    l_frame = batch_meta.frame_meta_list
    while l_frame is not None:
        try:
            # Note that l_frame.data needs a cast to pyds.NvDsFrameMeta
            # The casting is done by pyds.NvDsFrameMeta.cast()
            # The casting also keeps ownership of the underlying memory
            # in the C code, so the Python garbage collector will leave
            # it alone.
            frame_meta = pyds.NvDsFrameMeta.cast(l_frame.data)
        except StopIteration:
            break

        frame_number = frame_meta.frame_num
        num_rects = frame_meta.num_obj_meta
        l_obj = frame_meta.obj_meta_list

        result = {}
        result['frame_id'] = frame_number


        result['source_id'] = frame_meta.source_id

        result['camera_id'] = TASK_DICT.get(frame_meta.source_id,-1)


        base_config = VIDEO_INFO[result['source_id']]
        result.update(base_config)

        img_key = '{}_{}'.format(result['camera_id'], frame_number)
        result['img_key'] = img_key

        result['data'] = []

        while l_obj is not None:
            try:
                # Casting l_obj.data to pyds.NvDsObjectMeta
                obj_meta = pyds.NvDsObjectMeta.cast(l_obj.data)
            except StopIteration:
                break

            r = {}

            r['bbox'] = [0,0,0,0]
            r['bbox'][0] = int(obj_meta.rect_params.left)
            r['bbox'][1] = int(obj_meta.rect_params.top)
            r['bbox'][2] = int(obj_meta.rect_params.width)
            r['bbox'][3] = int(obj_meta.rect_params.height)

            r['track_id'] = long_to_int(obj_meta.object_id)
            r['class_type'] = class_names[obj_meta.class_id]
            r['score'] = obj_meta.confidence

            result['data'].append(r)
            #print(result)
            classfiter_meta = obj_meta

            try:
                l_obj = l_obj.next
            except StopIteration:
                break

        if frame_number % CAP_RATE == 0:
            try:
                n_frame = pyds.get_nvds_buf_surface(hash(gst_buffer), frame_meta.batch_id)
                # convert python array into numpy array format in the copy mode.
                frame_copy = np.array(n_frame, copy=True, order='C')
                # convert the array into cv2 default color format
                frame_copy = cv2.cvtColor(frame_copy, cv2.COLOR_RGBA2BGR)

                #del img_key
                lask_key = LAST_KEY_DICT.get(result['camera_id'],img_key)

                Task_queue = QUEUE_DICT.get(result['source_id'],TASK_NAME)
                LAST_KEY_DICT[result['camera_id']] = img_key

                image_list.put((img_key, frame_copy, result,lask_key,Task_queue))



            except Exception as e:
                print(e)

        try:
            l_frame = l_frame.next
        except StopIteration:
            break
    #print('-------------{}'.format(time.time() - tttt))
    return Gst.PadProbeReturn.OK


def decodebin_child_added(child_proxy, Object, name, user_data):
    print("Decodebin child added:", name, "\n")
    if (name.find("decodebin") != -1):
        Object.connect("child-added", decodebin_child_added, user_data)
    if (name.find("nvv4l2decoder") != -1):

        Object.set_property("drop-frame-interval", drop_frame_interval)
        Object.set_property("num-extra-surfaces", 0)


def cb_newpad(decodebin, pad, data):
    global streammux,VIDEO_INFO
    print("In cb_newpad\n")
    caps = pad.get_current_caps()
    gststruct = caps.get_structure(0)
    gstname = gststruct.get_name()
    
    # Need to check if the pad created by the decodebin is for video and not
    # audio.
    print("gstname=", gstname)
    if (gstname.find("video") != -1):
        source_id = data
        pad_name = "sink_%u" % source_id
        print(pad_name)
        VIDEO_INFO[source_id] = {'base_height':gststruct['height'],'base_width':gststruct['width'],'base_fps':float(gststruct['framerate'])}

        print(source_id,pad_name,VIDEO_INFO[source_id])


        # Get a sink pad from the streammux, link to decodebin
        sinkpad = streammux.get_request_pad(pad_name)
        if pad.link(sinkpad) == Gst.PadLinkReturn.OK:
            print("Decodebin linked to pipeline")
        else:
            sys.stderr.write("Failed to link decodebin to pipeline\n")
        print('paddddddd..................................................',caps)

def create_uridecode_bin(index, uri):
    global g_source_id_list
    print("Creating uridecodebin for [%s]" % uri)

    # Create a source GstBin to abstract this bin's content from the rest of the
    # pipeline
    g_source_id_list[index] = index
    bin_name = "source-bin-{}".format(int(time.time()*1000))
    print(bin_name)

    # Source element for reading from the uri.
    # We will use decodebin and let it figure out the container format of the
    # stream and the codec and plug the appropriate demux and decode plugins.
    bin = Gst.ElementFactory.make("uridecodebin", bin_name)
    if not bin:
        sys.stderr.write(" Unable to create uri decode bin \n")
    # We set the input uri to the source element
    bin.set_property("uri", uri)
    # Connect to the "pad-added" signal of the decodebin which generates a
    # callback once a new pad for raw data has been created by the decodebin
    bin.connect("pad-added", cb_newpad, g_source_id_list[index])
    bin.connect("child-added", decodebin_child_added, g_source_id_list[index])

    # Set status of the source to enabled
    g_source_enabled[index] = True

    return bin


def stop_release_source(source_id):
    global g_num_sources
    global g_source_bin_list
    global streammux
    global pipeline

    # Attempt to change status of source to be released
    state_return = g_source_bin_list[source_id].set_state(Gst.State.NULL)
    print('set source bin state {} {}'.format(source_id,state_return),g_source_bin_list[source_id].get_state(Gst.CLOCK_TIME_NONE))
    if state_return == Gst.StateChangeReturn.SUCCESS:
        print("STATE CHANGE SUCCESS\n")
        pad_name = "sink_%u" % source_id
        print(pad_name)
        # Retrieve sink pad to be released
        sinkpad = streammux.get_static_pad(pad_name)
        #过滤sourcebin创建失败
        if sinkpad is not None:
            # Send flush stop event to the sink pad, then release from the streammux
            sinkpad.send_event(Gst.Event.new_flush_stop(False))
            streammux.release_request_pad(sinkpad)
            print("STATE CHANGE SUCCESS\n")
        # Remove the source bin from the pipeline
        pipeline.remove(g_source_bin_list[source_id])
        source_id -= 1

    elif state_return == Gst.StateChangeReturn.FAILURE:
        print("STATE CHANGE FAILURE\n")

    elif state_return == Gst.StateChangeReturn.ASYNC:
        state_return = g_source_bin_list[source_id].get_state(Gst.CLOCK_TIME_NONE)
        pad_name = "sink_%u" % source_id
        print(pad_name)
        sinkpad = streammux.get_static_pad(pad_name)
        sinkpad.send_event(Gst.Event.new_flush_stop(False))
        streammux.release_request_pad(sinkpad)
        print("STATE CHANGE ASYNC\n")
        pipeline.remove(g_source_bin_list[source_id])
        source_id -= 1


def delete_sources(task_id):
    global loop
    global g_num_sources
    global g_eos_list
    global g_source_enabled
    global TASK_DICT


    print('flush.....')
    #flush_sources()

    del_source_id = -1

    for k,v  in TASK_DICT.items():
        if v==task_id:
            del_source_id=k

    if del_source_id==-1:
        print('can not find task {}'.format(task_id))
        return False

    print(del_source_id,g_source_enabled[del_source_id]) 
    if True:
        # Disable the source
        g_source_enabled[del_source_id] = False
        # Release the source
        print("Calling Stop %d " % del_source_id)
        stop_release_source(del_source_id)

    delete_task_info(del_source_id)

    return True

def delete_task_info(source_id):
    global TASK_DICT
    global g_num_sources
    global g_source_id_list
    global g_eos_list
    global g_source_enabled
    global g_source_bin_list

    if source_id in TASK_DICT:
        del TASK_DICT[source_id]

    g_num_sources -=1
    g_source_id_list[source_id]=0
    g_eos_list[source_id]=False
    g_source_enabled[source_id]=False
    g_source_bin_list[source_id]=None


    #send finish
    print('delete source id info : {}'.format(source_id))


def flush_sources(clear=False):


    print('starting flush_sources...........')

    global loop
    global g_num_sources
    global g_eos_list
    global g_source_enabled
    global TASK_DICT
    global g_source_bin_list
    global pipeline
    if not clear:
        all_state = [Gst.State.PLAYING,Gst.State.PAUSED,Gst.State.READY]
    else:
        time.sleep(5)
        all_state = [Gst.State.PLAYING,Gst.State.READY]
    print(all_state,clear)
    # First delete sources that have reached end of stream
    for source_id in range(MAX_NUM_SOURCES):
        if (g_eos_list[source_id] and g_source_enabled[source_id]):
            g_source_enabled[source_id] = False
            stop_release_source(source_id)
            delete_task_info(source_id)
   
    print('g_num_sources: {}  g_source_enabled :{} task_dict {}'.format(g_num_sources,g_source_enabled,TASK_DICT))
    for source_id,source_bin in enumerate(g_source_bin_list):
        
        if source_bin is None:
            continue
        print('doning-----------',source_id,source_bin,source_bin.get_state(Gst.CLOCK_TIME_NONE).state)
        if source_bin.get_state(Gst.CLOCK_TIME_NONE).state not in all_state:
            #意外不行了
            print('kill error source bin',source_id,source_bin.get_state(Gst.CLOCK_TIME_NONE).state)
            g_source_enabled[source_id] = False
            stop_release_source(source_id)
            delete_task_info(source_id)

    pipeline.set_state(Gst.State.PLAYING)
    print('ending flush source.......')




def flush_loop():
    while True:
        time.sleep(60)
        try:
            flush_sources(True)
        except:
            import traceback
            traceback.print_exc()
def add_sources(task_id, uri,task_queue):
    global g_num_sources
    global g_source_enabled
    global g_source_bin_list
    global TASK_DICT,QUEUE_DICT

    print('flush...')
    #flush_sources()

    for k,v in TASK_DICT.items():
        if v==task_id:
            return False

    # Randomly select an un-enabled source to add
    source_id = random.randrange(0, MAX_NUM_SOURCES)
    while (g_source_enabled[source_id]):
        source_id = random.randrange(0, MAX_NUM_SOURCES)

    # Enable the source
    g_source_enabled[source_id] = True

    print("Calling Start {} {}".format(task_id,source_id))

    # Create a uridecode bin with the chosen source id
    source_bin = create_uridecode_bin(source_id, uri)

    TASK_DICT[source_id] = task_id
    QUEUE_DICT[source_id] = task_queue
    
    if (not source_bin):
        sys.stderr.write("Failed to create source bin. Exiting.")
        #exit(1)

    # Add source bin to our list and to pipeline
    g_source_bin_list[source_id] = source_bin
    pipeline.add(source_bin)

    # Set state of source bin to playing
    state_return = g_source_bin_list[source_id].set_state(Gst.State.PLAYING)

    if state_return == Gst.StateChangeReturn.SUCCESS:
        print("STATE CHANGE SUCCESS\n")
        source_id += 1

    elif state_return == Gst.StateChangeReturn.FAILURE:
        print("STATE CHANGE FAILURE\n")
        flush_sources()
        return False

    elif state_return == Gst.StateChangeReturn.ASYNC:
        state_return = g_source_bin_list[source_id].get_state(Gst.CLOCK_TIME_NONE)
        source_id += 1

    elif state_return == Gst.StateChangeReturn.NO_PREROLL:
        print("STATE CHANGE NO PREROLL\n")
        #flush_sources()
        #return False


    t_i = 0
    flag = False
    while True:
        time.sleep(2)
        t_i+=1
        if source_bin.get_state(Gst.CLOCK_TIME_NONE).state in [Gst.State.PLAYING]:
            flag = True
            break
        if t_i>10:
            break

    g_num_sources += 1

    return flag


def bus_call(bus, message, loop):
    global g_eos_list
    t = message.type
    if t == Gst.MessageType.EOS:
        sys.stdout.write("End-of-stream\n")
        # loop.quit()
    elif t == Gst.MessageType.WARNING:
        err, debug = message.parse_warning()
        sys.stderr.write("Warning: %s: %s\n" % (err, debug))
    elif t == Gst.MessageType.ERROR:
        err, debug = message.parse_error()
        sys.stderr.write("Error: %s: %s\n" % (err, debug))
        # loop.quit()
    elif t == Gst.MessageType.ELEMENT:
        struct = message.get_structure()
        # Check for stream-eos message
        if struct is not None and struct.has_name("stream-eos"):
            parsed, stream_id = struct.get_uint("stream-id")
            if parsed:
                # Set eos status of stream to True, to be deleted in delete-sources
                print("Got EOS from stream %d" % stream_id)
                g_eos_list[stream_id] = True
    return True


def run():
    global g_num_sources
    global g_source_bin_list
    global uri

    global loop
    global pipeline
    global streammux

    # Standard GStreamer initialization
    GObject.threads_init()
    Gst.init(None)

    # Create gstreamer elements
    # Create Pipeline element that will form a connection of other elements
    print("Creating Pipeline \n ")
    pipeline = Gst.Pipeline()
    if not pipeline:
        sys.stderr.write(" Unable to create Pipeline \n")


    # Create nvstreammux instance to form batches from one or more sources.
    streammux = Gst.ElementFactory.make("nvstreammux", "Stream-muxer")
    if not streammux:
        sys.stderr.write(" Unable to create NvStreamMux \n")

    # Create first source bin and add to pipeline
    source_bin = create_uridecode_bin(0, protect_uri)
    print(source_bin)
    g_source_bin_list[0] = source_bin
    pipeline.add(source_bin)
    g_num_sources = 1


    streammux.set_property('live-source', 1)
    streammux.set_property('width', MUXER_OUTPUT_WIDTH)
    streammux.set_property('height', MUXER_OUTPUT_HEIGHT)
    streammux.set_property('batch-size', 1)
    streammux.set_property('batched-push-timeout', 4000000)


    ##################模型#######################################
    
    # Use nvinfer to run inferencing on decoder's output,
    # behaviour of inferencing is set through config file
    pgie = Gst.ElementFactory.make("nvinfer", "primary-inference")
    if not pgie:
        sys.stderr.write(" Unable to create pgie \n")
    pgie.set_property('config-file-path', "config_infer_primary_yoloV5.txt")


    tracker = Gst.ElementFactory.make("nvtracker", "tracker")

    # Set properties of tracker
    config = configparser.ConfigParser()
    config.read('dstest2_tracker_config.txt')
    config.sections()

    for key in config['tracker']:
        if key == 'tracker-width':
            tracker_width = config.getint('tracker', key)
            tracker.set_property('tracker-width', tracker_width)
        if key == 'tracker-height':
            tracker_height = config.getint('tracker', key)
            tracker.set_property('tracker-height', tracker_height)
        if key == 'gpu-id':
            tracker_gpu_id = config.getint('tracker', key)
            tracker.set_property('gpu_id', tracker_gpu_id)
        if key == 'll-lib-file':
            tracker_ll_lib_file = config.get('tracker', key)
            tracker.set_property('ll-lib-file', tracker_ll_lib_file)
        if key == 'll-config-file':
            tracker_ll_config_file = config.get('tracker', key)
            tracker.set_property('ll-config-file', tracker_ll_config_file)
        if key == 'enable-batch-process':
            tracker_enable_batch_process = config.getint('tracker', key)
            tracker.set_property('enable_batch_process', tracker_enable_batch_process)
        if key == 'enable-past-frame':
            tracker_enable_past_frame = config.getint('tracker', key)
            tracker.set_property('enable_past_frame', tracker_enable_past_frame)

   

    # Use convertor to convert from NV12 to RGBA as required by nvosd
    nvvidconv = Gst.ElementFactory.make("nvvideoconvert", "convertor")
    if not nvvidconv:
        sys.stderr.write(" Unable to create nvvidconv \n")


    # Create OSD to draw on the converted RGBA buffer
    nvosd = Gst.ElementFactory.make("nvdsosd", "onscreendisplay")
    if not nvosd:
        sys.stderr.write(" Unable to create nvosd \n")
    nvvidconv_postosd = Gst.ElementFactory.make("nvvideoconvert", "convertor_postosd")
    if not nvvidconv_postosd:
        sys.stderr.write(" Unable to create nvvidconv_postosd \n")

    queue1 = Gst.ElementFactory.make("queue", "queue1")

    sink0 = Gst.ElementFactory.make("fakesink", "fakesink")



    print("Adding elements to Pipeline \n")
    pipeline.add(streammux)
    pipeline.add(pgie)
    pipeline.add(tracker)
    pipeline.add(queue1)
    pipeline.add(nvvidconv)
    pipeline.add(nvosd)
    pipeline.add(sink0)

    if not is_aarch64():
        # Use CUDA unified memory in the pipeline so frames
        # can be easily accessed on CPU in Python.
        print('cpu   ')
        mem_type = int(pyds.NVBUF_MEM_CUDA_UNIFIED)
        # streammux.set_property("nvbuf-memory-type", mem_type)
        nvvidconv.set_property("nvbuf-memory-type", mem_type)


    streammux.link(pgie)
    pgie.link(tracker)
    tracker.link(nvvidconv)
    queue1.link(nvvidconv)
    nvvidconv.link(nvosd)
    nvosd.link(sink0)

    # create an event loop and feed gstreamer bus mesages to it
    loop = GObject.MainLoop()
    bus = pipeline.get_bus()
    bus.add_signal_watch()
    bus.connect("message", bus_call, loop)

    # Lets add probe to get informed of the meta data generated, we add probe to
    # the sink pad of the osd element, since by that time, the buffer would have
    # had got all the metadata.
    osdsinkpad = nvosd.get_static_pad("sink")
    if not osdsinkpad:
        sys.stderr.write(" Unable to get sink pad of nvosd \n")

    osdsinkpad.add_probe(Gst.PadProbeType.BUFFER, tiler_src_pad_buffer_probe, 0)

    # start play back and listen to events
    print("Starting pipeline \n")
    pipeline.set_state(Gst.State.PLAYING)
    try:
        loop.run()
    except:
        pass
    # cleanup
    pipeline.set_state(Gst.State.NULL)
    print("ALL PIPELINE STOP  ..........")
    sys.exit(0)








#################################################################服务部分##################

import json

from flask import Flask, jsonify

from flask import request

app = Flask(__name__)

@app.route('/add_source', methods=['POST'])
def create_task():
    print(request.get_data())
    data = request.get_data(as_text=True)
    data = json.loads(data)
    task_id = data['source_id']
    rtsp_uri = data['url']
    task_queue = data['task_queue']

    delete_sources(task_id)
    add_state = add_sources(task_id,uri=rtsp_uri,task_queue=task_queue)


    if add_state:
        result = {
           'code': 10000,
           'task_id':task_id,
        }
    else:
        result = {
            'code': 10903,
            'task_id': task_id,
        }
    print(result,rtsp_uri)
    return jsonify(result)


@app.route('/delete_task', methods=['POST'])
def delete_task():
    print(request.json)

    task_id = request.json['source_id']

    delete_state = delete_sources(task_id)

    if delete_state:
        result = {
            'code': 10000,
            'task_id': task_id,
        }
    else:
        result = {
            'code': 10903,
            'task_id': task_id,
        }
    print(result)
    return jsonify(result)



def init():

    print('============================start init==================================')


    import threading
    import time

    t_main = threading.Thread(target=run)
    t_main.start()

    time.sleep(1)

    t_flush = threading.Thread(target=flush_loop)
    t_flush.start()
    

    
    for i in range(3):
        tt = Process(target=loop_to_redis, args=(image_list,))
        tt.start()
  
    time.sleep(5)
    delete_sources(0)


if __name__ == '__main__':

    import os
    os.system("rm -rf /opt/nvidia/deepstream/deepstream-5.0/sources/deepstream_python_apps/apps/deepstream-yolov5-c/core.*")

    init()


    print('============================start working==================================')


    app.run('0.0.0.0',port=8000)
