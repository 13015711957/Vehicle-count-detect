# -*- encoding: utf-8 -*-
"""
@Project : textcnn_my
@FileName: send
@Time    : 2021/2/19 14:05
@Author  : chenych
@Desc    :
"""
import json
from Common.RabbitMQClient.mq_connect_util import MQ_connect


def common_to_mq(where, host, username, pwd, queue, port, args_dict):
    MQ_client = MQ_connect(host=host, username=username, pwd=pwd, queue=queue, port=port)
    flag = False
    try:
        channel = MQ_client.get_channel()
        channel.basic_publish(exchange='',
                              routing_key=queue,
                              body=json.dumps(args_dict))
        channel.close()
        flag = True
    except:
        MQ_client.reconnect()
        channel = MQ_client.get_channel()
        channel.basic_publish(exchange='',
                              routing_key=queue,
                              body=json.dumps(args_dict))
        channel.close()
        flag = True
    finally:
        if flag:
            print("{} to_mq successfully".format(where))
        else:
            print("{} to_mq fault".format(where))
    return flag
