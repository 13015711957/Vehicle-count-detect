# -*- coding: utf-8 -*-

'''
@project : SmartHomeVideo
@FileName: mq_connect_util
@Author  :linych 
@Time    :2021/3/6 17:45
@Desc  : 
'''

import pika


class MQ_connect():

    def __init__(self, host, username, pwd, queue, port):

        self.host = host
        self.port = port
        self.username = username
        self.pwd = pwd

        self.queue = queue

        self.user_pwd = pika.PlainCredentials(username, pwd)

        # 连接
        self.connection = pika.BlockingConnection(pika.ConnectionParameters(
            host=self.host, credentials=self.user_pwd, port=self.port, heartbeat=0))

        # 建立会话
        self.channel = self.connection.channel()

        # 声明RPC请求队列
        self.channel.queue_declare(queue=self.queue)

    def reconnect(self):

        print('pika  reconnect......')

        try:

            self.connection = pika.BlockingConnection(pika.ConnectionParameters(
                host=self.host, credentials=self.user_pwd, port=self.port, heartbeat=0))

            # 建立会话
            self.channel = self.connection.channel()
            # 声明RPC请求队列
            self.channel.queue_declare(queue=self.queue)

        except Exception as e:
            print('reconnect error {}...........'.format(e))

    def get_channel(self):

        retry = 0
        while retry < 3:
            try:
                if self.connection.is_open and self.channel.is_open:
                    return self.channel
                else:
                    retry += 1
                    self.reconnect()
            except Exception as e:
                print('lost connnect..')
                retry += 1
                self.reconnect()

        print('pika connect error.....')
        return None


if __name__ == '__main__':
    mq = MQ_connect(host='59.53.87.129', username='admin', pwd='mYrbt@#2020w', queue='Test', port=8082)
    print(mq)
