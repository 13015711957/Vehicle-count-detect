# -*- coding: utf-8 -*-

'''
@project : rabbitmq_demo
@FileName: rpc_demo
@Author  :linych
@Time    :2021/2/22 15:57
@Desc  :
'''

import pika

# 建立连接，服务器地址为localhost，可指定ip地址
connection = pika.BlockingConnection(pika.ConnectionParameters(
        host='192.168.35.226'))

# 建立会话
channel = connection.channel()

# 声明RPC请求队列
channel.queue_declare(queue='rpc_queue')

# 数据处理方法
def fib(n):
    return n*2

# 对RPC请求队列中的请求进行处理
def on_request(ch, method, props, body):
    n = int(body)

    print(" [.] fib(%s)" % n)

    # 调用数据处理方法
    response = fib(n)

    # 将处理结果(响应)发送到回调队列
    ch.basic_publish(exchange='',
                     routing_key=props.reply_to,
                     properties=pika.BasicProperties(correlation_id = \
                                                         props.correlation_id),
                     body=str(response))
    ch.basic_ack(delivery_tag = method.delivery_tag)

# 负载均衡，同一时刻发送给该服务器的请求不超过一个
channel.basic_qos(prefetch_count=1)

channel.basic_consume(on_request, queue='rpc_queue')

print(" [x] Awaiting RPC requests")
channel.start_consuming()
