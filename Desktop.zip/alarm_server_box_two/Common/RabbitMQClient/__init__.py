# -*- coding: utf-8 -*-

'''
@project : SmartHome_Video
@FileName: __init__.py
@Author  :linych 
@Time    :2021/2/18 20:36
@Desc  : 
'''