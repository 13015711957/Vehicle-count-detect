# -*- coding: utf-8 -*-

'''
@project : SmartHomeVideo
@FileName: mq_rpc
@Author  :linych
@Time    :2021/2/22 15:33
@Desc  :
'''

import asyncio
import random
import uuid
from aio_pika import connect, IncomingMessage, Message
import time
import os


class RabbitMQProductClient:
    loop = asyncio.get_event_loop()
    connection = None
    host = None
    port = None
    login = None
    password = None
    queue = None

    channl_list = None

    futures = {}

    loop_lock = asyncio.Lock(loop=loop)
    connect_lock = asyncio.Lock(loop=loop)

    '''
    async def init_loop(self):

        if RabbitMQProductClient.loop is None:
            async with RabbitMQProductClient.loop_lock:
                if RabbitMQProductClient.loop is None:
                    RabbitMQProductClient.loop = asyncio.get_event_loop()
    '''

    async def init_connect(self):

        if RabbitMQProductClient.loop is None or RabbitMQProductClient.channl_list is None:
            async with RabbitMQProductClient.connect_lock:
                if RabbitMQProductClient.loop is None or RabbitMQProductClient.channl_list is None:

                    # print('connect....................')
                    RabbitMQProductClient.connection = await connect(
                        host=self.host, port=self.port, loop=RabbitMQProductClient.loop, login=self.login,
                        password=self.password
                    )
                    print('connect finish')
                    channel_list = []
                    for i in range(2):
                        channel = await self.connection.channel()
                        channel_list.append(channel)
                    RabbitMQProductClient.channl_list = channel_list
                    print('channel finish ')

    async def re_connect(self):

        async with RabbitMQProductClient.connect_lock:
            print('connect....................')
            RabbitMQProductClient.connection = await connect(
                host=self.host, port=self.port, loop=RabbitMQProductClient.loop, login=self.login,
                password=self.password
            )
            print('connect finish')
            channel_list = []
            for i in range(2):
                channel = await self.connection.channel()
                channel_list.append(channel)

            RabbitMQProductClient.channl_list = channel_list
            print('channel finish ')

    async def call(self, correlation_id='', body=''):

        # await self.init_loop()
        await self.init_connect()

        channel = random.choice(RabbitMQProductClient.channl_list)

        if correlation_id is '':
            correlation_id = str(uuid.uuid4())

        s = time.time()
        try:
            await channel.default_exchange.publish(
                Message(
                    str(body).encode(),
                    content_type="text/plain",
                    correlation_id=correlation_id,
                ),
                routing_key=self.queue,
            )
        except Exception as e:

            print('publish error : {}...'.format(e))
            await self.re_connect()
            await channel.default_exchange.publish(
                Message(
                    str(body).encode(),
                    content_type="text/plain",
                    correlation_id=correlation_id,
                ),
                routing_key=self.queue,
            )

        print('doing.. {}'.format(time.time() - s))
