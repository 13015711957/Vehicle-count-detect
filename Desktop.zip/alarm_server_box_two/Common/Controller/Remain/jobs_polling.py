# -*- coding: utf-8 -*-
"""

@project : ctgAI
@FileName: jobs_polling.py
@Desc  : 任务轮询

"""

import functools
import os
import sys
import time

import numpy as np

# JOBS_BASE_DIR = os.path.dirname(os.path.abspath(__file__))
# if JOBS_BASE_DIR not in sys.path:
#     sys.path.append(JOBS_BASE_DIR)
#
# PROJ_DIR = os.path.dirname(os.path.dirname(JOBS_BASE_DIR))
# if PROJ_DIR not in sys.path:
#     sys.path.append(PROJ_DIR)



from Controller.Remain.MyCrontab import loop_time_fun

from Common.Dao import LockDao
from SYS import mysql_config
job_lock = LockDao(mysql_config)
from SYS import SYS_CODE

import ailog



#aictg 轮询逻辑
def ai_loop(interval, table_name, id_name, status_name, condition, func, *args):
    #参数检查
    if func is None:
        raise Exception("#ERROR: There is not polling logic!")

    assert job_lock
    worker = jobs_polling(table_name, id_name, status_name, func, condition, job_lock, limit=10)
    
    loop_time_fun(interval, 0, worker.call_jobs, *args)


def loop_wapper(interval, table_name, id_name, status_name, condition, limit=10,order_by=None, *args):
    def call(func):
        @functools.wraps(func)
        def ai_loop():
            if func is None:
                raise Exception("#ERROR: There is not polling logic!")

            assert job_lock
            worker = jobs_polling(table_name, id_name, status_name, func, condition, job_lock, limit=limit,order_by=order_by)

            loop_time_fun(interval, 0, worker.call_jobs, *args)

        return ai_loop

    return call


class jobs_polling(object):
    def __init__(self, table_name, id_name, status_name, func, condition, job_lock, limit=10, order_by=None):

        self.func = func
        self.limit = limit
        self.table_name = table_name
        self.id_name = id_name
        self.status_name = status_name
        self.condition = condition
        self.order_by = order_by

        self.lock_dao = job_lock

        self.lock_dao.set_table_and_id_name(table_name=self.table_name,id_name=self.id_name,status_name=status_name,order_by=self.order_by)
    
    def __del__(self): 
        pass
    
    def check_job_status(self,job_id):
        state = self.lock_dao.get_job_status(job_id)
        if state is None or len(state)==0:
            print('#WARN:Job ID[%s] is not exist!'%job_id)
            return False
        
        if state[0] not in np.array([self.condition[self.status_name]]).reshape(-1).tolist():
            #任务还未开始
            return True
        else:
            return False
    
    def call_jobs(self, *args):
        try:
            #检查连接
            if self.lock_dao.lock_db.check_reconnect() is False:
                print('#ERROR: DB connect has problem!')
                err_info='#ERROR: DB connect has problem!'
                t_id=0
                ailog.error(err_info)
                ailog.save_error_log(t_id, '04', 900000, err_info, 9)
                return False

            #提取任务列表
            jobs_list = self.lock_dao.get_jobs_list(self.condition,self.limit)
            if jobs_list is None or len(jobs_list) == 0:
                print('#LoopInfo: No new missions.')
                return False

            count=0
            for line in jobs_list:

                res_dict = line
                t_id = res_dict[self.id_name]
                # create_time = one_line[1]

                count+=1

                if self.check_job_status(t_id):
                    #该记录任务已进行
                    print('This job is annulled or in progress!')
                    continue

                #设置任务进行中
                time_str = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
                # self.lock_dao.set_job_status_commit(t_id,RUNNING_STATE,time_str)

                #开始事物
                self.lock_dao.lock_db.transaction_begin()

                #加锁
                if not self.lock_dao.check_job_lock(t_id):
                    #加锁失败
                    print('This job is locking,next!')
                    continue

                try:
                    #任务调度
                    status = self.func(**res_dict)
                    print('#结果为 ',status)
                    #任务表状态更新
                    time_str = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
                    self.lock_dao.set_job_status_not_commit(job_id=t_id,status_key=self.status_name,status_value=status,uptime=time_str)

                except Exception as e:
                    print('#Job[%s] FAILED:'%t_id,e)
                    self.lock_dao.set_job_status_not_commit(job_id=t_id,status_key=self.status_name,status_value=SYS_CODE.STATUE.FAIL,uptime=time_str)
                    #LOG
                    err_info = '#Job[%s] FAILED:%s'%(t_id,e)
                    ailog.error(err_info)
                    ailog.save_error_log(t_id, '04', 900001, err_info, 9)

                #事物结束 & 锁释放
                self.lock_dao.lock_db.transaction_commit()
                print('-----')

            print('### Count %d records were processed.'%count)
            #轮循结束时间
            time_str = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
            print('### loop end time: ',time_str)
            return True

        except Exception as e:
            err_msg = '#FATAL: [轮询异常] {}'.format(e)
            print(err_msg)
            ailog.error(err_msg)
            ailog.save_error_log(0, '04', 900000, err_msg, 9)
            return False



if __name__ == '__main__':

    @loop_wapper(interval=3,table_name='t_batch',id_name='batch_id',status_name='status',condition={'status':(0,1)})
    def a(**kwargs):
        print('*************')
        print(kwargs)
        while True:
            time.sleep(1)

    # ai_loop(interval=3,table_name='t_batch',id_name='batch_id',status_name='status',condition={'status':(0,1)},func=a)

    a()
