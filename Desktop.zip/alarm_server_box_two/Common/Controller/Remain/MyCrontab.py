#coding:utf-8

import time
from threading import Timer
import os

cron_count = 1

#do something
def worker():
    #time.sleep(15)
    print("do something %d" % cron_count)
    print('===pid:%d==='% os.getpid())

def loop_time_fun_old(interval, total=0, func=None):
    now_str = time.strftime('%Y-%m-%d %H:%M:%S',\
        time.localtime(time.time()))
    print('----------------------------------------------')
    print('begin #: ' ,now_str) 
    if func != None:
        func()
    global cron_count
    
    if total == 0:
        Timer(interval, loop_time_fun, (interval, 0, func)).start()
        #time.sleep(interval)
        loop_time_fun(interval, 0, func)
    elif cron_count < total:
        cron_count += 1
        Timer(interval, loop_time_fun, (interval, total, func)).start()
        #time.sleep(interval)
        loop_time_fun(interval, total, func)
    
    #PYTHON默认最大递归数为1000次,因此不使用线程时存在问题
    

def loop_time_fun(interval, total=0, func=None, *args):
        global cron_count
        
        while True:
            now_str = time.strftime('%Y-%m-%d %H:%M:%S',\
                                    time.localtime(time.time()))
            print('----------------------------------------------')
            print('begin #: ' ,now_str) 
            if func != None:
                if len(func.__code__.co_varnames)>0:
                    func(*args)
                else:
                    func()
            
            if total == 0:
                time.sleep(interval)
            elif cron_count < total:
                cron_count += 1
                time.sleep(interval)   
            else:
                break   
                
        
        
if __name__ == '__main__':
    now_str = time.strftime('%Y-%m-%d %H:%M:%S',\
        time.localtime(time.time()))
    print('### process start time: ', now_str)

    interval = 3
    #Timer(interval, loop_time_fun, (interval, 0)).start()
    #loop_time_fun_2(interval, 5, worker)
    loop_time_fun(interval, 0, worker)
    #loop_time_fun(1, func=worker)
    
