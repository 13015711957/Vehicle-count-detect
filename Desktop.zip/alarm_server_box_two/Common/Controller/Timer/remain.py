# -*- coding: utf-8 -*-

'''
@project : publicOpinionAnalysis
@FileName: remain
@Author  :linych 
@Time    :2020/4/14 17:45
@Desc  : 
'''
import time
import functools

def remain_wapper(seconds,**kwargs):
    def call(func):
        @functools.wraps(func)
        def ai_loop():
            if func is None:
                raise Exception("#ERROR: There is not polling logic!")

            while True:
                func(**kwargs)
                time.sleep(seconds)

        return ai_loop

    return call
