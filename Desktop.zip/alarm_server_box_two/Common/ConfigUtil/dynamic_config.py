# -*-coding:utf-8 -*-

"""
# Project    : AIStreamPlatform
# File       : dynamic_config.py
# Time       ：2021/8/22 14:41
# Author     ：linych
# version    ：python 3.7
# Description：
"""

class DynamicConfig():

    is_new = False


    @classmethod
    def set(cls,key,value):
        setattr(DynamicConfig,key,value)



    @classmethod
    def get(cls,key):
        r = getattr(DynamicConfig,key)
        return r


    @classmethod
    def update(cls,key,value):
        cls.is_new = True
        cls.set(key,value)









