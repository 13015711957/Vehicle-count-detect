# -*-coding:utf-8 -*-

"""
# Project    : AIStreamPlatform
# File       : sync_config.py
# Time       ：2021/8/20 15:35
# Author     ：linych
# version    ：python 3.7
# Description：
"""

import time
import threading


class SyncConfig():


    def __init__(self,ConfigClass):

        self.redis_connect  = ''
        self.ConfigKey = ''
        self.ConfigClass = ConfigClass
        self.Lock = threading.Lock()

        t1 = threading.Thread(target=self.sync_config_from_reids)
        t2 = threading.Thread(target=self.sync_config_to_reids)

        t1.start()
        t2.start()




    def _read_config(self):
        #读取redis配置信息
        pass



    def _write_config(self,data):
        #更新redis配置信息
        pass


    def sync_config_from_reids(self):
        #同步本地配置

        while True:

            self.Lock.acquire()
            try:
                if not self.ConfigClass.is_new:
                    data = self._read_config()
                    for k,v in data.items():
                        self.ConfigClass.set(k,v)
                    break
            except:
                pass
            self.Lock.release()

            time.sleep(5)


    def sync_config_to_reids(self):
        #同步本地配置

        self.Lock.acquire()
        try:
            if self.ConfigClass.is_new:
                data = self.ConfigClass.__dict__
                self._write_config(data)
                self.ConfigClass.is_new = False
        except:
            pass
        self.Lock.release()





