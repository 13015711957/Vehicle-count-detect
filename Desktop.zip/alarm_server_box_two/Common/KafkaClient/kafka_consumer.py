# -*- encoding: utf-8 -*-
"""
@Project : AIStreamPlatform
@FileName: kafka_consumer
@Time    : 2021/12/5 11:44 
@Author  : zhangec
@Desc    :
"""
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from pykafka import KafkaClient
from SYS import conf


class KafkaTest(object):
    def __init__(self, host):
        self.host = host
        self.client = KafkaClient(hosts=self.host)

    def balance_consumer(self, topic, offset=0):
        """
        使用balance consumer去消费kafka
        :return:
        """
        result = []

        topic = self.client.topics[topic.encode()]
        # managed=True 设置后，使用新式reblance分区方法，不需要使用zk，而False是通过zk来实现reblance的需要使用zk,必须指定
        # zookeeper_connect = "zookeeperIp",consumer_group='test_group',
        consumer = topic.get_balanced_consumer(consumer_group='test_group',
                                               auto_commit_enable=True, managed=True,
                                               consumer_timeout_ms=1000)
        partitions = topic.partitions
        print("分区 {}".format(partitions))
        earliest_offsets = topic.earliest_available_offsets()
        print("最早可用offset {}".format(earliest_offsets))
        last_offsets = topic.latest_available_offsets()
        print("最近可用offset {}".format(last_offsets))
        offset = consumer.held_offsets
        print("当前消费者分区offset情况{}".format(offset))
        while True:
            msg = consumer.consume()
            if msg:
                offset = consumer.held_offsets
                print("当前位移：{}".format(offset))
                result.append(eval(msg.value.decode()))
                print(msg.value.decode())
                consumer.commit_offsets()  # commit一下

            else:
                print("没有数据")


if __name__ == '__main__':
    host = conf.get('kafka', 'servers')
    kafka_ins = KafkaTest(host)
    topic = conf.get('kafka', 'topic')
    kafka_ins.balance_consumer(topic)
