# -*- encoding: utf-8 -*-
"""
@Project : AIStreamPlatform
@FileName: kafka_util
@Time    : 2021/12/5 10:55 
@Author  : zhangec
@Desc    :
"""
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
import json
from pykafka import KafkaClient
from SYS import conf


class KafkaProduct():

    def __init__(self, hosts, topic):
        """
        初始化实例
        :param hosts: 连接地址
        :param topic:
        """
        self.__client = KafkaClient(hosts=hosts)
        self.__topic = self.__client.topics[topic.encode()]

    def __set_topic(self, topic):
        self.__topic = self.__client.topics[topic.encode()]

    def set_topic(self, topic):
        """
        设置topic
        :param topic:
        :return:
        """
        self.__set_topic(topic)

    def get_topics(self):
        """
        获取当前所有topic
        :return:
        """
        return self.__client.topics

    def get_topic(self):
        """
        获取当前topic
        :return:
        """
        return self.__topic

    def Producer(self, data):
        """
        生产者对象
        :return:
        """
        try:
            with self.__topic.get_producer(delivery_reports=True) as producer:
                producer.produce(json.dumps(data).encode('utf-8'))
            print("kafka sended")
        except Exception as e:
            print("kafka send error", e)
        finally:
            producer.stop()

    def balance_consumer(self, group, offset=0):
        """
        使用balance consumer去消费kafka
        :return:
        """
        result = []

        topic = self.__topic
        consumer = topic.get_balanced_consumer(consumer_group=group,
                                               auto_commit_enable=True, managed=True,
                                               consumer_timeout_ms=1000)
        partitions = topic.partitions
        print("分区 {}".format(partitions))
        earliest_offsets = topic.earliest_available_offsets()
        print("最早可用offset {}".format(earliest_offsets))
        last_offsets = topic.latest_available_offsets()
        print("最近可用offset {}".format(last_offsets))
        offset = consumer.held_offsets
        print("当前消费者分区offset情况{}".format(offset))
        while True:
            msg = consumer.consume()
            if msg:
                offset = consumer.held_offsets
                print("当前位移：{}".format(offset))
                result.append(eval(msg.value.decode()))
                print(msg.value.decode())
                consumer.commit_offsets()  # commit一下

            else:
                return result


if __name__ == '__main__':
    t = KafkaProduct(conf.get('kafka', 'servers'), conf.get('kafka', 'topic'))
    print(t)
    result = {
                'eventId': "UUID",
                'companyId': 600,
                'scenesId': 10001,
                'eventType': 1001,
                'eventLocation': "宝龙广场",
                'quality': 0.98,
                'eventPeriod': "1" if 7 <= int("2021-12-06 10:26:16"[11:13]) < 19 else "2",
                'eventTime': "2021-12-06 10:26:16",
                'eventStatus': 0,
                'duration': 1230255,
                'eventGrade': 1,
                'personNums': 3,
                'cameraNum': 1,
                'cameraName': "宝龙广场",
                'cameraILongitude': 98.256,
                'cameraILatitude': 23.543,
                'cameraDistrict': "广场",
                'cameraAddress': "宝龙广场",
                'panoramicImage': "url",
                'sectionImage': "object_url",
                'vedioUrl': "",
                'sendType': 0,
                'reportType': 1001,
                'extraInfo': ""
            }
    t.Producer(result)

    t.balance_consumer(conf.get('kafka', 'topic'))
