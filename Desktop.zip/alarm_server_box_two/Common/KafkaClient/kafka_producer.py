# -*- encoding: utf-8 -*-
"""
@Project : AIStreamPlatform
@FileName: kafka_producer
@Time    : 2021/12/5 11:42 
@Author  : zhangec
@Desc    :
"""
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from pykafka import KafkaClient
from SYS import conf

client = KafkaClient(hosts=conf.get('kafka', 'servers'))  # 实例化
print(client.topics)
print(client.brokers)
topic = client.topics[conf.get('kafka', 'topic')]  # 指定topic,没有就新建
producer = topic.get_producer()
for i in range(1):
    producer.produce(('test message ' + str(i ** 2)).encode())
producer.stop()
