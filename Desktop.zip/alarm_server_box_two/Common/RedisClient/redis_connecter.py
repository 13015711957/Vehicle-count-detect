# -*- coding: utf-8 -*-

'''
@project : AIGateWay_fastapi
@FileName: redis_connecter
@Author  :linych 
@Time    :2020/12/16 21:57
@Desc  : 
'''
import os
import sys

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import redis
from SYS import conf
import random

TASK = 14
DATA = 13
PARAM = 7
TRACK = 8

Mot_host = conf.get('REDIS', 'Mot_host')
Mot_port = conf.get("REDIS", 'Mot_port')
Mot_password = conf.get("REDIS", 'Mot_password')
Mot_Task = 'Mot_Task'
Det_Task = 'Det_Task'

Mot_pool = redis.ConnectionPool(host=Mot_host, port=Mot_port, decode_responses=True, db=TASK, password=Mot_password)
redis_TASK = redis.StrictRedis(connection_pool=Mot_pool)

Mot_pool = redis.ConnectionPool(host=Mot_host, port=Mot_port, decode_responses=True, db=DATA, password=Mot_password)
redis_DATA = redis.StrictRedis(connection_pool=Mot_pool)

TASK_pool = redis.ConnectionPool(host=Mot_host, port=Mot_port, decode_responses=True, db=PARAM, password=Mot_password)
redis_PARAM = redis.StrictRedis(connection_pool=TASK_pool)

TASK_pool = redis.ConnectionPool(host=Mot_host, port=Mot_port, decode_responses=True, db=TRACK, password=Mot_password)
redis_TRACK = redis.StrictRedis(connection_pool=TASK_pool)


