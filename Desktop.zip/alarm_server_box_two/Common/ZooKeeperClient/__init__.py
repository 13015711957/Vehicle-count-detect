# -*-coding:utf-8 -*-

"""
# Project    : AIStreamPlatform
# File       : __init__.py.py
# Time       ：2021/9/2 16:36
# Author     ：linych
# version    ：python 3.7
# Description：
"""

