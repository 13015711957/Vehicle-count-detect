# -*-coding:utf-8 -*-

"""
# Project    : AIStreamPlatform
# File       : test1.py
# Time       ：2021/9/2 16:37
# Author     ：linych
# version    ：python 3.7
# Description：
"""


from kazoo.client import KazooClient
zk = KazooClient(hosts='192.168.35.225:2181')    #如果是本地那就写127.0.0.1
zk.start()    #与zookeeper连接
node = zk.get_children('/')  # 查看根节点有多少个子节点
print(node)
# zk.create('/test/test',b'this is my house',makepath=True)
node = zk.get_children('/')  # 查看根节点有多少个子节点
print(node)

node = zk.get('/test/test',watch=True)  # 查看根节点有多少个子节点
print(node)

