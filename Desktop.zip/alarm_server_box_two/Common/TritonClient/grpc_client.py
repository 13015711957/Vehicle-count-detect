#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2021/5/6 16:13
# @Author  : lx-rookie
# @File    : grpc_client.py

import tritonclient.grpc as grpcclient


class Client(object):
    def __init__(self, params):
        self.triton_client = grpcclient.InferenceServerClient(
            url=params['url'],
            verbose=params['verbose'])
        self.params = params
        if self.params['data_type'] == 'float32':
            self.data_type = 'FP32'
        elif self.params['data_type'] == 'int32':
            self.data_type = 'INT32'
        else:
            self.data_type = 'FP32'

    def predict(self, inputs_data):
        inputs = []
        outputs = []
        trt_outputs = []
        for i in inputs_data:
            if self.params['input_names'][i] is not None:
                inputs.append(grpcclient.InferInput(i, self.params['input_names'][i], self.data_type))
            else:
                inputs.append(grpcclient.InferInput(i, list(inputs_data[i].shape), self.data_type))
            inputs[-1].set_data_from_numpy(inputs_data[i])

        for i in self.params['output_names']:
            print('====ii====', i)
            outputs.append(grpcclient.InferRequestedOutput(i))

        results = self.triton_client.infer(model_name=self.params['model_name'],
                                           inputs=inputs,
                                           outputs=outputs,
                                           client_timeout=self.params['client-timeout'])

        for i in self.params['output_names']:
            trt_outputs.append(results.as_numpy(i))

        return trt_outputs
