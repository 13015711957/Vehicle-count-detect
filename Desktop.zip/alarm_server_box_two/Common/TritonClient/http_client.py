#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2021/5/6 16:13
# @Author  : lx-rookie
# @File    : grpc_client.py

import tritonclient.http as httpclient
from Client.asyn_request import AsynClient

from Common.TritonClient.aio_triton import test_post

asyn = AsynClient()


class Client(object):
    def __init__(self, params):
        # self.triton_client = httpclient.InferenceServerClient(
        #     url=params['url'],
        #     verbose=params['verbose'])
        self.params = params
        if self.params['data_type'] == 'float32':
            self.data_type = 'FP32'
        elif self.params['data_type'] == 'int32':
            self.data_type = 'INT32'
        else:
            self.data_type = 'FP32'

async def t_predict(pclass, inputs_data):
    inputs = []
    outputs = []
    trt_outputs = []
    for i in inputs_data:
        if pclass.params['input_names'][i] is not None:
            inputs.append(httpclient.InferInput(i, pclass.params['input_names'][i], pclass.data_type))
        else:
            inputs.append(httpclient.InferInput(i, list(inputs_data[i].shape), pclass.data_type))
        inputs[-1].set_data_from_numpy(inputs_data[i])

    for i in pclass.params['output_names']:
        outputs.append(httpclient.InferRequestedOutput(i))


    results = await test_post(
        model_name=pclass.params['model_name'], inputs=inputs, outputs=outputs,
         base_url=pclass.params['url'],timeout=pclass.params['client-timeout']
    )

    for i in pclass.params['output_names']:
        trt_outputs.append(results.as_numpy(i))

    return trt_outputs
