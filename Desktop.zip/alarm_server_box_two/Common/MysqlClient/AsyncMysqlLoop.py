# -*- coding: utf-8 -*-

'''
@project : AIGateWay
@FileName: AsyncThreadLoop
@Author  :linych 
@Time    :2020/12/4 14:16
@Desc  : 
'''


import asyncio
import threading

from Common.MysqlClient.asyn_mysql_connect import asyn_mysql_connecter


class AsyncMysqlThreadLoop():


    def __init__(self,conf):

        self.loop = asyncio.new_event_loop()

        self.db_util = asyn_mysql_connecter(conf)

        self.t = threading.Thread(target=self.start_loop, args=(self.loop,))  # 通过当前线程开启新的线程去启动事件循环

        self.t.start()



    def start_loop(self,loop):

        asyncio.set_event_loop(loop)
        loop.run_forever()


    def run(self,asynfunc):

        asyncio.run_coroutine_threadsafe(asynfunc, self.loop)

