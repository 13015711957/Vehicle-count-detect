# -*- coding: utf-8 -*-

'''
@project : AIPLAT
@FileName: logError
@Desc  : 
'''

import traceback


def save_error_log(job_id, job_type, error_code, key_word='', error_level=9):
    """

    :param job_id:  int 任务id
    :param job_type: int 任务类型
    :param error_code: str 异常信息编码
    :param key_word:  str 错误关键字
    :param error_level: int 错误等级 默认9
    :return:
    """
    # error_strack = traceback.format_exc()
    # if len(error_strack)>1500:
    #     error_strack = error_strack[:1500]
    # try:
    #     if isinstance(job_id,int) and job_id>0:
    #         task_id = jobid_to_taskid(job_id=job_id)
    #     else:
    #         task_id = ''
    # except:
    #     task_id = ''
    #
    # try:
    #     insert_error_info(job_id=job_id, sys_task_id=task_id, job_type=job_type, error_code=error_code, key_word=key_word,
    #                   error_strack=error_strack, error_level=error_level)
    # except Exception as e:
    #     print('{}'.format(e))
    pass