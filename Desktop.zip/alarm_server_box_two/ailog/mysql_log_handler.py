# -*- coding: utf-8 -*-

'''
@project : AIGateWay_fastapi
@FileName: mysql_log_handler
@Author  :linych 
@Time    :2020/12/19 10:35
@Desc  : 
'''

from logging import Handler
from SYS import mysql_ailog_loop
from Common.Dao import insert_error_log


class MysqlLogHandler(Handler):

    def __init__(self):
        Handler.__init__(self)


    def emit(self, record):
        """
        Emit a record.

        If a formatter is specified, it is used to format the record.
        The record is then written to the stream with a trailing newline.  If
        exception information is present, it is formatted using
        traceback.print_exception and appended to the stream.  If the stream
        has an 'encoding' attribute, it is used to determine how to do the
        output to the stream.
        """
        try:
            print(record.__dict__)
            mysql_ailog_loop.run(insert_error_log(**record.__dict__))
        except Exception as e:
            print('handle error : {}'.format(e))
            self.handleError(record)

