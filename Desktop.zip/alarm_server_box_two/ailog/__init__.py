# -*- coding: utf-8 -*-

"""
@project : TeleAI
@FileName: __init__.py
@Desc  : 
"""

from ailog.log import DEBUG, INFO, WARN, ERROR
from ailog.log import debug
from ailog.log import error
from ailog.log import fatal
from ailog.log import info
from ailog.log import log_file
from ailog.log import set_log_file
from ailog.log import set_verbosity
from ailog.log import warning
from ailog.logError import save_error_log

__all__ = ['debug', 'error', 'fatal', 'info', 'warning', 'save_error_log','set_log_file',
           'log_file', 'set_verbosity', 'DEBUG', 'INFO', 'WARN', 'ERROR']
