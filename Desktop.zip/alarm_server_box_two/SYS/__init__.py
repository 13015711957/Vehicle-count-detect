# -*- coding: utf-8 -*-

'''
@project : AI_ControlServer
@FileName: __init__.py
@Desc  : 
'''

import os
import sys
sys.path.append("/home/face/projects/AIStreamPlatform")
print(sys.path)
#import SYS.sys_code_config as SYS_CODE
from SYS import sys_code_config as SYS_CODE
from Common.ConfigUtil.config_util import ConfigUtil
from Common.ConfigUtil.dynamic_config import DynamicConfig

from Common.MysqlClient.AsyncMysqlLoop import AsyncMysqlThreadLoop
from Common.MysqlClient.mysql_connecter import mysql_connecter
from Common.ThreadLoop.AsyncThreadLoop import AsyncThreadLoop


__all__ = ['conf', 'db_util', 'SYS_CODE', 'root_path', 'log_path']


config_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

if os.path.exists(r'/opt/config/config.ini'):
    config_path = r'/opt/config/'
else:
    config_path = os.path.join(config_path, 'config')
print("config_path: ", config_path)
try:
    conf = ConfigUtil(config_path=os.path.join(config_path, 'config.ini'))
except Exception as e:
    print('config read error : {}'.format(e))

dyconf = DynamicConfig

mysql_config = {
    'user': conf.get(section='MysqlClient', option='user'),
    'passwd': conf.get(section='MysqlClient', option='password'),
    'db': conf.get(section='MysqlClient', option='db'),
    'host': conf.get(section='MysqlClient', option='host'),
    'port': conf.get(section='MysqlClient', option='port'),
    'minsize': conf.get(section='MysqlClient', option='minsize'),
    'maxsize': conf.get(section='MysqlClient', option='maxsize'),

}
print(mysql_config)
db_util = mysql_connecter(db_cfg=mysql_config)
db_util.set_transaction_isolation_read_committed()
# lock_db_util = mysql_connecter(db_cfg=mysql_config)

root_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
mysql_config_log = mysql_config.copy()
mysql_config_alarm=mysql_config.copy()
alarm_loop=AsyncMysqlThreadLoop(mysql_config_alarm)

mysql_config_log['db'] = conf.get(section='MysqlClient', option='db_log')
print(mysql_config_log)
create_face_loop = AsyncThreadLoop()
create_index_loop = AsyncThreadLoop()

mysql_log_loop = AsyncMysqlThreadLoop(conf=mysql_config_log)
mysql_ailog_loop = AsyncMysqlThreadLoop(conf=mysql_config_log)

try:
    dir_name = conf.get(section='logging', option='dir')
except:
    dir_name = 'log'
log_path = os.path.join(root_path, dir_name)

NODE = conf.get('global', 'node')

redis_connect = None

