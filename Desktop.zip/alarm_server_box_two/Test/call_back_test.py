import requests

data = {
    'code': 1007,
    'data': {
        "taskId": "1004",
        "frameId": 1,
        "detection": [{
            "trackId": 0,
            "x": 870,
            "y": 291,
            "x1": 1018,
            "y1": 723,
            "score": 0.9404296875,
            "classId": 1,
            "className": "person",
            "taskType": 5,
            'smallImage': ''
        }],
        "image": "",
        "timestamp": 1666246539469055
    }
}

data1 = {
    'code': 1007,
    'data': {
        "taskId": "1004",
        "frameId": 12,
        "detections": [{
            "algoTask": 8001,
            "trackId": 0,
            "box": [1, 2, 3, 4],
            "attrs": [{"score": 0.5, "classId": 1, "className": "VehicleClass", "box": [1, 2, 3, 4]},
                      {"score": 0.5, "classId": 1, "className": "VehicleColor", "box": [1, 2, 3, 4]},
                      {"score": 0.5, "classId": 1, "className": "VehicleType", "box": [1, 2, 3, 4]},
                      {"score": 0.5, "classId": 1, "className": "VehicleDirection", "box": [1, 2, 3, 4]},
                      {"score": 0.5, "classId": 1, "className": "VehicleOcclusionDegree", "box": [1, 2, 3, 4]},
                      {"score": 0.5, "classId": 1, "className": "SpecialVehicleType", "box": [1, 2, 3, 4]},
                      {"score": 0.5, "classId": 1, "className": "DangerousVehicle", "box": [1, 2, 3, 4]},
                      {"score": 0.5, "classId": 1, "className": "LicensePlate", "box": [1, 2, 3, 4]},
                      {"score": 0.5, "classId": 1, "className": "VehicleRoof", "box": [1, 2, 3, 4]},
                      {"score": 0.5, "classId": 1, "className": "VehicleSkylight", "box": [1, 2, 3, 4]},
                      {"score": 0.5, "classId": 1, "className": "LicensePlateClass", "box": [1, 2, 3, 4]},
                      {"score": 0.5, "classId": 1, "className": "闽A312313", "box": [1, 2, 3, 4]},
                      ],
            "smallImage": ""
        }],
        "image": "",
        "base_width": 1920,
        "base_height": 1080,
        "pts": 10000000
    }}

data2 = {
    'code': 1007,
    'data': {
        "taskId": "1004",
        "frameId": 12,
        "detections": [{
            "algoTask": 9001,
            "trackId": 0,
            "box": [1, 2, 3, 4],
            "attrs": [{"score": 0.5, "classId": 1, "className": "FaceClass", "box": [1, 2, 3, 4]},
                      {"score": 0.5, "classId": 1, "className": "Mask", "box": [1, 2, 3, 4]},
                      {"score": 0.5, "classId": 1, "className": "Glass", "box": [1, 2, 3, 4]},
                      {"score": 0.5, "classId": 1, "className": "SunGlass", "box": [1, 2, 3, 4]},
                      {"score": 0.5, "classId": 1, "className": "Age", "box": [1, 2, 3, 4]},
                      {"score": 0.5, "classId": 1, "className": "Male", "box": [1, 2, 3, 4]},
                      {"score": 0.5, "classId": 1, "className": "Hair", "box": [1, 2, 3, 4]},
                      {"score": 0.5, "classId": 1, "className": "Hat", "box": [1, 2, 3, 4]},
                      ],
            "smallImage": ""
        }],
        "image": "",
        "base_width": 1920,
        "base_height": 1080,
        "pts": 10000000
    }}

r = requests.post(url='http://192.168.102.157:7003/BoxCallBack', json=data1)
# r = requests.post(url='http://127.0.0.1:7003/BoxCallBack', json=data)
print(r.text)
