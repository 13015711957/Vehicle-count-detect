import os
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import time
import json
import math
import base64
import requests

ip = '49.7.178.146'
ip = '192.168.254.30'
class SearchPicbyPic():

    @classmethod
    def DbCreate(cls, userId, group_name):
        '''创建底库'''
        data = {
            "userId": "test",
            "secretId": "",
            "Timestamp": 1528787199,
            "seqid": "8f43ee27",
            "group_name": "test1",
            "version": "0",
            "massage": "group crate test",
            "type": 1
        }

        r = requests.post(url='http://'+ip+':15001/openapi/portrait_task/create_index', data=json.dumps(data))
        print(r.text)

    @classmethod
    def DbChange(cls, userId, group_name, MaxNum):
        '''预估底库数量修改底库大小（扩容）'''
        from AlgorithmAbility.IVMFaceManager import IVMDbManager
        IVMDbManager.DbChange(userId, group_name, MaxNum)

    @classmethod
    def feature_register(cls, userId, group_name, img_path):
        '''分批次注册人像到底库并获取失败列表（防止接口调用时间过长超时）'''
        img_list = os.listdir(img_path)
        fail_list = []
        img_num = math.ceil(len(img_list)/100)
        for i in range(img_num):
            data = []
            for index in range(100):
                print(100*i+index,len(img_list))
                if (100*i+index) >= len(img_list):
                    continue
                img = img_list[100*i+index]
                img_name = os.path.join(img_path, img)
                featureId = img.split('.')[0]
                print(img_name, featureId)
                b64img = base64.b64encode(open(img_name, "rb").read())
                data.append({
                    "image": str(b64img, encoding="utf-8"),
                    "featureId": featureId,
                    "name_type": 0
                })
            req = {
                "userId": userId,
                "secretId": "3d11da771769aa3b62332bd5edba44c4",
                "Timestamp": "1634730772040",
                "seqid": "c8e2e8bb93fe4be8928f89a57a8dc3d4",
                "group_name": group_name,
                "type": 1,
                "version": "0",
                "data": data
            }
            r = requests.post(url='http://'+ip+':15001/openapi/portrait_task/register_feature', data=json.dumps(req))
            res = json.loads(r.text)
            fail_list += res.get("data",{}).get("fail_list",[])
            print(f"fail_list:{fail_list}")


    #查询底库大小获取底库id list（验证注册成功失败总数
    @classmethod
    def FeatureSearch(cls, userId, group_name):

        data = {
            "userId": userId,
            "secretId": "",
            "Timestamp": 1528787199,
            "seqid": "8f43ee27",
            "group_name": group_name,
            "featureId": '142'
        }

        r = requests.post(url='http://49.7.178.146:15001/openapi/portrait_task/search_feature', data=json.dumps(data))
        print(f"[TEST args]:", data)
        print(r.text)

        res = json.loads(r.text)
        feature_list = res.get("data").get("feature_list")
        featureIds = []
        for item in feature_list:
                featureIds.append(item["featureId"])
        print(featureIds)

        return featureIds


    @classmethod
    def face_1vn(cls, filefloder_path, userId, group_name):
        '''1vn比较聚档,结果保存到json'''
        result_dict = {}
        sst = time.time()
        filefloder_list = os.listdir(filefloder_path)
        print(filefloder_list)
        for filefloder in filefloder_list:
            filefloder='v2'
            file_path = os.path.join(filefloder_path,filefloder)
            video_list = os.listdir(file_path)
            print(video_list)
            for video in video_list:
                video_path = os.path.join(file_path, video)
                img_list = os.listdir(video_path)
                for img in img_list:
                    img_name = os.path.join(video_path, img)

                    b64img = base64.b64encode(open(img_name, "rb").read())
                    b64img = b64img.decode('utf-8')
                    from AlgorithmAbility.IVMFaceManager import IVMFeatureManager
                    st = time.time()
                    res = IVMFeatureManager.Feature1vn(b64img, userId, group_name, threshold=60, top=1)
                    print('单次调用1vn耗时:', time.time()-st)
                    print('1vn调用结果:', res)
                    feature_list = res.get("res",[])
                    featureId_hit = []
                    featureId = -1
                    pic_name = filefloder + '_' + video.split('.')[0] + '_' + img
                    if feature_list:
                        for item in feature_list:
                            faceImageId = item["faceImageId"]
                            from Dao.I_feature_info import select_i_feature_info_by_faceImageId
                            featureId = select_i_feature_info_by_faceImageId(faceImageId)[0]['feature_id']
                            res_path = os.path.join(r"/project/30WDATA/result",featureId)
                            if not os.path.exists(res_path):
                                os.makedirs(res_path)
                            order = 'cp '+ img_name +' '+os.path.join(res_path,pic_name)
                            print(order)
                            os.system(order)
                    if result_dict.get(featureId, -1) == -1:
                        result_dict[featureId] = []
                    result_dict[featureId].append(pic_name)
                print(result_dict)
                print('总耗时',time.time()-sst)
            break

        f = open('search_result_test1'+filefloder+'.json', 'w')
        f.write(json.dumps(result_dict))
        f.close()

if __name__=='__main__':
    userId = '1'
    group_name = 'financialstreet'
    # SearchPicbyPic.DbCreate(userId, group_name)
    # maxNum = 2000
    # SearchPicbyPic.DbChange(userId, group_name, maxNum)
    img_path = "/project/30WDATA/test1"
    # SearchPicbyPic.feature_register(userId, group_name, img_path)
    # ['142', '143', '145', '149', '505', '534', '535', '538', '539', '786', '789', '802', '849', '851', '853', '854', '855', '857', '858']
    # featureIds = SearchPicbyPic.FeatureSearch(userId,  group_name)
    SearchPicbyPic.face_1vn(img_path, userId, group_name)

    # f = open('search_result.json', 'r')
    # result = json.loads(f.read())
    # f.close()
    # print(result)
