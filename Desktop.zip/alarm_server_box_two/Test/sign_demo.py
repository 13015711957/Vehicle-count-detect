from Crypto.PublicKey import RSA
from Crypto.Signature import PKCS1_v1_5
from Crypto.Hash import SHA256
import base64
import requests


def RSA_sign(data):

    privateKey = '''MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAIomSxczHPOsN1F/LEQiq8s/wKYf8+jsVGqsNC6LrEPTdxy4woJKDxIzpUVeAs2bFiyx/eVUyQE1Fo6NpCUheXtBY0DL4NW+InFjsJweMtvJdZ5M5JCzkPugWP5Nr43XhB7DhJo26+eUpLwjlyMlsx9sD30tuJ/tXlBZ+y9IPjh9AgMBAAECgYA9ijVlDkXVXl/+E9KaP3+buLiOyCkVF0G7ix5rpZiFVkv3JW6wL2FrUEpNDkXdZTqJinh5kj1AJm/37Ky0RachUxDYZ8lXp3o+nrOQVdcd1OTmKGSqk3UI8m//vDyxcdsjcbGP6wV16wMnVArr3Xky4VS6tAPE53MsY+MnxZm8WQJBAMU0nF/IQqbHpExPEBlIB0mwvsxbW9uARjtnlwLBfEPIzTp8yB+dlenjOF6Dkko+SjAYsvb509ThjPPv11BrJxMCQQCzVlXG6MD2itGkk6A+3f7IYwmm2VQPb4g9LSdHCGVQxF/JR8jca1X+pcjOTJULmyHsMBF2ryU61+QvYgBKK0QvAkAOpSiTyGiCwELIU/rLFdlMtK6GuKYqt+z/TmMdlkbnNctf85JdHrPaacBu7HB5yQRza/Ime0kq/xEbsI0Z8Ms3AkBUCG93HhdVLyUe/gHHk5RQZ3/dS9bEyNlI+UB/W2LGHs5XbaikCDOqeBqI+H+aiZ2yo697MoS6dvE4dq52EqIHAkEAk+8UPkmVazogQAoHor7aOjnwlFmZsbBRpiqW7GthI8YfRWVOeaJxdBJ6NlYahME51i0oXCfj4LueG/LMbw41OQ=='''

    private_keyBytes = base64.b64decode(privateKey)
    priKey = RSA.importKey(private_keyBytes)
    signer = PKCS1_v1_5.new(priKey, )
    hash_obj = SHA256.new(data.encode('utf-8'))
    signature = base64.b64encode(signer.sign(hash_obj))
    return signature


def get_sign(req):

    rk = list(req.keys())
    rk.sort()
    res=''
    parm_num = 0
    for k in rk:
        if parm_num >= 1:
            res = res+'&'
        res = res + str(k) + '=' + str(req[k])
        parm_num += 1
    signature = RSA_sign(res)
    return signature.decode('utf8')


def sign_test(url, rsaKey):

    req = {"name": "addRepo"}
    sign = get_sign(req)
    data = {
            "code": "41601",
            "req": req,
            "rsaKey": rsaKey,
            "timestamp": "20191230110038019",
            "sign": sign
    }

    r = requests.post(url, json=data)
    res = r.json()
    return res


if __name__ == '__main__':

    # url = 'http://218.78.14.59:9007/ivmapi/v3/index'
    # rsaKey = '4eed105044af017b6c'
    # print(sign_test(url, rsaKey))

    a = 'type=0&url=rtsp://192.168.254.16:8894/rtp/01002000010000000101'
    # a = str(a)
    print(a.encode('utf-8'))