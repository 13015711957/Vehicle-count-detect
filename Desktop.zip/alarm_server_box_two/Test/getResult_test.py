# -*-coding:utf-8 -*-

"""
# Project    : AIStreamPlatform
# File       : Alarm_API_main.py
# Time       ：2021/8/23 17:01
# Author     ：zhengqx
# Description：
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from SYS import conf
from Dao.T_task_info import select_t_task_info
from Dao.I_task_info import select_i_task_info_by_taskId
from Dao.I_feature_info import select_i_feature_info_by_faceImageId
import json
import uuid
import traceback
import requests
from datetime import datetime
import time
from flask import Flask, request, jsonify


app = Flask(__name__)
@app.route('/getResult', methods=['POST'])
def IVMCallback():
    try:
        data = request.get_data()
        print("data: ",data)
        data = json.loads(data)

        return jsonify({
            "code": 10000,
            "info": 'Success'
        })
    except Exception as e:
        traceback.print_exc()
        return jsonify({
            "code": 10903,
            "info": "Fail:{}".format(e)
        })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=7003, threaded=False)
