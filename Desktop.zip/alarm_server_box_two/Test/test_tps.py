# -*- encoding: utf-8 -*-
"""
@Project : Face_contrast_API
@FileName: test_tps
@Time    : 2021/1/27 17:20
@Author  : zhangec
@Desc    :
"""
import os, sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import cv2
import base64
import requests
import threading
import json
import random
import time
import numpy as np

res_list = []
tps_list = []
use_time_list = []
success = 0

server_url = 'http://192.168.102.157:7001/openapi/stream_task/state_stream'

headers = {'Content-Type': 'application/json;charset=UTF-8'}
# path = r'/home/wanghuibing/wanghb/silent_bioassay/test/zheng.jpeg'

# with open("/home/ffcs/Face_contrast_test/test/idcard_image/证件照片.txt", "r", encoding='utf-8') as f:
#     image = f.read()
# image = cv2.imdecode(np.fromfile(path, dtype=np.uint8), -1)
# image = cv2.imencode('.jpg', image)[1].tostring()
# image = base64.b64encode(image)

# 开始时间
start = time.time()
avg_time = 0


def run(i):
    global res_list, tps_list, use_time_list, success, avg_time

    tt = time.time()
    data = {
        'timestamp': '1641265514',
        'seqid': '1868b79be32744a79b7edfadd9d44d3a',
        'camera_id': '7778',
        'camera_uri': 'rtsp://192.168.35.225:1554/video/snap/FallDown.264',
}
    r = requests.post(server_url, json=data)
    res = json.loads(r.text)  # 将字符串转字典
    print(res)

    if '10000' in str(res):
        success += 1
        # avg_time+=eval(res['data']['timeSecond'])
    res_list.append([i, time.time() - tt, t, res])

    tps = len(res_list) / (time.time() - start)
    tps_list.append(tps)
    use_time_list.append(time.time() - tt)

    # print(resp)
    # print('tps :{} max : {} use : {}'.format(tps,max(tps_list),time.time()-tt))
    # print('avg_use:{},min_use:{},max_use:{},tps:{}'.format(sum(use_time_list) / len(use_time_list),
    #                                                                min(use_time_list), max(use_time_list),
    #                                                                max(tps_list)))
    print('#' * 30)
    print('成功率 : {}%'.format((success / len(res_list)) * 100))
    print('avg_use : {}'.format(sum(use_time_list) / len(use_time_list)))
    print('max_use : {}'.format(max(use_time_list)))
    print('min_use : {}'.format(min(use_time_list)))
    print('avg_tps : {}'.format(sum(tps_list) / len(tps_list)))
    print('max_tps : {}'.format(max(tps_list)))
    print('min_tps : {}'.format(min(tps_list)))
    print('#' * 30)


def loop(i):
    # 单个线程执行数
    for j in range(1):
        print('接口请求时间 : {}'.format(time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())))
        run(i)


# 线程数
w = 10
th_list = []

for i in range(w):
    t = threading.Thread(target=loop, args=(i,))
    t.start()
    th_list.append(t)

for t in th_list:
    t.join()
end = time.time()
sum_time = end - start
print('总耗时:', sum_time)
# print('平均耗时',avg_time/(w*100))
