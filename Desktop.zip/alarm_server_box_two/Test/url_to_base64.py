def url_to_base64(image_url):
    import os, base64
    import requests as req
    from PIL import Image
    from io import BytesIO
    # 将这个图片保存在内存
    print(image_url)
    response = req.get(image_url)
    print('1')
    image = Image.open(BytesIO(response.content))
    print('2')
    image_base64 = base64.b64encode(BytesIO(response.content).read())
    # 打印出这个base64编码
    print(len(image_base64),image_base64[:100])
    return image_base64

url='http://49.7.201.39:9007/picture/8220274147008380928.jpg'
url_to_base64(url)
