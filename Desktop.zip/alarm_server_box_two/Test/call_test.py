import grpc

from proto import alarm_server_pb2, alarm_server_pb2_grpc

import ctypes
def run():
    # 本次不使用SSL，所以channel是不安全的
    options =(('GRPC_ARG_MAX_RECEIVE_MESSAGE_LENGTH', 100 * 1024 * 1024),)
    channel = grpc.insecure_channel('localhost:7003', options=options)
    # 客户端实例
    stub = alarm_server_pb2_grpc.AlarmServerStub(channel)
    detections=[
        {
            "algo_task": 3002,
            "track_id": 1,
            "box": {
                "x0": 100,
                "y0": 100,
                "x1": 300,
                "y1": 300
            },
            "attrs": [
                {
                    "score": 0.5,
                    "class_name": "Smoking",
                    "class_value": 0.3,
                    "result_str": "smoking",
                    "points": [
                        {
                            "x": 10,
                            "y": 10
                        },
                        {
                            "x": 220,
                            "y": 220
                        }
                    ],
                    "features": [
                        0.1,
                        0.2,
                        0.3
                    ],
                    "box": {
                        "x0": 50,
                        "y0": 50,
                        "x1": 250,
                        "y1": 250
                    },
                    "class_id": 0
                }
            ],
            "small_image": ""
        }
    ]
    task_id='TestConstruct'
    frame_id=12
    image='asdasdd'
    base_width=1920
    base_height=1080
    pts=11111


    response = stub.Publish(alarm_server_pb2.PublishRequest(task_id=task_id,frame_id=frame_id,
                                                            detections=detections,image=image,
                                                            base_height=base_height,base_width=base_width,
                                                            pts=pts))
    print("用户信息： " + response.message)


if __name__ == '__main__':
    run()