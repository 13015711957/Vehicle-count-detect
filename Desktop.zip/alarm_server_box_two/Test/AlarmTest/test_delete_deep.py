import requests
import json

deepstream_stop_url = 'http://192.168.254.180:8003/delete_source'

def persondecode_delete_task(analysis_id):
    deepstream_data = {
        "source_id": analysis_id
  }
    res = requests.post(deepstream_stop_url, deepstream_data)
    print(res.text)
    res = json.loads(res.text)
    if res.get('code', 10903) == 10000:
        return True
    return False

persondecode_delete_task(0)
