# -*- encoding: utf-8 -*-
"""
@FileName ：alarm_delete_test.py
@Time ： 2021/8/27 16:28
@Auth ： Ying
"""
import sys
import os
sys.path.append("/home/face/projects/AIStreamPlatform")
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import requests
import json

# data = {
# 	"userId":"test",
# 	"secretId":"53bed29e1e434e8ab520b2e5f29f8b7e",
# 	"Timestamp":"1528787199",
# 	"seqid":"26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
# 	"taskId":"722dd22feb9b49a28ebab0f50f395932"
# }
data={
        "userId": "test",
        "secretId": "53bed29e1e434e8ab520b2e5f29f8b7e",
        "timestamp": "1528787199",
        "seqid": "26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
        "taskId": "1004"
    }
r = requests.post(url='http://192.168.102.253:7002/openapi/alarm_task/delete_task',data=json.dumps(data))
# r = requests.post(url='http://127.0.0.1:7002/openapi/alarm_task/delete_task',data=json.dumps(data))

print(r.text)
