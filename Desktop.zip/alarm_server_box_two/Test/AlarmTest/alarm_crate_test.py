# -*- encoding: utf-8 -*-
import sys
import os

import requests
import json

data = {
    'userId': 'test',
    'secretId': '53bed29e1e434e8ab520b2e5f29f8b7e',
    'timestamp': '1641265514',
    'seqid': '1868b79be32744a79b7edfadd9d44d3a',
    'taskId': '1004',
    'event_type': '4004',
    'result_receiver': {'uri': 'http://192.168.102.253:20092/AI/Event', 'method': 'post',
                        'Type': 'HTTP'},
    'event_define_massage': {
        'alarm_start_time': '00:00:00',
        'alarm_end_time': '23:00:00'
    },
    'camera_config': {
        'camera_id': '01002000010000001301',
        'camera_uri': 'rtsp://192.168.35.225:1554/video/river.264',
    },
    'event_config': {
        'threshold': 10,
        'alarm_rate': 6,
        'line': [573, 603, 1167, 600],
        'arrow': [846, 606, 867, 828],
        'warning_area': [{'x': 0, 'y': 0}, {'x': 1920, 'y': 0}, {'x': 1920, 'y': 1080}, {'x': 0, 'y': 1080}],
        'capture_mode': 0,
        'warning_time':10

    },
    'threshold': 0.5,
    'alarm_rate': 3,
}

r = requests.post(url='http://192.168.102.253:7002/openapi/alarm_task/create_task', data=json.dumps(data), timeout=30)
# r = requests.post(url='http://127.0.0.1:7002/openapi/alarm_task/create_task', data=json.dumps(data))
print(r.text)
