# -*- encoding: utf-8 -*-
"""
@FileName ：alarm_delete_test.py
@Time ： 2021/8/27 16:28
@Auth ： Ying
"""
import sys
import os
sys.path.append("/home/face/projects/AIStreamPlatform")
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import requests
import json

tasks = [
    {
        'taskId': '3002-1',
        'event_type': '3002',
        'camera_uri': 'rtsp://192.168.35.225:1554/video/snap/FallDown.264'
    },
    {
        'taskId': '3002-2',
        'event_type': '3002',
        'camera_uri': 'rtsp://192.168.35.225:1554/video/snap/FallDown.264'
    },
    {
        'taskId': '3002-3',
        'event_type': '3002',
        'camera_uri': 'rtsp://192.168.35.225:1554/video/snap/FallDown.264'
    },
    {
        'taskId': '5003-1',
        'event_type': '5003',
        'camera_uri': 'rtsp://192.168.35.225:1554/video/smoke_phone_01.265'
    },
    {
        'taskId': '5003-2',
        'event_type': '5003',
        'camera_uri': 'rtsp://192.168.35.225:1554/video/smoke_phone_01.265'
    },
    {
        'taskId': '5001-1',
        'event_type': '5001',
        'camera_uri': 'rtsp://192.168.35.225:1554/video/snap/Intrusion.264'
    },
    {
        'taskId': '5001-2',
        'event_type': '5001',
        'camera_uri': 'rtsp://192.168.35.225:1554/video/snap/Intrusion.264'
    },
    {
        'taskId': '5004-1',
        'event_type': '5004',
        'camera_uri': 'rtsp://192.168.35.225:1554/video/snap/SafetyHat.264'
    },
    {
        'taskId': '5004-2',
        'event_type': '5004',
        'camera_uri': 'rtsp://192.168.35.225:1554/video/snap/SafetyHat.264'
    },
    {
        'taskId': '4003-1',
        'event_type': '4003',
        'camera_uri': 'rtsp://192.168.35.225:1554/video/snap/Weapons.264'
    },
    {
        'taskId': '4003-2',
        'event_type': '4003',
        'camera_uri': 'rtsp://192.168.35.225:1554/video/snap/Weapons.264'
    },
    {
        'taskId': '4003-3',
        'event_type': '4003',
        'camera_uri': 'rtsp://192.168.35.225:1554/video/snap/Weapons.264'
    },
    {
        'taskId': '4002-1',
        'event_type': '4002',
        'camera_uri': 'rtsp://192.168.35.225:1554/video/snap/Intrusion.264'
    },
    {
        'taskId': '4002-2',
        'event_type': '4002',
        'camera_uri': 'rtsp://192.168.35.225:1554/video/snap/Intrusion.264'
    },
    {
        'taskId': '4001-1',
        'event_type': '4001',
        'camera_uri': 'rtsp://192.168.35.225:1554/video/snap/Intrusion.264'
    },
    {
        'taskId': '4001-2',
        'event_type': '4001',
        'camera_uri': 'rtsp://192.168.35.225:1554/video/snap/Intrusion.264'
    },

]

data={
        "userId": "test",
        "secretId": "53bed29e1e434e8ab520b2e5f29f8b7e",
        "timestamp": "1528787199",
        "seqid": "26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
        "taskId": "3002"
    }
for i in tasks:
    data['taskId']=i['taskId']

    r = requests.post(url='http://127.0.0.1:7002/openapi/alarm_task/delete_task',data=json.dumps(data))

    print(r.text)
