# -*- encoding: utf-8 -*-
import sys
import os

import requests
import json

tasks = [
    {
        'taskId': '3002-1',
        'event_type': '3002',
        'camera_uri': 'rtsp://192.168.35.225:1554/video/snap/FallDown.264'
    },
    {
        'taskId': '3002-2',
        'event_type': '3002',
        'camera_uri': 'rtsp://192.168.35.225:1554/video/snap/FallDown.264'
    },
    {
        'taskId': '3002-3',
        'event_type': '3002',
        'camera_uri': 'rtsp://192.168.35.225:1554/video/snap/FallDown.264'
    },
    {
        'taskId': '5003-1',
        'event_type': '5003',
        'camera_uri': 'rtsp://192.168.35.225:1554/video/smoke_phone_01.265'
    },
    {
        'taskId': '5003-2',
        'event_type': '5003',
        'camera_uri': 'rtsp://192.168.35.225:1554/video/smoke_phone_01.265'
    },
    {
        'taskId': '5001-1',
        'event_type': '5001',
        'camera_uri': 'rtsp://192.168.35.225:1554/video/snap/Intrusion.264'
    },
    {
        'taskId': '5001-2',
        'event_type': '5001',
        'camera_uri': 'rtsp://192.168.35.225:1554/video/snap/Intrusion.264'
    },
    {
        'taskId': '5004-1',
        'event_type': '5004',
        'camera_uri': 'rtsp://192.168.35.225:1554/video/snap/SafetyHat.264'
    },
    {
        'taskId': '5004-2',
        'event_type': '5004',
        'camera_uri': 'rtsp://192.168.35.225:1554/video/snap/SafetyHat.264'
    },
    {
        'taskId': '4003-1',
        'event_type': '4003',
        'camera_uri': 'rtsp://192.168.35.225:1554/video/snap/Weapons.264'
    },
    {
        'taskId': '4003-2',
        'event_type': '4003',
        'camera_uri': 'rtsp://192.168.35.225:1554/video/snap/Weapons.264'
    },
    {
        'taskId': '4003-3',
        'event_type': '4003',
        'camera_uri': 'rtsp://192.168.35.225:1554/video/snap/Weapons.264'
    },
    {
        'taskId': '4002-1',
        'event_type': '4002',
        'camera_uri': 'rtsp://192.168.35.225:1554/video/snap/Intrusion.264'
    },
    {
        'taskId': '4002-2',
        'event_type': '4002',
        'camera_uri': 'rtsp://192.168.35.225:1554/video/snap/Intrusion.264'
    },
    {
        'taskId': '4001-1',
        'event_type': '4001',
        'camera_uri': 'rtsp://192.168.35.225:1554/video/snap/Intrusion.264'
    },
    {
        'taskId': '4001-2',
        'event_type': '4001',
        'camera_uri': 'rtsp://192.168.35.225:1554/video/snap/Intrusion.264'
    },

]

data = {
    'userId': 'test',
    'secretId': '53bed29e1e434e8ab520b2e5f29f8b7e',
    'timestamp': '1641265514',
    'seqid': '1868b79be32744a79b7edfadd9d44d3a',
    'taskId': '3002-1',
    'event_type': '3002',
    'result_receiver': {'uri': 'http://192.168.102.157:20093/AI/Event', 'method': 'post',
                        'Type': 'HTTP'},
    'event_define_massage': {
        'alarm_start_time': '2022-01-01 00:00:00',
        'alarm_end_time': '2023-01-31 00:00:00'
    },
    'camera_config': {
        'camera_id': '01002000010000001301',
        'camera_uri': 'rtsp://192.168.35.225:1554/video/snap/FallDown.264',
    },
    'event_config': {
        'line': [573, 603, 1167, 600],
        'arrow': [846, 606, 867, 828],
        'warning_area': [{'x': 0, 'y': 0}, {'x': 1920, 'y': 0}, {'x': 1920, 'y': 1080}, {'x': 0, 'y': 1080}]
    },
    'threshold': 0.8,
    'alarm_rate': 10,
}

for i in tasks:
    data['taskId'] = i['taskId']
    data['event_type'] = i['event_type']
    data['camera_config'] = {
        'camera_uri': i['camera_uri'],
        'camera_id': i['taskId']
    }
    print(data)
    r = requests.post(url='http://127.0.0.1:7002/openapi/alarm_task/create_task', data=json.dumps(data))
    print(r.text)
