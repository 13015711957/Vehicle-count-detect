import base64

import requests

def image_to_base64(path):
    with open(path, 'rb') as img:
        # 使用base64进行编码
        b64encode = base64.b64encode(img.read())
        s = b64encode.decode()
        # 返回base64编码字符串
        return s
car_img = r"./img/car.jpeg"
car_img_base64=image_to_base64(car_img)
car_small_img = r"./img/car_small.jpg"
car_small_img_base64=image_to_base64(car_img)

person_img = r"./img/person.jpg"
person_img_base64=image_to_base64(person_img)
person_small_img = r"./img/person_small.jpg"
person_small_img_base64=image_to_base64(person_img)
data1 = {
    'code': 10000,
    'seqId': '2c85864f-f39e-4b39-a024-8ee4f0f0f1ef',
    'message': 'ok',
    'flag': 1,
    'data': {
        'taskId': 'test',
        'alarm_id': '57468f9b-d59a-4305-982c-4daee740bd61',
        'alarm_type': '80012',  # (80010-person 80011-vehicle 80012-non_motorized_vehicle)
        'alarm_time': '2023-01-30 16:53:47.263992',
        'camera_id': 't72',
        'image': car_img_base64,
        'alarm_detail': [{
            'objectId': '0c47d812-2bfb-4f4a-af75-774ecf30c108',
            'alarm_action_type': '80011',
            'score': 0.5,
            'bbox': [935.0, 273.0, 52.0, 146.0],
            'object_image': car_small_img_base64,
            'eventType': '80011',
            'alarm_message': '人车非解析',
            'attribute': [
                {'key': 'VehicleClass', 'value': 0},
                {'key': 'VehicleColor', 'value': 0},
                {'key': 'VehicleType', 'value': 0},
                {'key': 'VehicleDirection', 'value': 0},
                {'key': 'VehicleOcclusionDegree', 'value': 0},
                {'key': 'SpecialVehicleType', 'value': 0},
                {'key': 'DangerousVehicle', 'value': '0'},
                {'key': 'LicensePlate', 'value': '0'},
                {'key': 'VehicleRoof', 'value': '0'},
                {'key': 'VehicleSkylight', 'value': '0'},
                {'key': 'LicensePlateClass', 'value': '0'},
                {'key': 'PlateNumber', 'value': '闽A8098921'},
            ]
        }]
    }
}

data2 = {
    'code': 10000,
    'seqId': '2c85864f-f39e-4b39-a024-8ee4f0f0f1ef',
    'message': 'ok',
    'flag': 1,
    'data': {
        'taskId': 'test',
        'alarm_id': '57468f9b-d59a-4305-982c-4daee740bd61',
        'alarm_type': '9001',
        'alarm_time': '2023-01-16 16:53:47.263992',
        'camera_id': 't72',
        'image': person_img_base64,
        'alarm_detail': [{
            'objectId': '0c47d812-2bfb-4f4a-af75-774ecf30c108',
            'alarm_action_type': '9001',
            'score': 0.5,
            'bbox': [935.0, 273.0, 52.0, 146.0],
            'object_image': person_small_img_base64,
            'eventType': '9001',
            'alarm_message': '人脸解析',
            'attribute': [
                {'key': 'FaceClass', 'value': 1},
                {'key': 'Mask', 'value': 0.5},
                {'key': 'Glass', 'value': 0.5},
                {'key': 'SunGlass', 'value': 0.5},
                {'key': 'Age', 'value': 0.5},
                {'key': 'Male', 'value': 0.5},
                {'key': 'Hair', 'value': 1},
                {'key': 'Hat', 'value': 0},
            ]
        }]
    }
}

r = requests.post(url='http://192.168.102.157:20093/AI/Event', json=data2)
print(r.text)
