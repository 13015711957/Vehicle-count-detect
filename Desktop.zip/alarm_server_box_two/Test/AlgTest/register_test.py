# -*- encoding: utf-8 -*-
"""
@FileName ：alarm_delete_test.py
@Time ： 2021/8/27 16:28
@Auth ： Ying
"""
import sys
import os

sys.path.append("/home/face/projects/AIStreamPlatform")
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import requests
import json

data = {

    "code": 1009,
    "data": {
        "server_id": "1234"
    }

}
r = requests.post(url='http://192.168.102.157:7005/api/Register',data=json.dumps(data))
# r = requests.post(url='http://127.0.0.1:7005/api/Register', data=json.dumps(data))

print(r.text)
