# -*- encoding: utf-8 -*-
import sys
import os

import requests
import json

data = {
        'timestamp': '1641265514',
        'seqid': '1868b79be32744a79b7edfadd9d44d3a',
        }


r = requests.post(url='http://192.168.102.253:7002/openapi/get_version_info', data=json.dumps(data))
# r = requests.post(url='http://127.0.0.1:7005/openapi/get_version_info', data=json.dumps(data))
print(r.text)
