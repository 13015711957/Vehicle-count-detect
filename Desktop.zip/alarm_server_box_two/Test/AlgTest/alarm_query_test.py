# -*- encoding: utf-8 -*-
"""
@FileName ：alarm_query_test
@Time ： 2021/8/27 16:24
@Auth ： Ying
"""

import sys
import os

sys.path.append("/home/face/projects/AIStreamPlatform")
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import requests
import json

data = {
    'userId': 'test',
    'secretId': 'a455xcoc78d1',
    'timestamp': '1528787199',
    'seqid': '26f2739a-6e0f-11e8-bc7a-58fb8443ee27',
    'taskId': '110404_5003'
}

r = requests.post(url='http://192.168.102.157:7002/openapi/alarm_task/search_task', data=json.dumps(data))

print(r.text)
