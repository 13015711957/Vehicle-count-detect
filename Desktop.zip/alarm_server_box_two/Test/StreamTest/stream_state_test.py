# -*- encoding: utf-8 -*-
"""
@FileName ：alarm_query_test
@Time ： 2021/8/27 16:24
@Auth ： Ying
"""

import sys
import os
import time

sys.path.append("/home/face/projects/AIStreamPlatform")
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import requests
import json

data = {
        'timestamp': '1641265514',
        'seqid': '1868b79be32744a79b7edfadd9d44d3a',
        'camera_id': '7778',
        'camera_uri': 'rtsp://192.168.35.225:1554/video/snap/FallDown.264',
}

t1=time.time()
r = requests.post(url='http://192.168.102.253:7001/openapi/stream_task/state_stream',data=json.dumps(data))
print(time.time()-t1)
print(r.text)
