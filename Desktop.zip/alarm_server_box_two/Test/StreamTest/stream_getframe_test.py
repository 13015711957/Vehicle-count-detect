# -*- encoding: utf-8 -*-
import sys
import os

import requests
import json



data = {
        'video': 'rtsp://192.168.35.225:1554/video/wastebin_.264',
        }

# r = requests.post(url='http://127.0.0.1:7001/openapi/stream_task/create_stream', data=json.dumps(data))
r = requests.post(url='http://192.168.102.253:7001/openapi/get_video_frame', data=json.dumps(data))
print(r.text)

