# -*- encoding: utf-8 -*-
"""
@FileName ：alarm_delete_test.py
@Time ： 2021/8/27 16:28
@Auth ： Ying
"""
import sys
import os

import requests
import json
data={
        "timestamp": "1528787199",
        "seqid": "26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
        'camera_id': '7778'
}
r = requests.post(url='http://192.168.102.157:7001/openapi/stream_task/delete_stream',data=json.dumps(data))

print(r.text)
