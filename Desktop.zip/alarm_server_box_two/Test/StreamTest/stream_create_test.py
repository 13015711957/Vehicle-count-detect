# -*- encoding: utf-8 -*-
import sys
import os

import requests
import json



data = {'timestamp': '1641265514',
        'seqid': '1868b79be32744a79b7edfadd9d44d3a',
        'camera_id': '7778',
        'camera_uri': 'rtsp://192.168.35.225:1554/video/cross_intrusion.264',
        }

# r = requests.post(url='http://127.0.0.1:7001/openapi/stream_task/create_stream', data=json.dumps(data))
r = requests.post(url='http://192.168.102.157:7001/openapi/stream_task/create_stream', data=json.dumps(data))
print(r.text)
