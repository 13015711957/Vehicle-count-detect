import numpy as np
import pandas as pd


def preprocessing_data():
    '''
    处理excel
    获取qualityScore,similarity,hasMask,数据总数，是否正确
    转换成规定条件下的score,flags
    生成np格式的data
    '''
    score_list = [1,2,3,4,5,6,7,8,9,10]
    flags_list = [1,0,0,0,0,1,1,1,0,1]
    data = np.array([score_list, flags_list])
    return data

class CalculateROC():

    def __init__(self):
        pass

    @classmethod
    def CalculateROC(cls,threshold, data):
        pass



def test():
    # 计算方式，将prob从大到排列，prob = [0.9,0.8,0.7,0.3,0.2],对应
    # truth=[1,1,0,1,1],然后取prob的第一个元素到最后一个元素作为阀值，
    # 当大于这个阀值为正样本否则为负样本（如取0.9，则pred=[0,0,0,0,0]），
    # 构建混淆矩阵 计算 tpr = tp/(tp+fn) 和 fpr = fp/(fp+tn)
    import math
    import matplotlib.pyplot as plt
    from sklearn.metrics import roc_curve, auc, mean_squared_error, accuracy_score
    def Find_Optimal_Cutoff(TPR, FPR, threshold):
        y = TPR - FPR
        Youden_index = np.argmax(y)  # Only the first occurrence is returned.
        optimal_threshold = threshold[Youden_index]
        point = [FPR[Youden_index], TPR[Youden_index]]
        return optimal_threshold, point

    def check_fit(truth, prob):

        fpr, tpr, threshold = roc_curve(truth, prob)  # drop_intermediate:(default=True)
        optimal_th, optimal_point =  Find_Optimal_Cutoff(tpr, fpr, threshold)
        roc_auc = auc(fpr, tpr)  # 计算auc值，roc曲线下面的面积 等价于 roc_auc_score(truth,prob)
        # print(f'fpr:{fpr},tpr:{tpr}')

        z1 = np.polyfit(fpr, tpr, 3)  # 用3次多项式拟合，输出系数从高到0
        p1 = np.poly1d(z1)  # 使用次数合成多项式
        tpr_pre = p1(fpr)

        FP = [0.00001, 0.0001, 0.001, 0.01 ,0.1]
        TP = p1(FP)
        print(f'FP:{FP},TP:{TP}')

        plt.figure()
        plt.plot(fpr, tpr, color='darkorange', lw=2, label='ROC curve (area = %0.2f)' % roc_auc)
        plt.plot(fpr, tpr_pre)
        plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
        plt.xlim([-0.1, 1.05])
        plt.ylim([-0.1, 1.05])
        plt.xlabel('False Positive Rate')
        plt.ylabel('True Positive Rate')
        plt.title('Receiver operating characteristic example')
        plt.legend(loc="lower right")
        plt.show()

        print('results are RMSE, accuracy, ROC')
        predics = [1 if i >= 0.5 else 0 for i in prob]
        print(math.sqrt(mean_squared_error(truth, prob)), accuracy_score(truth, predics), roc_auc)
    import random
    prob = range(0, 1000, 1)
    truth = []
    for i in range(1000):
        truth.append(random.choice([0,1]))
    check_fit(truth=truth, prob=prob)

if __name__ == '__main__':
    # print(preprocessing_data())
    test()

