import json

import cv2
import numpy

from Common.RedisClient.redis_connecter import redis_PARAM
# redis_PARAM.hdel('task_args','722dd22feb9b49a28ebab0f50f395932')
args_dict={
    'userId': 'test',
    'secretId': '53bed29e1e434e8ab520b2e5f29f8b7e',
    'timestamp': '1641265514',
    'seqid': '1868b79be32744a79b7edfadd9d44d3a',
    'taskId': '1004',
    'event_type': '8001',
    'result_receiver': {'uri': 'http://192.168.102.253:20093/AI/Event', 'method': 'post',
                        'Type': 'HTTP'},
    'event_define_massage': {
        'alarm_start_time': '00:00:00',
        'alarm_end_time': '23:00:00'
    },
    'camera_config': {
        'camera_id': '01002000010000001301',
        'camera_uri': 'rtsp://192.168.35.225:1554/video/snap/SafetyHat.264',
    },
    'event_config': {
        'threshold': 0.8,
        'alarm_rate': 6,
        'line': [573, 603, 1167, 600],
        'arrow': [846, 606, 867, 828],
        'warning_area': [{'x': 0, 'y': 0}, {'x': 1920, 'y': 0}, {'x': 1920, 'y': 1080}, {'x': 0, 'y': 1080}],
        'effective_area': [{'x': 497, 'y': 330}, {'x': 984, 'y': 330}, {'x': 984, 'y': 714}, {'x': 497, 'y': 714}]
    },
    'threshold': 0.8,
    'alarm_rate': 10,
}


# redis_PARAM.hset('task_args', '1004', str(args_dict))
# p=redis_PARAM.hget('task_args', '1004')
# print(p)

# image=cv2.imread(r'E:\ffcs\code\alarm_server_box_test\Test\img\car.jpeg')
# image=image.tolist()
# redis_PARAM.set('testimg',str(image) )
#
#
# p=redis_PARAM.get('testimg')
# p=json.loads(p)
# p=numpy.array(p)
# cv2.imwrite(r'E:\ffcs\code\alarm_server_box_test\Test\img\car1.jpg',p)
redis_PARAM.set('testimg',str([1,2,'11']) )
p=redis_PARAM.get('testimg')
p=eval(p)
print(type(p[2]))