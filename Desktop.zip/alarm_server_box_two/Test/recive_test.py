
import requests
import json


def run ():
    url = "http://192.168.102.158:8003/BoxCallback"
    #data = {"taskId":"7c328519576b457aa33919f418d85e4b","image":"/9j/4A==","timestamp":1664418827320,"frameId":6348,"detection":[{"x0":1779,"y0":167,"x1":1965,"y1":392,"score":0,"classId":0,"moduleType":15},{"x0":1615,"y0":169,"x1":1999,"y1":781,"score":0,"classId":0,"moduleType":15},{"x0":377,"y0":12,"x1":1187,"y1":1114,"score":0,"classId":0,"moduleType":15},{"x0":563,"y0":1,"x1":790,"y1":110,"score":0,"classId":0,"moduleType":15},{"x0":1779,"y0":167,"x1":1965,"y1":392,"score":0,"classId":0,"moduleType":14},{"x0":1615,"y0":169,"x1":1999,"y1":781,"score":0,"classId":0,"moduleType":14},{"x0":377,"y0":12,"x1":1187,"y1":1114,"score":0,"classId":0,"moduleType":14},{"x0":563,"y0":1,"x1":790,"y1":110,"score":0,"classId":0,"moduleType":14}]}
    # data = json.loads('/opt/1665211931610.json')
    with open('/opt/1665211931610.json','r') as f:
        data = f.read()
    print(data)
    r = requests.post(url=url, data=json.dumps(data))
    return r.text
if __name__ == '__main__':
    print(run())
