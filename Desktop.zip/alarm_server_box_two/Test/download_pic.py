import base64
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from SYS import db_util
from Utils.image_util import base64_to_array
import cv2
from datetime import datetime


def select_scene_url():
    try:
        db_util.check_connect()
        sql = '''select scene_url
from T_alarminfo where  (create_time like "2022-06-07 13%"
or create_time like "2022-06-07 14%"
or create_time like "2022-06-07 15%"
or create_time like "2022-06-07 16%") and similarity = -1'''
        res = db_util.query(sql, 'all_dict')
        return res
    except Exception as e:
        import traceback
        traceback.print_exc()

def url_to_base64(image_url):
    import os, base64
    import requests as req
    from PIL import Image
    from io import BytesIO
    # 将这个图片保存在内存
    response = req.get(image_url)
    image = Image.open(BytesIO(response.content))
    image_base64 = base64.b64encode(BytesIO(response.content).read())
    # 打印出这个base64编码
    print(len(image_base64))
    return image_base64

def main():
    urls = select_scene_url()
    print(urls)
    for scene_url in urls:
        filename = scene_url.split('/')[-1]
        print(filename)
        imgb64 = url_to_base64(scene_url)
        imgarry = base64_to_array(imgb64)
        cv2.imwrite(filename=filename,img=imgarry)

if __name__ == '__main__':
    main()