import cv2
camera_uri='rtsp://192.168.35.225:1554/video/snap/FallDown.264'
camera = cv2.VideoCapture(camera_uri)
print(f'打开视频流{camera_uri}')
try:
    ret, frame = camera.read()
    print(ret)

except Exception as e:
    print(e)
finally:
    # 释放资源
    camera.release()
