import cv2

# x0, y0, x1, y1 = [861,35,888,66]
image=cv2.imread(r"E:\ffcs\code\alarm_server_box_test\Test\img\11.jpg")
target_area = [[598, 121], [966, 121], [966, 702], [598, 702]]
target_area = [[990, 222], [802, 828] ]
# target_area = [[1129, 593], [1141, 1081], [618, 1080], [778, 448],[878, 8],[1087, 11]]
for i in range(len(target_area)):
    x0, y0 = target_area[i]
    x1, y1 = target_area[(i + 1) % len(target_area)]
    cv2.line(image, (x0, y0), (x1, y1), (0, 255, 255), thickness=4)
thickness = 2
color = (0, 255, 0)
bbox = [861,35, 26, 30]
x, y, w, h = bbox
x0, y0, x1, y1 = x, y, x + w, y + h
# cv2.rectangle(image, (x0, y0), (x1, y1), color, thickness=thickness)

cv2.imwrite(r'E:\ffcs\code\alarm_server_box_test\Test\img\2.jpg',image)