# -*-coding:UTF-8 -*-

import socket
import time
import base64
import cv2
import json
import numpy


from multiprocessing import Process


def handle_client(client_socket):
    """
    处理客户端请求
    """
    # request_data = b''
    # while True:
    #     data = client_socket.recv(65536)
    #     if len(data) > 0:
    #         request_data += data
    #     else:
    #         break

    # print("request data:", request_data)
    output_file_path = f"output/recv_{time.time()}.json"
    with open(output_file_path, "wb") as fp:
        while True:
            response = client_socket.recv(65536)
            if len(response) > 0:
                fp.write(response)
                if response[-1] == 10:
                    break
            else:
                break

    response = json.loads(open(output_file_path, 'r').readlines()[-1])
    data = response['data']
    print(data)
    # alarm_detail = data['alarm_detail']
    # bbox = alarm_detail["bbox"]
    # image = data["image"]
    # raw_pic_buf = base64.b64decode(image)
    # nparr = numpy.frombuffer(raw_pic_buf, numpy.uint8)
    # cv_mat_image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
    # x = int(bbox[0])
    # y = int(bbox[1])
    # w = int(bbox[2])
    # h = int(bbox[3])
    # cv2.rectangle(cv_mat_image, (x, y), (x + w, y + h), (0, 0, 255), 2)
    # cv2.putText(cv_mat_image, str(data['alarm_time']), (x, y), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255))
    # cv2.imshow("base64", cv_mat_image)
    # cv2.waitKey(1000)
    # open(debug_pic_path, 'wb').write(base64.b64decode(object_image))

    # 构造响应数据
    response_start_line = "HTTP/1.1 200 OK\r\n"
    response_headers = "Server: My server\r\n"
    response_body = "<h1>OK</h1>"
    response = response_start_line + response_headers + "\r\n" + response_body

    # 向客户端返回响应数据
    client_socket.send(bytes(response, "utf-8"))

    # 关闭客户端连接
    client_socket.close()
    print("Close")


if __name__ == "__main__":
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(("", 8003))
    server_socket.listen(128)

    while True:
        client_socket, client_address = server_socket.accept()
        print("[%s, %s]用户连接上了" % client_address)
        handle_client_process = Process(target=handle_client, args=(client_socket,))
        handle_client_process.start()
        client_socket.close()


