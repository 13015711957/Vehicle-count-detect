# -*-coding:utf-8 -*-

"""
# Project    : AIStreamPlatform
# File       : AlarmSearch.py
# Time       ：2021/8/25 16:39
# Author     ：zhengqx
# Description：
"""
import base64
import json
import os
import traceback
import uuid

import requests

from Dao.Alg_info import select_alg_info
from SYS import conf



class GetVersion(object):
    @classmethod
    def run(cls, args_dict):
        res = {
            'ability_info': {},
            'alg_info': {}
        }
        try:
            ability_info = []
            res_info = select_alg_info()
            if res_info:
                for each in res_info:
                    # img_url = r'E:\ffcs\code\box_alarm_server0930\docs/' + each['img_url'].split('/')[-1]
                    img_url = each['img_url']
                    with open(img_url, 'rb') as f:
                        img = base64.b64encode(f.read())
                        img = str(img, 'utf-8')
                    ability_info.append({
                        'name': each['name'],
                        'algo_id': each['algo_id'],
                        'describe': each['describe'],
                        'img_b64': img
                    })
                data = {
                    'code': 1017,
                    'data': {}
                }
                try:
                    r = requests.post(url=conf.get('Box', 'get_all_AlgoVersion'), json=data)

                    r = json.loads(r.text)
                    print(r)
                    if r['code'] == 1018:
                        alg_info = r['data']
                    else:
                        alg_info = {}
                except Exception as e:
                    import traceback
                    traceback.print_exc()
                    alg_info = ''

                res['ability_info'] = ability_info
                res['alg_info'] = alg_info

        except Exception as e:
            import traceback
            traceback.print_exc()
            # raise Exception(e)
        finally:
            return res


if __name__ == '__main__':
    args_dict = {
        'userId': 'test',
        'secretId': '53bed29e1e434e8ab520b2e5f29f8b7e',
        'timestamp': '1641265514',
        'seqid': '1868b79be32744a79b7edfadd9d44d3a',

    }

    print(GetVersion.run(args_dict))
