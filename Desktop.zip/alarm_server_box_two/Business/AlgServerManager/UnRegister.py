# -*-coding:utf-8 -*-

"""
# Project    : AIStreamPlatform
# File       : UnRegister.py
# Time       ：2021/8/25 16:39
# Author     ：zhengqx
# Description：
"""
import json

import requests
from Dao.S_server_online import delete_server_online
from Dao.S_server_task import select_server_task_serverid
from SYS import conf


class UnRegister(object):
    @classmethod
    def run(cls, args_dict):

        try:
            data = args_dict.get('data', dict())
            server_id = data.get('server_id')
            delete_server_online(server_id)
            r = select_server_task_serverid(server_id)
            for i in r:
                task_id = i['task_id']
                data = {
                    "userId": "test",
                    "secretId": "53bed29e1e434e8ab520b2e5f29f8b7e",
                    "timestamp": "1528787199",
                    "seqid": "26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
                    "taskId": task_id
                }
                result = requests.post(url='http://127.0.0.1:7002/openapi/alarm_task/delete_task',
                                  data=json.dumps(data))

            res = {'code': 1012, 'data': {}}
        except Exception as e:
            res = {"code": 1012, "data": str(e)}
        finally:
            return res

if __name__ =='__main__':
    arg_dict = {
    'userId':'test',
    'secretId':'a455xcoc78d1',
    'Timestamp':'1528787199',
    'seqid':'26f2739a-6e0f-11e8-bc7a-58fb8443ee27',
    'taskId':'190'
}
    print(UnRegister.run(arg_dict))