# -*-coding:utf-8 -*-

"""
# Project    : AIStreamPlatform
# File       : HeartBeat.py
# Time       ：2021/8/25 16:39
# Author     ：zhengqx
# Description：
"""
import json
import uuid

import requests

from Business.ALL_BUISS_CODE import ALG_API_CODE
from Dao.S_server_online import update_server_online_time, update_server_online_state
from Dao.S_server_task import select_server_task_serverid, delete_server_task_id
from SYS import conf


class HeartBeat(object):
    @classmethod
    def run(cls, args_dict):

        try:
            data = args_dict.get('data', dict())
            server_id = data.get('server_id')
            update_server_online_time(server_id)
            update_server_online_state(server_id, 1)
            db_res = select_server_task_serverid(server_id)
            # print(db_res)
            for each in db_res:
                task_id = each['task_id']
                req_data = {
                    "code": ALG_API_CODE.SELECT_TASK_STATE_REQUEST,  # 1005
                    "data": {
                        "task_id": task_id
                    }
                }
                try:
                    r = requests.post(url=conf.get('Box', 'search_task_url'), json=req_data)
                    r = json.loads(r.text)
                    print(r)
                except Exception as e:
                    print('查询算法服务失败:', e)
                    continue

                status = r['data']['pipeline_status']
                if status == 1:
                    post_data = {
                        "code": 10000,
                        "seqId": str(uuid.uuid4()),
                        "message": "ok",
                        "flag": 1,
                        "data": {
                            "taskId": task_id
                        }
                    }
                    try:
                        result = requests.post(url=conf.get('Box', 'heart_url'), json=post_data, timeout=1)
                        result = json.loads(result.text)
                        print(result)
                    except Exception as e:
                        print('发送心跳失败:', e)
                    print(post_data)

            res = {'code': 1014, 'data': {}}
        except Exception as e:
            res = {"code": 0, "data": str(e)}

        finally:
            return res


if __name__ == '__main__':
    arg_dict = {
        'userId': 'test',
        'secretId': 'a455xcoc78d1',
        'Timestamp': '1528787199',
        'seqid': '26f2739a-6e0f-11e8-bc7a-58fb8443ee27',
        'taskId': '110404_5003'
    }
    print(HeartBeat.run(arg_dict))
