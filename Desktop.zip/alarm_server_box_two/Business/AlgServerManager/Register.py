# -*-coding:utf-8 -*-

"""
# Project    : AIStreamPlatform
# File       : Register.py
# Time       ：2021/8/25 16:39
# Author     ：zhengqx
# Description：
"""
from Dao.S_server_online import insert_server_online, select_server_online_serverid, delete_server_online


class Register(object):
    @classmethod
    def run(cls, args_dict):

        try:
            data = args_dict.get('data', dict())
            server_id = data.get('server_id')
            r = select_server_online_serverid(server_id)
            if len(r) > 0:
                print('server_id已注册')
                delete_server_online(server_id)
            insert_server_online(server_id)
            res = {'code': 1010, 'data': {}}
        except Exception as e:
            import traceback
            traceback.print_exc()
            res = {"code": 0, "data": str(e)}
        finally:
            return res


if __name__ == '__main__':
    arg_dict = {
        'userId': 'test',
        'secretId': 'a455xcoc78d1',
        'Timestamp': '1528787199',
        'seqid': '26f2739a-6e0f-11e8-bc7a-58fb8443ee27',
        'taskId': '190'
    }
    print(Register.run(arg_dict))
