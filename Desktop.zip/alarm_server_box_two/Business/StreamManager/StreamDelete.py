# -*-coding:utf-8 -*-

"""
# Project    : AIStreamPlatform
# File       : StreamSearch.py
# Time       ：2021/8/25 16:39
# Author     ：zhengqx
# Description：
"""
import json
import traceback

import requests
from SYS import conf
from Dao.T_task_info import delete_t_task_info


# from AlgorithmAbility.IVMStreamManager import IVMStreamManager

class StreamDelete(object):
    @classmethod
    def run(cls, args_dict):
        try:
            timestamp = args_dict['timestamp']
            seqid = args_dict['seqid']
            camera_id = args_dict.get('camera_id')
            data = {
                'secret': '035c73f7-bb6b-4889-a715-d9eb2d1925cc',
                'key': '__defaultVhost__/live/' + camera_id
            }
            r = requests.post(url=conf.get('Box', 'delStreamProxy_url'), data=data)
            r = json.loads(r.text)
            print(seqid,r)
            return r
        except Exception as e:
            traceback.print_exc()
            res = {"code": -1, "message": str(e)}
            return res


if __name__ == '__main__':
    arg_dict = {
        "timestamp": "1528787199",
        "seqid": "26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
        'camera_id': '01002000010000001301'

    }
    StreamDelete.run(arg_dict)
