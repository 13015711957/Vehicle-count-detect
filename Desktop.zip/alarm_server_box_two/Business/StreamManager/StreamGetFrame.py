# -*-coding:utf-8 -*-

"""
# Project    : AIStreamPlatform
# File       : AlarmSearch.py
# Time       ：2021/8/25 16:39
# Author     ：zhengqx
# Description：
"""
import json
from datetime import datetime

import cv2
import requests
from SYS import conf
from Utils.image_util import array_to_base64


class StreamGetFrame(object):
    @classmethod
    def run(cls, args_dict):
        data = {
            'data': '',
            'height': 0,
            'width': 0
        }
        url = args_dict['video']
        camera = cv2.VideoCapture(url)
        print(f'打开视频流{url}')
        imgb64 = 0
        h = w = 0
        try:
            ret, frame = camera.read()
            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            h, w, _ = frame.shape
            print(h, w)
            imgb64 = array_to_base64(frame)
        except Exception as e:
            import traceback
            traceback.print_exc()
        finally:
            # 释放资源
            camera.release()

        data = {
            'data': imgb64,
            'height': h,
            'width': w
        }

        return data


if __name__ == '__main__':
    arg_dict = {
        'timestamp': '1641265514',
        'seqid': '1868b79be32744a79b7edfadd9d44d3a',
        'camera_id': '01002000010000001301',
        'camera_uri': 'rtsp://admin:aiNewBee666@192.168.102.254:554',
    }
    print(StreamGetFrame.run(arg_dict))
