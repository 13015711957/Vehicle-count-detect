# -*-coding:utf-8 -*-

"""
# Project    : AIStreamPlatform
# File       : AlarmSearch.py
# Time       ：2021/8/25 16:39
# Author     ：zhengqx
# Description：
"""
import json
from datetime import datetime

import cv2
import requests
from SYS import conf


class StreamState(object):
    @classmethod
    def run(cls, args_dict):

        timestamp = args_dict['timestamp']
        seqid = args_dict['seqid']
        camera_id = args_dict.get('camera_id')
        camera_uri = args_dict.get('camera_uri')
        camera = cv2.VideoCapture(camera_uri)
        print(f'打开视频流{camera_uri}')
        online = 0
        try:
            # ret, frame = camera.read()
            # if ret:
            #     online = 1
            isopen = camera.isOpened()
            if isopen:
                online = 1
        except Exception as e:
            print(e)
        finally:
            # 释放资源
            camera.release()

        res_data = {
            'online': online,
            'uri': camera_uri
        }
        r = {
            'code': 0,
            'res_data': res_data
        }

        return r


if __name__ == '__main__':
    arg_dict = {
        'timestamp': '1641265514',
        'seqid': '1868b79be32744a79b7edfadd9d44d3a',
        'camera_id': '01002000010000001301',
        'camera_uri': 'rtsp://admin:aiNewBee666@192.168.102.254:554',
    }
    print(StreamState.run(arg_dict))
