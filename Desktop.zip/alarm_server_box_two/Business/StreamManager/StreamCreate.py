# -*-coding:utf-8 -*-

"""
# Project    : AIStreamPlatform
# File       : AlarmSearch.py
# Time       ：2021/8/25 16:39
# Author     ：zhengqx
# Description：
"""
import json
import time
import traceback
import uuid

import requests
from SYS import conf


def is_online(camera_id):
    data = {
        'secret': '035c73f7-bb6b-4889-a715-d9eb2d1925cc',
        'vhost': '__defaultVhost__',
        'app': 'live',
        'schema': 'rtsp',
        'stream': camera_id,
    }
    res = requests.post(url=conf.get('Box', 'isMediaOnline_url'), data=data)
    res = json.loads(res.text)
    print(res)
    if res['code'] == 0:
        if res['online']:
            return 1
        else:
            return 0
    else:
        return 0


class StreamCreate(object):
    @classmethod
    def run(cls, args_dict):
        try:

            timestamp = args_dict['timestamp']
            seqid = args_dict['seqid']
            camera_id = args_dict.get('camera_id')
            camera_uri = args_dict.get('camera_uri')
            # if is_online(camera_id):
            #     try:
            #         data = {
            #             'secret': '035c73f7-bb6b-4889-a715-d9eb2d1925cc',
            #             'key': '__defaultVhost__/live/' + camera_id
            #         }
            #         r = requests.post(url=conf.get('Box', 'delStreamProxy_url'), data=data)
            #         r = json.loads(r.text)
            #     except:
            #         pass

            data = {
                'secret': '035c73f7-bb6b-4889-a715-d9eb2d1925cc',
                'vhost': '__defaultVhost__',
                'app': 'live',
                'stream': camera_id,
                'url': camera_uri,
                'enable_hls': 0,
                'enable_mp4': 0,
                'enable_rtsp': 1,
                'enable_rtmp': 1,
                'enable_ts': 0,
                'enable_fmp4': 0,
                'enable_audio': 0,
            }
            r = requests.post(url=conf.get('Box', 'addStreamProxy_url'), data=data)
            r = json.loads(r.text)
            print('====post_res', seqid, r)
            time.sleep(2)
            if r['code'] == 0:
                # http://192.168.102.157/live/test3.live.flv
                data = {
                    'secret': '035c73f7-bb6b-4889-a715-d9eb2d1925cc',
                    'vhost': '__defaultVhost__',
                    'app': 'live',
                    'schema': 'rtsp',
                    'stream': camera_id,
                }
                res = requests.post(url=conf.get('Box', 'isMediaOnline_url'), data=data)
                res = json.loads(res.text)
                print(res)
                if res['code'] == 0:
                    if res['online']:

                        flv_uri = '/live/' + camera_id + '.live.flv'
                        print(flv_uri)
                        res_data = {
                            'camera_id': camera_id,
                            'rtsp_uri': camera_uri,
                            'flv_uri': flv_uri
                        }
                        r['res_data'] = res_data
                        return r
                    else:
                        return {'code': -1, 'msg': '流绑定失败,请检查流地址是否正确或可用'}
                else:
                    return {'code': -1, 'msg': '流绑定失败,请求流媒体服务失败'}
            else:
                data = {
                    'secret': '035c73f7-bb6b-4889-a715-d9eb2d1925cc',
                    'key': '__defaultVhost__/live/' + camera_id
                }
                d_r = requests.post(url=conf.get('Box', 'delStreamProxy_url'), data=data)
                d_r = json.loads(d_r.text)
                print(d_r)
                return r

        except Exception as e:
            traceback.print_exc()
            return {'code': -1, 'msg': str(e)}


if __name__ == '__main__':
    args_dict = {

        'timestamp': '1641265514',
        'seqid': '1868b79be32744a79b7edfadd9d44d3a',
        'camera_id': '8877',
        'camera_uri': 'rtsp://192.168.35.200/show_video/CrossBorder.264',

    }
    StreamCreate.run(args_dict)
