import json

import requests

from Business.ALL_BUISS_CODE import ALG_API_CODE
from SYS import conf


def create_task(taskUUID, event_type, event_config, camera_uri):
    url = conf.get('Box', 'create_task_url')
    capture_mode = event_config.get('capture_mode', 1)
    warning_area = event_config.get('warning_area', [])
    if event_type == '4001':
        line = event_config.get('line', [0, 0, 0, 0])
        arrow = event_config.get('arrow', [0, 0, 0, 0])
        warning_area = [
            {'x': line[0], 'y': line[1]},
            {'x': line[2], 'y': line[3]},
            {'x': arrow[0], 'y': arrow[1]},
            {'x': arrow[2], 'y': arrow[3]}
        ]
    data = {
        'code': ALG_API_CODE.CREATE_TASK_REQUEST,  # 1001
        'data': {
            'taskId': taskUUID,
            'algoTasks': [{
                'algoTask': int(event_type),
                'algoConfig': {
                    'roi': [{
                        'regionId': 0,
                        'warningArea': warning_area
                    }],
                    'captureMode': capture_mode
                }
            }],
            'url': camera_uri,
        }
    }
    print('request_data:', data)
    result = requests.post(url=url, json=data, timeout=30)
    result = json.loads(result.text)
    return result


def delete_task(taskUUID):
    url = conf.get('Box', 'delete_task_url')
    req_data = {
        "code": ALG_API_CODE.DELETE_TASK_REQUEST,  # 1003
        "data": {
            "taskId": taskUUID
        }
    }
    result = requests.post(url=url, json=req_data, timeout=30)
    result = json.loads(result.text)
    return result


def search_task(taskUUID):
    url = conf.get('Box', 'search_task_url')
    req_data = {
        "code": ALG_API_CODE.DELETE_TASK_REQUEST,  # 1003
        "data": {
            "taskId": taskUUID
        }
    }
    result = requests.post(url, json=req_data, timeout=30)
    result = json.loads(result.text)
    return result


def get_task_state(taskUUID):
    r = search_task(taskUUID)
    if r and r['code'] == ALG_API_CODE.SELECT_TASK_STATE_RESPONSE:  # 1006
        state = r['data']['pipeline_status']
    else:
        state = 0
    return state


if __name__ == '__main__':
    get_task_state('1111')
