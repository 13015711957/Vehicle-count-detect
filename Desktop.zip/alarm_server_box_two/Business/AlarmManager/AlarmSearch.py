# -*-coding:utf-8 -*-

from Business.ALL_BUISS_CODE import ALG_API_CODE
from Business.aiServerRequest import  search_task

class AlarmSearch(object):
    @classmethod
    def run(cls, args_dict):

        try:
            taskUUID = args_dict.get("taskId")
            r = search_task(taskUUID)
            print('===search_res', r)
            if r and r['code'] == ALG_API_CODE.SELECT_TASK_STATE_RESPONSE:  # 1006
                return r['data']
            else:
                raise Exception(r.get('msg', '算法服务调用失败'))
        except Exception as e:
            raise Exception(r.get('msg', str(e)))


if __name__ == '__main__':
    arg_dict = {
        'userId': 'test',
        'secretId': 'a455xcoc78d1',
        'Timestamp': '1528787199',
        'seqid': '26f2739a-6e0f-11e8-bc7a-58fb8443ee27',
        'taskId': '110404_5003'
    }
    print(AlarmSearch.run(arg_dict))
