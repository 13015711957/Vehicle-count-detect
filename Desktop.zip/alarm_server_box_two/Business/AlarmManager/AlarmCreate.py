# -*-coding:utf-8 -*-

"""
# Project    : AIStreamPlatform
# File       : AlarmSearch.py
# Time       ：2021/8/25 16:39
# Author     ：zhengqx
# Description：
"""
import json
import traceback
import uuid
import random
from datetime import datetime

import requests

from Business.AlarmManager.AlarmDelete import AlarmDelete
from Business.aiServerRequest import get_task_state, create_task
from Dao.S_server_online import select_server_online_state
from Dao.S_server_task import insert_server_task, delete_server_task_id
from SYS import conf
from Dao.T_task_info import insert_t_task_info, select_t_task_info, delete_t_task_info
from Common.RedisClient.redis_connecter import redis_DATA, redis_PARAM
from Business.ALL_BUISS_CODE import ALG_API_CODE

search_task_url = conf.get('Box', 'search_task_url')


class AlarmCreate(object):
    @classmethod
    def run(cls, args_dict):

        try:
            online_server = select_server_online_state(state=1)
            if not online_server:
                res = {"code": -1, "message": '无可用算法服务'}
                return res

            server_id = random.choice(online_server)['server_id']
            userId = args_dict['userId']
            secretId = args_dict['secretId']
            timestamp = args_dict['timestamp']
            seqid = args_dict['seqid']
            taskUUID = args_dict['taskId']
            now = datetime.now()
            print("*" * 30)
            print("请求时间:{} task_id:{}".format(now, taskUUID))
            event_type = args_dict['event_type']
            event_define_massage = args_dict['event_define_massage']
            if event_define_massage:
                alarm_start_time = event_define_massage.get('alarm_start_time')
                alarm_end_time = event_define_massage.get('alarm_end_time')
            result_receiver = args_dict.get('result_receiver', None)
            if result_receiver:
                res_type = result_receiver.get('type')
                uri = result_receiver.get('uri')
                method = result_receiver.get('method')
            camera_config = args_dict['camera_config']
            if camera_config:
                camera_id = camera_config.get('camera_id')
                camera_uri = camera_config.get('camera_uri')
            event_config = args_dict['event_config']
            if not event_config:
                event_config = {}

            threshold = event_config.get('threshold', 0)
            alarm_rate = event_config.get('alarm_rate', 10)
            min_face_size = event_config.get('min_face_size', [100, 100])
            min_body_size = event_config.get('min_body_size', [100, 44])
            capture_mode = event_config.get('capture_mode', 1)
            have_image = event_config.get('have_image', 0)
            sub_event_type = event_config.get('sub_event_type', None)

            if get_task_state(taskUUID) == 1:
                del_data = {
                    "userId": "test",
                    "secretId": "53bed29e1e434e8ab520b2e5f29f8b7e",
                    "timestamp": "1528787199",
                    "seqid": "26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
                    "taskId": taskUUID
                }
                AlarmDelete.run(del_data)
            r = create_task(taskUUID, event_type, event_config, camera_uri)
            # r = {'code':1002,'data':{'taskCode':0,'msg':'创建成功'}}
            print('====create_task_res', taskUUID, r)
            if r['code'] == ALG_API_CODE.CREATE_TASK_RESPONSE:  # 1002
                task_code = r['data'].get('task_code')
                if task_code == 0:
                    # taskID唯一性
                    res = select_t_task_info(taskUUID)
                    print('search task res', res)
                    if res:
                        delete_t_task_info(taskUUID)
                        delete_server_task_id(taskUUID)
                    insert_t_task_info(taskUUID, userId, seqid, event_type, event_define_massage, result_receiver,
                                       camera_config, event_config, threshold, alarm_rate)
                    insert_server_task(server_id, taskUUID)
                    redis_PARAM.hset('task_args', str(taskUUID), str(args_dict))
                    res = {"code": 0, "message": r['data']}

                else:
                    res = {"code": -1, "message": r['data']}
            else:
                res = {"code": -1, "message": r['data']}
        except Exception as e:
            traceback.print_exc()
            res = {"code": -1, "message": str(e)}
        finally:
            return res


if __name__ == '__main__':
    args_dict = {
        'userId': 'test',
        'secretId': '53bed29e1e434e8ab520b2e5f29f8b7e',
        'timestamp': '1641265514',
        'seqid': '1868b79be32744a79b7edfadd9d44d3a',
        'taskId': '12',
        'event_type': '4001',
        'result_receiver': {'uri': 'http://192.168.254.16:18080/ptService/alarmTask/getResult', 'method': 'post',
                            'Type': 'HTTP'},
        'event_define_massage': {
            'alarm_start_time': '2022-01-01 00:00:00',
            'alarm_end_time': '2022-01-31 00:00:00'
        },
        'camera_config': {
            'camera_id': '01002000010000001301',
            'camera_uri': 'rtsp://192.168.35.225:1554/video/CrossBorder.264',
        },
        'event_config': '',
        'threshold': 0.8,
        'alarm_rate': 10,
    }

    print(AlarmCreate.run(args_dict))
