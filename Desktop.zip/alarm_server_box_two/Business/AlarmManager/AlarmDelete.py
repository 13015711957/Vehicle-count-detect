# -*-coding:utf-8 -*-

"""
# Project    : AIStreamPlatform
# File       : AlarmSearch.py
# Time       ：2021/8/25 16:39
# Author     ：zhengqx
# Description：
"""
import json
from datetime import datetime

import requests

from Business.ALL_BUISS_CODE import ALG_API_CODE
from Business.aiServerRequest import delete_task
from Common.RedisClient.redis_connecter import redis_PARAM, redis_DATA
from Dao.S_server_task import delete_server_task_id
from SYS import conf
from Dao.T_task_info import delete_t_task_info


class AlarmDelete(object):
    @classmethod
    def run(cls, args_dict):
        try:
            taskUUID = args_dict.get("taskId")
            now = datetime.now()
            print("*" * 30)
            print("请求时间:{} task_id:{}".format(now, taskUUID))
            r = delete_task(taskUUID)
            task_args = redis_PARAM.hget('task_args', str(taskUUID))
            task_args = eval(task_args)
            event_type = task_args.get('event_type')
            camera_config = task_args.get('camera_config')
            camera_id = camera_config.get('camera_id')
            # r = {'code': 1002, 'data': {'taskCode': 0, 'msg': '删除成功'}}
            print('===delete_task_res', r)
            if r and r['code'] == ALG_API_CODE.DELETE_TASK_RESPONSE:  # 1004
                task_code = r['data'].get('task_code')
                if task_code == 0:
                    delete_t_task_info(taskUUID)
                    delete_server_task_id(taskUUID)
                    redis_PARAM.hdel('task_args', str(taskUUID))
                    redis_DATA.delete('{}_{}'.format(camera_id, event_type))
                    res = {"code": 0, "message": r['data']}
                else:
                    res = {"code": -1, "message": r['data']}
            else:
                raise Exception(r.get('msg', ''))
        except Exception as e:
            import traceback
            traceback.print_exc()
            res = {"code": 0, "message": str(e)}
        finally:
            print(res)
            return res


if __name__ == '__main__':
    arg_dict = {
        "userId": "test",
        "secretId": "53bed29e1e434e8ab520b2e5f29f8b7e",
        "timestamp": "1528787199",
        "seqid": "26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
        "taskId": "10"
    }
    AlarmDelete.run(arg_dict)
