class PROJECT:
    ID = '101'


class FILETYPE:
    IMAGE = '01'
    VIDEO = '02'


class ALARM_TYPE:
    ALARM_FACE_MON = '1001001'
    ALARM_CAR_MON = '1005001'
    ALARM_KIT_MON = '1006001'
    ALARM_KIT_MON_HAT = '1002002'
    ALARM_KIT_MON_MASK = '1002001'
    ALARM_KIT_MON_MOUSE = '1004003'


class SCENE_TYPE:
    SCENE_MON_FACE = '001'
    SCENE_MON_CAR = '002'
    SCENE_MON_KIT = '003'


class Factory_Event_TYPE:
    EVENT_FACE_MON = '1'
    EVENT_CAR_MON = '2'
    EVENT_KIT_MON = '3'


class Factory_Ada_TYPE:
    ADA_YITU_VIDEO = '1'
    ADA_AI_VIDEO = '2'


class Factory_Alarm_TYPE:
    ALARM_HTTP = '1'


class white_black_face:
    WHITE_FACE = '0'
    BLACK_FACE = '1'
    OTHER = '2'


class QUEUE_TYPE:
    CREATE_TASK = '0'
    DELETE_TASK = '1'
    SEARCH_TASK = '2'
    UPDATE_TASK = '3'


class INTERFACE_TYPE:
    CAMERA_CREATE = '0'
    CAMERA_DELETE = '1'
    CAMERA_SEARCH = '2'
    ALARM_CREATE = '3'
    ALARM_DELETE = '4'
    ALARM_SEARCH = '5'


class TASK_TYPE:
    STRUCTRED_TASK = 1
    ALARM_TASK = 2


class STATUS:
    RUN = 1
    WAIT = 0
    STOP = 2
    ERROR = 3
    FINISH = 4
    INSPECT = 5


class EVENT_CODE:
    FACE_MONITOR = '2002010'  # 人脸布控
    ACCESS_DISCERN = '2002015'  # 进出识别
    AREA_INTRUSION = '2002014'  # 区域入侵
    RISK_DISCERN = '2002001'  # 危险行为
    PERSON_STAY = '2002011'  # 人员停留
    AREA_COUNT = '2002007'  # 区域人数统计（人员聚集）
    FLOW_STATISTICS = '2002006'  # 客流统计
    PERSONNEL_ACCESS = '2002021'  # 人员进出
    VEHICLE_ACCESS = '2002022'  # 车辆进出
    EQUIPMENT_INSPECTION = '3001001'  # 设备巡检


class ALG_API_CODE:
    CREATE_TASK_REQUEST = 1001  # 创建任务请求包
    CREATE_TASK_RESPONSE = 1002  # 创建任务响应包
    DELETE_TASK_REQUEST = 1003  # 删除任务请求包
    DELETE_TASK_RESPONSE = 1004  # 删除任务响应包
    SELECT_TASK_STATE_REQUEST = 1005  # 查询任务状态请求包
    SELECT_TASK_STATE_RESPONSE = 1006  # 查询任务状态响应包
    ALG_INFO_UP_REQUEST = 1007  # 算法结构化信息上报
    ALG_INFO_UP_RESPONSE = 1008  # 算法结构化信息上报响应包
    REGISTER_REQUEST = 1009  # 注册请求
    REGISTER_RESPONSE = 1010  # 注册响应
    LOGOFF_REQUEST = 1011  # 注销请求
    LOGOFF_RESPONSE = 1012  # 注销响应

