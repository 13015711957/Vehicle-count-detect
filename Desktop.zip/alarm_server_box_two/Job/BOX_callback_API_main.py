from sanic import Sanic
from sanic.response import json as sanicjson
import sys
import os

import cv2

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import json
import uuid
import traceback
import requests
from datetime import datetime, timedelta
import time
from Utils.image_util import img_cut, base64toarray, array_to_base64
from Dao.T_alarminfo import insert_t_alarminfo
from Common.RedisClient.redis_connecter import redis_DATA, redis_PARAM
from AlgorithmAbility.AlgorithmManager import alg_manager_handle
from copy import deepcopy
from Utils.iou_util import is_in_poly

app = Sanic("BoxCallBackApp")


def save_img(data):
    image = data['image']
    img1 = data['alarm_detail'][0]['object_image']
    image = base64toarray(image)
    img1 = base64toarray(img1)
    path = os.path.join('/project/testimg', data['alarm_type'])
    if not os.path.exists(path):
        print('####新建文件夹: ', path)
        os.makedirs(path)
    # if data['alarm_type'] == '4001':
    #     cv2.line(image, (492, 197), (691, 407), color=(255, 0, 0), thickness=5)
    img_name = data['alarm_id'] + '.jpg'
    img_cut_name = data['alarm_id'] + '_cut.jpg'
    cv2.imwrite(os.path.join(path, img_name), image)
    cv2.imwrite(os.path.join(path, img_cut_name), img1)


def is_in_alarmtime(start_time, end_time):
    if start_time is None or end_time is None:
        return True
    if start_time == '' or end_time == '':
        return True
    dt1 = datetime.strptime(start_time, "%H:%M:%S")
    dt2 = datetime.strptime(end_time, "%H:%M:%S")
    dt3 = datetime.now().strftime("%H:%M:%S")
    dt3 = datetime.strptime(dt3, "%H:%M:%S")
    if (dt1 - dt3).days < 0 and (dt3 - dt2).days < 0:
        return True
    else:
        return False


def is_alarm_time(task_id, alarm_rate, alarm_start_time, alarm_end_time):
    last_alarm_time = redis_DATA.hget('Box_alarm_time', '{}'.format(task_id))
    if not last_alarm_time:
        last_alarm_time = '0'
    now_time = time.time()
    print(now_time - eval(last_alarm_time))
    if abs(now_time - eval(last_alarm_time)) >= alarm_rate and is_in_alarmtime(alarm_start_time, alarm_end_time):
        return True
    else:
        return False


@app.route('/BoxCallBack', methods=['POST'])
async def BoxCallback(request):
    try:
        t0 = time.time()
        seqid = str(uuid.uuid4())
        # 取算法数据
        data = request.json
        data = data['data']
        task_id = data['taskId']
        image = data['image']
        # timestamp = data['timestamp']
        # print(timestamp)
        # 取任务参数
        print('*' * 30)
        data_info = deepcopy(data)
        data_info['image'] = ''
        try:
            for i in range(len(data_info['detections'])):
                data_info['detections'][i]['smallImage'] = ''
            print(data_info)
        except:
            import traceback
            traceback.print_exc()

        task_args = redis_PARAM.hget('task_args', str(task_id))
        if not task_args:
            print("没有算法配置")
            return sanicjson({
                "code": 10000,
                "info": 'Success'
            })
        task_args = eval(task_args)
        event_type = task_args.get('event_type')
        result_receiver = task_args.get('result_receiver')
        event_define_massage = task_args.get('event_define_massage')
        alarm_start_time = alarm_end_time = None
        if event_define_massage:
            alarm_start_time = event_define_massage.get('alarm_start_time', None)
            alarm_end_time = event_define_massage.get('alarm_end_time', None)
        camera_config = task_args.get('camera_config')
        event_config = task_args.get('event_config')

        if not event_config:
            event_config = {}

        threshold = event_config.get('threshold', 0)
        alarm_rate = event_config.get('alarm_rate', 10)
        have_image = event_config.get('have_image', 0)
        warning_area = event_config.get('warning_area', None)

        # 算法分类拼接告警信息

        alarm_type = event_type
        alarm_time = str(datetime.now())
        camera_id = camera_config.get('camera_id')

        if not is_alarm_time(task_id, alarm_rate, alarm_start_time, alarm_end_time):
            print('不在告警时间内')
            return sanicjson({
                "code": 10000,
                "info": 'Success'
            })
        alarm_detail = alg_manager_handle(data, task_args)

        if alarm_detail:
            if True:
                for item in alarm_detail:

                    alarm_id = str(uuid.uuid4())
                    bbox = item['bbox']

                    if warning_area and (not is_in_poly(bbox, warning_area)):
                        print('不在告警区域内')
                        continue
                    # print('task_id {} score{} 算法阈值{}'.format(task_id,item['score'] * 100, threshold))
                    if item['score'] * 100 < threshold:
                        print('task_id {} score:{}低于算法阈值:{}'.format(task_id, item['score'] * 100, threshold))
                        continue
                    t3 = time.time()

                    if alarm_type == '8001':
                        alarm_type = item['eventType']
                    if have_image == 0 and alarm_type in ['8001', '80010', '80011', '80012', '9001']:
                        # 0不推场景图
                        image = ''
                    data = {
                        "taskId": task_id,
                        "alarm_id": alarm_id,
                        "alarm_type": alarm_type,
                        "alarm_time": alarm_time,
                        "camera_id": camera_id,
                        "image": image,
                        "alarm_detail": [item],
                    }
                    # save_img(data)
                    res_data = {
                        "code": 10000,
                        "seqId": str(uuid.uuid4()),
                        "message": "ok",
                        "flag": 1,
                        "data": data}
                    r = requests.post(url=result_receiver.get('uri'), json=res_data)
                    r = json.loads(r.text)
                    # r = {'code': 10000}
                    print(r)
                    print('{},推送告警耗时:{}'.format(seqid, time.time() - t3))
                    if r['code'] == 10000:
                        print('推送告警成功')
                        redis_DATA.hset('Box_alarm_time', '{}'.format(task_id), str(time.time()))
                    else:
                        print('推送告警失败')

                    insert_t_alarminfo(task_id, alarm_id, alarm_type, alarm_time, camera_id,
                                       image, item['objectId'], item['alarm_action_type'],
                                       item['bbox'], item['object_image'], item['eventType'],
                                       item['alarm_message'])
                    res_data['data']['image'] = ''
                    for i in range(len(res_data['data']['alarm_detail'])):
                        res_data['data']['alarm_detail'][i]['object_image'] = ''
                    print(res_data)

        print('{},全流程耗时:{}'.format(seqid, time.time() - t0))
        return sanicjson({
            "code": 10000,
            "info": 'Success'
        })
    except Exception as e:
        traceback.print_exc()
        return sanicjson({
            "code": 10903,
            "info": "Fail:{}".format(e)
        })


if __name__ == "__main__":
    app.run(port=7003, host='0.0.0.0', debug=False, access_log=False, fast=True)
