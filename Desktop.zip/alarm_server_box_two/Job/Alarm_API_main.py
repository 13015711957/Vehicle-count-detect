# -*-coding:utf-8 -*-

"""
# Project    : AIStreamPlatform
# File       : Alarm_API_main.py
# Time       ：2021/8/23 17:01
# Author     ：zhengqx
# Description：
"""
import sys
import os


sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from Service.AlarmServer.alarm_create_handler import AlarmCreatehandler, AlarmCreateItem
from Service.AlarmServer.alarm_delete_handler import AlarmDeletehandler, AlarmDeleteItem
from Service.AlarmServer.alarm_get_handler import AlarmGethandler, AlarmGetItem

from Service.AlgServer.get_version_handler import GetVersionhandler, GetVersionItem
from Service.AlgServer.register_handler import Registerhandler, RegisterItem
from Service.AlgServer.unregister_handler import UnRegisterhandler, UnRegisterItem
from Service.AlgServer.heartbeat_handler import Heartbeathandler, HeartbeatItem

import uvicorn
from SYS import conf
from Service import app

url_alarm_create = conf.get('gateway_url', 'url_alarm_create')
url_alarm_delete = conf.get('gateway_url', 'url_alarm_delete')
url_alarm_get = conf.get('gateway_url', 'url_alarm_get')

url_register = conf.get('gateway_url', 'url_register')
url_unregister = conf.get('gateway_url', 'url_unregister')
url_HeartBeat = conf.get('gateway_url', 'url_HeartBeat')
url_version = conf.get('gateway_url', 'url_version')


@app.post(url_alarm_create)
async def alarm_create_main(item: AlarmCreateItem):
    print('start...')
    return await AlarmCreatehandler.post(item)

@app.post(url_alarm_delete)
async def alarm_delete_main(item: AlarmDeleteItem):
    print('start...')
    return await AlarmDeletehandler.post(item)

@app.post(url_alarm_get)
async def alarm_search_main(item: AlarmGetItem):
    print('start...')
    return await AlarmGethandler.post(item)


@app.post(url_register)
async def register_main(item: RegisterItem):
    print('start...')
    return await Registerhandler.post(item)


@app.post(url_unregister)
async def unregister_main(item: UnRegisterItem):
    print('start...')
    return await UnRegisterhandler.post(item)


@app.post(url_HeartBeat)
async def HeartBeat_main(item: HeartbeatItem):
    print('start...')
    return await Heartbeathandler.post(item)


@app.post(url_version)
async def version_main(item: GetVersionItem):
    print('start...')
    return await GetVersionhandler.post(item)

if __name__ == '__main__':
    uvicorn.run(app, host="0.0.0.0", port=7002)
