import json
import time
from datetime import datetime
import sys
import os

import requests

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from Business.ALL_BUISS_CODE import ALG_API_CODE
from Dao.S_server_online import select_server_online_state, update_server_online_state
from Dao.S_server_task import select_server_task_serverid, delete_server_task_id, select_server_task_state, \
    update_task_state
from Dao.T_task_info import delete_t_task_info
from SYS import conf

BEATTIM = int(conf.get('global', 'BEATTIM'))


def delete_server(server_id):
    res = select_server_task_serverid(server_id)
    for i in res:
        task_id = i['task_id']
        delete_t_task_info(task_id)
        delete_server_task_id(task_id)
        # redis_PARAM.hdel('task_args', str(task_id))


def update_online():
    res = select_server_online_state(1)
    for i in res:
        server_id = i['server_id']
        now_time = datetime.now()
        update_time = i['update_time']
        print(server_id, (now_time - update_time).seconds)
        if (now_time - update_time).seconds > 60 * BEATTIM:
            update_server_online_state(server_id, 0)
            delete_server(server_id)

    res = select_server_task_state(1)
    for i in res:
        task_id = i['task_id']
        req_data = {
            "code": ALG_API_CODE.SELECT_TASK_STATE_REQUEST,  # 1005
            "data": {
                "task_id": task_id
            }
        }
        r = requests.post(url=conf.get('Box', 'search_task_url'), json=req_data)
        r = json.loads(r.text)
        if r and r['code'] == ALG_API_CODE.SELECT_TASK_STATE_RESPONSE:  # 1006
            state = r['data']['pipeline_status']
        else:
            state = 0
        print(r)
        update_task_state(task_id, state)


# 获取文件大小
def get_FileSize(filePath):
    fsize = os.path.getsize(filePath)
    fsize = fsize / float(1024 * 1024)  # 单位换算 从 B --> MB
    return round(fsize, 2)  # 保留两位小数


def clear_log():
    log_dir = '/project/box_alarm_server_new/log/'
    for log_name in os.listdir(log_dir):
        log_path = log_dir + log_name
        log_size = get_FileSize(log_path)
        if log_size > 50:
            os.system("cat /dev/null >{}".format(log_path))


if __name__ == '__main__':
    while True:
        try:
            update_online()
            clear_log()
        except:
            import traceback

            traceback.print_exc()
        time.sleep(5 * 60)
