# -*-coding:utf-8 -*-

"""
# Project    : AIStreamPlatform
# File       : stream_API_main.py
# Time       ：2021/8/23 17:01
# Author     ：zhengqx
# Description：
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from Service.StreamServer.stream_create_handler import StreamCreateItem, StreamCreatehandler
from Service.StreamServer.stream_delete_handler import StreamDeleteItem, StreamDeletehandler
from Service.StreamServer.stream_state_handler import StreamStateItem, StreamStatehandler
from Service.StreamServer.stream_getframe_handler import StreamGetFrameItem, StreamGetFramehandler





import uvicorn
from SYS import conf
from Service import app

url_stream_create = conf.get('gateway_url', 'url_stream_create')
url_stream_delete = conf.get('gateway_url', 'url_stream_delete')
url_stream_state = conf.get('gateway_url', 'url_stream_state')

url_frame_get = conf.get('gateway_url', 'url_frame_get')



@app.post(url_stream_create)
async def stream_create_main(item: StreamCreateItem):
    print('start...')
    return await StreamCreatehandler.post(item)


@app.post(url_stream_delete)
async def stream_delete_main(item: StreamDeleteItem):
    print('start...')
    return await StreamDeletehandler.post(item)

@app.post(url_stream_state)
async def stream_state_main(item: StreamStateItem):
    print('start...')
    return await StreamStatehandler.post(item)


@app.post(url_frame_get)
async def stream_getframe_main(item: StreamGetFrameItem):
    print('start...')
    return await StreamGetFramehandler.post(item)

if __name__ == '__main__':
    uvicorn.run(app, host="0.0.0.0", port=7001)
