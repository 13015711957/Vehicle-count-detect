#!/bin/bash
./script/run/run.sh restart
now=`date "+%Y%m%d"`

PY_CMD='python'
UVICORN_CMD='uvicorn'
API_DIR='/project'
EXE_DIR='/project/box_alarm_server_new'
cd ${EXE_DIR}
($PY_CMD -u Job/update_server_state.py )

