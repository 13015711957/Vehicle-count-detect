import datetime
import os
import shutil
import  time
path='/data/AI_ImageLibrary/AI_DataAudit/AI_ResData/sign_date_json/20220607/'

for i in os.listdir(path):
    name=path+i
    t=os.path.getmtime(name)
    timeStruce=time.localtime(t)
    day=time.strftime('%Y-%m-%d %H',timeStruce)
    if day=='2022-06-07 17':
        print(i)
        shutil.copy(name,'/home/wanghuibing/sign_img/'+i)
