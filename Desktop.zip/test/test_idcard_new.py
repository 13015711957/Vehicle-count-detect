# -*- coding:utf-8 -*-
import requests
import base64
import os
import pandas as pd
import json


def seal_identity():
    # url = 'http://127.0.0.1:5050/api/sealidentify'
    # url = 'http://192.168.35.175:1001/api/sealidentify'
    # url = 'http://192.168.35.175:1001/api/sealidentifyFtp'
    # url = 'http://192.168.35.143:5050/ocr/license'
    url = 'http://10.142.157.211:5101/ocr_API/idCardOCR'
    url = 'http://10.142.157.211:5121/ocr_API/idcardTemporaryOcr'
    #url = 'http://10.142.156.167:5050/ocr_API/idCardOCR'

    path="/data6/linyicheng/hbw/身份证样本/"


    testRes0 = pd.DataFrame(columns=['图片名', '姓名', '性别', '民族', '出生年月', '身份证号码', '身份证地址','签发机关','有效期限','url'])#, '坐标'])
    df_res = []
    s=[]
    for d in os.listdir(path):
        pre_dir=path+d+'/'
        if '临时'not in pre_dir:continue
        for file in os.listdir(pre_dir):
            print(pre_dir  + file)
            img_url=pre_dir  + file
            with open(pre_dir  + file, "rb") as f:
                source_img = base64.b64encode(f.read())
                # print(source_img)
            data = {
                "image":  str(source_img, "utf-8"),
                'seqid': 'test',
            }
            r = requests.post(url, json=data)
            res = r.json()
            print(res)
            if res['code'] == '10000':
                try:
                    if res != None:
                        df_res.append([file, res['data']['words_result']['姓名']['words'], res['data']['words_result']['性别']['words'],
                                       res['data']['words_result']['民族']['words'], res['data']['words_result']['出生年月']['words'],
                                       res['data']['words_result']['身份证号码']['words'], res['data']['words_result']['身份证地址']['words'],
                                       res['data']['words_result']['签发机关']['words'], res['data']['words_result']['有效期限']['words'],img_url])#,res['data']['words_result']['location']['words']])
                except:
                    try:
                        df_res.append(
                            [file, '','','','','','',res['data']['words_result']['签发机关']['words'], res['data']['words_result']['有效期限']['words'],img_url])
                    except:
                        df_res.append([file, '', '', '', '', '', '证件拍摄不完整，建议重拍', '', '',img_url])
            else:
                df_res.append([file, '', '', '', '', '', '错误','',''])
    for i in range(len(df_res)):
        testRes0.loc[i] = df_res[i]
    testRes0.to_excel('temp_idcard(0524线上结果).xlsx', index=False)



if __name__ == '__main__':
    # import threading
    # for i in range(5):
    #     a = threading.Thread(target=seal_identity, name='worker')
    #     a.start()
    seal_identity()

    # with open("./test.jpg", "rb") as f:
    #     source_img = base64.b64encode(f.read())
    # print (source_img)
