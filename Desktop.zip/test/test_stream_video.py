import os
import time

import numpy as np
import pandas as pd
import cv2
import base64
import requests
import json


def businessLicenseOCR(camera,rtsp_url):

    url = 'http://127.0.0.1:17108/StreamAnalysis/rtspinfo'


    data = {
        "Province ": 11,
        "dcId ": 10000,
        "roomName": "xxx",
        "roomNum": 1,
        "cameraNum": camera,
        "rtspUrl": rtsp_url,
        "action": 1
    }
    r = requests.post(url, json=data)

    res = r.json()  # 将字符串转字典
    print(res)
    return res
if __name__ == '__main__':
    #路径
    file_dir = "./av/"
    # 获得文件夹及文件完整路径
part1="213"
part2="219"
for root, dirs, files in os.walk(file_dir):
    for name in dirs:
        camera = ''
        #print(os.path.join(root, name)) # 子文件夹
    for name in files:
        #print(os.path.join(root, name)) # 文件
        path=os.path.join(root, name)
        if part1 in path: 
                    camera='01679e82265b427c8b2a22ea5dff221b'
        elif part2 in path:  
                   camera='01679e82265b427c8b2a22ea5dff271w'
        # url = 'file:///opt/nvidia/deepstream/deepstream-5.0/sources/apps/sample_apps/yolov5_deepstream/video-219/2022-05-05/01679e82265b427c8b2a22ea5dff271w.mp4'
        url = 'file:///opt/nvidia/deepstream/deepstream-5.0/sources/apps/sample_apps/yolov5_deepstream/video-219/'+path[5:]
        print(url)
        print(camera)
        res=businessLicenseOCR(camera,url)
        time.sleep(60)
        
    #path = r"/home/ctff/temp"
    #res = businessLicenseOCR()
    #print("res", res)
    #camera = '01679e82265b427c8b2a22ea5dff271w'
    #219  '01679e82265b427c8b2a22ea5dff271w'
    #213  '01679e82265b427c8b2a22ea5dff221b'
    #url = 'file:///opt/nvidia/deepstream/deepstream-5.0/sources/apps/sample_apps/yolov5_deepstream/video-219/06-02/219/10-40-28.mp4'
    #businessLicenseOCR(camera,url)
