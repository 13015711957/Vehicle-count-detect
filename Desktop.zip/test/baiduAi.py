# encoding:utf-8

import requests
import base64

'''
港澳通行证识别
'''
host = 'https://aip.baidubce.com/oauth/2.0/token?grant_type=client_credentials&client_id=mT4a3WRy7Oiyua5Xe48qbk6T&client_secret=NVjhjGMf1ktLTMhiuCuGIGIOD6AvgjrZ'
response = requests.get(host)
if response:
    print(response.json())

request_url = "https://aip.baidubce.com/rest/2.0/ocr/v1/HK_Macau_exitentrypermit"
# 二进制方式打开图片文件
f = open(r'E:\ffcs\code\HK_Macau_permit\test\img\1.jpg', 'rb')
img = base64.b64encode(f.read())

params = {"image":img}
access_token = response.json()['access_token']
request_url = request_url + "?access_token=" + access_token
headers = {'content-type': 'application/x-www-form-urlencoded'}
response = requests.post(request_url, data=params, headers=headers)
if response:

    print(response.json())