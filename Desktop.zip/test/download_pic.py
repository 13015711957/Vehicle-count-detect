import datetime
import os
import time


# cv2.rectangle(img_1, (1061,0), (858,973),(255,0,0), 3)
# cv2.imshow('1',img_1)
# cv2.waitKey()
import pandas as pd
import requests
import urllib3
# from bs4 import BeautifulSoup

def getPage(url):
    re = requests.get(url)
    html = re.content
    return html

def down_file(url):

    file_name = url.split('/')[-1]
    connection_pool =urllib3.PoolManager()
    resp=connection_pool.request('GET',url)
    save_path=r'C:\Users\gstx\Desktop\testimg/'
    if not os.path.exists(save_path):
        print('####新建文件夹: ', save_path)
        os.makedirs(save_path)
    f = open(save_path+file_name, 'wb')
    f.write(resp.data)
    f.close()

pre_url = 'http://134.128.231.100:20400'
# html = getPage(pre_url)
# soup = BeautifulSoup(html, 'html.parser')
#
pics=['http://134.224.120.77:8080/group1/M06/FD/E6/huB4TWKQSr-ALzj6AABjkvneD3M168.jpg',
'http://134.224.120.77:8080/group1/M06/FD/E6/huB4TWKQSr-ALzj6AABjkvneD3M168.jpg',
'http://134.224.120.77:8080/group1/M05/3E/54/huB4TWJvRUKAfatKAACedkcluFY192.jpg',
'http://134.224.120.77:8080/group1/M05/CD/BF/huB4TWKInBSAP0kvAAB7b-kwhTk796.jpg',
'http://134.224.120.77:8080/group1/M05/36/0C/huB4TWJuDyqAOtG9AADugim2cnk935.jpg',
'http://134.224.120.77:8080/group1/M05/89/B7/huB4TWIdeSSAQ8_UAAA-rbX2vIs575.jpg',
'http://134.224.120.77:8080/group1/M05/89/BC/huB4TWIdeXqAUVb3AABHMy8N_CY751.jpg',
'http://134.224.120.77:8080/group1/M05/09/98/huB4TWI1N02AK2aoAAB-290gRmY851.jpg',
'http://134.224.120.77:8080/group1/M05/6E/6B/huB4TWIZlw-ALXr3AAChyaf4Ofs337.jpg',
'http://134.224.120.77:8080/group1/M05/61/F8/huB4TWIXYW2ARoBXAACTqTfAS5I854.jpg',
'http://134.224.120.77:8080/group1/M05/0A/7B/huB4TWIKAgSAf92nAADY6kXZ_IA765.jpg',
'http://134.224.120.77:8080/group1/M05/EF/3C/huB4TWIEujyAftAFAABrj7UDLPo553.jpg',
'http://134.224.120.77:8080/group1/M01/80/E7/huB4TWGsKIOAKCSQAABfya5G5k8528.jpg',
'http://134.224.120.77:8080/group1/M05/1C/F3/huB4TWFFPNCAIqL4AACBoCtnNXs476.jpg',
'http://134.224.120.77:8080/group1/M05/1C/F4/huB4TWFFPOuACvjzAACCp-cgspE129.jpg',
'http://134.224.120.77:8080/group1/M05/F5/18/huB4TWE-uxmAEn6GAABW3LnRFhY203.jpg',
'http://134.224.120.77:8080/group1/M05/F1/C8/huB4TWE9zsSAbz7rAABwFmJLN00420.jpg',
'http://134.224.120.77:8080/group1/M05/F1/CB/huB4TWE9zv2ARZgWAAB66qlEzL0588.jpg',
'http://134.224.120.77:8080/group1/M05/CA/95/huB4TWE4TUeABEPNAACAU5OtwH8117.jpg',
'http://134.224.120.77:8080/group1/M05/73/41/huB4TWD-GvGABxkhAABuxD0iD2g226.jpg',
'http://134.224.120.77:8080/group1/M05/73/44/huB4TWD-GxaAacWCAABwfToEsLY881.jpg',
'http://134.224.120.77:8080/group1/M05/3B/B0/huB4TWDxe6iAQc3NAACAiR8U0_A081.jpg',
'http://134.224.120.77:8080/group1/M04/AE/C1/huB4TWDW6R6AX-eCAADAmRWxFJw878.jpg',
'http://134.224.120.77:8080/group1/M04/76/CF/huB4TWDNX8GASBYgAACLANXjRGQ956.jpg',
'http://134.224.120.77:8080/group1/M04/76/D1/huB4TWDNX92AXxjmAACCjrJaqas461.jpg',
'http://134.224.120.77:8080/group1/M04/76/D7/huB4TWDNYD6AER6LAACA6EUv67M913.jpg',
'http://134.224.120.77:8080/group1/M04/76/CF/huB4TWDNX8GASBYgAACLANXjRGQ956.jpg',
'http://134.224.120.77:8080/group1/M04/76/D1/huB4TWDNX92AXxjmAACCjrJaqas461.jpg',
'http://134.224.120.77:8080/group1/M04/76/D7/huB4TWDNYD6AER6LAACA6EUv67M913.jpg',
'http://134.224.120.77:8080/group1/M04/76/CF/huB4TWDNX8GASBYgAACLANXjRGQ956.jpg',
'http://134.224.120.77:8080/group1/M04/76/D1/huB4TWDNX92AXxjmAACCjrJaqas461.jpg',
'http://134.224.120.77:8080/group1/M04/76/D7/huB4TWDNYD6AER6LAACA6EUv67M913.jpg',
'http://134.224.120.77:8080/group1/M04/4A/1D/huB4TWDEQDGAX-n9AABpOq4I5o4333.jpg',
'http://134.224.120.77:8080/group1/M04/4A/1E/huB4TWDEQFiAIT1GAACHTH08j0Q358.jpg',
'http://134.224.120.77:8080/group1/M04/9D/D5/huB4TWDUOeqAVoUSAABrcBtQ8o4910.jpg',
'http://134.224.120.77:8080/group1/M04/35/E8/huB4TWDAboyAE-mOAABghwM1_Bk972.jpg',
'http://134.224.120.77:8080/group1/M05/84/6B/huB4TWEu4aCAK9xIAABURisHmME291.jpg',
'http://134.224.120.77:8080/group1/M04/94/E4/huB4TWBuvLCAEkY3AACMaj91JHk355.jpg',
'http://134.224.120.77:8080/group1/M04/94/E4/huB4TWBuvLCAEkY3AACMaj91JHk355.jpg',
'http://134.224.120.77:8080/group1/M04/94/E4/huB4TWBuvLCAEkY3AACMaj91JHk355.jpg',
'http://134.224.120.77:8080/group1/M04/19/B3/huB4TWAgoLCAacOPAABwi0OjAss099.jpg',
'http://134.224.120.77:8080/group1/M04/DA/E0/huB4TWAXvI6Afz8KAABqNo5gjgg711.jpg',
'http://134.224.120.77:8080/group1/M04/DA/C6/huB4TWAXu1aAJsgsAABkyDzlC4o926.jpg',
'http://134.224.120.77:8080/group1/M04/6F/38/huB4TWAKc0eAOuyfAACHXzRl9XY716.jpg',
'http://134.224.120.77:8080/group1/M04/71/62/huB4TWAKjUWACoyXAABzGovjnCU945.jpg',
'http://134.224.120.77:8080/group1/M04/5D/60/huB4TWAH5ICAbj42AABs3Nb5T9I435.jpg',
'http://134.224.120.77:8080/group1/M04/A5/C3/huB4TWASGZ2AD_pQAAC1WK_aUtY109.jpg',
'http://134.224.120.77:8080/group1/M04/5D/4F/huB4TWAH46uAQmDLAAB4K8pG6KA958.jpg',
'http://134.224.120.77:8080/group1/M04/5D/5A/huB4TWAH5DWAOoEZAACi6XIXTSw219.jpg',
'http://134.224.120.77:8080/group1/M04/B0/8B/huB4TWASmqeAIzmeAABubCzCHkU258.jpg',
'http://134.224.120.77:8080/group1/M04/5C/6E/huB4TWAH2ZGATo4lAABtZnEBvCE944.jpg',
'http://134.224.120.77:8080/group1/M04/5C/74/huB4TWAH2dSAO7BwAABwGk_oV6E064.jpg',
'http://134.224.120.77:8080/group1/M04/5C/78/huB4TWAH2gCAY5kEAACT0A3byJs404.jpg',
'http://134.224.120.77:8080/group1/M04/5C/80/huB4TWAH2luAXWXgAACIrl8OtLE066.jpg',
'http://134.224.120.77:8080/group1/M04/5C/84/huB4TWAH2oiABzpTAACU9r0kB-4549.jpg',
'http://134.224.120.77:8080/group1/M04/8D/A4/huB4TWAOoPeAGoBqAABffsgHhOQ047.jpg',
'http://134.224.120.77:8080/group1/M04/34/AA/huB4TWABV4uAVRTsAABVV5Zd6eE148.jpg',
'http://134.224.120.77:8080/group1/M04/34/B5/huB4TWABWCuAIUv8AABg-IIP18g537.jpg',
'http://134.224.120.77:8080/group1/M04/34/B8/huB4TWABWE2AIX-yAABeiMoznbM005.jpg',
'http://134.224.120.77:8080/group1/M04/34/BA/huB4TWABWHOAV0PTAABjUjA0taQ638.jpg',
'http://134.224.120.77:8080/group1/M04/34/C7/huB4TWABWT-AIxnsAACPZNrbeEo515.jpg']

for i in pics:
    down_file(i)


#
# num=0
# file_excel = pd.read_excel(r'docs/gz.xlsx')
# for i in file_excel.itertuples():
#     if num==100:break
#     filename=i[4]
#     url=i[5]
#     down_file(url)
#     num+=1
