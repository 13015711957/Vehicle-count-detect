import base64
import shutil

import pandas as pd
import os
error=[]
df_res1 = pd.DataFrame(columns=['文件名', ])
path="/home/ctff/project/SmartHomeAPI/AIGateWay_fastapi/pictem/"

for i in os.listdir(path):
    if i.startswith('20211013'):
        data=path+i
        try:
            with open(data,'r')as f:
                imgdata = base64.b64decode(f.read())
                file = open(i.split('.')[0]+'.jpg', 'wb')
                file.write(imgdata)
                file.close()
        except:
            error.append([data])

for i in range(len(error)):
    df_res1.loc[i] = error[i]
    print("===============")
    print(error[i])
df_res1.to_excel('不存在.xlsx')