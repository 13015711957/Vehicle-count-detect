import numpy as np
import sys
import cv2
import tritonclient.http as httpclient
import base64
import random
import os
np.set_printoptions(suppress=True)
import torch.nn as nn
import torch


vehicle_color_categories = {0:"brown",1:"yellow",2:"blue",3:"red",4:"green",5:"black",6:"white",7:"purple",8:"gray"}
vehicle_type_categories = {0:"car",1:"bus",2:"truck"}
vehicle_brand_categories = {0: '罗伦士', 1: '长城', 2: '马自达', 3: '福迪', 4: '捷尼赛思', 5: '奇瑞', 6: '现代', 7: '雷诺', 8: '克莱斯勒', 9: '广汽', 10: '宇通', 11: '福特', 12: '岚图', 13: '云度', 14: '梅赛德斯', 15: '海马', 16: '路特斯', 17: '领克', 18: '金康赛力斯', 19: '五十铃', 20: '一汽', 21: '五菱', 22: '博速', 23: '林肯', 24: '野马', 25: '斯柯达', 26: '劳斯莱斯', 27: '宝马', 28: '凯翼', 29: '金杯', 30: '蔚来', 31: '星途', 32: '东风', 33: '凯迪拉克', 34: '本田', 35: '特斯拉', 36: '福田', 37: '爱驰', 38: '达契亚', 39: '合创', 40: '北京', 41: '天际', 42: '双龙', 43: '迈凯伦', 44: '大众', 45: '保时捷', 46: '雪铁龙', 47: '江铃', 48: '奔驰', 49: '三菱', 50: '零跑', 51: '众泰', 52: '威马', 53: '上汽大通', 54: '吉利', 55: '江淮', 56: '英菲尼迪', 57: '菲亚特', 58: '道奇', 59: '鑫源', 60: 'MINI', 61: '帕加尼', 62: '标致', 63: '金龙', 64: '小鹏', 65: '日产', 66: '欧宝', 67: '骐铃', 68: '长安轿车', 69: '雷克萨斯', 70: '中国重汽VGV', 71: '中华', 72: '讴歌', 73: '曙光', 74: '蓝旗亚', 75: '铃木', 76: '摩根', 77: '新特', 78: '兰博基尼', 79: '雪佛兰', 80: '沃尔沃', 81: '西雅特', 82: '宝沃', 83: '丰田', 84: '猎豹', 85: '枫叶', 86: '比亚迪', 87: '宾利', 88: '玛莎拉蒂', 89: '奥迪', 90: '华人运通', 91: '法拉利', 92: '开瑞', 93: '中兴', 94: '别克', 95: '依维柯', 96: '路虎', 97: '光冈', 98: '大运', 99: '大发', 100: '大乘', 101: '陆风', 102: '观致', 103: '力帆', 104: '腾势', 105: '国机智骏', 106: '起亚', 107: '斯巴鲁', 108: '汉腾', 109: '九龙', 110: 'Jeep', 111: '东南', 112: '昌河', 113: '理想', 114: '布加迪', 115: '长安', 116: '捷豹', 117: '合众', 118: '开沃', 119: '塔塔', 120: '哈飞', 121: '奔腾', 122: '夏利', 123: '纳智捷', 124: '荣威', 125: '哈弗', 126: '传祺', 127: '宝骏', 128: '名爵', 129: '启辰', 130: '华泰', 131: '川汽', 132: '安凯', 133: '北汽威旺', 134: '北汽制造', 135: '大宇', 136: '广汽吉奥', 137: '海格', 138: '红旗', 139: '华菱星马汽车', 140: '华普', 141: '皇冠', 142: '黄海汽车', 143: '吉利帝豪', 144: '吉利全球鹰', 145: '凯马', 146: '瑞麟', 147: '陕汽重卡', 148: '上海汇众', 149: '申龙', 150: '时代汽车', 151: '舒驰客车', 152: '唐骏欧铃', 153: '威麟', 154: '英伦', 155: '永源', 156: '跃进汽车', 157: '中通'}


def get_box(triton_client,file_name):
    model_name = 'ensemble'
    # file_name = ["pytorch_models/resnet_model/pipeline_test_imgs/test_sample.jpg"]
    image = cv2.imread(file_name[0]).astype(np.uint8)
    input_base64_matrix = []
    # input_base64_matrix.append([x for x in base64.b64encode(open("dog.jpg","rb").read())])
    input_base64_matrix.append([x for x in base64.b64encode(open(file_name[0], "rb").read())])
    input_base64_matrix_len_list = [len(l) for l in input_base64_matrix]
    max_len = max(input_base64_matrix_len_list)
    input_base64_matrix = list(map(lambda l: l + [0] * (max_len - len(l)), input_base64_matrix))
    input_base64_matrix = np.array(input_base64_matrix, dtype=np.uint8)
    print(input_base64_matrix.shape)

    # 576,768 （h,w)
    # 输入图片尺寸，根据输入图片尺寸的大小改动
    input_param = [(image.shape[0], image.shape[1], x) for x in input_base64_matrix_len_list]
    # input_param = [(360,640,x) for x in input_base64_matrix_len_list]
    input_param = np.array(input_param, dtype=np.uint32)
    print(input_param)

    # yolo和resnet的输入尺寸，固定
    input_size = np.array([[640, 640] for _ in range(len(file_name))], dtype=np.uint16)
    input_resnet_resize_size = np.array([[224, 224] for _ in range(len(file_name))], dtype=np.int32)

    inputs = []
    inputs.append(httpclient.InferInput('input_base64', list(input_base64_matrix.shape), "UINT8"))
    inputs.append(httpclient.InferInput('input_param', list(input_param.shape), "UINT32"))
    inputs.append(httpclient.InferInput('input_size', list(input_size.shape), "UINT16"))
    inputs.append(httpclient.InferInput('input_resnet_resize_size', list(input_resnet_resize_size.shape), "INT32"))
    inputs[0].set_data_from_numpy(input_base64_matrix)
    inputs[1].set_data_from_numpy(input_param)
    inputs[2].set_data_from_numpy(input_size)
    inputs[3].set_data_from_numpy(input_resnet_resize_size)

    outputs = []
    outputs.append(httpclient.InferRequestedOutput('output_yolo_res_nms_unresized'))
    outputs.append(httpclient.InferRequestedOutput('e_out_color'))
    outputs.append(httpclient.InferRequestedOutput('e_out_type'))
    outputs.append(httpclient.InferRequestedOutput('e_out_brand'))

    results = triton_client.infer(
        model_name=model_name, inputs=inputs, outputs=outputs, headers={"test": "1"}
    )

    output_yolo_res_nms_unresized = results.as_numpy("output_yolo_res_nms_unresized")
    e_out_type = results.as_numpy("e_out_type")
    e_out_color = results.as_numpy("e_out_color")
    e_out_brand = results.as_numpy("e_out_brand")


    for fileindex in range(len(file_name)):
        print("boxes num:", output_yolo_res_nms_unresized[fileindex][-1])
        boxes = np.reshape(output_yolo_res_nms_unresized[fileindex][:-1], (-1, 7))
        # print(boxes.shape)
        result_boxes = boxes[:,:4]
        result_scores = boxes[:,4]
        result_classid = boxes[:,5]
        # print(result_boxes)

        image_raw = cv2.imread(file_name[fileindex])

        for car_index in range(e_out_type.shape[0]):
            car_type = e_out_type[car_index].flatten()
            car_color = e_out_color[car_index].flatten()
            car_brand = torch.from_numpy(e_out_brand)
            # print("car_type: ",car_type.flatten())
            # print("car_color: ",car_color.flatten())
            car_type_id = car_type.argmax()
            car_color_id = car_color.argmax()
            car_brand_id = nn.Softmax(dim=1)(car_brand).tolist()
            car_brand_id = car_brand_id[car_index].index(max(car_brand_id[car_index]))
            print({"color": vehicle_color_categories[car_color_id], "type": vehicle_type_categories[car_type_id],
                  "brand": vehicle_brand_categories[car_brand_id]})

            box = result_boxes[car_index]
            y = [0 for _ in range(4)]
            y[0] = box[0] - box[2]/2
            y[2] = box[0] + box[2]/2
            y[1] = box[1] - box[3]/2
            y[3] = box[1] + box[3]/2
            print(y)

            # 保存结果图片
            plot_one_box(
                y,
                image_raw,
                label="{}:{}".format(
                    vehicle_color_categories[car_color_id], vehicle_type_categories[car_type_id], vehicle_brand_categories[car_brand_id]
                ),
            )
            # print("index",fileindex)
        # cv2.imwrite(file_name[fileindex]+"_res.jpg",image_raw)
        # print(file_name[fileindex]+"_res.jpg")


def plot_one_box(x, img, color=None, label=None, line_thickness=None):
    """
    description: Plots one bounding box on image img,
                 this function comes from YoLov5 project.
    param:
        x:      a box likes [x1,y1,x2,y2]
        img:    a opencv image object
        color:  color to draw rectangle, such as (0,255,0)
        label:  str
        line_thickness: int
    return:
        no return
    """
    tl = (
            line_thickness or round(0.002 * (img.shape[0] + img.shape[1]) / 2) + 1
    )  # line/font thickness
    color = color or [random.randint(0, 255) for _ in range(3)]
    c1, c2 = (int(x[0]), int(x[1])), (int(x[2]), int(x[3]))
    cv2.rectangle(img, c1, c2, color, thickness=tl, lineType=cv2.LINE_AA)
    if label:
        tf = max(tl - 1, 1)  # font thickness
        t_size = cv2.getTextSize(label, 0, fontScale=tl / 3, thickness=tf)[0]
        c2 = c1[0] + t_size[0], c1[1] - t_size[1] - 3
        # cv2.rectangle(img, c1, c2, color, -1, cv2.LINE_AA)  # filled
        cv2.putText(
            img,
            label,
            (c1[0], c1[1] - 2),
            0,
            tl / 4,
            [225, 255, 255],
            thickness=tf,
            lineType=cv2.LINE_AA,
        )



if __name__ == '__main__':
    # triton_client = httpclient.InferenceServerClient(url="127.0.0.1:58000", verbose=False) #工作站上run，请求工作站服务
    triton_client = httpclient.InferenceServerClient(url="10.143.165.45:31024", verbose=False) #工作站上run，请求工作站服务
    # triton_client = httpclient.InferenceServerClient(url="127.0.0.1:58000", verbose=False)  # 工作站上run，请求工作站服务
    file_name = os.listdir('/home/linyicheng/hbw/img')
    path = '/home/linyicheng/hbw/img/'
    file_name = [path+i for i in file_name]
    for i in file_name:
        print(i)
        get_box(triton_client, [i])
        print('--------------------------------------------------------------------------------------------------------')