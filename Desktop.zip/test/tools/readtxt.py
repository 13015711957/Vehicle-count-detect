import os, base64
import pandas as pd

path1=r'C:\Users\gstx\Desktop\aispicture1'
path2=r'\\192.168.35.126\public\hbw\gaozhishu\test1019\敬告用户书'
path3=r'\\192.168.35.126\public\hbw\gaozhishu\test1019\优享'
path4=r'\\192.168.35.126\public\hbw\gaozhishu\test1019\申请复机'
excel=r'C:\Users\gstx\Desktop\资料合规稽核案例数据.xlsx'
writer=pd.ExcelWriter(excel)

df1= pd.read_excel(excel,sheet_name='橙分期业务告知书')
df2= pd.read_excel(excel,sheet_name='敬告用户书')
df3= pd.read_excel(excel,sheet_name='中国电信号码优享业务协议')
df4= pd.read_excel(excel,sheet_name='用户复机告知书')
# 插入列
col_name = df1.columns.tolist()
index = col_name.index('橙分期订单号') + 1
col_name.insert(index, 'filename')
df1 = df1.reindex(columns = col_name)
temp=os.listdir(path1)
def getfilename(s):
    for i in temp:
        if i.startswith(s):
            return i

result=[]
for i in df1.iloc:
    x=getfilename(i[0])
    result.append([i[0],x])

for i in range(len(result)):
    df1.loc[i] = result[i]
    print("===============")
    print(result[i])

'''======================='''
# 插入列
col_name = df2.columns.tolist()
index = col_name.index('敬告用户书') + 1
col_name.insert(index, 'filename')
df2 = df2.reindex(columns = col_name)
temp=os.listdir(path2)
def getfilename(s):
    for i in temp:
        if i.startswith(s):
            return i

result=[]
for i in df2.iloc:
    x=getfilename(i[0])
    result.append([i[0],x])

for i in range(len(result)):
    df2.loc[i] = result[i]
    print("===============")
    print(result[i])
'''======================='''

'''======================='''
# 插入列
col_name = df3.columns.tolist()
index = col_name.index('中国电信号码优享业务协议') + 1
col_name.insert(index, 'filename')
df3 = df3.reindex(columns = col_name)
temp=os.listdir(path3)
def getfilename(s):
    for i in temp:
        if i.startswith(s):
            return i

result=[]
for i in df3.iloc:
    x=getfilename(i[0])
    result.append([i[0],x])

for i in range(len(result)):
    df3.loc[i] = result[i]
    print("===============")
    print(result[i])
'''======================='''

'''======================='''
# 插入列
col_name = df4.columns.tolist()
index = col_name.index('用户复机告知书') + 1
col_name.insert(index, 'filename')
df4 = df4.reindex(columns = col_name)
temp=os.listdir(path4)
def getfilename(s):
    for i in temp:
        if i.startswith(s):
            return i

result=[]
for i in df4.iloc:
    x=getfilename(i[0])
    result.append([i[0],x])

for i in range(len(result)):
    df4.loc[i] = result[i]
    print("===============")
    print(result[i])
'''======================='''
df1.to_excel(excel_writer=writer,sheet_name='橙分期业务告知书',index=False)
df2.to_excel(excel_writer=writer,sheet_name='敬告用户书',index=False)
df3.to_excel(excel_writer=writer,sheet_name='中国电信号码优享业务协议',index=False)
df4.to_excel(excel_writer=writer,sheet_name='用户复机告知书',index=False)
writer.save()
writer.close()