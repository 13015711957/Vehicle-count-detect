# coding=utf-8
import time
import uuid
import hashlib
import base64
import requests
from Crypto.Cipher import AES
from urllib.parse import urlencode
import json
import os


class DopAPI(object):
    def __init__(self, appKey, appSecret):
        self.appKey = appKey
        self.appSecret = appSecret
        self.sKey = appSecret[: 16]
        self.base_url = 'http://10.142.101.156/openapi'

    def getSignParams(self, params):
        ''' 获取签名所需参数 '''
        params['timestamp'] = int(round(time.time() * 1000))  # 毫秒

        src = str(uuid.uuid4())
        seqId = src[: 8] + src[9: 13] + src[14: 18] + src[19: 23] + src[24:]
        params['seqid'] = seqId
        sign = self.makeSign(params)
        params['sign'] = sign
        return params

    def makeSign(self, params):
        ''' 签名生成算法 '''
        paramsStr = 'appKey{}timestamp{}seqid{}'.format(self.appKey, params['timestamp'], params['seqid'])
        paramsStr = self.sKey + paramsStr + self.sKey
        paramsStr = paramsStr.lower()
        return hashlib.md5(paramsStr.encode('utf-8')).hexdigest().upper()

    def getRequestString(self, scriptName, params, method):
        ''' 调试用，程序中可不调用 '''
        url = self.base_url + scriptName
        info = '==========Request Info==========\n'
        info += 'method: ' + method + '\n'
        info += 'url: ' + url + '\n'
        info += 'query: ' + urlencode(params, encoding='utf-8')
        info += '\n'
        return info

    def perLicense(self, idcard_path, scene_path):
        ''' 人证稽核API '''
        with open(idcard_path, 'rb') as f:
            img_data1 = base64.b64encode(f.read())
        with open(scene_path, 'rb') as f:
            img_data2 = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'FaceContrast'
        params['idcard_image'] = img_data1
        params['scene_image'] = img_data2
        params = self.getSignParams(params)

        method = 'GET'
        path = '/dcoos/FaceContrast'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def idCardOCR(self, img_path):
        ''' 身份证识别API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'IdCardOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        method = 'GET'
        path = '/dcoos/IdCardOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def generalOCR(self, img_path):
        ''' 通用文字识别API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        params['method'] = 'generalOCR'
        params['imageBase64'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/GeneralOCR'

        result = self.decryptApi(path, params)
        print(result)
        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))
        # print(data)
        return self.decrypt(data)

    def decryptApi(self, path, params):
        ''' 解密消息 '''
        params = self.getSignParams(params)
        url = self.base_url + path
        headers = {
            'Authorization': 'TYDIC_DCOOS_AUTH appkey={};sKey={};timestamp={};sign={};seqid={}'.format(self.appKey,
                                                                                                       self.sKey,
                                                                                                       params[
                                                                                                           'timestamp'],
                                                                                                       params['sign'],
                                                                                                       params['seqid']),
            'contentType': 'UTF-8',
            'User-Agent': 'Java DopAPIv1 SDK Client',
            'Accept': 'application/json'
        }

        res = requests.post(url, headers=headers, data=params)
        # print("res", res)
        # 这里要补充结果校验
        return res.json()

    def BusinessLicenseOCR(self, img_path):
        ''' 证照分类识别API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'BusinessLicenseOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        method = 'GET'
        path = '/dcoos/BusinessLicenseOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def PRCorganCodeLicenseOCR(self, img_path):
        ''' 全国组织机构代码证识别API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'PRCorganCodeLicenseOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/PRCorganCodeLicenseOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def autoCodeLicenseOCR(self, img_path):
        ''' 基层群众性自治组织代码证识别API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'autoCodeLicenseOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/autoCodeLicenseOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def foreignOrganLicenseOCR(self, img_path):
        ''' 外国常驻代表机构登记证识别API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'foreignOrganLicenseOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/foreignOrganLicenseOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def PRCmedicalOrganLicenseOCR(self, img_path):
        ''' 全国医疗机构执业许可证识别API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'PRCmedicalOrganLicenseOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/PRCmedicalOrganLicenseOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def PRCCodeLicenseOCR(self, img_path):
        ''' 全国统一社会信用代码证识别API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'PRCCodeLicenseOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/PRCCodeLicenseOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def ElectIncOCR(self, img_path):
        ''' 全电子发票识别服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())


        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'ElectIncOCR'
        params['file'] = img_data
        params['file_type'] = img_path.split('.')[-1]
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/ElectIncOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def socialOrganLicenseOCR(self, img_path):
        ''' 社会团体法人登记证书识别服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'socialOrganLicenseOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/SocialOrganLicenseOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def doorPlateReco(self, img_path):
        ''' 门牌识别服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'doorPlateReco'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/doorPlateReco'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def creditCodeLicenseOCR(self, img_path):
        ''' 统一社会信用代码证书识别服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'creditCodeLicenseOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/CreditCodeLicenseOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def ruralCollectiveLicenseOCR(self, img_path):
        ''' 农村集体经济组织登记证识别服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'ruralCollectiveLicenseOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/RuralCollectiveLicenseOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def publicInstitutionLicenseOCR(self, img_path):
        ''' 事业单位法人证书识别服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'publicInstitutionLicenseOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/PublicInstitutionLicenseOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def nonEnterpriseLicenseOCR(self, img_path):
        ''' 民办非企业证书识别服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'nonEnterpriseLicenseOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/NonEnterpriseLicenseOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def LicenseOCR(self, img_path):
        ''' 证照识别服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'LicenseOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/LicenseOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def letterOCR(self, img_path):
        ''' 委托函识别服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'letterOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/LetterOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def businessLicenseOCR(self, img_path):
        ''' 营业执照识别服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'businessLicenseOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/BusinessLicenseOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def Face_similarity(self, img_path):
        ''' 人脸比对接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'Face_similarity'
        params['img_1'] = img_data
        params['img_2'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/Face_similarity'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def FaceContrast(self, img_path):
        ''' 人证合规性稽核服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'FaceContrast'
        params['scene_image'] = img_data
        params['idcard_image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/FaceContrast'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def idcardTemporaryOcr(self, img_path):
        ''' 临时身份证识别服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'idcardTemporaryOcr'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/idcardTemporaryOcr'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def expressBillOCR(self, img_path):
        ''' 快递单识别服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'expressBillOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/expressBillOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def licenseCensor(self, img_path):
        ''' 证照质量检测服务API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'licenseCensor'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/licenseCensor'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def mask(self, img_path):
        ''' 口罩识别服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'mask'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/mask'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def remake_detect(self, img_path):
        ''' 活体翻拍服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'remake_detect'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/remake_detect'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def sealOCR(self, img_path):
        ''' 印章识别服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'sealOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/sealOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def elecMeterOCR(self, img_path):
        ''' 电表识别服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'elecMeterOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/elecMeterOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def EntrustOCR(self, img_path):
        ''' 表格识别服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'EntrustOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/EntrustOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def multiFace_detect(self, img_path):
        ''' 多人脸检测服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'multiFace_detect'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/multiFace_detect'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def fiveSenses_detect(self, img_path):
        ''' 五官检测服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'fiveSenses_detect'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/fiveSenses_detect'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def face_detect(self, img_path):
        ''' 有无人像检测服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'face_detect'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/face_detect'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def block_detect(self, img_path):
        ''' 人像遮挡检测服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'block_detect'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/block_detect'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def hat_detect(self, img_path):
        ''' 免冠检测服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'hat_detect'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/hat_detect'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def exposure_detect(self, img_path):
        ''' 图像曝光度过高服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'exposure_detect'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/exposure_detect'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def clear_detect(self, img_path):
        ''' 图像质量清析度检测服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'clear_detect'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/clear_detect'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def face_audit(self, img_path):
        ''' 人像质量稽核服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'face_audit'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/face_audit'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def detection(self, img_path):
        ''' PS证件篡改识别服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'detection'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/detection/detection'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def signature(self, img_path):
        ''' 电子签名服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'signature'
        params['file'] = img_data
        params['file_type'] = img_path.split('.')[-1]
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/signature'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def poseDetection(self, img_path):
        ''' PS证件篡改关键点检测服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'poseDetection'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/poseDetection/poseDetection'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def UIMCardOCR(self, img_path):
        ''' UIM卡识别服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'UIMCardOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/UIMCardOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def notification(self, img_path):
        ''' 告知书合规性稽核服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'notification'
        params['file'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/notification'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def authorization(self, img_path):
        ''' 委托函稽核服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'authorization'
        params['file'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/authorization'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def offcial_letter(self, img_path):
        ''' 公函清晰度识别服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'offcial_letter'
        params['file'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/offcial_letter'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))


    def resBookLicenseOCR(self, img_path):
        ''' 户口本识别服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'resBookLicenseOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/resBookLicenseOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def BankCardOCR(self, img_path):
        ''' 银行卡识别服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'BankCardOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/BankCardOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def decrypt(self, text):
        """
        解密消息
        :param text: 加密文本
        :return:
        """
        try:

            cryptor = AES.new(self.sKey, AES.MODE_ECB)

            plain_text = cryptor.decrypt(base64.b64decode(text))
            plain_text = bytes.decode(plain_text)
            # print(plain_text)
            if plain_text[0] == "{":
                if plain_text[len(plain_text) - 1] == "}":
                    return json.loads(plain_text)
                else:
                    return json.loads(plain_text[: plain_text.rfind("}") + 1])
            elif plain_text[0] == "[":
                if plain_text[len(plain_text) - 1] == "]":
                    return json.loads(plain_text)
                else:
                    return json.loads(plain_text[: plain_text.rfind("]") + 1])
            else:
                return []
        except Exception as e:
            # print(e)
            return []


if __name__ == '__main__':



    sdk = DopAPI(appKey, appSecret)
    # 单张测试
    #     appKey = 'c2c0187368e39d1f5ec4fdbbdbeea9c5'
    #
    #     appSecret = 'd40597b42bb0c6848615e1a5f806b987'sdk.LicenseOCR('/home/linyicheng/wanghb/AI_EnterpriseLicense/docs/11月号百问题图片/07668983989.png')
    # sdk.BusinessLicenseOCR(pic_name)       #营业执照
    # sdk.generalOCR(pic_name)               #通用文字
    # sdk.idCardOCR(pic_name)                #身份证
    # sdk.PRCorganCodeLicenseOCR(pic_name)     # 全国组织机构代码证识别API
    # sdk.autoCodeLicenseOCR('0.jpg')  # 基层群众性自治组织代码证识别API
    # sdk.foreignOrganLicenseOCR('0.jpg')     # 外国常驻代表机构登记证识别API
    # sdk.PRCmedicalOrganLicenseOCR('0.jpg')  # 全国医疗机构执业许可证识别API
    # sdk.PRCCodeLicenseOCR('0.jpg')          # 全国统一社会信用代码证识别API
    # sdk.ElectIncOCR('1.pdf')                # 全国电子发票识别服务接口API
    # sdk.socialOrganLicenseOCR('0.jpg')      # 社会团体法人登记证书识别服务接口API
    # sdk.doorPlateReco('0.jpg')              # 门牌识别服务接口API
    # sdk.creditCodeLicenseOCR('0.jpg')       # 统一社会信用代码证书识别服务接口API
    # sdk.ruralCollectiveLicenseOCR('0.jpg')  # 农村集体经济组织登记证识别服务接口API
    # sdk.publicInstitutionLicenseOCR('0.jpg')# 事业单位法人证书识别服务接口API
    # sdk.nonEnterpriseLicenseOCR('0.jpg')    # 民办非企业证书识别服务接口API
    # sdk.LicenseOCR('0.jpg')    # 证照识别服务接口API
    # sdk.letterOCR('0.jpg')    # 委托函识别服务接口API
    # sdk.businessLicenseOCR('0.jpg')    # 营业执照识别服务接口API
    # sdk.Face_similarity('2.png')    # 人脸比对接口API
    # sdk.FaceContrast('0.jpg')    # 人证合规性稽核服务接口API
    # sdk.idcardTemporaryOcr('0.jpg')    # 临时身份证识别服务接口API
    # sdk.expressBillOCR('0.jpg')    # 快递单识别服务接口API
    # sdk.licenseCensor('0.jpg')    # 证照质量检测服务API
    # sdk.mask('0.jpg')    # 口罩识别服务接口API
    # sdk.remake_detect('0.jpg')    # 活体翻拍服务接口API
    # sdk.sealOCR('0.jpg')    # 印章识别服务接口API
    # sdk.elecMeterOCR('0.jpg')    # 电表识别服务接口API
    # sdk.EntrustOCR('0.jpg')    # 表格识别服务接口API
    # sdk.multiFace_detect('0.jpg')    # 多人脸检测服务接口API
    # sdk.fiveSenses_detect('0.jpg')    # 五官检测服务接口API
    # sdk.face_detect('0.jpg')    # 有无人像检测服务接口API
    # sdk.block_detect('0.jpg')    # 人像遮挡检测服务接口API
    sdk.hat_detect('0.jpg')    # 免冠检测服务接口API
    # sdk.exposure_detect('0.jpg')    # 图像曝光度过高服务接口API
    # sdk.clear_detect('0.jpg')    # 图像质量清析度检测服务接口API
    # sdk.face_audit('0.jpg')    # 人像质量稽核服务接口API
    # sdk.detection('0.jpg')    # PS证件篡改识别服务接口API
    # sdk.signature('0.jpg')    # 电子签名服务接口API
    # sdk.poseDetection('0.jpg')    # PS证件篡改关键点检测服务接口API
    # sdk.UIMCardOCR('0.jpg')    # UIM卡识别服务接口API
    # sdk.notification('0.jpg')    # 告知书合规性稽核服务接口API
    # sdk.authorization('0.jpg')    # 委托函识别服务接口API
    # sdk.offcial_letter('0.jpg')    # 公函清晰度识别服务接口API
    # sdk.resBookLicenseOCR('0.jpg')    # 户口本识别服务接口API
    # sdk.BankCardOCR('0.jpg')    # 银行卡识别服务接口API

    # print('分析用时（秒）:', result)
    # 批量测试
    # path = '/home/linyicheng/wanghb/AI_EnterpriseLicense/docs/11月号百问题图片'
    # path = '/home/linyicheng/wanghb/Dcoos_test/gd_test'
    #path = '/home/linyicheng/wanghb/Dcoos_test/business_154'
    # path = '/home/linyicheng/wanghb/idcard_ori_200'
    import time
    #
    # for pic in os.listdir(path):
    #     pic_name = path + '/' + pic
    #     print(pic_name)
    #     start = time.time()
    #
    #     # sdk.BusinessLicenseOCR(pic_name)       #营业执照
    #     # sdk.generalOCR(pic_name)               #通用文字
    #     # sdk.idCardOCR(pic_name)                #身份证
    #     #sdk.PRCorganCodeLicenseOCR(pic_name)     # 全国组织机构代码证识别API
    #     sdk.autoCodeLicenseOCR(pic_name)         # 基层群众性自治组织代码证识别API
    #     #sdk.foreignOrganLicenseOCR(pic_name)     # 外国常驻代表机构登记证识别API
    #     #sdk.PRCmedicalOrganLicenseOCR(pic_name)  # 全国医疗机构执业许可证识别API
    #     # sdk.PRCCodeLicenseOCR(pic_name)          # 全国统一社会信用代码证识别API
    #     # sdk.ElectIncOCR(pic_name)                # 全电子发票识别服务接口API
    #     # sdk.socialOrganLicenseOCR(pic_name)      # 社会团体法人登记证书识别服务接口API
    #     # sdk.doorPlateReco(pic_name)              # 门牌识别服务接口API
    #     # sdk.creditCodeLicenseOCR(pic_name)       # 统一社会信用代码证书识别服务接口API
    #     # sdk.ruralCollectiveLicenseOCR(pic_name)  # 农村集体经济组织登记证识别服务接口API
    #     # sdk.publicInstitutionLicenseOCR(pic_name)# 事业单位法人证书识别服务接口API
    #     # sdk.nonEnterpriseLicenseOCR(pic_name)    # 民办非企业证书识别服务接口API
    #     end = time.time()
    #     print('===============================')
    #
    #     print('耗时：', end - start)
    #     # sdk.perLicense(pic_name)
    #     print('===============================')
