import cv2
import os
from collections import Counter
path=r'\\192.168.35.126\public\hbw\idcard\data0818\images'
shapes=[]
labelpath=r'\\192.168.35.126\public\hbw\idcard\data0818\labels/'
for img in os.listdir(path):
    url=path+'/'+img
    image=cv2.imread(url)
    shape=image.shape

    height,width=shape[0],shape[1]
    if shape==(412,324,3):

        label=[[2,2,322,204,0],
               [2,208,322,410,1],
               [202,26,304,152,2]]
        # for i in label:
        #     cv2.rectangle(image, (i[0], i[1]), (i[2], i[3]), (0, 0, 255), 2)
        # cv2.imshow('1', image)
        # cv2.waitKey(0)
    elif shape==(434, 340, 3):

        label = [[2, 2, 338, 215, 0],
                 [2, 219, 338, 432, 1],
                 [212, 38, 320, 163, 2]]
        # for i in label:
        #     cv2.rectangle(image, (i[0], i[1]), (i[2], i[3]), (0, 0, 255), 2)
        # cv2.imshow('1', image)
        # cv2.waitKey(0)

    elif shape==(437, 338, 3):

        label = [[2, 2, 336, 215, 0],
                 [2, 219, 336, 432, 1],
                 [212, 38, 320, 163, 2]]
        # for i in label:
        #     cv2.rectangle(image, (i[0], i[1]), (i[2], i[3]), (0, 0, 255), 2)
        # cv2.imshow('1', image)
        # cv2.waitKey(0)

    elif shape==(549, 432, 3):

        label = [[2, 2, 430, 273, 0],
                 [2, 277, 430, 545, 1],
                 [266, 38, 400, 200, 2]]
        # for i in label:
        #     cv2.rectangle(image, (i[0], i[1]), (i[2], i[3]), (0, 0, 255), 2)
        # cv2.imshow('1', image)
        # cv2.waitKey(0)
    else:
        continue
    txturl=labelpath+img.split('.')[0]+'.txt'
    with open(txturl, "w") as f:

        for i in label:
            x_min,y_min,x_max,y_max=i[0],i[1],i[2],i[3]
            x_center=(x_max+x_min)/2
            y_center=(y_max+y_min)/2
            x=x_center/width
            y=y_center/height
            w=(x_max-x_min)/width
            h=(y_max-y_min)/height
            x=format(x,'.5f')
            y=format(y,'.5f')
            w=format(w,'.5f')
            h=format(h,'.5f')
            s=str(i[-1])+" "+str(x)+" "+str(y)+" "+str(w)+" "+str(h)+'\n'
            f.write(s)






