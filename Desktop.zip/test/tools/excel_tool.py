import pandas as pd

testRes0 = pd.DataFrame(columns=['dev_id', 'seqid'])

filename = pd.read_excel(r'E:\ffcs\workspace\excel\0601-15.xlsx')

filename2 = pd.read_excel(r'feedback.xlsx')

args_list = filename.iloc[:, 0]

sel_time = filename2.iloc[:, 5]
dev_id = filename2.iloc[:, 2]
for date in range(1,16):
    temp=str(date)
    temp=temp.zfill(2)
    temp='202106'+temp
    result = []
    for sel, dev in zip(sel_time, dev_id):
        if temp in str(sel):
            for args in args_list:
                dev = dev.replace(' ', '')
                if dev in args and temp in args:
                    args = eval(args)
                    # print(args['seqid'])
                    result.append([dev, args['seqid']])
    for i in range(len(result)):
        testRes0.loc[i] = result[i]
        print(result[i])
        print('======')
    testRes0.to_excel(r'C:\Users\gstx\Desktop\拉取结果表格/'+temp+'.xlsx', index=False)
    print(temp,'success')