# -*- coding: utf-8 -*-

'''
@project : AIGateWay
@FileName: image_util
@Author  :linych 
@Time    :2020/12/11 9:32
@Desc  : 
'''

import os
import sys

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import base64
import numpy as np

import cv2



def base64toarray(imagebase64):
    base64Image = imagebase64.replace("%2B", "+").replace("%3D", "=").replace("%2F", "/")
    img = base64.b64decode(base64Image)

    img_array = np.frombuffer(img, np.uint8)
    ori_img_array = cv2.imdecode(img_array, cv2.COLOR_RGB2BGR)

    return ori_img_array


def image_pos(fea_x1, fea_y1, fea_w, fea_h, all_w, all_h, drop=0.2):
    p_x1 = all_w * drop
    p_x2 = all_w * (1 - drop)
    p_y1 = all_h * drop
    p_y2 = all_h * (1 - drop)

    fea_x2 = fea_x1 + fea_w
    fea_y2 = fea_y1 + fea_h

    # in_h = min(fea_y2, p_y2) - max(fea_y1, p_y1)
    # in_w = min(fea_x2, p_x2) - max(fea_x1, p_x1)
    #
    # inner_area = 0 if in_h < 0 or in_w < 0 else in_h * in_w
    fea_area = fea_w * fea_h

    x11 = max(fea_x1, p_x1)
    y11 = max(fea_y1, p_y1)

    x22 = min(fea_x2, p_x2)
    y22 = min(fea_y2, p_y2)

    # print(x11, y11, x22, y22)

    inner_area = max(0, (x22 - x11) * (y22 - y11))

    return inner_area / fea_area


def image_area(w, h):
    return w * h


def img_arry_cut_to_base64(image, bbox):
    ori_img = image[int(bbox[1]):int(bbox[1]) + int(bbox[3]), int(bbox[0]):int(bbox[0]) + int(bbox[2])]
    image_base64 = cv2.imencode('.jpg', ori_img)[1].tostring()
    image_base64 = base64.b64encode(image_base64)
    image_base64 = str(image_base64)[2:-1]
    return image_base64


def img_cut(image_base64, bbox):
    base64Image = image_base64.replace("%2B", "+").replace("%3D", "=").replace("%2F", "/")
    img = base64.b64decode(base64Image)
    img_array = np.frombuffer(img, np.uint8)
    ori_img = cv2.imdecode(img_array, cv2.COLOR_RGB2BGR)
    # cv2.imwrite("/home/face/projects/SmartHomeVideo/temp/be_cutface.jpg", ori_img)
    # print(ori_img.shape)
    ori_img = ori_img[int(bbox[1]):int(bbox[1]) + int(bbox[3]), int(bbox[0]):int(bbox[0]) + int(bbox[2])]  # x, y, w, h

    # print("[{},{},{},{}]".format(int(bbox[1]), int(bbox[1])+int(bbox[3]), int(bbox[0]), int(bbox[0])+int(bbox[2])))

    # ori_img = ori_img[
    #           max(0, int(bbox[1] - bbox[3] * cut_prob)):min(int(bbox[1] + bbox[3] * (1 + cut_prob)), ori_img.shape[0]),
    #           max(0, int(bbox[0] - bbox[2] * cut_prob)):min(int(bbox[0] + bbox[2] * (1 + cut_prob)),
    #                                                         ori_img.shape[1])]  # x, y, w, h
    # ori_img = ori_img[bbox[1]:bbox[1]+bbox[3], bbox[0]:bbox[0]+bbox[2]]

    # print(ori_img.shape)
    image_base64 = cv2.imencode('.jpg', ori_img)[1].tostring()
    image_base64 = base64.b64encode(image_base64)
    image_base64 = str(image_base64)[2:-1]
    # cv2.imwrite("/home/face/projects/SmartHomeVideo/temp/cutface.jpg",ori_img)
    return image_base64


def img_resize(img):
    h, w, c = img.shape
    if h > 300 or w > 300:
        h_scale = 300
        w_scale = int(h_scale / h * w)
        img = cv2.resize(img, (w_scale, h_scale))
    return img


def img_to_base64(img_path):
    img = cv2.imread(img_path)
    pic_str = base64.b64encode(img)
    pic_str = pic_str.decode()
    return pic_str


def array_to_base64(img_array):
    retval, buffer = cv2.imencode('.jpg', img_array)
    pic_str = base64.b64encode(buffer)
    pic_str = pic_str.decode()
    return pic_str


def base64_to_array(img_base64, size=None):
    img_data = base64.b64decode(img_base64)
    nparr = np.fromstring(img_data, np.uint8)
    if size:
        img_np = nparr.reshape(size)
        return img_np
    img_np = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
    return img_np


def img_cut_resize(img_array, bbox, cut_prob):
    img_array = img_array[
                max(0, int(bbox[1] - bbox[3] * cut_prob)):min(int(bbox[1] + bbox[3] * (1 + cut_prob)),
                                                              img_array.shape[0]),
                max(0, int(bbox[0] - bbox[2] * cut_prob)):min(int(bbox[0] + bbox[2] * (1 + cut_prob)),
                                                              img_array.shape[1])]
    return img_array


def img_cut_no_prob(img_array, bbox):
    # bbox=[x,y,w,h]

    img_array = img_array[max(0, int(bbox[1])):min(int(bbox[1] + bbox[3]), img_array.shape[0]),
                max(0, int(bbox[0])):min(int(bbox[0] + bbox[2]), img_array.shape[1])]
    return img_array




if __name__ == '__main__':
    img_path = r'E:\Download\edge_download\582bde3ea89e7346745214a858175942.jpeg'
    frame = cv2.imread(img_path)
    img_str = cv2.imencode('.jpg', frame)[1].tostring()  # 将图片编码成流数据，放到内存缓存中，然后转化成string格式
    b64_code = base64.b64encode(img_str).decode('utf-8')  # 编码成base64
    # print(b64_code)
    box = [835, 449, 432, 439]
    # img_cut(b64_code, box)
    # print(img_to_base64(img_path))
    with open(img_path, 'rb') as f:
        image_base64 = base64.b64encode(f.read())
    print(str(image_base64))
