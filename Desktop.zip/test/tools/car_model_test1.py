# -*- encoding: utf-8 -*-
"""
@Project : AIImagePlatform
@FileName: car_model_test
@Time    : 2021/11/16 16:00 
@Author  : zhangec
@Desc    :
"""
import random
import threading

import numpy as np
import cv2
import tritonclient.http as httpclient
import base64
import pandas as pd
import json
np.set_printoptions(suppress=True)

char_table = ['京', '沪', '津', '渝', '冀', '晋', '蒙', '辽', '吉', '黑',
         '苏', '浙', '皖', '闽', '赣', '鲁', '豫', '鄂', '湘', '粤',
         '桂', '琼', '川', '贵', '云', '藏', '陕', '甘', '青', '宁',
         '新', '使', '领', '港', '澳', '警', '学', '挂',
         '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
         'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'J', 'K',
         'L', 'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'U', 'V',
         'W', 'X', 'Y', 'Z', '-'
         ]
car_categories = ["person", "car", "非机动车"]
plate_categories = ["蓝牌", "绿牌", "黄牌"]  # "蓝牌","绿牌","黄牌"
color_categories = ["0", "1", "2"]
type_categories = ["0", "1", "2"]
vehicle_color_categories = {0: "brown", 1: "yellow", 2: "blue", 3: "red", 4: "green", 5: "black", 6: "white",
                            7: "purple", 8: "gray"}
vehicle_type_categories = {0: "car", 1: "bus", 2: "truck"}

tri_lis = []
for i in range(0, 10):
    triton_client_tmp = httpclient.InferenceServerClient(url="{}:{}".format('10.142.156.167', '41000'), verbose=False)
    tri_lis.append(triton_client_tmp)


def get_car_discern(image):
    # print("start image:",image_path,"======================================================")
    model_name = "end2end"
    # retina_letterbox:
    #  1:scaleup=false src_location=center
    #  2:scaleup=true src_location=center
    #  3:scaleup=false src_location=lefttop
    #  4:scaleup=true src_location=lefttop
    retina_letter_box = 3
    #image = cv2.imread('/home/linyicheng/car.jpg').astype(np.uint8)
    image = np.expand_dims(image, axis=0)
    file_name = ['./car.png']
    input_retina_letterbox = np.array([[retina_letter_box] for _ in range(len(file_name))], dtype=np.int32)
    print("input_retina_letterbox:", input_retina_letterbox)

    input_size = np.array([[640, 640] for _ in range(len(file_name))], dtype=np.uint16)

    inputs = []
    # inputs.append(httpclient.InferInput('ensemble_input_base64', list(input_base64_matrix.shape), "UINT8"))
    # inputs.append(httpclient.InferInput('ensemble_input_base64_param', list(input_param.shape), "UINT32"))
    # inputs.append(httpclient.InferInput('ensemble_input_size', list(input_size.shape), "UINT16"))
    # inputs[0].set_data_from_numpy(input_base64_matrix)
    # inputs[1].set_data_from_numpy(input_param)
    # inputs[2].set_data_from_numpy(input_size)
    inputs.append(httpclient.InferInput('ensemble_input_image', list(image.shape), "UINT8"))
    # inputs.append(httpclient.InferInput('ensemble_input_base64_param', list(input_param.shape), "UINT32"))
    inputs.append(httpclient.InferInput('ensemble_input_size', list(input_size.shape), "UINT16"))
    inputs.append(httpclient.InferInput('ensemble_input_retina_letterbox', list(input_retina_letterbox.shape), "INT32"))
    inputs[0].set_data_from_numpy(image)
    inputs[1].set_data_from_numpy(input_size)
    inputs[2].set_data_from_numpy(input_retina_letterbox)

    outputs = []
    outputs.append(httpclient.InferRequestedOutput('e_out_nmsresult'))
    outputs.append(httpclient.InferRequestedOutput('e_out_carbboxs'))
    outputs.append(httpclient.InferRequestedOutput('ensemble_out_imgidx4car'))
    # outputs.append(httpclient.InferRequestedOutput('e_out_color'))
    # outputs.append(httpclient.InferRequestedOutput('e_out_type'))
    # outputs.append(httpclient.InferRequestedOutput('e_out_plate_conf'))
    outputs.append(httpclient.InferRequestedOutput('e_out_plate_attr_prob'))
    outputs.append(httpclient.InferRequestedOutput('e_out_plate_labels'))
    outputs.append(httpclient.InferRequestedOutput('e_out_plate_word_scores'))
    outputs.append(httpclient.InferRequestedOutput('e_out_plate_bbox'))
    outputs.append(httpclient.InferRequestedOutput('e_out_plate_point'))
    outputs.append(httpclient.InferRequestedOutput('e_out_caridx4plate'))
    # outputs.append(httpclient.InferRequestedOutput('out_plate_rec_imgs'))

    results = triton_client_tmp.infer(
        model_name=model_name, inputs=inputs, outputs=outputs, headers={"test": "1"}
    )
    # out_plate_rec_imgs = results.as_numpy("out_plate_rec_imgs")
    # print("out_plate_rec_imgs.shape:",out_plate_rec_imgs.shape)
    e_out_nmsresult = results.as_numpy("e_out_nmsresult")
    e_out_carbboxs = results.as_numpy("e_out_carbboxs")
    ensemble_out_imgidx4car = results.as_numpy("ensemble_out_imgidx4car")
    # e_out_type = results.as_numpy("e_out_type")
    # e_out_color = results.as_numpy("e_out_color")
    e_out_plate_attr_prob = results.as_numpy("e_out_plate_attr_prob")
    # e_out_plate_cls = results.as_numpy("e_out_plate_cls")
    e_out_plate_labels = results.as_numpy("e_out_plate_labels")
    e_out_plate_word_scores = results.as_numpy("e_out_plate_word_scores")
    e_out_plate_bbox = results.as_numpy("e_out_plate_bbox")
    e_out_plate_point = results.as_numpy("e_out_plate_point")
    e_out_caridx4plate = results.as_numpy("e_out_caridx4plate")

    # e_out_lpr_res_idx = results.as_numpy("e_out_lpr_res_idx")
    # e_out_lpr_res_score = results.as_numpy("e_out_lpr_res_score")

    # e_out_platebboxs_noenlarge = results.as_numpy("e_out_platebboxs_noenlarge")

    print("e_out_carbboxs:", e_out_carbboxs)
    print("ensemble_out_imgidx4car:", ensemble_out_imgidx4car)
    # print("e_out_type.shape:", e_out_type.shape)
    # print("e_out_color.shape:", e_out_color.shape)
    print("e_out_plate_attr_prob:", e_out_plate_attr_prob)
    print("e_out_plate_labels:", e_out_plate_labels)
    print("e_out_plate_word_scores:", e_out_plate_word_scores)
    print("e_out_plate_bbox:", e_out_plate_bbox)
    print("e_out_plate_point:", e_out_plate_point)
    print("e_out_caridx4plate:", e_out_caridx4plate)

    # print("out_imgidx4plate:", out_imgidx4plate)

    # lpr_result = lpr_postprocess(e_out_lpr_res_idx, e_out_lpr_res_score, e_out_platebboxs_noenlarge)

    plate_result = plate_postprocess(e_out_plate_labels, e_out_plate_word_scores, e_out_plate_bbox, \
                                     e_out_plate_point, e_out_plate_attr_prob,
                                     e_out_caridx4plate)

    pipeline_result_list = []
    # plate_idxs = list(out_imgidx4plate.flatten())
    plate_idxs = list(e_out_caridx4plate.flatten())
    # car_to_img_batch_idxs = list(ensemble_out_imgidx4car.flatten())
    car_to_img_batch_idxs = list(ensemble_out_imgidx4car.flatten())
    # 车牌检测 》 车辆检测、车牌识别 》 车辆属性
    for car_index, car_item in enumerate(e_out_carbboxs):
        # print(car_index,car_item)
        car_item = car_item.tolist()

        item_dict = {
            "class_name": car_categories[int(car_item[5])],
            "vehicle_bbox": [int(n) for n in car_item[:4]],
            "score": car_item[4],
            "classid": int(car_item[5]),
            "image_batch_index": int(car_to_img_batch_idxs[car_index])
        }
        #with open("tmp.json", "w", encoding='utf-8') as f:
        #    json.dump(item_dict, f, ensure_ascii=False)

        # 是否 有车牌

        # if car_index in out_imgidx4plate.flatten():
        if car_index in e_out_caridx4plate.flatten():
            plate_id = plate_idxs.index(car_index)
            print("car_index:", car_index)
            print("plate_id:", plate_id)
            # plate_box_no_enlarge = e_out_platebboxs_noenlarge[plate_id].tolist()
            print("plate_result.len:", len(plate_result))
            item_dict["plate_item"] = plate_result[plate_id]


        pipeline_result_list.append(item_dict)
    
    result = []
    for item in pipeline_result_list:
        result.append(item)
    print(f"车辆模型返回结果： {result}")
    return result

def plate_postprocess(plate_labels, plate_word_scores, plate_bboxes, plate_points, e_out_plate_attr_prob,
                      caridx4plate):
    plate_rec_conf = 0.6
    result = []
    batchsize = plate_bboxes.shape[0]
    for i in range(batchsize):
        plate_attr_prob = e_out_plate_attr_prob[i]
        plate_attr_score = np.exp(plate_attr_prob) / (0.000001 + np.sum(np.exp(plate_attr_prob)))
        plate_cls = np.argmax(plate_attr_score)
        #print("plate_cls:", plate_cls)
        res = plate_labels[i].astype('int')
        score = plate_word_scores[i]
        box = plate_bboxes[i]
        points = plate_points[i]
        label = ""
        label += char_table[int(res[0])]

        min_score = float('inf')
        for index, c in enumerate(res[1:]):
            if char_table[int(c)] == "-":
                continue
            label += char_table[int(c)]
            min_score = min(min_score, score[1 + index])

        plate_info = {}
        plate_info["plate_type"] = plate_cls
        # plate_info["plate_cls_conf"] = cur_plate_attr_conf  # no need
        plate_info["plate_number"] = label
        plate_info["plate_number_conf"] = min_score
        plate_info["plate_bbox"] = box
        plate_info["plate_points"] = points
        # plate_info["carindex"] = caridx4plate[i]
        plate_info["plate_conf"] = box[4]
        result.append(plate_info)
    return result

def savejson(file_name):
    fileObject = open(
        '/data6/AI_ImageLibrary/AI_DataAudit/cars_Dataset/Vedio_streaming/car_211222_json/{}.json'.format(
            file_name.split('.')[0]+file_name.split('.')[1]), 'w')
    fileObject.write(str(result))
    fileObject.close()
def saveimg(file_name):
    savePath = '/data6/AI_ImageLibrary/AI_DataAudit/cars_Dataset/Vedio_streaming/car_211222_after' + '/' + file_name
    cv2.imencode('.jpg', image)[1].tofile(savePath)


import time
import os
if __name__ == '__main__':

    have=[]
    for i in os.listdir('/data6/AI_ImageLibrary/AI_DataAudit/cars_Dataset/Vedio_streaming/car_211222_json'):
        have.append(i.split('.')[0])

    path = '/data6/AI_ImageLibrary/AI_DataAudit/cars_Dataset/Vedio_streaming/car_211222'
    for file_name in os.listdir(path):
            if file_name.split('.')[0] in have:
                continue
            print('11111')
            starttime = time.time()
            image = cv2.imread(path + '/' + file_name).astype(np.uint8)
            image = cv2.resize(image, (960, 540))
            result = get_car_discern(image)
            # endtime1 = time.time()
            # print('=============预测耗时===================')
            # print(endtime1 - starttime)
            # a=0

            if len(result) > 0:
                threads = []
                t1 = threading.Thread(target=savejson, args=(file_name,))
                threads.append(t1)
                t2 = threading.Thread(target=saveimg, args=(file_name,))
                threads.append(t2)

                for t in threads:
                    t.setDaemon(True)
                    t.start()

                for t in threads:
                    t.join()

            endtime=time.time()
            print('=============耗时===================')
            print(endtime-starttime)
