import os
import numpy as np
import pandas as pd
import cv2
import base64
import requests
import json
import shutil

exl=r'E:\ffcs\workspace\0809\活体检测-东信-自研对比结果(1).xlsx'
df=pd.read_excel(exl,sheet_name='Sheet3')

xc=df['超链接']
# zj=df['证件图片超链接']
for i in xc:
    print(i)
    img=i.split('/')[-1]
    shutil.copy(i,r'\\192.168.35.126\public\人像合规性稽核\山东数据\上传集团照片文件\fht/'+img)