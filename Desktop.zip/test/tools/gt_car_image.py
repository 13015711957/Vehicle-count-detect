from av import open
from multiprocessing import Process, Queue
import cv2

queue_out = Queue()
streamUrl = '/data6/AI_ImageLibrary/AI_DataAudit/cars_Dataset/Driving/2016_0806_200401_615.MOV'
# try:

dic_option = {'rtsp_transport': 'tcp'}
video = open(streamUrl, options=dic_option, timeout=(50, 120))
# except Exception as e:
#     # queue_out.put((did,'no connect'))
#     #continue
#     pass

stream = next(s for s in video.streams if s.type == 'video')
stream.codec_context.skip_frame = 'NONKEY'
cnt = 0
index = 0
is_break = False
imgname=0
for packet in video.demux(stream):
    for frame in packet.decode():
        if frame.key_frame:
            index +=1
#           if index%3==0:
#           continue
        cnt+=1
        if cnt>4:
            is_break = True
        img = frame.to_ndarray(format='rgb24')
        image = img[:, :, ::-1]

        cv2.imwrite(str(imgname)+'_.jpg',image)
        print(imgname)
        imgname+=1


