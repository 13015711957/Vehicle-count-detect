import numpy as np
import sys
import cv2
import tritonclient.http as httpclient
import base64
import random
import os
# import torch.nn.functional as F
# import torch
import json

np.set_printoptions(suppress=True)
# char_table = ["京", "沪", "津", "渝", "冀", "晋", "蒙", "辽", "吉", "黑",
#               "苏", "浙", "皖", "闽", "赣", "鲁", "豫", "鄂", "湘", "粤",
#               "桂", "琼", "川", "贵", "云", "藏", "陕", "甘", "青", "宁",
#               "新",
#               "0", "1", "2", "3", "4", "5", "6", "7", "8", "9",
#               "A", "B", "C", "D", "E", "F", "G", "H", "J", "K",
#               "L", "M", "N", "P", "Q", "R", "S", "T", "U", "V",
#               "W", "X", "Y", "Z", "I", "O", "-"
#               ]
char_table = ['京', '沪', '津', '渝', '冀', '晋', '蒙', '辽', '吉', '黑',
         '苏', '浙', '皖', '闽', '赣', '鲁', '豫', '鄂', '湘', '粤',
         '桂', '琼', '川', '贵', '云', '藏', '陕', '甘', '青', '宁',
         '新', '使', '领', '港', '澳', '警', '学', '挂',
         '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
         'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'J', 'K',
         'L', 'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'U', 'V',
         'W', 'X', 'Y', 'Z', '-'
         ]
car_categories = ["person", "car", "非机动车"]
plate_categories = ["蓝牌", "绿牌", "黄牌"]  # "蓝牌","绿牌","黄牌"
color_categories = ["0", "1", "2"]
type_categories = ["0", "1", "2"]
vehicle_color_categories = {0: "brown", 1: "yellow", 2: "blue", 3: "red", 4: "green", 5: "black", 6: "white",
                            7: "purple", 8: "gray"}
vehicle_type_categories = {0: "car", 1: "bus", 2: "truck"}


def get_box(triton_client, image_path):
    # print("start image:",image_path,"======================================================")
    model_name = "end2end"
    # retina_letterbox:
    #  1:scaleup=false src_location=center
    #  2:scaleup=true src_location=center
    #  3:scaleup=false src_location=lefttop
    #  4:scaleup=true src_location=lefttop
    retina_letter_box = 3
    image = cv2.imread(image_path).astype(np.uint8)
    image = np.expand_dims(image, axis=0)
    file_name = [image_path]
    input_retina_letterbox = np.array([[retina_letter_box] for _ in range(len(file_name))], dtype=np.int32)
    print("input_retina_letterbox:", input_retina_letterbox)

    input_size = np.array([[640, 640] for _ in range(len(file_name))], dtype=np.uint16)

    inputs = []
    # inputs.append(httpclient.InferInput('ensemble_input_base64', list(input_base64_matrix.shape), "UINT8"))
    # inputs.append(httpclient.InferInput('ensemble_input_base64_param', list(input_param.shape), "UINT32"))
    # inputs.append(httpclient.InferInput('ensemble_input_size', list(input_size.shape), "UINT16"))
    # inputs[0].set_data_from_numpy(input_base64_matrix)
    # inputs[1].set_data_from_numpy(input_param)
    # inputs[2].set_data_from_numpy(input_size)
    inputs.append(httpclient.InferInput('ensemble_input_image', list(image.shape), "UINT8"))
    # inputs.append(httpclient.InferInput('ensemble_input_base64_param', list(input_param.shape), "UINT32"))
    inputs.append(httpclient.InferInput('ensemble_input_size', list(input_size.shape), "UINT16"))
    inputs.append(httpclient.InferInput('ensemble_input_retina_letterbox', list(input_retina_letterbox.shape), "INT32"))
    inputs[0].set_data_from_numpy(image)
    inputs[1].set_data_from_numpy(input_size)
    inputs[2].set_data_from_numpy(input_retina_letterbox)

    outputs = []
    outputs.append(httpclient.InferRequestedOutput('e_out_nmsresult'))
    outputs.append(httpclient.InferRequestedOutput('e_out_carbboxs'))
    outputs.append(httpclient.InferRequestedOutput('ensemble_out_imgidx4car'))
    # outputs.append(httpclient.InferRequestedOutput('e_out_color'))
    # outputs.append(httpclient.InferRequestedOutput('e_out_type'))
    # outputs.append(httpclient.InferRequestedOutput('e_out_plate_conf'))
    outputs.append(httpclient.InferRequestedOutput('e_out_plate_attr_prob'))
    outputs.append(httpclient.InferRequestedOutput('e_out_plate_labels'))
    outputs.append(httpclient.InferRequestedOutput('e_out_plate_word_scores'))
    outputs.append(httpclient.InferRequestedOutput('e_out_plate_bbox'))
    outputs.append(httpclient.InferRequestedOutput('e_out_plate_point'))
    outputs.append(httpclient.InferRequestedOutput('e_out_caridx4plate'))
    # outputs.append(httpclient.InferRequestedOutput('out_plate_rec_imgs'))

    results = triton_client.infer(
        model_name=model_name, inputs=inputs, outputs=outputs, headers={"test": "1"}
    )
    # out_plate_rec_imgs = results.as_numpy("out_plate_rec_imgs")
    # print("out_plate_rec_imgs.shape:",out_plate_rec_imgs.shape)
    e_out_nmsresult = results.as_numpy("e_out_nmsresult")
    e_out_carbboxs = results.as_numpy("e_out_carbboxs")
    ensemble_out_imgidx4car = results.as_numpy("ensemble_out_imgidx4car")
    # e_out_type = results.as_numpy("e_out_type")
    # e_out_color = results.as_numpy("e_out_color")
    e_out_plate_attr_prob = results.as_numpy("e_out_plate_attr_prob")
    # e_out_plate_cls = results.as_numpy("e_out_plate_cls")
    e_out_plate_labels = results.as_numpy("e_out_plate_labels")
    e_out_plate_word_scores = results.as_numpy("e_out_plate_word_scores")
    e_out_plate_bbox = results.as_numpy("e_out_plate_bbox")
    e_out_plate_point = results.as_numpy("e_out_plate_point")
    e_out_caridx4plate = results.as_numpy("e_out_caridx4plate")

    # e_out_lpr_res_idx = results.as_numpy("e_out_lpr_res_idx")
    # e_out_lpr_res_score = results.as_numpy("e_out_lpr_res_score")

    # e_out_platebboxs_noenlarge = results.as_numpy("e_out_platebboxs_noenlarge")

    print("e_out_carbboxs:", e_out_carbboxs)
    print("ensemble_out_imgidx4car:", ensemble_out_imgidx4car)
    # print("e_out_type.shape:", e_out_type.shape)
    # print("e_out_color.shape:", e_out_color.shape)
    print("e_out_plate_attr_prob:", e_out_plate_attr_prob)
    print("e_out_plate_labels:", e_out_plate_labels)
    print("e_out_plate_word_scores:", e_out_plate_word_scores)
    print("e_out_plate_bbox:", e_out_plate_bbox)
    print("e_out_plate_point:", e_out_plate_point)
    print("e_out_caridx4plate:", e_out_caridx4plate)

    # print("out_imgidx4plate:", out_imgidx4plate)

    # lpr_result = lpr_postprocess(e_out_lpr_res_idx, e_out_lpr_res_score, e_out_platebboxs_noenlarge)

    plate_result = plate_postprocess(e_out_plate_labels, e_out_plate_word_scores, e_out_plate_bbox, \
                                     e_out_plate_point, e_out_plate_attr_prob,
                                     e_out_caridx4plate)

    pipeline_result_list = []
    # plate_idxs = list(out_imgidx4plate.flatten())
    plate_idxs = list(e_out_caridx4plate.flatten())
    # car_to_img_batch_idxs = list(ensemble_out_imgidx4car.flatten())
    car_to_img_batch_idxs = list(ensemble_out_imgidx4car.flatten())
    # 车牌检测 》 车辆检测、车牌识别 》 车辆属性
    for car_index, car_item in enumerate(e_out_carbboxs):
        # print(car_index,car_item)
        car_item = car_item.tolist()

        item_dict = {
            "class_name": car_categories[int(car_item[5])],
            "vehicle_bbox": [int(n) for n in car_item[:4]],
            "score": car_item[4],
            "classid": int(car_item[5]),
            "image_batch_index": int(car_to_img_batch_idxs[car_index])
        }
        with open("tmp.json", "w", encoding='utf-8') as f:
            json.dump(item_dict, f, ensure_ascii=False)

        # 是否 有车牌

        # if car_index in out_imgidx4plate.flatten():
        if car_index in e_out_caridx4plate.flatten():
            plate_id = plate_idxs.index(car_index)
            print("car_index:", car_index)
            print("plate_id:", plate_id)
            # plate_box_no_enlarge = e_out_platebboxs_noenlarge[plate_id].tolist()
            print("plate_result.len:", len(plate_result))
            item_dict["plate_item"] = plate_result[plate_id]


        pipeline_result_list.append(item_dict)
    print("pipline result img:", image_path, "==================================================")
    for item in pipeline_result_list:
        print(item)
    print("pipline result end :==================================================")

    # for item in pipeline_result_list:
    #     print(item)

    # 渲染并保存图片
    osd_images = []
    for fileindex in range(len(file_name)):
        osd_images.append(cv2.imread(file_name[fileindex]))
    for item in pipeline_result_list:
        print(item)
        obj_class_name = item['class_name']

        car_box = item["vehicle_bbox"]
        plot_one_box(
            car_box,
            osd_images[item["image_batch_index"]],
            label="{}".format(
                obj_class_name
                # obj_class_name, item["car_attr"]["color"], item["car_attr"]["type"]
            ),
        )
        if "plate_item" in item.keys():
            if item['plate_item']['plate_number'] != "":
                plate_box = item["plate_item"]["plate_bbox"]
                plate_class_name = item["plate_item"]["plate_type"]
                plate_score = item["plate_item"]["plate_conf"]
                curpoints = item["plate_item"]["plate_points"]
                # y = [0 for _ in range(4)]
                # y[0] = plate_box[0] - plate_box[2] / 2
                # y[2] = plate_box[0] + plate_box[2] / 2
                # y[1] = plate_box[1] - plate_box[3] / 2
                # y[3] = plate_box[1] + plate_box[3] / 2
                plot_one_box(
                    plate_box,
                    osd_images[item["image_batch_index"]],
                    label="{}".format(
                        item["plate_item"]["plate_number"]
                    ),
                )
                for t in range(0, 8, 2):
                    tmppoint = (int(curpoints[t]), int(curpoints[t + 1]))
                    cv2.circle(osd_images[item["image_batch_index"]], tmppoint, 5, (255, 0, 0), 3)

    for index, osd_image in enumerate(osd_images):
        save_path = "trition_out/" + image_path.split("/")[-1].split('.')[0] + "_pipe.jpg"
        print("save_path:", save_path)
        cv2.imwrite(save_path, osd_image)
        # with open("json_out/" + image_path.split("/")[-1].split('.')[0] + ".json", "w", encoding='utf-8') as f:
        #     json.dump(pipeline_result_list, f, ensure_ascii=False)

        # cv2.imwrite("./pytorch_models/resnet_model/pipeline_test_res/" + image_path.split("/")[-1].split('.')[0] +"_pipe.jpg",osd_image)
        # print("cv2 imwrite","./pytorch_models/resnet_model/pipeline_test_res/" + image_path.split("/")[-1].split('.')[0] +"_pipe.jpg")


def plot_one_box(x, img, color=None, label=None, line_thickness=None):
    """
    description: Plots one bounding box on image img,
                 this function comes from YoLov5 project.
    param:
        x:      a box likes [x1,y1,x2,y2]
        img:    a opencv image object
        color:  color to draw rectangle, such as (0,255,0)
        label:  str
        line_thickness: int
    return:
        no return
    """
    tl = (
            line_thickness or round(0.002 * (img.shape[0] + img.shape[1]) / 2) + 1
    )  # line/font thickness
    color = color or [random.randint(0, 255) for _ in range(3)]
    c1, c2 = (int(x[0]), int(x[1])), (int(x[2]), int(x[3]))
    cv2.rectangle(img, c1, c2, color, thickness=tl, lineType=cv2.LINE_AA)
    if label:
        tf = max(tl - 1, 1)  # font thickness
        t_size = cv2.getTextSize(label, 0, fontScale=tl / 3, thickness=tf)[0]
        c2 = c1[0] + t_size[0], c1[1] - t_size[1] - 3
        # cv2.rectangle(img, c1, c2, color, -1, cv2.LINE_AA)  # filled
        cv2.putText(
            img,
            label,
            (c1[0], c1[1] - 2),
            0,
            tl / 4,
            [225, 255, 255],
            thickness=tf,
            lineType=cv2.LINE_AA,
        )


def plate_postprocess(plate_labels, plate_word_scores, plate_bboxes, plate_points, e_out_plate_attr_prob,
                      caridx4plate):
    plate_rec_conf = 0.6
    result = []
    batchsize = plate_bboxes.shape[0]
    for i in range(batchsize):
        plate_attr_prob = e_out_plate_attr_prob[i]
        plate_attr_score = np.exp(plate_attr_prob) / (0.000001 + np.sum(np.exp(plate_attr_prob)))
        plate_cls = np.argmax(plate_attr_score)
        print("plate_cls:", plate_cls)
        res = plate_labels[i].astype('int')
        score = plate_word_scores[i]
        box = plate_bboxes[i]
        points = plate_points[i]
        label = ""
        label += char_table[int(res[0])]

        min_score = float('inf')
        for index, c in enumerate(res[1:]):
            if char_table[int(c)] == "-":
                continue
            label += char_table[int(c)]
            min_score = min(min_score, score[1 + index])

        plate_info = {}
        plate_info["plate_type"] = plate_cls
        # plate_info["plate_cls_conf"] = cur_plate_attr_conf  # no need
        plate_info["plate_number"] = label
        plate_info["plate_number_conf"] = min_score
        plate_info["plate_bbox"] = box
        plate_info["plate_points"] = points
        # plate_info["carindex"] = caridx4plate[i]
        plate_info["plate_conf"] = box[4]
        result.append(plate_info)
    return result


if __name__ == '__main__':
    triton_client = httpclient.InferenceServerClient(url="10.143.165.45:31028", verbose=False)# 工作站上run，请求工作站服务
    # triton_client = httpclient.InferenceServerClient(url="10.141.255.162:30800/car", verbose=False) # 工作站上run，请求工作站服务
    # triton_client = httpclient.InferenceServerClient(url="10.143.165.45:31016", verbose=False) #工作站上run，请求工作站服务
    # triton_client = httpclient.InferenceServerClient(url="127.0.0.1:58000", verbose=False)  # 工作站上run，请求工作站服务
    img_path = "sourceid_0_framenum_34.jpeg"
    # img_path3 = '/home/huangzhe/lyTest/car/car_test.jpg'
    # img_path3 = '/home/ai/triton_models2/test_simple/test_5.jpg'
    img_path2 = "test1.jpg"
    img_path3 = "/home/dubaochen/tmp/pycharm_project_151/yolo_yolo_resnet_lpr/3HKC054385RMDLB_00004140.jpg"

    imgs = os.listdir('/home/linyicheng/hbw/img')
    imgs_path = ['/home/linyicheng/hbw/img/' + i for i in imgs]
    for img in imgs_path:
        print(img)
        get_box(triton_client, img)
        # print(get_box())

    # img = "testimage/1.png"
    # # img = "1627991934438.jpg"
    # img = "./pytorch_models/resnet_model/pipeline_test_imgs/2.jpg"
    # get_box(triton_client, img)

    # images = os.listdir("20210927_jx_jpg_test")
    # for image in images:
    #     imagename = "20210927_jx_jpg_test/" + image
    #     get_box(triton_client, imagename)
