import shutil

import pandas as pd
import os
df = pd.read_excel(r'business_1502_out.xlsx')
path=r'\\192.168.35.126\public\0901打标_事业单位_统一信用代码\211027/'

def mkdir(path):
    # 引入模块
    import os

    # 去除首位空格
    path = path.strip()
    # 去除尾部 \ 符号
    path = path.rstrip("\\")

    # 判断路径是否存在
    # 存在     True
    # 不存在   False
    isExists = os.path.exists(path)

    # 判断结果
    if not isExists:
        os.makedirs(path)

        return True


for tup in df.itertuples():
    print(type(tup[9]))
    if type(tup[9])==str:
        mkdir(path+tup[9])
        shutil.copy(tup[11],path+tup[9]+"/"+tup[1])
