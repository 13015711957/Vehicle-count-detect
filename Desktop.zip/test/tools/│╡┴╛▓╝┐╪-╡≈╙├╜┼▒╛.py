import numpy as np
import sys
import cv2
import tritonclient.http as httpclient
import base64
import random
import os
np.set_printoptions(suppress=True)
char_table = ["京", "沪", "津", "渝", "冀", "晋", "蒙", "辽", "吉", "黑",
              "苏", "浙", "皖", "闽", "赣", "鲁", "豫", "鄂", "湘", "粤",
              "桂", "琼", "川", "贵", "云", "藏", "陕", "甘", "青", "宁",
              "新",
              "0", "1", "2", "3", "4", "5", "6", "7", "8", "9",
              "A", "B", "C", "D", "E", "F", "G", "H", "J", "K",
              "L", "M", "N", "P", "Q", "R", "S", "T", "U", "V",
              "W", "X", "Y", "Z", "I", "O", "-"
              ]

car_categories = ["person","car","非机动车"]
plate_categories = ["蓝牌","绿牌","黄牌"]  # "蓝牌","绿牌","黄牌"
color_categories = ["0","1","2"]
type_categories = ["0","1","2"]
vehicle_color_categories={0:"brown",1:"yellow",2:"blue",3:"red",4:"green",5:"black",6:"white",7:"purple",8:"gray"}
vehicle_type_categories = {0:"car",1:"bus",2:"truck"}


def get_box(triton_client, image_path):
    model_name = "end2end"
    image = cv2.imread(image_path).astype(np.uint8)
    image = np.expand_dims(image, axis=0)
    file_name = [image_path]
    # input_base64_matrix = []
    # img = cv2.imread(file_name[0])
    # # input_base64_matrix.append([x for x in base64.b64encode(open("dog.jpg","rb").read())])
    # input_base64_matrix.append([x for x in base64.b64encode(open(file_name[0], "rb").read())])
    # # input_base64_matrix.append([x for x in base64.b64encode(open(file_name[1],"rb").read())])
    # input_base64_matrix_len_list = [len(l) for l in input_base64_matrix]
    # max_len = max(input_base64_matrix_len_list)
    # input_base64_matrix = list(map(lambda l: l + [0] * (max_len - len(l)), input_base64_matrix))
    # input_base64_matrix = np.array(input_base64_matrix, dtype=np.uint8)
    # print(input_base64_matrix.shape)
    #
    # # 576,768 （h,w)
    # input_param = [(img.shape[0], img.shape[1], x) for x in input_base64_matrix_len_list]
    # # input_param = [(360,640,x) for x in input_base64_matrix_len_list]
    # input_param = np.array(input_param, dtype=np.uint32)
    # print(input_param)

    input_size = np.array([[640, 640] for _ in range(len(file_name))], dtype=np.uint16)

    inputs = []
    # inputs.append(httpclient.InferInput('ensemble_input_base64', list(input_base64_matrix.shape), "UINT8"))
    # inputs.append(httpclient.InferInput('ensemble_input_base64_param', list(input_param.shape), "UINT32"))
    # inputs.append(httpclient.InferInput('ensemble_input_size', list(input_size.shape), "UINT16"))
    # inputs[0].set_data_from_numpy(input_base64_matrix)
    # inputs[1].set_data_from_numpy(input_param)
    # inputs[2].set_data_from_numpy(input_size)
    inputs.append(httpclient.InferInput('ensemble_input_image', list(image.shape), "UINT8"))
    # inputs.append(httpclient.InferInput('ensemble_input_base64_param', list(input_param.shape), "UINT32"))
    inputs.append(httpclient.InferInput('ensemble_input_size', list(input_size.shape), "UINT16"))
    inputs[0].set_data_from_numpy(image)
    inputs[1].set_data_from_numpy(input_size)

    outputs = []
    outputs.append(httpclient.InferRequestedOutput('e_out_nmsresult'))
    outputs.append(httpclient.InferRequestedOutput('e_out_platebboxs'))
    outputs.append(httpclient.InferRequestedOutput('e_out_platebboxs_noenlarge'))
    outputs.append(httpclient.InferRequestedOutput('ensemble_out_imgidx4car'))
    outputs.append(httpclient.InferRequestedOutput('e_out_imgidx4plate'))
    outputs.append(httpclient.InferRequestedOutput('e_out_carbboxs'))
    outputs.append(httpclient.InferRequestedOutput('e_out_lpr_res_idx'))
    outputs.append(httpclient.InferRequestedOutput('e_out_lpr_res_score'))
    outputs.append(httpclient.InferRequestedOutput('e_out_color'))
    outputs.append(httpclient.InferRequestedOutput('e_out_type'))
    outputs.append(httpclient.InferRequestedOutput('e_out_brand'))

    results = triton_client.infer(
        model_name=model_name, inputs=inputs, outputs=outputs, headers={"test": "1"}
    )
    out_imgidx4plate = results.as_numpy("e_out_imgidx4plate")
    ensemble_out_imgidx4car = results.as_numpy("ensemble_out_imgidx4car")
    e_out_lpr_res_idx = results.as_numpy("e_out_lpr_res_idx")
    e_out_lpr_res_score = results.as_numpy("e_out_lpr_res_score")

    e_out_carbboxs = results.as_numpy("e_out_carbboxs")
    e_out_platebboxs_noenlarge = results.as_numpy("e_out_platebboxs_noenlarge")
    e_out_type = results.as_numpy("e_out_type")
    e_out_color = results.as_numpy("e_out_color")
    e_out_brand = results.as_numpy("e_out_brand")

    print("e_out_lpr_res_idx.shape:",e_out_lpr_res_idx.shape)
    print("e_out_lpr_res_score.shape:",e_out_lpr_res_score.shape)
    print("e_out_type.shape:",e_out_type.shape)
    print("e_out_color.shape:",e_out_color.shape)

    lpr_result = lpr_postprocess(e_out_lpr_res_idx, e_out_lpr_res_score, e_out_platebboxs_noenlarge)

    pipeline_result_list = []
    plate_idxs = list(out_imgidx4plate.flatten())
    car_to_img_batch_idxs = list(ensemble_out_imgidx4car.flatten())
    # 车牌检测 》 车辆检测、车牌识别 》 车辆属性
    for car_index, car_item in enumerate(e_out_carbboxs):
        # print(car_index,car_item)
        car_item = car_item.tolist()

        item_dict = {
                     "class_name": car_categories[int(car_item[5])],
                     "box":[int(n) for n in car_item[:4]],
                     "score":car_item[4],
                     "classid":int(car_item[5]),
                     "image_batch_index":car_to_img_batch_idxs[car_index]
                     }

        # 是否 有车牌

        if car_index in out_imgidx4plate.flatten():
            plate_id = plate_idxs.index(car_index)
            plate_box_no_enlarge = e_out_platebboxs_noenlarge[plate_id].tolist()

            item_dict["plate_item"] = {"class_name": plate_categories[int(plate_box_no_enlarge[5])],
                                       "box": [int(n) for n in plate_box_no_enlarge[:4]],
                                       "score": plate_box_no_enlarge[4],
                                       "classid": int(plate_box_no_enlarge[5]),
                                       "plate_number": lpr_result[plate_id]
                                       }

        # 车辆属性
        if item_dict["class_name"] == "car":
            car_type = e_out_type[car_index].flatten()
            car_color = e_out_color[car_index].flatten()
            car_type_id = car_type.argmax()
            car_color_id = car_color.argmax()
            item_dict["car_attr"] = {"color": vehicle_color_categories[car_color_id], "type": vehicle_type_categories[car_type_id]}

        pipeline_result_list.append(item_dict)

    # for item in pipeline_result_list:
    #     print(item)

    # 渲染并保存图片
    osd_images = []
    for fileindex in range(len(file_name)):
        osd_images.append(cv2.imread(file_name[fileindex]))
    for item in pipeline_result_list:
        print(item)
        obj_class_name = item['class_name']

        car_box = item["box"]
        y = [0 for _ in range(4)]
        # y[0] = car_box[0] - car_box[2]/2
        # y[2] = car_box[0] + car_box[2]/2
        # y[1] = car_box[1] - car_box[3]/2
        # y[3] = car_box[1] + car_box[3]/2
        y[0] = car_box[0]
        y[2] = car_box[2]
        y[1] = car_box[1]
        y[3] = car_box[3]
        # plot_one_box(
        #     y,
        #     osd_images[item["image_batch_index"]],
        #     label="{}:{:.2f},{},{}".format(
        #         obj_class_name, item["score"], item["car_attr"]["color"], item["car_attr"]["type"]
        #     ),
        # )
        plot_one_box(
            y,
            osd_images[item["image_batch_index"]],
            label="{},{},{}".format(
                obj_class_name, item["car_attr"]["color"], item["car_attr"]["type"]
            ),
        )
        if "plate_item" in item.keys():
            if item['plate_item']['plate_number'] != "":
                plate_box = item["plate_item"]["box"]
                plate_class_name = item["plate_item"]["class_name"]
                plate_score = item["plate_item"]["score"]
                y = [0 for _ in range(4)]
                y[0] = plate_box[0] - plate_box[2]/2
                y[2] = plate_box[0] + plate_box[2]/2
                y[1] = plate_box[1] - plate_box[3]/2
                y[3] = plate_box[1] + plate_box[3]/2
                plot_one_box(
                    y,
                    osd_images[item["image_batch_index"]],
                    label="{}".format(
                         item["plate_item"]["plate_number"]
                    ),
                )
    # for index, osd_image in enumerate(osd_images):
    #     cv2.imwrite("./pytorch_models/resnet_model/pipeline_test_res/" + image_path.split("/")[-1].split('.')[0] +"_pipe.jpg",osd_image)
    #     print("cv2 imwrite","./pytorch_models/resnet_model/pipeline_test_res/" + image_path.split("/")[-1].split('.')[0] +"_pipe.jpg")



def plot_one_box(x, img, color=None, label=None, line_thickness=None):
    """
    description: Plots one bounding box on image img,
                 this function comes from YoLov5 project.
    param:
        x:      a box likes [x1,y1,x2,y2]
        img:    a opencv image object
        color:  color to draw rectangle, such as (0,255,0)
        label:  str
        line_thickness: int
    return:
        no return
    """
    tl = (
            line_thickness or round(0.002 * (img.shape[0] + img.shape[1]) / 2) + 1
    )  # line/font thickness
    color = color or [random.randint(0, 255) for _ in range(3)]
    c1, c2 = (int(x[0]), int(x[1])), (int(x[2]), int(x[3]))
    cv2.rectangle(img, c1, c2, color, thickness=tl, lineType=cv2.LINE_AA)
    if label:
        tf = max(tl - 1, 1)  # font thickness
        t_size = cv2.getTextSize(label, 0, fontScale=tl / 3, thickness=tf)[0]
        c2 = c1[0] + t_size[0], c1[1] - t_size[1] - 3
        # cv2.rectangle(img, c1, c2, color, -1, cv2.LINE_AA)  # filled
        cv2.putText(
            img,
            label,
            (c1[0], c1[1] - 2),
            0,
            tl / 4,
            [225, 255, 255],
            thickness=tf,
            lineType=cv2.LINE_AA,
        )

# lpr-后处理-业务逻辑
def lpr_postprocess(e_out_lpr_res_idx, e_out_lpr_res_score, e_out_platebboxs):
    result = []
    for i in range(e_out_lpr_res_idx.shape[0]):
        res = e_out_lpr_res_idx[i, :].astype('int')
        score = e_out_lpr_res_score[i, :]
        color = e_out_platebboxs[:, 5][i]
        bbox = e_out_platebboxs[:, :4][i]

        label = ''
        length = 0

        # if bbox[2] / bbox[3] < 1 or bbox[3] < 26 or bbox[2] < 66:
        #     result.append('')
        #     continue

        # 如果首位汉字置信度小于0.5，将车牌首位汉字置为“赣”
        if score[0] < 0.5:
            res[0] = 14
        # 将分类结果转换为车牌字符
        label += char_table[int(res[0])]
        length += 1
        for i in range(1, 18):
            if res[i] != 0:
                label += char_table[int(res[i])]
                length += 1
        # 如果车牌长度不符合要求（绿牌长度不为8，蓝牌黄牌不为7），返回空结果
        if (color == 1)&(length != 8):
            result.append('')
        elif (color != 1) & (length != 7):
            result.append('')
        # elif bbox[2] / bbox[3] < 1 or bbox[3] < 26 or bbox[2] < 66:
        #     result.append('')
        else:
            # 如果除首位字符的最小置信度小于0.5，则返回空结果，否则返回车牌号码
            min_score = score[1:length].min()
            if min_score < 0.5:
                result.append('')
            else:
                result.append(label)
    return result

if __name__ == '__main__':
    # triton_client = httpclient.InferenceServerClient(url="127.0.0.1:58000", verbose=False) #工作站上run，请求工作站服务
    triton_client = httpclient.InferenceServerClient(url="192.168.3.2:41000", verbose=False) #工作站上run，请求工作站服务
    # triton_client = httpclient.InferenceServerClient(url="127.0.0.1:58000", verbose=False)  # 工作站上run，请求工作站服务

    imgs = os.listdir('/home/linyicheng/hbw/img')
    imgs_path = ['/home/linyicheng/hbw/img/'+i for i in imgs]
    for img in imgs_path:
        print(img)
        get_box(triton_client, img)
        print(get_box())

    # img = "./pytorch_models/resnet_model/pipeline_test_imgs/2.jpg"
    # get_box(triton_client, img)