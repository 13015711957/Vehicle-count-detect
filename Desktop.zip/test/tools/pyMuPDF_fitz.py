import shutil
import sys, fitz
import os
import datetime


def pyMuPDF_fitz(pdfPath, imagePath):
    startTime_pdf2img = datetime.datetime.now()  # 开始时间
    print(startTime_pdf2img)
    print("imagePath=" + imagePath)
    pdfDoc = fitz.open(pdfPath)
    for pg in range(pdfDoc.pageCount):
        page = pdfDoc[pg]
        rotate = int(0)
        # 每个尺寸的缩放系数为1.3，这将为我们生成分辨率提高2.6的图像。
        # 此处若是不做设置，默认图片大小为：792X612, dpi=72
        zoom_x = 2.0  # (1.33333333-->1056x816)   (2-->1584x1224)
        zoom_y = 2.0
        mat = fitz.Matrix(zoom_x, zoom_y).preRotate(rotate)
        pix = page.getPixmap(matrix=mat, alpha=False)

        if not os.path.exists(imagePath):  # 判断存放图片的文件夹是否存在
            os.makedirs(imagePath)  # 若图片文件夹不存在就创建

        pix.writePNG(imagePath + '/' + 'temp.png' )  # 将图片写入指定的文件夹内

    endTime_pdf2img = datetime.datetime.now()  # 结束时间
    print(endTime_pdf2img)
    print('pdf2img时间=', (endTime_pdf2img - startTime_pdf2img))

def pyMuPDF2_fitz(pdfPath, imagePath):
    startTime_pdf2img = datetime.datetime.now()  # 开始时间
    print(startTime_pdf2img)
    pdfDoc = fitz.open(pdfPath) # open document
    for pg in range(pdfDoc.pageCount): # iterate through the pages
        page = pdfDoc[pg]
        rotate = int(0)
        # 每个尺寸的缩放系数为1.3，这将为我们生成分辨率提高2.6的图像
        # 此处若是不做设置，默认图片大小为：792X612, dpi=72
        zoom_x = 1.33333333 #(1.33333333-->1056x816)   (2-->1584x1224)
        zoom_y = 1.33333333
        mat = fitz.Matrix(zoom_x, zoom_y).preRotate(rotate) # 缩放系数1.3在每个维度  .preRotate(rotate)是执行一个旋转
        rect = page.rect                         # 页面大小
        mp = rect.tl  # 矩形区域    56=75/1.3333
        clip = fitz.Rect(mp, rect.br)            # 想要截取的区域
        pix = page.getPixmap(matrix=mat, alpha=False, clip=clip) # 将页面转换为图像
        if not os.path.exists(imagePath):
            os.makedirs(imagePath)
        pix.writePNG(imagePath+'/'+imagePath.split('/')[-1]+'_%s.png' % pg)# store image as a PNG
        endTime_pdf2img = datetime.datetime.now()  # 结束时间
        print(endTime_pdf2img)
        print('pdf2img时间=', (endTime_pdf2img - startTime_pdf2img))

if __name__ == "__main__":
    pdfPath = r'\\192.168.35.225\image\福建\4类福建告知书等稽核\220315\aispicture2'
    imagePath = r'\\192.168.35.225\image\福建\4类福建告知书等稽核\220315\橙分期温馨提示书'
    # path = r'/home/image_group/wangxb/AI_EnterpriseLicense/docs/picture/pdf_to_img'
    # img=r'/home/image_group/wangxb/mss_data/soft/CTS.img'
    temp=os.listdir(imagePath)
    for i in os.listdir(pdfPath):
        print(i)
        if i.split('.')[0] not in temp:
            #shutil.move(pdfPath+'/'+i,r"\\192.168.35.126\public\福建\4类福建告知书等稽核\data1/"+i)
            pyMuPDF2_fitz(pdfPath+'/'+i, imagePath+'/'+i.split('.')[0])