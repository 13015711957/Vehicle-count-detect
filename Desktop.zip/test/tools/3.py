import os
import shutil
import cv2
img=cv2.imread('1.jpg')
img=cv2.resize(img,(960, 540))
draw_1=cv2.rectangle(img, (88,25), (741,540), (0,255,0), 2)
draw_1=cv2.rectangle(img, (443,363), (588,410), (0,255,255), 2)
cv2.imshow('1',draw_1)
cv2.waitKey()