import os
import shutil
path1=r'\\192.168.35.126\public\hbw\idcard\data0818\images'
labels=r'\\192.168.35.126\public\hbw\idcard\data0818\labels'
path2=r'\\192.168.35.126\public\hbw\idcard\data0823\images/'

lab=[]
for i in os.listdir(labels):
    print(i)
    lab.append(i.split('.')[0])
for i in os.listdir(path1):
    if i.split('.')[0] not in lab:
        shutil.move(path1+'/'+i,path2+i)