import base64

import pandas as pd
import os
exceldir=r'拉取结果表格'
#exceldir=r'拉取结果表格'
imgdir=r'img'
df_res1 = pd.DataFrame(columns=['文件名', ])
error=[]
for excel in os.listdir(exceldir):
    url=exceldir+'/'+excel
    df = pd.read_excel(url, sheet_name='Sheet1')
    for i in df.itertuples():

        data='/home/ctff/project/SmartHomeAPI/AIGateWay_fastapi/pictem/'+str(i[2])+'.dat'
        print(data)
        try:
            with open(data,'r')as f:
                imgdata = base64.b64decode(f.read())
                file = open(str(i[2])+'.jpg', 'wb')
                file.write(imgdata)
                file.close()
        except:
            error.append([data])

for i in range(len(error)):
    df_res1.loc[i] = error[i]
    print("===============")
    print(error[i])
df_res1.to_excel('不存在.xlsx')
