import base64
import json
import six
from PIL import Image
import os

def base64_to_PIL(string):
    try:

        base64_data = base64.b64decode(string)
        buf = six.BytesIO()
        buf.write(base64_data)
        buf.seek(0)
        img = Image.open(buf).convert('RGB')
        return img
    except:
        return None
def read_json(p):
    with open(p) as f:
        jsonData = json.loads(f.read())
    shapes = jsonData.get('shapes')
    imageData = jsonData.get('imageData')
    lines = []
    labels = []
    for shape in shapes:
        lines.append(shape['points'])
        [x0, y0], [x1, y1] = shape['points']
        label = shape['label']
        if label == '0':
            if abs(y1 - y0) > 500:
                label = '1'
        elif label == '1':
            if abs(x1 - x0) > 500:
                label = '0'

        labels.append(label)
    img = base64_to_PIL(imageData)
    return img, lines, labels

if __name__ == '__main__':
    url=r"\\192.168.35.126\public\表格\table_data"
    for i in os.listdir(url):
        if 'json'in i:
            jsonurl=url+'/'+i
            img,lines,labels=read_json(jsonurl)
            with open(r"\\192.168.35.126\public\表格\table_data_txt/"+i.split('.')[0]+'.txt','w')as f:
                f.writelines('img:'+str(img))
                f.writelines('lines:'+str(lines))
                f.writelines('labels:'+str(labels))
