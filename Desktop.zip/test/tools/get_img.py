# 导入所需要的库
import os

import cv2
import numpy as np


# 定义保存图片函数
# image:要保存的图片名字
# addr；图片地址与相片名字的前部分
# num: 相片，名字的后缀。int 类型
def save_image(image, addr, num):
    address = addr + str(num) + '.jpg'
    image=cv2.resize(image,(1920,1080))
    cv2.imencode('.jpg', image)[1].tofile(address)
    # cv2.imwrite(address, image)
j = 0
path='/data6/AI_ImageLibrary/AI_DataAudit/cars_Dataset/Street/220106/'
# path=r'\\192.168.35.225\image\vidio\厨师服不规范误识别录屏/'
# name='20211201153654-34020000001310019112_Trim.mp4'
# path=r'C:\Users\gstx\Desktop\211119/'
for name in os.listdir(path):
    # 读取视频文件
    print(path+name)
    videoCapture = cv2.VideoCapture(path+name)

    # 通过摄像头的方式
    # videoCapture=cv2.VideoCapture(1)

    # 读帧
    success, frame = videoCapture.read()
    i = 0
    # 设置固定帧率
    timeF = 5

    while success:
        i = i + 1
        if (i % timeF == 0):
            j = j + 1
            save_image(frame, '/data6/AI_ImageLibrary/AI_DataAudit/cars_Dataset/Vedio_streaming/car_220106/', name+"_"+str(j))
            # save_image(frame, r'\\192.168.35.225\image\vidio\厨师服不规范误识别录屏\img/', name+"_"+str(j))
            # save_image(frame, r'C:\Users\gstx\Desktop\111/', name+"_"+str(j))
            print('save image:', i)
        success, frame = videoCapture.read()