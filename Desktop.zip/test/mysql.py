import pymysql

conn = pymysql.connect(host='134.154.3.49', user='root', password='1D@Aha72f', database='room', port=30672)
cursor = conn.cursor()
sql = """
    show tables
    """

res=cursor.execute(sql)
conn.commit()
print(res)
# 关闭数据库连接
conn.close()