# coding=utf-8
import copy
import time
import uuid
import hashlib
import base64
from threading import Thread

import requests
from Crypto.Cipher import AES
from urllib.parse import urlencode
import json
import os


class DopAPI(object):
    def __init__(self, appKey, appSecret):
        self.appKey = appKey
        self.appSecret = appSecret
        self.sKey = appSecret[: 16]
        self.base_url = 'http://10.142.101.156/openapi'
        # self.base_url = 'http://10.128.86.64:8000/serviceAgent/rest/openapi'

    def getSignParams(self, params):
        ''' 获取签名所需参数 '''
        params['timestamp'] = int(round(time.time() * 1000))  # 毫秒

        src = str(uuid.uuid4())
        seqId = src[: 8] + src[9: 13] + src[14: 18] + src[19: 23] + src[24:]
        params['seqid'] = seqId
        sign = self.makeSign(params)
        params['sign'] = sign
        return params

    def makeSign(self, params):
        ''' 签名生成算法 '''
        paramsStr = 'appKey{}timestamp{}seqid{}'.format(self.appKey, params['timestamp'], params['seqid'])
        paramsStr = self.sKey + paramsStr + self.sKey
        paramsStr = paramsStr.lower()
        return hashlib.md5(paramsStr.encode('utf-8')).hexdigest().upper()

    def getRequestString(self, scriptName, params, method):
        ''' 调试用，程序中可不调用 '''
        url = self.base_url + scriptName
        info = '==========Request Info==========\n'
        info += 'method: ' + method + '\n'
        info += 'url: ' + url + '\n'
        info += 'query: ' + urlencode(params, encoding='utf-8')
        info += '\n'
        return info

    def perLicense(self, idcard_path, scene_path):
        ''' 人证稽核API '''
        with open(idcard_path, 'rb') as f:
            img_data1 = base64.b64encode(f.read())
        with open(scene_path, 'rb') as f:
            img_data2 = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'FaceContrast'
        params['idcard_image'] = img_data1
        params['scene_image'] = img_data2
        params = self.getSignParams(params)

        method = 'GET'
        path = '/dcoos/FaceContrast'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def idCardOCR(self, img_path):
        ''' 身份证识别API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'IdCardOCR'
        params['image'] =img_data
        params = self.getSignParams(params)

        method = 'GET'
        path = '/dcoos/IdCardOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)
        # print(self.decrypt(result))
        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data']=self.decrypt(data)

            print(result)

    def generalOCR(self, img_path):
        ''' 通用文字识别API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        params['method'] = 'generalOCR'
        params['imageBase64'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/GeneralOCR'

        result = self.decryptApi(path, params)
        # print(result)
        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        if result['code'] == '10000':
            data = result['data']
            # print(self.decrypt(data))
            result['data']=self.decrypt(data)
            print(result)
        # print(data)
        return self.decrypt(data)

    def decryptApi(self, path, params):
        ''' 解密消息 '''
        params = self.getSignParams(params)
        url = self.base_url + path
        headers = {
            'Authorization': 'TYDIC_DCOOS_AUTH appkey={};sKey={};timestamp={};sign={};seqid={}'.format(self.appKey,
                                                                                                       self.sKey,
                                                                                                       params[
                                                                                                           'timestamp'],
                                                                                                       params['sign'],
                                                                                                       params['seqid']),
            'contentType': 'UTF-8',
            'User-Agent': 'Java DopAPIv1 SDK Client',
            'Accept': 'application/json'
        }
        temp = copy.deepcopy(params)
        for key, value in temp.items():

            print(key)
        res = requests.post(url, headers=headers, data=params)
        # print(params)
        print("res", res)
        # 这里要补充结果校验

        return res.json()

    def BusinessLicenseOCR(self, img_path):
        ''' 证照分类识别API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'BusinessLicenseOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        method = 'GET'
        path = '/dcoos/BusinessLicenseOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print('data',self.decrypt(data))

    def PRCorganCodeLicenseOCR(self, img_path):
        ''' 全国组织机构代码证识别API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'PRCorganCodeLicenseOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/PRCorganCodeLicenseOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def autoCodeLicenseOCR(self, img_path):
        ''' 基层群众性自治组织代码证识别API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'autoCodeLicenseOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/autoCodeLicenseOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def foreignOrganLicenseOCR(self, img_path):
        ''' 外国常驻代表机构登记证识别API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'foreignOrganLicenseOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/foreignOrganLicenseOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def PRCmedicalOrganLicenseOCR(self, img_path):
        ''' 全国医疗机构执业许可证识别API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'PRCmedicalOrganLicenseOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/PRCmedicalOrganLicenseOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def PRCCodeLicenseOCR(self, img_path):
        ''' 全国统一社会信用代码证识别API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'PRCCodeLicenseOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/PRCCodeLicenseOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def ElectIncOCR(self, img_path):
        ''' 全电子发票识别服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())


        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'ElectIncOCR'
        params['file'] = str(img_data, 'utf-8')
        params['file_type'] = 'pdf'
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/ElectIncOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def socialOrganLicenseOCR(self, img_path):
        ''' 社会团体法人登记证书识别服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'socialOrganLicenseOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/SocialOrganLicenseOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def doorPlateReco(self, img_path):
        ''' 门牌识别服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'doorPlateReco'
        params['image'] = str(img_data,'utf8')
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/DoorPlateReco'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def creditCodeLicenseOCR(self, img_path):
        ''' 统一社会信用代码证书识别服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'creditCodeLicenseOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/CreditCodeLicenseOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def ruralCollectiveLicenseOCR(self, img_path):
        ''' 农村集体经济组织登记证识别服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'ruralCollectiveLicenseOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/RuralCollectiveLicenseOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def publicInstitutionLicenseOCR(self, img_path):
        ''' 事业单位法人证书识别服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'publicInstitutionLicenseOCR'
        params['image'] = str(img_data,'utf-8')
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/PublicInstitutionLicenseOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def nonEnterpriseLicenseOCR(self, img_path):
        ''' 民办非企业证书识别服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'nonEnterpriseLicenseOCR'
        params['image'] = str(img_data,'utf-8')
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/NonEnterpriseLicenseOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def LicenseOCR(self, img_path):
        ''' 证照识别服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'LicenseOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/LicenseOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def letterOCR(self, img_path):
        ''' 委托函识别服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'letterOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/LetterOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def businessLicenseOCR(self, img_path):
        ''' 营业执照识别服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'businessLicenseOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/BusinessLicenseOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def Face_similarity(self, img_path):
        ''' 人脸比对接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'Face_similarity'
        params['img_1'] = str(img_data,'utf8')
        params['img_2'] = str(img_data,'utf8')


        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/Face_similarity'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def FaceContrast(self, img_path1,img_path2):
        ''' 人证合规性稽核服务接口API '''
        with open(img_path1, 'rb') as f:
            img_data1 = base64.b64encode(f.read())
        with open(img_path2, 'rb') as f:
            img_data2 = base64.b64encode(f.read())
        params={}
#         params = {
#     "facesImage": str([
#         "/9j/4AAQSkZJRgABAQEAyADIAAD/2wBDAAEBAQEBAQEBAQEBAQEBAQIBAQEBAQIBAQECAgICAgICAgIDAwQDAwMDAwICAwQDAwQEBAQEAgMFBQQEBQQEBAT/2wBDAQEBAQEBAQIBAQIEAwIDBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAT/wAARCAHgAWgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwDw23jRd+84YcgAjk+4q5EmXBB5YjbnjOOv9KoliAD94Oc5xyM59vpWlDLGrZm27hnackjB65pO19DKVKnKXqWNitGwKKGkXBYk+ufX3/Sr1qmNqow2jkgnG3nNVhtmi3ggqR1IGKfG6luOAOMsNv8ASuum5crT7HmTwnL70Vr6/wDANNJm3YDdDycjnj/69dTYFXKkHO0FSSe/HQVy0IQhj0brx2rY0258ssOCS2Mdx9aunXgopSOecZS9+Wx0d0NmApUfNuyxxkj+XerFluSTzGO7I55Awc/n/OqYukkYySABhnoMZGRxViI75AQwVBwQWGep7Y/ziqp1uVabGqpOWtM6iO7IBVWUK5CsH4z3yK2LKRyTwNuOPb/GuUiCxIvy7sHOerfpWtBI2cK5Ug5GD0J9PrW/tU3ddTjkpSk39511tOsYbe4245OckVZOo7TtAzzjJ4zXKxy9QeSeSM9eetagdVaIFCwZQwxyv06fStFd6GCVOTa6nV2t0zL1VgWJGRhl5zmtQOxKnJ99ozmuWhuV3LtTaAcFVHLVorfZJUoQAvTGQOnFO8ufQ2aUrwlujoIX2fMrZ4zkHFXhd/vG5yMY5PDZPX/PrXLpcbsBiQpztBGB71caeLaiLuZgCdwGB7Zrb27Sstwily8j2OyS6jwAxA2klSeCM8j+la0F3Gse1iCCMnnG305rz5Z5HPz7sDtgc8n/AOtWt9sdEQKOgzu/Gs41U4naoKLXMjo2uowCEYk9TkYBNSG4LsilhuVCxx2GR1rmorh2cOTznON3tii5vfKcDcTuG0nG4dOgNP283HlRFnF37m3cSooVjjDjCq3ykjFVZXWNg5ZQeuFPIGMCubkuWkO8EccDseOBio3nkkAZyRgZOOp59KmU3HSe5zxpt6NGtNeE7dgBHBBYYP8Anp+VZVxcZ3OSuV5PPIHU8f561jtesuMht4Py4HDf4d6fk3CH7gGCWDHr9P0q/ap+6cThFy5ZFyWVDhyw5PHoPrUb3iBHByWK7cAYB+n86y7hgpf7pA6Z4HHv9cVRMrDD7sHbwTyPwFcUk1HmezPfo4eFRu/YsTzkxuFJUk5yoBC/59KyZZGbIZiw6DOATStcMPlIDL9zBPvj+tV5I3dgiDG8fKMgE9K5ZTklY2UKsIqCtZGVcTiNlHLEtwOoOewqncmQLvRCGOcB1I/z/wDrq9PH9kmVJ1IdMdSG6qCDkexqjeXnmAxxJgsNoYnbgnJ9PatnUsrPdHNZSXLLddjGe5cFV3D3KtgZ9iRVOabewDNnK/LnqvP0pLpJoNsjpgNz7c9P5VSAEznOQ235cn5RUe1k7m8oczi5EzzquCuWG7LE9BimiTKu6gKOuGz157dcc1WctCdpBdV4YKMnt09aaZnKhlwpIwckj8PXtXmVbytGnujtlFqVx91KdsSoABuG4qAfTPH596oTxO0rFTjcg5x0/Efh1q6xKqWCqcckMcZPpVWe5WR3EaMjbcKwG4H1/lWFaK5byer/AK+R0+yqTk5JambJcNxGpUrjaDnBOev8+nSleVlBjGAWBGQvJFNKsCTsBYHPXHTNMkwrq5AyO3DVCp07Wn0HefIoszlWNzkqxYAfNwQ3Bx+HWs5yC0h25YnnB2nnHQZrQnAYiSIdThl6Z96hmjQDzFXYytzjIBz7UOm2+ZbeZ53s7Wmt2TWiRomH4VjkksBjH/66qYXzCIiTg9SOTV+ZlKBhjLKA2cGq6K8asScI68H2GRj9ax5IpuXc7nFrXqMj35kU/MrfecgAr+vvUkMat5iFztGcg8Ecnof604RRgR7GDFiAS3I4B5/z60+NVMrAA8feHZ+AT7//AKqhQhHWO7E5PRS2FVmfEKLtRD95lwTz2/Sip9mwFtp+Y5B+lFJU42tb70VKavqeZeZIFChiM/fJyRnuP5d+1PVmJ3SNhcBTt6j15+lRbRI5bYXVDgqBjdjqCasJufEYjQfwnDc8Z/Ltx7V7rknFLqcdnb3ehqRzhY1jjeTyyuSN3QnrgVchZdy7m2gcglsbTWYigAKRhgcYHPP1q0kBkzztyOpbGc+lJN2Lp1XNe98R11pOgGASAOMk4PvWjaMqSMQRtyDyePw/OuVskGDG2FyCOSCMe1bkG7csZIaMOSdrlSR1xkc9cd6Ss9S6qlFJSWpZcEkOsj7G5wOM55FX4H5+8cdQAefT9azUTO3AC8/KM4Xn0H4Vo28YViCwywBP8XrXWnFN9j5+MXN+0kdHCTIAI3O9RknqMdxjHvWhbozSbzIx2jG0DjPPXvWFA5j+bGNrZBOc9a0LeeXe0kaBgOGHIXjFaQtHWOxrKE5yd9zsBubC7zuIAbBz6df89q24gHRPnDbflHPTFc1FOGC5TlW5zz2rpIHQIhyoOAMdM4HFSk7uS2OlQje72NaOwYqsiyZYnJycDH+f51dRMtxyeMkfeas9JyNoU4GOS4yFyARz/SrfnLGQQdxxliO3oBVKSbsjZuktIdSTCgDKglByQOn0pwGGDKFK9VyCG9azftBUkoSwfnaclQc9OKaLqRc4woJzzwe/H610JTiuZHlyfKuWRtpcOWAIG0ep5qR7khgSSQF6dq58zGUdspgcnr7/AP1/ehnZgCxBA4zjcBQ1KTTYe78KOmFyQNytwcZ759R1qN7sTZG4KVz3xiueaRdxGeOgGMHvT1n8ollJBIzgZArOUm9jt5Wo6G89zEgK+YST1JBznrThKzLvaXapGFVcc1zH2hS7MwGSTng9+vWplvVUkPucBQFHJU9+f0qW7u7LhG/vRNCXzWkALAgdMnOeM8fp+VNLTYZEYqoX5/myM9eD2qjLc7o1TBGeSEbgZ9arR3Eu5wCB/wACznqOfzpptbHRTlUdlLYiu7mRcqO/AZun+eBVBriRsgucAYIHANOnuS7PvQE7iT3K1lC7ijcxkgSEjapGC+TjAzxnqcZFTJJrU3SlzO+w2eSQ/dY5z3Jzx9aIdSZZlDyMpI5yRnuazLnUYI2I+crjHyDjofT/ADxWVNe+XJ5qsjkghegPr7UpOXxI5JRV1bc6Od7m9aWRZFZYiwYyMRJhAB1APOAPrjFZJdvMwGJC85K8rjoR+fpXH3ni8WG4tLsc58yFZHXcCT6delVT4tsjKrQvnzIxMWR1MQyeQe4Ixkgj+IVyXdV3+0bcjWrOw1i4MsMMYYMEUAAKq4JJJyQM9wOTj5Rx1qnAfLBKgFiuMDovX0rFGtx3A80MmOgIJIx61p2kys4y+RjLc4Y9eufTOfw5rSV0mcLmuVd0V5jukYOo+bkYDf1rTs9OSVGdnVGPQAcfj61m3EqsrFGVyxILKCx4rRtbn92sSBmYnoMDA+tZy53H8yZOUnzMxbqArctG28rngqCEI5w2emOMfjUMiLHhtuT6r2HvV/V7po8BSWZgC/GCvQ1zz3kpGNxwQScYAyK8qdOF7QZ6EJyhFS7mkUdgMFiTzhRk/lVKS3l3g5wCckEYIINWVuxEC5O4/dwRkqetMSdXyS/Kk8DPGK5qSiuZS3PWhOTk0xpikXJH1JJI3VHJbOxGSOTkrxx+P41ZaaNsDc3XBUjPrTvP29Nrbu+ATxzUTjUktDaopJafMyXsg5UspyvKsMkD/OcULBKchQRnCgN6kgD6ckCtFLpkQ4VSxzkkA7R7cU6GbLM4AVs5C9M805c9NJy6nBGUZ/CZEVgzJnByeV5xmmfY5In5KjP4Adq6RCXwq9Twozkd6q3dsC4YKSU+8c4yM8jtRJWfNczXNFsrSAIoDcvjggZzj8qKvCAFcNGhLfNz7f8A6/1orm5b7J2OtVIyV3+R5HMvllCgIRhkjIDE8f5H0qWEkOzIdzgcB+c+veqeXdv3eCyjduySDx6VowMPvFcSsuCSPSvdhP3nUo79b9jCM+aOmxKFUKJT87EZKdQM8nH+e1WQ4ZVAHyqMejDn0qtGwyRtGAAM5x6/4VaUhdj8Aqc4Lbc5rVVIxl7RdTz5c+0TThiYNyOhOGBymeOorRs1ZJixYYPQcgEnpxWVBdyISAoO442jkD6H8K11k3lCCVAGRxyOhqG3ud0oxn7sjpI4WKJKc4+U5YBg3IJGD2I4/GriRAuCrDgYUk8D/wDVWPDcOm0MzSIRkgKSBkduPetGKUFiVUqRyMjaPrQtWOMElyLYtP5oIBHzNz8pDBs/StGBzlUJ284K8AZ6flWOWlDK2SScdOTWrFtbYQrFj8xzzjnoPX8K60oxvY5KkE7U49NzdiEigGTauG6buowf/rVr27S7snOCMqvQ9Oc1g2Uoc7XVhg5Xcx4Iya2I7j94NijGMcnp61dNx5FydS3GnGTjK/kWY3Yv1AX/AGeCT7/57VbUNknPBxwBnPX/AD+VZyNwGx958kAAe5+lWN+GBUEKRyRg4rujG0mfPznaKUtkWklZHC5O0tg85A79AaWQu7A5I3AkqpxuwQR2qMhiVYEbc4IPUdecY/r3pVKpliOnQA7Ace/H+FWYuSerLygqCpfKsOCThgcnNKZgM7WJCj7vBB/HrVZrgMvyjG0A/M3P+elUt+A3J6ZJxyMnj+eKhySVonoXiSSSM7Lgkc9ckA8Ec889f0pgkkV8MU2jBGR07etVTPskJKblUfdKA7cnG4H9PxqjJcN5hYfKNvduPwH5U4qaXN3Od3T0NlpNwOWAx8wYHBP+eaVjtBO5CpXPzcjt/wDXrM85xtzuVsjOTjbwfbNSPOAFJICsOMnHHH+NVZbjiue7e5Isu5ThgTnkq2e//wBes6WYpLlpQBnIAYkj9PpVG4voYwwicqeSeikDuRz/AJzXM3/iPT7Jlaebgv8AO7e55wf89aGlJ3kcSUU0nuegC4iaMncCx5bJ5Fc7cyxLOXZRIzdE27mU54x789feuGl8d2CiU2xeXyiUCt+7LdOQc9K8p8TfEm4bG2YwypITttkCsByRubqfxqUozV2en1ue06p4jsYLaa38yMT7WRssoMecgkZ68Hjj39q8i1zxotjcRzC9CKG3KPMyGIPfvjp+deC6l4v1i9lkeR2BldjuwcKCRgcf5zXn3iDVruK3c+YZGPzZdmkOc8evGT61w1uV/EdtP21T3o2sejeJ/ixqty9wix2MSs/kkrF5sqKCTlT6nJzx3rm9K8eW9rCIj5oikz5qIThWYkk8nv1r56m1mciVpGVzJIVKoWDDpuDcAHnoR+tQRX0gDEHAPOR94dun41lJclpQejLjdppn1vp3xXSzdLUX6pDKcFJ/vxjn5gT/AE4r3rw143j1PT4ruG8a5gkBQXIPzOM8j3r81HuIllR3kZwWOzjAH4k+wr1Hw18QrvR4BYxYki3ACMn5IgTliAPzrlqzcLOJ1U+SK16H6P6dco6RSROrrMu/P3yM5P4Vu2sgLOZCqInAI+VgO/NfKfhX4hrLYAwBzIm1RAWx5jkdvTnr/wDqr2CPxfjTYVuSsN88QeSGKXeIiRnaW79hx1x0pOneTkzaMvdTkbGr3qkswZ2Uv800kgRIuuSxYg9gOATkiuD1fWmtoPLju4yC25vLcMScjABHODxn6CvH/GfxBSzuRG9xJMssgjjggLSJEQMlmP3R+ByeODXkV78Q5xOVK7kkPUSEBF7D9arnldyPK95O8dmfVC+Ib4S77e4VVzhomAdR78jrXU2PiBZNgnZQx6kDkevA618lwePtPhtyJ5mFyQXXAaRF54BYV02l+PtMeztrsX1vLHKwQOJhIFJbZ68gHrjNeNK9+bofSRj/AD7n1bFcRTbGjdmBXAOSQT34PT/61TkOjfMxUEZAIIPPf/69eX+GPFFrOVjkvIG+cAQmUbyTzwK9USdrmNCArMpKjao3rySOg9CPy6Uk1ZyXU5mrJKRcjRyuSdwPzA/mcYqRl6Mg25HOVx79B06mmqHGDuPyk8Nls+3T/OKcoLsodDtA3bgPX/JrONtbHU42d49STe8KoVOSxDDGQz/WrFvOs28OXAWXy23IVI+VWyOmR8w5HHUZqtJJHAjq6EoR8ueSTzge2f60+2DBAwAIPPJyRmqjJwXvdTJKMJy8y8skS4DkgEDDYyR7E0VWKJJjPfkqBk89cDP+c0VcZSStHYySlbQ8csolkJwmMDcCTjPTt9anEZDtmPkHPLAdfb/PSqdsxj3BCdxJxkjDc9OfwqyJHAYtgux5xtBH4ivak53XKeZCUW+aXxPfsWRE2CVGQPmwhCeg7kD0pgjfOWJAYcBuSKSKVkKv3xyP6cU9pFkbLEgDgdNvX/69aSU4y5qe737GNm3yrobEEgR8knaOCQePpW5bkTMjhwkKlg6Fc7wQcc4yMHn8KxEQAltqyDrheF6djitKKdmUqBImw/P0BAwCCpGc9a5JQxEY3Vj2HFKpKmuhZWaJFTaxPYZyd3H0rWt2U7SSvHIAJJPP0rAikhdUVY3AxgllAb3yPzrTj25XDA4HQHA9/wAsV3U3zK9RadD5uSSVzrIANykjcd2cCtBGyec4U9OpHX/6/NY6S/KCV6HnGea1YmDZGcbhn5vboKXvRXMj06Scn7R7MgTegBLBMjOMnNbMMZ35DEkjIBGAO+Kw164k3EKSFAOCvPGDW9bMAqkksDxljyeo5ya76alJ3PDxCi/j26evmdPErOu0PsODx03ZP+fyq4iJEpLMCTkgFh1/ziq9ojsWZVB424LYI71eSIgsSMYHzAH7/uffrTaaVzqbu7sppKx2gkBAxPAyent+HX0prg7mYFvU4PFW4o0JLFWBB5BXIPX25NJPGRgIm4c5wu05/wAKp3cVcizcWpfIzWRmwwxjHXHSkaJOQAhcgI0gUByByBn0BJI9yauCNo1GFUc4wDgH9Ki8sl+MYPdq05pWSkctp8quYMqscEEEKMMec5qv5ZLbiSR1OBjae3TmtC7hKBQBncMnvz+VZF7fR2UEssrBFiQszsCQoHJzgfWtk3ynDG9rF57qOOHEjMwAJDsFWQjBPPT36+leP+KPiXp+muUimErZMaRMm4nGM/KT6Z5rz34jfFMQTvY6O8cm1QZpvO4Ut/cA6jFfJniHxLcX2py6jId8rKEaBXOBt4wB2z6isrdDuTUWz6a1v4qzTPax2xP2aZd7z7ysyndyCOvauP1LxlJcMkl3dh4iP3eW3hSPYd/1rwKbXppPKJjaNMYfGSwznpxUsEjzvtAzuUshlYgKcZ54rOUXT+I6XaSsj2GTxHeXMYjs5BCDkeYSFkPHP+ev5Vz9ws8UW555JnlZpGMr73bnJHXPGcfgK5htTW1AjjfzHzhmAKjOOefTt07VHJqaIpnknZ0Khfs0bLJICSeRkg85HUgcVcWnsFNpLk6ou3M/lwsJTnjYdvJHavKPEurzIZlQt5IQ4BkBIwAe568H8q29Y1+3ngc20dxGkchjLXK+UZNo+8g3H5ckjJAJxXjeuakxLKJZAhBzgEZHfIHrmuOpDm17Hs4enam5d0RvqPmjMTBlU8kg4OOCPwINP+2MpVyd27sCMDp/Wuagl3qWx3OSFIyc+nbrWlEBNtA4wTgkbe/P655rk51e63LhGMbI3LW6FwypIiqBgk7tx7ZwK1EsZZ72KewS4a4WMwtFFIziccbQI+mcjqAPvVBoGgTXjpuTCvKIw4Yg+5A68ZzXrugaDJoSDUZzH+6m+zxxyOpkucqpLnHQDfjnn5DWclOUnOO5i6cFLnd7sboV7qXhjUDa3Fy1xNGySmMtuWEsBlM9MjGOM9K7u+8bXEke5ZVUbT5jYPmDjPTH8s15nNftd393PK3KEErt2vGhOAemcZz1rCvdWhiJAkTY4xwHK554IwSOncY6c+uUeeXvdzROUb9jotX1r7W6SMxYjLdSiMeRyDyfWvE/Emv3g1Dy7a4eGEIFEcQHludxPOQeSAPwx61Lq2vEAxxuPMOcjA2j8SM+tee3epCSO5OWa6yUVwRtz2PqcfTHFc9RqL903jycicDZfxCbOyffON20qIzlmZiMAYA45I5OAKxNM1r+zDG0UjWwErTeWhZYg5JJO3P06j8K43e8sxRx8+d7Bww4OCDyOeuPxrQ/coBJMd5VSMBTg89M03LmfKtzlhBvWR9D+HPi/qWn3lkZfsc0C3StKZAVkKDOdp9e4PvX2v8ADT4yaD4puXsrLUNt/F/rLe7kEchQ4yQCckDofwr8nFvkDIsKSFlUMSwKnPfB59R+ddToWoXVlqEF/E7RXkTMYLiF2jmiyOcEdsZyKmUek+h1Ob1ifu/YSJcpG6yI4fnghgc5PataW3jWMEOgYfeU5GTjPfr/APrr88vgz+0La6WbfQPGeoI8BmFrbanK2WUsflRznjHQE8dM+/37pmpWmqWUd5p8wubKZQ0U0R3hs9zz/nFefLmUtNj0IP3Uupi3hSQoMkq0sZII2pjzEL88dFywHOSBWlbOqAqgLhgAT0Vvw7f/AFqQ2olZQ6sNi/u4iNsQLLnJAPXB6np6VPEiIShOH3bs9cHPOOK0cVN3R53JJxS7E+D5gHSQjICnGByM59j/ACoq+salScHcOFzmit40ouN2dh4NICqghwGzxg9ealt2k3MHy2VzhmLE/wCeKdIYkV1OTtBC8EMOQOn50ka5GOgxu3uOPp+P9K6PZK3J1W/oZStpJEwmySvDDJUdCv1rSgtvNQ9RxxxxznnH4VlIAqMBhQuX4A3N+FaVtclUAXnIwoOQB06j8K6o1IQSUepxttu7IFWWFQpcIN5AB4J9xx0q/CUc7CCr5DbiQAfU+/1rKkd5UVn5O8A98cf/AFv1q4hdlBRwWQYAZACvbGa2dRKb5jyVdK/c3lyCPukY9SelXrYhyRxwehOAKy7aSRFUuvzDkc5A71fQFmVkG5iMHJ2jP1q48tSPMzapCLevQ6uAsgyzKwHA2nfj/wCvWtDIzBQQdxyVBGAR1zjvj/Gsi1TBPmsA2AwVWDY6Y5x71u22xsgnafulgOcciohy213PTqTcEmti5C4cbuOPl46nFW4YmeQjPIGFHYcVQRCo2qCc4yeOOxPJx71pQP13AgBdpJI5/wAa9Ki5ci5jxa1Xn22Ojsg4barnJJ4H3m74Hb863hbqRzzg5y3Y1zVrIgZHUfdP3SOOODXSxOsu05JBXqODWtON07mcXuupmAYKkYyvfrmh9u5huXnnHarXkEjeiltpwQvJ/wA81F9mcNgoxJGeRgHv1qlo7HlK/UNqMpVeHYY+YAHPtUTR8HgKQeRnFXkt9hzgnnOBjiopJUkjLgkRsSQzIYioUlTwQDgFTzQ6btqjvak15HMajPDbxPIXA2rvBZsIo9z/AJ6V8cfGT4oX5/4lemPOlnEc3V3YRkzXPOPLBHJHPPHaux+LfxTITVdB8LXsL3EINlLfY3iCQghwoPDFRx6BvXpXyBdS3BgEbStNscGRpZAX5I3HJ69z+FV7KbV1sc7cYqzOV1PUjPKZFmZmY7ywznJJ4JNc1K7yT/aG2F4xtDsQ2Bnpg1ZvtkMzlFOHbEmBlRk5/wAPyrMmll24AAU8nJChiOh6c9qpRcVc5Kbp6rsb0eo2yoFMW6Xd9/8AgXknpuHv245obU5IF8yRkVQp8tU+Zn4ztIHPb6VyZleNyxVV3MACzbdvf6DP+NY+oagyTqqOjuAedwfbwpx6Z5rklaya2PoNLXO0u9dh3qwYxxMgy7tkgnrkf061VXVxCuINjx4+SSRdpfjJxk8Y5x64rze4vEcbm5IbAZwVGee/4HmqQ1pUJBVuBwwA29Pz6+lXypO6OeEVGGmx0etawbg8OEVBtZVIXHBHX/GuCuZZZpDIJS+75AnUYBx3yP8A9VXpobjUFaSNXZZHyFCkqxPTpz2zXS2fhF3gjnVcOCSVY7WxjJPpjJ+vsa5qsofDI66NGc5XitDiIbOaUjyy2GblcbgMnPTv0rqdM0+bzY5JHYKTgrsZACpAONwGe/PTg4Nd7p3hOfMZMGwM5UuUIRTgnBzxzx2717f4a+HL3Eavc2bSbYt0bOASVUg8LnOOvUdq86vVhQTb6nbClOc1Gxn/AA38PLLd2MkkfmwTHCzMuXzjKADH8TYXP/166/xho0sMmoRwReZp2mhpSsRZ7q6lMEMxjiU5+6CAQMfM3HfHrHhbwVcaILS4it5Y4xOuBGWQoWOxcBR3Ljj3rsdQ0CGW0eV7fzJHcsS/zNkgcn9Bz6V5qx8FK97tnofU6k37y2Pzy8QyS6bPcbYRGZIVicDgttdnCscZIAYcZ9fpXl+r6vNHH86xxbwSoGWYY9ea+4/E/wAO1v3fzVgMZRmVFQiRWbdglgvbIPXtXy/4x+Hl5becm5WWIllIV/u7Thfu9cg/55rpji+ZmMqM1H3lotj5p1HWUDLIWy4YKCoPzEnAx37nnpWBcXjlyyspHlgqccZJ/pxXT694avYTPJBCZFXc7eYgQDI57c9+etcWYpUVxMrKRkKMcNj8Kc5U6lpR3MlGSk00Tw6iwZWmcuWPViBgYJ/z9a1mlSVVVJNyso5BJwfmBHPpwOlcYZ2Uq7DYEAUgN6Y7ce35Vqwakqyovy4KEgEgL0yf5GiooxnyxIinzOR0Edo6xiTDAK2d+fmxgdB6g5rbtpjI6IvlZGcs/wAr9COcZ+nNQWupwSwwWzohQny5Gcs3kk91GOvzBqfKi2pEkBLKwyCFJcjIGe3r3pui5LmhsW7WNVdLh+0CdXcP5u87W+T3/wA+5r6z+C3xf1b4ctaabcXUuo6Hd3yyTwTO0j6ejkZMQycbTltvTk8eny3a38duiO27LDd8o+bpn8O3Wt6K8aIJdxMc9QTgY9yPr/OuSSlNX6HXJSajyH7aeHNdsfEukRa1pV1Fd2lxufzBwflJB468Y/KtVy2dhQAN1baARkHpX5ofBT4tXXhW5trKW7uLiwvb7ybjT3cCKFXH+tjLEY5I3c+vFfo/pN9DqtlFNBLG6SrvjdW3/wAjXBycsuaJ3Sp3d1uacOECndyzbVU/KMngZPYe9FQSRmHIyx4/hHX8vpRXpQ0ijzmrOx4a8TFiSu0Z5PGanCgIFO0knnjGOR/npVyK0kRflwxAJO98k1MYGQjzICN3Yqeen+Nb1KnN7reqM2pS22MRIC6qSSCmMMGPY1ZhiCnIOGzkc4zT2j8rKqgI6rzjHb/P1pA77AGOcc571rhpKcpcq2Rwe63yroaNssh2s5BUkjkc/hV1AhJCIinPJ3cn36VlLM0TKqFnOc85wOvSrsUhY7mGOpIwevIPH4VMpte9G1maSTcnY015ZcgOFIBA4A4rSjnJG2PAIXoDgsfrWZEwYcYUDpxg1dtQm7HUnoc8jtWsJXgnIzsk79y/bMWwSjJju4Uvxwc4yD+BrVSRt4ClcdCPSsVP3eCPvZyATjBwc1fi+dwwwBjP3gefQ8Z6AV0UqjdR8ux505KC1Ozty2OcYI+8ecda6GJQ6g5xx0AxXKRSuuAqkjdgA8jj+lbkNzJuCmNFyOkY2r06+ldsJxva5vNSevQ2bGPAWQEHcOh4A/zxXWafpN3csTFhoynmsyEbUUEglgSD24Az/WuNtLmJBl0dWAy5CFhgZJOBzxjtXtPwl0y98U+OfB3g3TZIkvvGfiO28N2Ely3kwJPdsI4mY7ccu0Y+bgbsngGrejuca5r2ZtaD4Lvr6HfFFNkfOyso3MCcB8DOAT2POMHFdBqHw/1HTrYXd3D5dqygxzCWM7iWC42g7gQTzkCv6Gvgt+wH4A8E6XFdfEMTeKtbuIgbvTLa9e20CBjnjMSxyykYXLOQCeAuAK+gP+GU/wBn3IJ+GPh+QAYKXAlvEbpg4kdsEY4Ix1Nc7rU0etChLl5pH8pVn4A1C8Tz4opVhkk2I7xuqscLjGV6HeMHnJHGa+Uf2gvHTfDyS68NaW9vceIokBvlOTLYxuBnIH8RBOB+Nf2J/GT9mz4F+GPh3418aW/hW20IeEfDN54l3acxCYsbaWfYEYkfNsIwB34xX8HnxU8V3+veOfFninV2im1PXdWkmHURQRFmMKKDnhVxgemK9HCJ4ms4w6Hm16fslzWsePXUzXFzNJufzJZDNM0n+skY8sfxNc5qc3kMDI4fJAAHReO4PH5dxW5quqB0VmESso+9wHbPqe9cRqCyXxRmbcoBKnow/D3zXtOEnHVW/I8qdWMpW6+hkXzLK7FXBAPIyADWFeNLIoG5VCEgLyA2fU1climaSaIhl2ZwCR81Yeox+QSrSnzMbvlY4HoPQdf0715GInFvlj0PXpOMXaJxGqXLnMQkw6jLFGPy56dvx/EVyskrh22HcT/GxDcnrnnNaF5dRTSyRsrsxYpuC7t/pk/Tv/8AWpsOkvIzbYWBbuQcAY9DxUuouW8tzzqNKdeXLFGSyXs7BcuctwR8wHOehrpNM8OXN0xZwGCDex2g4wOSee3FdNpegNI8cItZZmYgYjTIQE4yeP5+lfQvg/4Y3d1NBCYPLWZQXBRQSq5JHTryfzryMVmFHDqyabPoMLlFWs1FrY8w8P8Ag2e52GJflZ9oKrtKnnt1xz+te/8Ahz4YSXEaKSd7HgCISEdOMY7f1r6D8EfBnYbS5EUiAvlV8gSRSnGBk9ABg578CvsjwN8LLNjbAW8FvJGpMtwsQbLZPGO/QV81Xx0q/vxeh9dQwFOlHla1Pj/w78EmuIIobi2MayBR5rDywAMdV6Z56gd6+lfDfwKtbSztoB9rnKBj50qCRh5hPAJHQZr7U8O/DLTzDCskCsVILyTxK2/njAI+lejv4e0y0SFYolYJht2QPMwcEZHI6dPpXmVsRJqzeh10qUYvVH5/a18PItJtGt7e3iiKzmR5Bu3qWCqdmc8naowMDJPFedSeFpH8yFozjHAxlhkZ5P5dB3r7u8X2NjeXUolSOOIybQFHCgDBI9+Cc579a+bNato7S5kK7eDtDcYYAnGDge3WvJr1kve6HqUMNCfvHzjrHg1YQ4CgMB8vAUHnofrXhnij4dzXrOIYWLHKSFhlcE9OnccZOO9fZWo2sU0aMQGySWA5YAD/AD+Vc1PpsUuV8vB24AYYxnA6/lWNPGVYvmgzqlhION7I/LvxX8LLrT96zWqFZJCI3bezkHPPT3OP85+dvEPw7Z7m4cqE+bEYC4ZyQDz1wMg+nSv2j1PwLa6nDh44nLJgoUV/LyMcccH8R9a8Z1f4NWcslxC1q77wH84KXKjLAZBPB6/nX0GCzu0W5anzuNymM9Y6fI/GnUfDE7iZYUYPEGjIIyDtJ7/n+dee3tpe2cyxzx4C5G7t1OQfToPzr9efEX7P8BkkksYltJbhwfNcAxzMSCS6DPX39RzXyj8RPgrqWkfaJHsbu65GHt7UrAoOf7rD0z07nNddLMadWVov7zlq5ZOlHmi9T4ysdRlspFRy7o5DOCwYcjqOvOMV6NZailzGsYIZnjxG3UgkYHU1yOt+GrmwEsjWrxJHLtLMpjVcnABz0OeMGs7TtUis5dt1E5gPyOYneJlODnJUhhjI5BzzXqxqRnecu3Q8SrSkpefmemvFOkZlR92W+RHXcCQM4HPTntUlve3cj7ZcwhgdoyFCgdgv1yfxqnZahFqEYeK4DB1yVffJJknH3iDnGe5zU01ud0cpkkGw5Cpxnud3f0qI2loL2cUrnothMIShXBAPBUFQCOOOa+t/gf8AG7/hHtQh0PxDcyHTboiGCSQmVYAB94dSOOuOuK+I7PUnW3jxGzBcAAd/TNdbpmohZo5SSrIQVJGH6cY/xpOk2vZrdHUnduR+41tcwanZWt7a3EV1bTxiS3ubdxJBKh6bTn6fnRXx/wDs7/EXydL/AOEev723NjCd1pukImhZ2OV2HkrznI6UVjyxirS3BSjayPXI9vlNy5ZRkYJ5/DFOSaUuCQWAOMNyR2zn86t4UBgIwx6HAGX6c1SmFyjq+8rHtJZI1BTuOSRkevBFbOPtG/Z7LXU82UnFty2Y+VVIDEAHGMjqPpVIIql1Byc5HGAfepo5Cxj81SUBAbqGKnv15x196l2oT8w43ZGBg1tCM5JOPzOBQi3puiIRlYgxG59uF2cgY4qReACTgr1z39SfyomAhyE5JGdo5x7VAA7su/8AiXB5PHIHQkCsVyuo0j0lCMrs1Ymc4wCAy9Rgjp+NaMG5CSW3hmAAGAB17YqgkTKEKH5eCecYz1rVi2qrEjJwAM9T2/pXS6KlpLZbGbaWxajkLtweF6tjOO2Oc/5FaMeRIuxixB6YG0A+/tmsmHChWJB5weA2BWtaTfvCF4T1wMZOK6OZ6LsZ2lza7dDqbYScMMHauSccj/H8a2oWwdzEbtgBHcfX/CsazmMbNgfKRnGQDnIrVtgN0r7Rkkj7vPr1zit6Uot3e5liW3N3NGCUDBBJOPmII4/T6V6B4Qu72x1vSdT0y7kstV0nVbbVNLnikWOSKWCZJAyk9wFzxz1ry8SOdw27cttPOcV0ulSyW80UkY+c7SNx+Ukc4Pse/tXfzW1R50YXa8j+2v4S+L7b4gfDXwR4ysnEkHiPwxZaorBgTult4zIrY4DK+9WX+FlI7V6AWUEgnGOuegr8nv8AgmZ+0doOrfC2P4ReKtXstL8T+ENQkg0KK/uY7eLVrG4Mc6eU5YBpRPPOpTg7QhAJ3be0/wCClv7bugfsmfBTV7XRr21v/i748sp9C8FaFBdL9s04So0c+pzKDuRIAx2Ej5pCowQGxjGjOrW9nBXb2MfaxhBNdD5e/wCCof7deiWvgzxV8A/hb4i0u51DU7abSPHGtQXiONuzEum2jgkF8kCV+g5QZ+fH8gfjGIySNGGMjQzNcS+YOdwyAwbuQNwx/hXe+KPG994guX1O7ubmS+usS3RkuGuXaYtlirdFxx/kV4/rWpOcoxLHHToecYz+tfV4LLlhbQu3PrtbVGeKxiq6SWi8jgrwSvKXkL7VP1U1Qu7ryIzIu4YGXPp/kkVrXOqQfMkkG3K9sHJ5ySPyrjr/AFFJhLAqJ5YPBAwxzzzW2LqRpQUUtfPU5KdO8nJdTM1C8QwNJ5pUyfKhBGSepzx/hXD3U880pzKznsWILfTnrwfwq/cNJPujRR8v3SRkDPX+VbGjeHZr2RXkgchzwV5YnoeCeOwyR9K+axdWUG51P60PUwWGnUShRWph6VoE15iVIlwGDPI0e4545z2x05x9O9eveG/A11eMZGjBCr82ByoPc9vWvRfCngvPlWxt3kRiH2ohB6AYJ9sV9Q+Efh/BpzwTzwNDiIxmIndCynONynv948evvXx2Y5rCS5aW59llWUex1qLseVeAvh3AZRAlmJDcDMk0igrjPAU4znr09K+y/h18LbaK5t7iW33OwW3hWSPzEIJwRntxkZx/Wr/h3w/a5iEEKrsOxSF2qPw96+kPCulyWL2hYRtEoJkDrlh1xj6HFfOr2ldtyd/mfVOHskklqTeFvA97ElzFcafb2dpFOY7Ly2DtPH97cVA+UZOR65Ney+HvCFvA8Usu9dsgcKrEA4HQjuM0+DUrSCJlcvlTj931znnjv0rM1Px9a6ay/NAryv5cFvJKY5blhg4Rc8nrx7V006cnHQ0qSk3d9T2EzR2UKuAqqi8luAMelcXqmsuS32fks2c8DAzn5cHrz6V55P8AEKaWJI5Aqq8QwjuVJ4Gfr0qK3162ndzIyooX5ixHJOT7ZrmrJRbjMwpUXzGd4iFzdxtIrM77udoy2T6f5714jren3E0kzREukZG4kBiCc5JPrwa9q1C/s3Ty1mYbidro+wr6cjB4wMfWvLtUuooJ5onkXkk/P8pJ5715OKTT5juoOUYuKPOxpryfMzEAcAYGe/pWdPaImVPyshWXK7shlYODwexAP4V0321Iy2GygkPyg43DODWBckyTmVQFGSQQeg6j/PNcUYzV35HqUY+57xSWP7OHDMcEZbg55OcY/HpWrY2kNxIf9HjmBbymJypBwDg++Cpx6EVUmmMmSF5BBU9CO2fX/wDUK1dLBV/3e5ckFwfkGe2Py/SssKpqbb20/M1rpWJrzwfpt3EGeFWbIkYFySGCheOoHAHQDpn1rwTxv4IthFcR/ZI57d2LYaPLMcEbenB5PPuK+ubBoZbcrJgt1AK5Y/161574uhRVk+UsnG1SmfU/0FexCs4tpHkW5vdZ+R/xX+ElvLZ3FsLJWEspmWNYlVWb74V8decZJxnFfn94o8Capot7dxm0CRw5klXbiONQBgsRnsB69q/c7xloMGqvMwBjZ9yqwXaynkA8cAYx7g5r46+IPwxNzJcxzwM9uWDRSxy+dLLkHKtn5gARwOQQetelhMbCKVOq9TPG5aqlHnp7o/NjSbkWRQBf3cpLHaR1IHU/l+XSu1WU4XdJnzEJBbhD04/Wn+NfCk2j6jO1tbyRQFzGIlXYm5eCVU9M4/zmuctbgxyIJPlK4yM5Zfwr35So+zjKk9z5iUFRfLNam4A0Kq28qpILhcEHj6VuWd1byyrEJgkzDKLnbu29Tnp71z6XJk4RVLAemCcdSK0bSXyZDIAVfAG4NgDOcj1rpUVFczPLTlKTjPoet+HtW1bSllbT5WabzdsMqtlonUhsd/bIPrRXNaJeJEuVYkSvuddxAL92I45O0DPfj0orNaKxopRsfrqFZgCWGeeCcUjDzF2cDaOQTgc+9T+dbsqgow2L65J4AoZUibcGxuUZBB2gfXp61jeSnzR2ZwKMeS87lUREABsHA4JGaf5BIyNwYcc8DFW2Efys+4jjaAvPOc/yp/mg5IygQZGOc59RVVZ1FJqe5cPZKP7vfqVXiVUaTJ3IdxGMinr5XykBuQR90AmrjRxOpdABg7drEAk9frTI4ljw20E9eDuA4rkipWTkdyUFIiQqUG3cDjAT6YzVyJCSGBb7uCMgFajVAwkIUswBO0Ebz+JIAAGT+FWoyRwmAQMHdwfyr06P7z3H02MH+8qNvqJHAy7JJFIUnjPQDpz+dXoUQhihCMTwTwE469D09MVSQyMBuQEg85G38auxEqS2Oq8KD1/GvSs0nrqeDKDhK0zatiUAErfMT1AwO/tW9aTJuIyOgzu6HHQZ/OuajufMQYAxnkgc/wAq0oZGUgodvIbg45Vg2DjqCRgg9iaqg5KnepaxpXo865kdjCVckAjjJLAZx35q9FMquArFcDAUDjJ56/pXM28k7KpUJgcOWchvbAA+la9p8sse4gAsNzZznB7V2xnF2S2PPlFRSXU9f8OamLTQde864ukmu7IMLpJvLktPK3NGyOMMPXr6V+WfxA+KPiPxh4o1DXda17V/ENzuewsbrW9Rl1EwQIxVTGzsSMjn054AFfWvx8+LFr4N8AXmi6W0ra/rkDadaSIAqwCRQHYc9lLHPTgV+ZUWpsF/eFyFQKpzk8Dv9cV24KVR1m72jG35nPVlPl5I7o6GfVnSU+VLGih8kbQXJ9yTz7cfjWLqN2bpxukdJMhiY225xjr9e/1rIEsV1LmQgSON6p3IAJIAwP7pPPqax729iEwDPsdeFJfgDtx2r6uOMpRi431PCnGu7XS37lnWEYwNMrLnGMMcEDjOPy/SvO7u4bcAG2AHDKPvE5/+vWhqOsTM0iyFDHGACoPXBPzfqPyrn4Jnu7kOETAYABAG6YwOnPrmvHxmJnUgorY9DDUb1FFvT/gnS6VC11LEifMHZUD4LFcnB4A7DJGevt1r6t+H/g57iSC5kjdoJT5cqtHw4x/D/EMZ615D4D8LyXUyThSu9w+XjCqCxx1x7n8q+3vBOlLY2aFTltwZlZgQCQOnOeo69K+AznGqK9nF+8j9SyXLoU/3rO68OeErDTlhmSELMigMCAwxjggetdu0QXGNqDvgcN1qHSrgSIXcKoBIyR1H+TUt/dwxAgAMTz0wCM18ViHKpNyZ9fBU5WUDrtE1AWfltKR5eQSyqFbHXIyR7Gvb9M8VQSGBbeSNSNrHeoKtgg4ZT27EfrXypaahEoaNhtXOQRwvfr+leh6RrKICGY/wgKDv3cHpxWWFlCjKXN1O6slLZH0RNrjxRqWuIw0pzIoYKoxgnaO34Y4rnNQubS4kWaRYJHiO+KSQBnjYcfKTyOp6V56mtz3DeWQfLL4UtwcDpwRWwJPMiGZQePlPQEf/AKq9SNZxjpseZ7KM5tszb3ULmZ8ROI1VgyuAkmFDfdwwI5GR+PFQf23LBG489ySAWx82cZH9e1WkhidNnGC3JFVdQh09ElbGZcbQSpGAOBjnH4kVzV5yb93YypRkk1HY5jUfE10FQLO+x2yCZNpB6gj0x7VzFxrtxdEkszOeT1c9O5xzVu6W2R/mJxn5T1z1rDllhScFAPLPzZJIJ6dQK5ajbd2XhW3G7LS6hOiMHdsE9CMjnH/1qadZEaMuQG9T94Z44HeszUbmOJCcnk5A3nA44ArkZL7Mu5hlgOepPY1wc9pNM9hQcUprqeqWeoCTDF85+YZXIrqYbqOPy3IOBkAAEDjv7dOteCjWh8hQlQpwQ4Ixgf4ZrootekjjCAuVcYfPykY6dvc04Sg5OHY6asHLVHuNn4hiCsGaMKxKxnB3H29c9Kw9d1y3a3nUosxlRlhYk7UJxyec/hXj02tSkDyCysvIbOCP8/1qSLU2kP7/AJJxubJbHua1klBcyOGUJOTZRv4lnZg6j5upHUGvL/EOgNeEog+XO4rja2eMjP0zXqd4wCFk+YKN2Oo96w7kpOCyJwx2MSu0qwAJAB+o596iEpKXMjmdJyhyyPiD4mfD5LrekVqAys7SvIV8xzhlGWxjAHpX56eKNHuPD2szWc8boUJJDkFMbuDnPcDjjrxX7ca94Vj1e3lztJKbTubBUAjIH4D9K+Avjf8ACyW6N5dW9pHi2jZczqIg4XDsyY5PPT2FfQ5bjqfIqVR/eeVmOXSUPbU1qj4thu0R43Dsqk/NhsDoRgfr+ddKzRyxr5e7OMhsFc9Oa4pLCS1fbLGUJJVCylVfGeg9q6i0EqNEC4EfBK8bsj3I6cetfZUlFR5odf67H53OD3W52WmTmPy1aT94W+Xdktnk4OOeM/pRUMMamXcEKsG3CVVyEA5J9T36UVySo4jT2SVvM9NXtqftMYydpXGCowM8t1P9f0qWMBsqzAbVwEYEdv5fSrqR+aB/eXBA7D+tSJbBnwQCQOSvX3x/WvKvKXyOq/NHlW6GW0Pl7SxDFgNu7gdM/wCfpRt5ypUq2SGQcn5scHv6fhV4xhCpRmcYx8y4APpgdgMdaka2OSF2tgZURAhV9sY/lxXS7RV5bs5LuT5Y9NzmzFzxkE+uB7VJEwUsoCllG44Xd2zwehJ/LNbBhyFEkahxyAgyn6knt3qtPAzDEK7SR83J2/h/hShrJ3OAiG3cSpK4GDsYkn1zVtSqnKHLkchu1VYkKuTk7mPIPKjr0qbyzGAIyWyd2MY5x3Na0fbXk6dr21CaXNtoabPmPcGXcoyFPOSB0qsZnOcgnBwQDwMdajjAlT5kIYsSR/C36c/T2q4IYhhi21u6qp6D3xiimly89Q0lyxkkihE7Kpy6cEEKT16+3bFbNncqrEO5JZgowd2C3HT05+grMym8BArKVAJxjaeauRRFHGFG08ljgnPBH869Ck1K8V8J5jhKb5jqbe6bYVXjjqSFJ59sVHe6p5NrOwJBVQQehPXv27VmRsVbcTk7cY3kAc56A479TXDfELWI9G0K8v5pJFWC3aaOONsNKwBCj8yP8a2pVKdN8qOSrRbk09j5B+M3jhvEnju9j8/z7Tw7F/Y0YMgMplysk7Few5RR6+X2zXj9xetC/mo+VdcIOnT0P9K5jUtWa9v9QvLoCG6v7uS7ufLzku7FjnPXr/KsG41OZlKndIEOE3fLjJPOM4H3uceld9Go1qup1TpwWqO2fVtx3CQxOOhVyGHUfn/jWFf6gh3y+azuy7QxbJGOB9AK5aS7YhQAAc8jPI781k3l7v3AqRtGFYPgt3q7u9zptfQknvZBgSXAdnbAywLnnpXpXhHSYrmRWkIDSLkDjng5I/M9K8e0KGTUbuNBFu+bkDlgAO2favsz4a+FEnEJkco8YDlnQnKscfTt0HrXDmWLp0YNTev/AAC8qy721ZSa931PV/AuiTJaIVXA27wCdox94kZxnpXvWmMbcKWZQVUBsAY4x9c96yNK06CC3RI0YtEuFJOWbk9c/U/pWo+UU7VwWGPlHJ+v51+e18Qqk3Vm9z9MwlCNOjGFPZHQLrbRBRG5wOMjgmq82qSXLGNWXB6Yzu/Ouda2lmUM8TFfvDbyo/T3rUhi8iMEqQfXpkADsPxrn5oyukd9KMlHlaNhBKuG8xhghSBgDJ9c11ekyNHMHaXauMYOMHkda4gXPzDCnGCBjJ4/Grtpdqk3mOGEYG0gYz7ZHXtXL70XzrVHpuLkrQPX01UssSeYuEOODhjgHrnP6VpTeIPLjVUfGE7sNp6D9K8oGpLIwePcFDE8/JjrxVW4vnZwC52g8fMdyj145/EelaupdeRgqCT5ZHocfidPLVZZoFbLEmN84wSB19iP1rK1TxSmGPmbgELHy3Mg49hXlt1dkAquRzk7XJU+4/Ks9rpvM3bm5GCA2QcEHn9K3nWpW0PMjR1vY7t9ZLjd5rOWPHO04PPcZ/A1BJe7oi6EllI4bnk/l6VxkkySYJZkBHrhW9KYb7KNGrNhPuliMmuOVVR0l+B6lOLtqdJe3ckqsS5bLZwTk85z/SuaaWYysnGSOBs5GeetSpeBo2HljJfOduSPxx7dKY867ipUBv4SOT368cV5c588rHuqEVTVtwLFj0GFPQnIb861EuDs3MfmPcgYXr2xnvWYMvj5eMjOeh9v5/nWxbQbiPlHK8BeT/k1UfcfvBebbXQhzuiRo2JcNk9gakj3lzufGRwAev1qybHCA4xjvkAHJ4qdEUgZLDbwMHPHFbOfv8p4yhC2u4yAMQ2TuzkYbt19KlW2UkgA5b0ctjjJ4J+vNNiXYrADCtxjpxn2rTSJCqFSzHHPYfgf89KcpNzscEqDbvD5mJc2EkauM/KwwctsDDtmvJ/E/hCDVI7osX3MjKUUrhwR83Ud8d/avf5LdZEYOqnjIzyDmsDUNJlnEgQKisOrZz3zxXTSfLKKdyMRSgqdkj8ffjR4AutA1WaWysmksXbdHLGir9nJb7jINu3I3HIBBwPQ14Xa3bxSCKUZljOQuOEySckf571+tHxa8H/atPuZzEZEjbNxHt2llHygrjknpX5meK9GtrLVroLGYxCx/g2MQSTg985r6/LsQnT17HgY7DSo1OfoyrYXDuy74jIWIJARQsYxzwMflRVXTbtfMUBnAyCCR0/A/wCeaK9lVKv2bNHz8nNPofuHgKEYg4HyA52njjn8qnTZuJVgSRnnJA6j6ev508p5seGJBXjGMAc5yOPeo44NjHAzuxknIFeY+eT5X0OWU4RvHWwM0aglyuVGQOdzHt2xj1781aSbA+U8N8oAPTtUbWu/PyY+YnIOQfwqzDanbnAXAPGDmlOCW+5hGMOXmVymZgWZRjA4POad5rldvAGc9Oc9Kka3TaGKuDnnIIGec4PegKR2GCAAM4C9e/5frSTSSkwpp1PeexRb5lY/LhRgADsM9vyqmZZAQeCW+U7lwPrzWusEPlsQTxwyspU4456fyqgQpYxopYDoSN3of1xXUpPmcn8LOZ0vsxHRlgMna2QFyFAOCD2pySTgYX7pHGRj1pikjfGUwQ2MbcEcen6/jSYkRirKN2P4u1UpQi7xKUG4qHU6CNlVAScO3XHT6VbFwTkNgnjAHBPGKqR5QAtx/sjkmlZjuD9gueTznnjFclSpKpp2PehFU5NLcc5ZBneM9cbgc56e1fJ37SXi28tNBjsrJnjnurxbaVoMKYEXJ3kkHOcEY/2q+m7qbaMpnnkDoR6cCvz4/aG1eSfxF9lE88lrbQEtCCFjZ+T8wx1GSMn3reM25xiu55s6fNFwpo+YNTvN7PJNI5kkkywzwx5bk/UD8q5x9cWSeSMyAshHHqew4P8AOqms3iFskAHecBT0wP8AP51yZnkLMeQc53buTX01NtwXMeDWpSpStPY7U3u1XnDBmZc7WOO39ayDey3kyIqqPmw218jBIGcnp/8AXrmZ72SEId0khZg3L5VM+o9cZrqvC2myahdechkKIDuwp54HQ4xjJ9e1TWrexg5Lz/IVGhOrNU6Z7R8PPD8txNEEMJMjA+YFLPHnkjpjGO+e/wCf3x4R0K30y1iJ3tI0a4V2C5x1469RxXz78MfB0mLaZo+GBbaw6khvvZ6deg9a+xbC1SGKCEc7VAyVBbnPGAOf/rV+fZtjJV53i99/kfouUZdHD0VdG9aEeXjcMt8wUcKOvatNFTdkgMAuMnPzcdhVGOCQqiqAVU/eXIA4zjOK3re3WSMNIrNjKk844wf6/rXhOLmuaotT6mEI7IgixHuA2hd5O0gkHt/QflTbqNXQKSFIJACgc9zkVotDCq4CbgMckYqq4wzMzYAIzlgB61MlKWvQ3gpRirnNeU8T5ZiUzkHG0ZyTxiplkXBOeTx0IOO39ajuZc58tSQpwFyKryTDAJAyOF9fyrqcptabHHGLkrI2TchY9pJIAxgEYbnNY8l6qSM4fbg4ChycH169+aqXV02AEAbI5AYAp+HrWNLKS+MAckntg59etclNpycT14RT1kdDLfNJxkZJxgbRjrxUYulDBWlVSASFP3j0z9T1rn/PO9gqkfNnjpjHc0yS4LyZA3SL91gfu/pWVSFm7bnpRpyUtDVluiF27iACOV4LnnPH4frURuBGNx3FmI+Q8MOO9Yr3IVkXJyoyCGwoOcdfX/GnmTBVsruPOe/4fnS5XKN3uckYq7l1OihuAQRk5LBMBGwCQD1x0ww56VaQb3AB9s8bgciubhmc+W7MuUbdg8se3T8a07eaTzVPO1j1YbOPWoUpR91nVJxlBdzprWFCFMbfd67uc8kH9c1uWSKjh2+bH3gOcemAf5/SuctrsBwpQ5LkFgcqcZ7+lbS3Ksy7sqSewyB+NXKTbszzOVP3pG08YYBvNUKRk/NtVMe1UJLdklOSzHJ6g/jn25q1HJu2j5NucFXYHeCKjGfOcsFxgqCBxgdv0rJ0pu10RJRjexoCMkAkqFHbGK14LdlCsCGGOhAPT05qCGHehOMnJI28t7fT/wCvW9BBhFGwjAxuYdeaiCtJpHoXuZEUaiRCX5LYYZ6jk+/tVw26OCzDIJySw6YHSr0FluUFwfqgyVq6bXdtByyZAboSPbHtXZFyc+aXQ+eleabPJfEmjQ3Fu58pHXYVdZELow5PI6f/AKq/Lr9oDwUbTUbie2tnjM8heObyyBhiAOOeOMfhX7M31gLi28pYyEb5W2j5hjjIGPavi39prwRJB4YudUCeTb2owZUGXQfKCOQcklgRzX0GUYtzqKC20Pn81wlSdLna03Pyy0m1kguI7e4ERLugkUqJEYnBUDgcZKn2oqz5ojnwE3vC5+ZgQQQ3X8xRX17Te54LlFOx+4iAfMxCkIxGWXGecUycktuRQFPoACev+P8AKlUkqwK7RuwcjGDj8qWCHcXaZiw3sIhGAuwejcDPIPPJ5HSuCVWm212Pn/e5uSOyNmNschRgjGCDz65q1Ekjt8hGB1AGPc8VTYODwowegPrznn8aeAVXJLdSSeSMHsPyrzvekrwPoOZqK5iwEDcblAcbAARnPuelUngCuwHIAyGU5C8A9hV2IJIpWFl3MNxV/lbP5Uv2ZQW3phh3PJP9M/StEqThyv4zPn9662MTyN5bDNgNypHDeuBj9KcYFDjaCHJznoCffmtBIY1wV6gY561XmRxJuVhjqBj5fwpWlHTuYOEuZyitxj27hjJkBj3PDH3pxjyA+RknJOcc57frV7IYL8pJzjjg+9WXt12KwXCk7AcjPQE+/cVME0jvUGoq+5hsFj+aJgwwDyMk/T8aR4yQHLYJ567iO/Na0kIGAmGA9uVPrVSVVAJclivAB5+tRNzi9LWCSvscTr2pf2bp93dlWJggMpEQG75AWzyccY7mvym+KniifVtW1O93zCS6kYSRN+625YLyM8fKeg71+jHxf1620XwveS3EckiXSCzjiQ7ZJJJOAF69snp2r8p/H1+s19cpCiQxrIJPOOC0mcEgDsO34V3UZ02ud3+44pRlNcsXojyS6lmkyNxyWw3Rse4P/wBeqhkJEhDAsM5wQG78/jVOa5kRmVgSC5AbcSeMjg9f/wBVULi4ESHaFG7oHO5hz65z+de1Tq6c62PDnh5OpK/Q2Ii08iptDMMHJ+6OOTkn/Oa+0PhR4Ia5gs3EEIeRVkBMCISVIYHJBHAK4r5w+EfhuTxFqsYmtBJbJgPK0e5EU7gTkjGeBxntX6n/AA58LJDpcMkcMjps+RnQBk2qCOMk42g+/FeDnGZu3s09ttD6bIMHr7Srovv1udf4c0G3022gVQVygEgDZGcYPvjI/wA4Fem2OnmVlUbjg5BAyBnr1pbLTvL8oFCN/TaPlGTuPb3ru9NslDRqQAq4BJYAema+Hq+0m7y6s/SVeMblPTtCJURpvkYgMeMr05rQuNMt7ZGQny9owUDDamK2LvUYdNhW3ieLew3sY+WJOe/+NcBqHiOE+akrwxkDaFL/ADPzXZGhKMVzLToeJCrTd9Se9uo0A24CA8AH+f51iy3SOpZWZsngLkD8DWTe6tbpH52+OUO2xV87bIxC8YHcZrKh1SHYrF4kLjDIjBgCOoH0q3Cd7SR61OpFWb2LM935bMiFQRw2c5OTk81lz3f3SWYfNgZ4ycZOOenvVS7u4ncyF0zxuGcGqE1/DJIAHyQMBlbgfX8qboN9DSNWm7pM05G3qHRgSR8xxyMVVeN2JbOSRkEY46/549etQ21yDkEngHBXBY+wBOM+nNacwVUxjO/ocg5qO9zWNXQ5iZZEJK9FJ4UYDfn/AJ4pgchgQdpYZ6CrzxseWC4LdByRwOMf560xrfYRwCcZ2kkEfWuZ021sW1opJlYYJD5Bz15yP8/4VJtJOCPlYYx1HUYx/OpI484+UDDdAOKufZmClm2/Kcg5yD9Kp0NFykrlTbexKihUXGM4/i6/5/wqZp5EKK+4hAQDk8c9aQTR26hpQNkYaQP5e51AGT05PQ8Vh396iyt+8YK3OQNrNnkduO9bKlJr3dzXngr23OuW9k4EUxK5ywOMjrW3Y3zhmMu9uMjIzx7GvH38T29nJ5LvtiwMnIJ6fh9aE8c6daSNGLkFw3yPvGzkZ6njNKODlJ+0FUzCEZciVz32KcMA6sAVOeeefpWj9rVk2DBJ+9jhTyc9/avnqz8eQO5U3CAhiNqOCT9P1rq4PGmmLAj/AG1S24BkdwJV9cg10VMHNrRHi/Xpa8qPZrO7Ma4Izxweh/L8q62yvYXUAKwZjvy2SM4A4BPHTOB6181z+Mrc7XtZ2kZeoPIHX9KuWnjyaLaQ28p8xDNnHcgf57Vn9RlF8yWpzQxTk7tbn1OtwoBZZNvJTZ94+ueOatRNv4LEMeW+baB+BrxPSfHdtdXkVvOxiaUEw/KfnKhicfQLnn0Neu6XPJfYlRVKgDLEn26Y+nT3rinTqweq0PdpVKc5OMrnWWMYJUcNwoPcnrnNeTftB+FX1z4eavZxogkkeMxGQEITuG5TgZ6c8ele5aPCkyIpjHmIwwSmB7CrfjnQhe+FL+Js7ntmYKFyS2CBjjtnI78VthJuniIt6O/6nPjoU6lCUF/Wh/MlqETaZruoWVxktZ372sqFgPuSd8+2KK6L4maFPoHjPxBZzyyTzpqkhnEhCFmLn5xx3A/HFFfd0oRcFzXufn9SDhUcHpY/bZ0h8v7zF8/MGGAOexoiVNwRmVeCVUnDNgZOPXufpS+SytlkO0kADGMfjThFGWR2SMvFu8t2QMybgQcHGRkHHFcbScEpfL1PKlyOfMvmNKq+CC67T8pHP50u6JVZQ+HJ5CggjsOcYpWbhQyHC43c5x26fhT2twVMiICTyARz7EVTU4I0hJSVkU4hLCEYkruO1cSYI/8ArVLHcPI+1skfdYEZI96nitpC28lwwQjb5aMr4yQCSMjBOeMflTpVhVvmDZIyRgAfTj6kVjK17omKkpNIe0sUSOgPIfLHyipJ+uOarNLC+4EkAnhnB3D29Kf5QYllTJBI5XGfxqJMu/zRqu4YGOCPU85rCbbimzt9nedo7oEniHzKRhTkBjjd+tXRd2+WEkyqWXIDHCHJ6ZwBn6+tU2t4ixRQSFGSSAWPqelMksQQ3yiROhOAQMHPP0OD+FRsatSlotycyxgtiRCScAA4D/Krcf8AfWPqDVO7ngAKl08xcjCnBP1/L9apS2wQcbC20ZGSD0HP6/zqhcL5K5kBIUcY+Y+4P5VpKMEr63ZyKTjvuzwz473kH9h28JijmuPPWVVkcbMYO7aPULur8nPH+s2p1e+USw+TI2YoFHEJARWB+pVj9WNfoh+0HdGO90uOO3nnk+zXF5BIp2+WAyoysexOfyxX5aeMpoL3UZ1MaELMxcsASCTyM10YJQi/f+7puelrFuJybXvmq++RlCkgMGAAw3PNURK6zI7uHiyGClhkjPB/UdKY0oihkVQCACpDDC8n0x0/Osl7oyyFcAvtIIWLCqADjgAA8Af5xXs1JRo07L+tzw3Sk5Lm6M/QT9l7S5tYs7tYYsbLwAKVKgIAvJ6ddrdPav1L8P2P2CzhQJIhRQAhOAuMjKnOfXOfeviX9kDQTP4ZsNSa3BchtxT91EcZVcqMZHy4HB+8a+8gsiIVCK2AcqvIxx7f/W5r4PMKrniZJ7H32V0XHDKf9WLPmIqDcqqQfvknPHrk1j6942tNFsSLVonuW/d7o2DeUePmYfjXL+JtTu7SLbDglmyig+38Xfoe3evC/Fep3zAG3sXuLq5m4jhYmOIbUy3HOSVP/fXWng4OLu2a4mTtdI0te+JuqPcMVuZSQMFwckEnOM9OmDjtmuGuvG+oeYbme5uZAxwUeQkgDuBnpWZp2maldCaa6t54neQho5c+WCAACO3pz9K5XxJoWtGdIrW2nkVht3xk+X0HBr2oVINe8cDheN5HWXXxRCogRySo+UjLDjPX8j+Vcm3xPvRcI0dv5nlMWDIzDd7n8f5Vzr+C9Z+zLKqAsz7WhIJK47mtS18BXsMaT3MQZ8BlZV+RT6H3pKrh7uK3RsqFaVrG7J8RdbuJI508qKRl2yL8xGOg7/rXRab4v1WTazIQd2JAFO4dMkHPvWFaeDpYmWSbDAsMqRggeo454/lXTQ6CsDjy8gFdw6HcPf0NcVSrBpuFzsjhZx9+R6NofiMTlC2VIODvO0n/ADmvSVvkkWPbtAIy2cEqeO9eLWVl5XzICWDZIyOnQ8HjnJ5ruLWSdAsRD4xuYg9OneuGpOC1Peoc9k5HUu5IBGzpkH15/wDrUIN53u4AxtADHAz3P5Vn20v7jfISQOMk5I44qYy7QGA6nORhgB2P8qylGS97oy1Nc1kTNFsBIJG1t2V4A/Gp2vfNRVGQQDyRjrjODj29ayxNIQQvKgYCgZH60hlkyQ2duMkA8j6VUlKCSewRhKepNeSAK0rEhR0H3SMV5nrt5K/mJAzZVSxIBYjsB1/zmuuuXST+I+WoPytxjNc9dWRZjIMMrLhlA5HII9f6Y4rtjUaV4nmVKbnfseIX8V8GZJJrhlePYzb8gdzjj3PWuJvILlHYJPcBOoPoPr7cV9DS6bE6szxqwJPDDGOvTvXP3OiWUjtuiC8DJC59f89a1jiuRa/keNWwkXK0DxuyvtRstqwPKYosmV3PIOMHnPqeB71vabfaldysq3T+SH3lIwoYN3JbqSff0FenReBlvGUMFht2YMmxQxf2OO2PX06V1dj8PrKGQTrbqpQfKI1KliMdfrnP4Uo4zV6I7vqUorllscxoUOoSeWTvZQnlq2cuwO4cnHuf0r0m2srhkVQmG5yQ3P8AnPvXVaL4Yiig+ZFBflSAFI/Dt0P613tn4etXwrLlShBG37w+tZTrKerWi1ClQhTXKr3PNdPWRbiFGSMTQKBDJ5QVxyQ3OD2yM8/pXvnhDxOttLHaXEjFW/iI4bjIBA4HbpjNYUfhOwMkZNuZOMjeCRz/AE4rs9O8CTyItzbJOjK/yMoKpgYwOOD24rCpUhX0l0MZUqlNJp6H0t4eImWDAAViCPL+U4I6816dd6fHcaS8LAOrAqSx+b5uOv49vSvGPBMWpWdoY9TtPLlhmKx8Euwx/XjmvfNEjXUrfyHBHzcMVJIPINcN4xkuXuj1pr3dD+bv9rPwjL4Z+LWuPIC0V/MLuNypVmL7mOR0I5xn27UV9qf8FI/h7NY2mk+IUie1hSdkW+tgDMXaVfkLf7Q6A+hor7DC4iTw8eWSX4nxWKShiJJI+hZbULsYYC9enTjsKppCBKfmOM844IA69q0ygbaCSVJ+YOMjFLHEqvIREpyM5xkNxnGK6JRgrTfxXPm4VZJ2XUUW4w7KwGflVSCW/wAKWKNh8pYnHTJrT2Bh8oG1eARwev8AnpQYwvTcfwNc8qlSbcpdT2+aVOKuZ5tsoq/KMD5nAwT3xVVoBIUUYJABGRkduK0ni8xdoB3Z+Ue+KqujRDcBhgvUcg0pu6SOOOquY6wDJVxjBx04IHbp71RvbUwKzoS24eoYA9sAc+vPvVxp2xsZMEuQMcgHr1p8oWVWDHDKhKjGRJ3C+wOMU5x1utzyJNxtYzIZDgszAZG3kYz0I9KtqJSpUhthySFJx1qZbVzGxChSWIAyABz6de1QtuxsJyAOSBzXHe71R7ijdXexA0axKCC3zLld2SoOAPw+6Dgd81j3MY2MGBI6KB6fXitZlG0Y3MQeFHKjp2rFvGZty7dxxsG4lVHbn9fzpqPJJtbMwVkvU+OfjpZzTG5mW6eRbbTn+RUjEisXLHDJgABWAyeSckmvyO1lla+uyFfAuHQpMoDttYg5GD6V+s3x6Eg0jXkZoiTYuxRlxHkxqRnp0GCP97Nfklr9251W+DISPtDZ3KARycHg13U24xTJcHB3Zg3UsoJyqLhQrjPHA9B9OgrLRvMlKoXDONmUYLgtgAk5OAMgnPbNLqMzRhnjwoJwULZLcAc/kTxTfDbpNrNgsj7Wk1GGLYAWVsyxL098kVvCc1Fvo0dEYe9zdz96/wBmDRDpvw40OaSERynS4onSM5U8Z3YPdt2T3Oa+gXkd5JFQbVKZIPCgdfzHHSuU+GumPp3gnQ4kQJGNOjl5+WViwBBPHoSMegrt7aNGcsUBy2PmGRwT2r4vETVTEyb2ufaUJKnhoRh21OPvdEuL1zI8RKMdqcHac9MZGD2rNXw/ZWpDSKDKrZHILD/P0r0bUb8xYAOSvKcgYI6EY6Y4ri7295YylQMnBPTk9/061vOvJRUI/wBIyjG8tNjlzbW0TSxmJYozIwDGFpQNx2jO1WPvwO1ZsmkwyvtWGPBJztXOfdT/AIiurV4Wy2UO7oc4Hf8A+vVd76ygaXOQVG5gV+bgE8Dqfw9acalm3fQ6adL3mn/X4HE3HhmON/ugiU7lKr8qDGMZ9Risu50MRN/slfnDDcpwQQe3pXYvq8e5gFkZdpZdseMAE46gf5Nc1qerByTFE6xKhaUmMKV55xzj/JqXUk3dbGdOmv4fU566SP5U2KPL+UEL9eT7nNUVUKeQOvB6YqhqOrQxqG3EKZCwHRwO+R26CqdvrEU8mMhRtyMDd+ePzrJV5KmotHsRjyx5WdpFAjlXBxkZIK7t3NaMV20CMJEbDcqvO4fXP1rCXUIgqlWY5BKZGC36U836z8Nt44BJG76fpn8Kwk017ysei4wjFSijoUvXcqCAFA44yT7n9K2I5laFTjZ2JZM/lz/j1rl4JkUKApZ8bsqckVt26OXJww+Xjacqc57dOtJThBb6k2lK3Lr3J1u9uCy7cDGMhQDU6vuXcWABOSRx65qpPEyIMk8nuM+vsPSpSEjUO0pdlXAVQAp6dKtVHa73ZpyxvdGffGPO5QFXGeGzuHb/APVWc8gCccZ4A28DuaZqMvyNIGUHk4IwKxYrxiVRgrKcjCgk/Shq7SMKikpXS0NrzCIPLAAVmBJ9MEHOevVRWXJFG8hPX0PTOO9PuLoRqS5A3ISSWBHX9PpXKXXiCOBztZNzNtO5ue+DjFE+e7YVLq10egaaU3Qrkk7gFB5I9DXo+n2lvKUZyQ68434U/UdDnPevn/TvEEUrRCRt2SC2MDA/D+lejWGvgRqLYxl1HylvnXp3Geee3oauPvRSZ41k3ofRdhYRGNSTHIwPy/NyB6YzWxBpzx/vMsEG4LtUAHPI9B19SOtePWHjl4N++3CSlgAYZA0IBzkFSd3YEYr0bSPFmk6gCHkMM7P5S+YhiZicEHkd8j865lVUX7OJ7lSk1K7PQ9KsFmSPDgMAu/JBHpnp9a918HWpmMVpKUMC4Dq6YIBPOB64zXhukkBAQxMbLn73LD/P867PRvFtp4aujezl3i4SSMNhWyeCWxx65+tbK6fuHnzioo+itT0yIWolhjRdmD8y5YkAd+vb9ak8NX5iu47YsqLKwEbKvQkgDn9PxqX7ak+mTOMlyCF5wGGSQPfjFYOnSJLd2UhdEH2gGLDbHZlGcAA8jAz/AIVMpSTcbHDJNR93Y8G/b98GNq/wC8U6hDF5l7pdumqxyN84hEJDGQDsQCefaivtH4reC7Pxz8GfG+j7EuJtZ8JXWnQoVDku9uyfnls/hRXu5ZWjDD8k3szwcdSqSrXitD84pY1AcdWDbTkVB5kigsqfKqksVQnAHfA/GtiWGRLp0mhmtpEJjkhmUckcHB6FcjhhkEU37PKMOGCE8hkO0t+NfRuXJLkn8X4H51GEk+aOzJorgrFxGo3j7xXB/L/GrCyA7mAdR93qV6/56VZgs/N2iQhcnLZ6r7k4Jq39mIyvylQNo2s2fbjgfn615tVJpc3xXPoWmmlIz45YNoSQfeYAMNwBLEKF45GSwHbrUEiJklgQDxkjk57f59avtbDKpFGQc4JYY21ZlsY1jJZTI5Tjc7bVx2HOO+ahqUbR6or3+m5zktsCWK5ZBzvUfKOB/jUJXAVQBkAgkdSM9xW35TAFpCB3wuNoHXrWKzZlwqsW6ZII9K5Z805cx1wU1KysUWRpQMErgdSKDaSjGxckjJyCP1rUijO4MxOcEEbefSqszNG7c5QLtIznB/z/ACpznzW5N/MxaUnoc9cbIwyk4bcdw2gL2/8Ar1jXSpLG4bk8kYGR9a1b+Qli/Q8YA5HXof8A69Y87MiOdp+6TnHFUqkUrPc51Fq6W58NftI3ken3lzYvthXUNAYkhNsKs4kj3t+CoOOu0/Wvya1gSNf3b7t5EzFnHCnJOD+PNfqJ+1reXEuv2MCW85gOkJDLOkPmCZnedmIJXjClV49K/MHW1R7qdEBiCk7eTJjLV10LKmrm0o6c0jza/mR42wc7WIznKggVvfC20XUPHnhm0MX2o3WuW0X2YNh5f3y/dO046E/h+IwLqKGMSLnEh6KAcsc/5P417j+yr4ej8QfHTwJYRpulS9e/ZXOUIjV+cHvkE/hXdXnai7K+/wCR5dHldSPN3X5o/ot0rSjBoWnwBSogs4kOckZVVyAfwI71TuHFu4AO0owyVwc+uB1/SvUG0pYLG3ijRRtjBYhfmJ2gZx+dcBrNmPOUhHDplerbeevHTJ46818Gk5Sc5b3v+J+lU6cfsrSxwep6gWlZYXEi8KwkJXJI56c9a5i+u4g8SykMM5bHBBxx3ra10LbIXVT8nXI/DPPvXimt6/5LTuC3lxqTJIozHGAOrHsK0UvaSbOmnSi9eqOzutUlcSQQtscnakmQdg4HTkHv+lZD39rpaG61jVo1O7afPcQhsgkBR36fQ18s+O/jVcaU66ZoOJb1mxdXLKDBbg/3T3b9OK4/SYNT8UTWd7faldaibmQTq0szHy8kBlA7YwRxit4UIyd2zqqVYx+FH0/4i+Nnw+8P2zyXd7Cr5CxPJDtR3YcfN1P4V5Fqn7Tnw/likgmuLa3mAyj20nnecCOcjORXmXx78PKvgvzrazt7i4tbhFldwxNkgIzIhJ+926cjP1r4OurWK4s/nJiZfmEyYBfOOM/gTXXDC0viqXOR46s5Wp/kffln8VdC8TiSbT7yMBZSFQvsDdcHBwex/Kun8MeK7e6vEhjuYgZm8pFVhKz8EgAde36V+WVhPcRXccSGZY94A2OUx3DZAzn/AAr23Q/EGp6Dd2d/pVxPJcRukjmZi8bDGGH1OevtWlSnCCutjhhia80nNan6it5otdrF41ZfLwg2uu5ThlPXIzmn2jTvLtBIDLwp5OBxn+VYfw88Rr4q0DT9TP3Wt1iclt7+YuQ4PHY16TBaOGLLHlX6Z749f1rwajjHZnvUruCUy9pNjPkMzF2BGMjIH4f5616RaaY84j2jBx0VefrWFodhNK6/KGiPy8nkfUfiK9T0y0RSIwhJUbRgevPWsXKVlbY6ItxlrocLfaXIkioocDdhmIwMjOfp9Kybqz+RkEm1hweMkcfX/OK9l1OziZTujCgDJJwuenSuB1PTThni27So+6ckcdvTrWPtJQ0Z3xlFu61PFtTWVN6CTdglG3Nkj1xVC2dFIGVUp1LfLmuy1C0MTGRlYKz5IznDHrXM3VusrMTE6x44ZRgH2+tdVOolaTsU1B3ucb4m1qGCyuZsrF5C4c55dumBjv1/KvDj4ge9nYHfjOFZfT3rP+Il7rMviW70q0WePT7KJJFEUhKXTMNzMR7dMVjaPqjRMY5LRY5AAGdkLY44JHH8/Wvaoyp1I3keDioVfac1INe+Jlx4PurbFtLdGdiotuVZs5IIJzgZDfkfSufT9prXYL6N10xbGzhG8+Wd8kpGcK5I5B6EjHU1kfFxm1HTYL6zhWa+tXVZWRW2xwjghBnk5OcnpzjFfOlxY318sPzyRBHyVAKFh6E/56V2RjhqmnbueW3ineEunqfYel/tEa94s1LzoxJpyQlYo4Wh3CdlYYAA9TgGvaPCnx2t7rVLXR9YWWynnORcqxW3jKjoxzlemQeMZHNfEHwu0yefxJG07MlrpzC5eIKSHcH5c+wIyce1fRF94EsvEt8upTwzQyg5DW0pjifOPvKP5/WvOrrDpts9OlUquWqP0n8E/ESRDDFfX632myoFtrvzFfYG5UB/4h25OR6mvoWIabq9si3KiSAlSwLFGAXkHgj+dfjv4P07xrot5Ho9lc3t3YLMJ4IGRmVRnO0Ac9ug/rX3L4B1L4iXNtDcXVjczWQBEKXELI+wDDAjjHTvziuCq4OdofCVO/Iktz780fxeZIks43MysEhUsApB+7lunHTmu30ZBcXNoi+XLItwsiGQ4NtnhinXnaSPevnvwnNM8dvNJbNEzASNkfMCe361754ZnQXURwQQc9xkg8ZOc0NRmlHotTjkrO259peFtPivtG+x3bDIgkgdI8P5mVAGcf7xH0oq78Nt2p20MG4HzLn7MFORlgnmOSwHTBH5UVVPEShddOnQiSjGTi4/19x8Y+Pf2b/jL4IXV5/Evw68fR2ulRvJFql14TvYFa2Ds8YlcxABgrbec8gfMc14Ha232uET2gLwrw+PnaNskYbHAIIIP0r+3m6+MHwcubWaO6+JXw4lsnixcrc+MdKktXjYYIcGYqVIPfjmv5hP27fhl8LtH+OninxZ8ENT0eXwjqYtrjVtK0e9gn0SLUHUi7msjHlQrEJIVU7SZm2hVCiv0PE04L3os/KKNeSqukvvPgyG2KZLxrI+chGkKBiPujI5Ayf50427Lg4KgjAUcfzrSKzhxkB1LnCnkAfXHpVkRQujl1AIJAy2MD0FeVK0XzRO+MdeZ7mCEcEgdAev+fpUUxwNoOPUA4zWxIAm5V2gFf4BgH/PSsG7RhuY/NleAMgn6UpzcjaC3RlmAFXcuuwvtGThvUDp71nNFiQjBBzngf1qaeVgwwGIBBVdgG3HuB396giuHZcOAGIzuPUegrCUm9vmSrQt32NOKMEqHI2rjgAntjmsfUoQjOVcbWPGRg8Ec1eaSQHlgseDhsZPuB71RnAuGbByABty3XjNcLcb83RnppSTaRzEsSODIpyV4YE/Kcc4qhcsgjZZN+QpKGJVPbpk47+hrUubN4g2ACCckA7iv0x9a5y/leFCdpzGuVB535Gcc9quLUZOL3OSFKfs76HwV+0xcXLeJ7HTrWNrhRpv77ZIpkgLhigZT1zvc5JwAor8vvGFqtpd3sAkaEsxAkjC7kPDDkdeCOfev1a+N9ol7qDXzRmS7lI3MFLLhfMBVTj25HsOK/MD4kQFdfu9rD7O67oWVGBQDcrBlIGDlPyI/HvwqNsRCy1PGJIWlkKxlj8xYyzOzk5y3XOeK/QX/gnh4QGr/HIautuXXwl4dnu1ld9pMtz5cLMTjLBUkkwpOATnHOa+FBG4kCRxlmLcdFX169vWv03/AOCcgu7f4maxCqGGO40ETucFTPmRYyMn2UdfSpxdvYNvs/yZ2YS7rxS7r8z9w3sS1rCwBchTuOOCPp+FcJqunM7M+wcg9B0+n69a9mtbVTbAFCoUbRhvmbAwcZqP/hHBeu6iIkN0YrjJOe/4V8k9VbsfXQUY00o7nxD4u0jVrtpI7FAsn3RgncT26d6+ePEHwM+KHiNLr7ZYXUFpcDCJNMI2eNTks0YOSOhwa/Wu28CaPY/6XcWMEl2B8zsgLt12545xmub1998zBIgq7SAMhRwegH5flWiTaumSqUpK7PyBf9la3gtppNXvZ2uceZFHCGKljnrkZrJj+FmueFUtfsVuzxc/MjhhEeuTnpnnrX6Y6xYwySt5kC5DZ6Eg9elcDqWnWjO+63UdAVCkg++CfbNUlJK73OmnBpn5veNdM8S3mn3Wk3thdTRXEZhNsF2mUHjIYdR618o3fwV8RT/6OLaWJUbzBGYdwkXn5QODx6+1ftFf6Bp95FKj2keWXYshH7xB144rnZdB0+LCxWsW9UGGMAd1GfU1aryjFQaO14aEtUflDo/wB11pIn+zw+Vv/efaEeNmUHnBx2r3Lw98BrWOVCW87OSY44NyKSMAHjoOa+138OAq6xR4EhCnZDktW/pfhhbEghC4ZQdxTbg91/T3rnqTmk7vc1WFVkzhPA3w7h8OaRBpdvEiJGxlISPZtL/MQMe5/Ou/tdBkjnO5WZACcY6Y6dq7e2jWB0TyQQRhmPT+VTXaNFIPKJYOoy6gjqOQf15rhSclZbrc9WCsrSMbSrExuBFGWGQWwOnp/OvS9HtPtU/EW3I3FiuM/p60/wAL6JM/lvtXadsjEjAUHGOfX2+te0+HPDkNzqMUJjfEhwWEe5emeT26d66o2Z5NSDd2eEeIbKeHClN2B02kEj1/SuUFv5sbdPlG5lK4I/ya+wvHHgzyba2Z7bKqSqyAdscBv8968E1Tw6kCybF2Scktt+7WsqdPZI48M1E8H1PTI5C25M84JC9KxJdDkdvLAPl8MFC4UZHX616drOnmNwERgGOA68sMVkTQOUVVGOMZIzn8K5FG7uj3LzaujxDVvhrp8xnvooLQ300Yj86VfMYKuSFHpgZxXAy/DO3ZZE8hEdl+eUW/zntn/OOlfUMScGN4h1K8KML9R6du9Rz6bDuV1UbwCAu3p7fqa6oymouEWcLouS5mfEEvwm1K6SeJYFi2SMgnmX92y84OMZ71x0fwPnhmktzZESs5EcrqRF/vL7HrX3+NPJLOYcBnBwQdv+TUq6VbmQq8Z3q3IyNpzz2479ulVCdZ6y2IqYSMldf1+B8c+FfgBJFKstuRFPI5FwyxgJIcnAJ9P/r19SeD/g1Yx2sdtqsMbSkkyfZ5GIcnpz1444FeiabYRwvEsajJPyo2VAOTwePb9a9J0qJQ2NoBI+6Bx6cmurm1c0zieC93mX9fgR+FPhboenG1dLG3lntpFeGeeJXkQjkYJ6Y/pX0ppuk2aaetvNDAdwOSka8Y45I78HivMLGcxGNVX5gcnJGDwQf516JZaovlICQFwQSOQK45WtzHS8M3JtG9a+GIEDS2oUrgZTeNzegI68GtvSbF0mTau0K2crVDR7zrJvUb1wBux37139jFFOqtEpE4OXULw2e/+fWstXZxOedHk0Pqf4I2tw0iFJI1kMhKRuMlyVIY+3y559qK6v8AZuto7zXZbO8tDG8UCmzuE/eSOZDtkGOg49DkiilKm5pNI55Q55N3PyRFjZSqClqrRpgKMAnp/dzzVqErEDFFFFbKRtby1WNmGRkE4yfpntVSF5FxsyAOQSM5+tacRDffhz3LgryT06479ea/QfrE4ppbH5hFJOyNazY7FjkLBN3yk/dJPf8ASp5bZTkKAvbjqPpUFqhbDyHbtHCEHafTmrOWZxxtAAxggg9/8K85NPc7XFcqMue18zhJGAC4ALFj+ZyfTgelYtyiwBkkRnOwgHPKkg4I+h7H0rppisa+Z82V5IUZrndSJnbIIRcfM7dienTPoac6jimRRpc/ociwWR9qqM7uSRn8jWbOY0dyyk4wAPuhs5OelTTuSzqCwKyFMKwHTHI9uf0qjKHGScD3xgmudyS1CGHklZA9xNI4TJAJLK2CNuc8frVcO6TFFIDFeWyavSkRQk43EjAPvWbKQxYqCCTlgVwwI9Prn9K45VZKNrHtRocsnFle5nuFT5mKNnGF/irjdZYpGXDbvM++rNhgcEdfyrcvbyRiyBSWAABBI24rC1K3ZlVXxuYbshunepVVJXluEKb+FdD5q+LWmM2iNfRqqGOcydNyqT0OewJOCPb8vy3+LljHBrEgUOzSx+cCVxhHVR17fMsgx14Ffs94tsPtelS2UiM8ciqhA2qq7W3DJ/Cvyw+OuhpNrEsK2s0c+nq1qCY1Axu35DZ5yrjv0xXdhK8ZS5U9THF07U7xep8l2KLNK8e2PzEYtl2IJA+nHv0r9Uf+Cbjo/wAQfE8N2oac6NHEpJCmFI3LJtwBnPn/AJg1+Vg83TbqWIoVcnyy7A5Gcc5/L86/Tj/gmvqLSfFTxZDN+8I8Oo8Eqpv3sZIQc46YH5ZrrxspLCuXr37GODivrMH1T/U/dkSp5yREg/LyEOSBkgZOOpweBnj9e2tJoViGCnyr83GG7/4V5s/yzJKW+VHBKMuCemfqOPWt9bxYYGKuAXX5R0x7/wA6+RqTemm5+h0Epxu9i/e3ysj+UvC8jOcnsOf8K881HO6Q4Chh94EFQc88fWpJtaJleN1GcHO4/KOvP+f61yepX6qW2tuUgZCNwxOAOM8fnXQ5csVbYinSg4vc5rV0lc+YqF2U9Rhl+mB9f1rh720kkLM0YDgcLtxjNd5NMwidggdSnAz82M59M1lSbpRloVRM5yBkc+5qVKLjzdClSja8b3POLqAAMvRwSuF5zjoeD/I1QWxMznA524yQASPfPWux1WOLzFiiUK8uVRgp5xkkE4x+dLZ2TEgyFi2eh6CsJVItJo9Syc25GFb6WIgGzvb+HuBntV+LT5kOHVSPvdQCe5wK7BbKOEeYqou/r8xxWfdnaWMZQrgggkBeOvPvmsXBOXMelGCsnLboY/8AZ8EsKsQRhdzFVA79M/Sr9lpkDuqsA5ByA2CTj1JIHT+VZklwIwjI3yHDbcjC+34Zre0w+bsd1IBIDEcnGcE1q4216HBKKseseHtNj2RIW4cgAAA8DmvevCenpa3NuVjEjuwCBhtAzwMn05rxTwwhZINqgkndkAZ9P8ivpbwlEIbq3TaX3AKSq7sEY5x+f5GinHoRKg2nOPU6rxjoFreaQuSouCEKgn5S2VDH8ia8H1fwJavbTu0bGYRlmC/LtI6YB+nevrLX7GSPT42eMiKQjaSvK8cc9u1eY6rGhiaPYhXBH97IPGcD060VLuV0clBOLbkfBXiLQpYJZC6IFDYCcZ69QK4OW1gWYIyrzyGOB9fr3r6S8Zacd00hieNo2YNFt5GMnHHHIxjFfP8Aq1s0hk2jYw+ZeeG+vFTJOyaPThCLbkcnJZRKTIAdwORtPHFMTT/MyVBJAICkZwP8mqwvVmR4mOHjUq2Qdoxx1rY06UxSgNtyVywByMHBre2mm558oxaSprXqMW1lw8RQlf4sg5/A9qkWxiBdijKwH3flP8x/nmu/ghinyTHHkkA8ZJLMAD07kgfjUs9jGgdfKDIe6rzjvXJFp/Fuj15KUFanqkcHaQKpLqQMDBx257+/Sumsp2ilJIRlIATa3zZ6nNOt7OCIf6vcCAPmXJXOKvCyhI+QkMDk8YFbKsrXexF5NJ9TXt5iFVyAT1J9B7mul0+9hddpbGwAFe5964mJJUQBkJj6AgE/5zTobja+AGU4JC45IHFRUk+VN9RSlLc9c029WORGLrtBIUDuemDXuHhecSzRJgOXACnOduP8+/SvmXRZZVVXeNZQ5DAA/jyPpX0F4Ju1N5bMLiOOQnCEnciHoM8fhTtKVO0Njx68pRT8z9R/2X/Cxu9Xg1O4kCQ6dmcRrFzOSrDAf25yBRXr37OItE03TpiirHe24SaWDKxK6owJ6/dJJ5I6tRXE5VIJRieYlGTdmfzu28+YwHBYqowT69+1bUDSOh4KqRggg/pxXPWzxyRKqKSTgNn5cdT1xj/IrprMySq8YG0jBJI4IJ5PT8fwr7fmUneT94+ChBRbS2HwyMnA3sF9yw9hk/54q2r733KAWAw4DYHGcY/WoYATncpxGdo2ggNjIyf1rZgiG3ftAAwAI1G5x3znA/OtpzfJzPcyjHWy2M5mWQNmNQwHzZH1rltSLCQKgwSpAcDI5wRk/rXYXrEIfKHTr8uGPb8f/rV55qk8jMysjbTjgqTk/WuOpONlJrVnZThztJGI6kFiXJb8yfwqOdSAF3qVHHqQTQTtQbgc9CByaiZ8LsLZBwdozXmzbuz3qVDkirlQxrtIZw/y5DA8VnTgoDtLMSegxznir0krthRGAAOcDGRx3/Cs+Z2ZgABkHqOmOO9ccrN2PQcU3aJiQWw5mkUtt6AHDHPXOeAOvUis248qS5EZOQBkAdD0xxXQZdMk/dPC8kdjWBGGl1EuchkiCFjuO4AkjjoOWbJrbmUaljy401axia9aSLZXDfJs8kg7wONwwDz6bgfwr4L+O3hBbi2m12PIe3VjeLj/AFyoDggAckD0I4Tv2/RXXLYSWriSBZU2kfKPvqMjH86+c/FWiR3mn6jGLJppShwm5uVHVdvTlcjGOc124WvCk1PrcyqUJzvKNj8WdfsAlxcSmHBJKjzFBIG4nbjrwSeo7V+h/wDwTbEGm/FLUrRo2mTUvDMyxsVKrBJ5iOc8Y3bY8jPYmvmz4g+A2t9XvLyFZJrCSV7iNDEIjCgADqOBkhldiOSAa+mf2C7u2074yWWmkRRC+8O3cdvITtkeUMpIYH+LG8D2r28RUhOhL0Z89RoVfrClbZo/bjVLjyp3cssao3ygHGe9YcutCTbiQnDYJPAbHpTfE1wyPImSwJ3bV4B5rzt7mVWVUDAhupyRzmvjoNvSZ+rYP3o3e51d5eRynzAxGRkYJA5GOlZpEjO5Dtgnn5ioP+IplsjuiOAx4ySRxn61qxxAA7yWz3UdP0qrqTcex3wlOVosxorZ5kWIyDoduF5A7c/56UuoWUrBYkJ2hQMclfatS2i8r58A+u44yBmrJkUMOAc+nT9P881ryxUnc4YxbWpxk2ksqgumWAwCOh69D0qSKwjjG5wGyAShOD7iupmYMSGChc7RtzgZJ5z2rCu3MZcnaqLzkHcTXJUVpabHXGHMrszNTkuDA+yHarDCNyevv61xt/OsIJclQcFsDqT9a6C81HeTGkhEYbO3OFNeReL9fjsUeIfNICHBHCD15oTT0id3Io01Jbs6SS9a6lEMEoRQRuOc4B6DB/zxXpej2RuIEUSAbQGLbcDpgYx9K+fPCt3qHiK8EdlaspgUbiWG1z656fhX1XptlJp+lW/nQqbn7PztG1WbHALE+vGamUp6J7HTOMJaRvzdTrPCjiCeATHKqwAyQFbt0xX0ZomoWttdW8s7uqZBKxn5zyPb/Oa+ZdDkkS4SdAEaM+Y0bPkRnn8PXnGetdNP4ruLeUSO8Z2ZUbDtxjkYx1rb3OZx6mSg4xWmh9veI9Tt59Ittt0DAABtwASFHHGeK8ovNShIEUUifMCASfu56Z9P/r14K3xKvbu3Ft57CMMOM43c9OtA8UmcBTKqIDuKkdOtVfl93oY+zp8zvt0J/FMqvdSeYwkLsW4UDsB1/D9a8C8RWEtsZJkSRly2Co3EgDivU9R1ATTqWJJY5DD7g9s/561ci0n+1YzbmNAzAPG4yT0I4Y8g+wyOawfLJ2ZHsWnzM+EZNZjt7plZDiVyjEj5kOemMfX8q7fRb+GVFbKt82RyCD2rB+OPga/8EvH4jRZJdKlugl4+3yzDvJALY7buMnpmuB8MeII7nabZn8ongfxAjqP/AB4c+9egrctonHSs1eR9TWl1DBsZGxK3Jx1TH/666i2mSQAuwKEEAHjB5weB7mvJdHllKbpN2OFjYnOQM121gZGZJB5ny87cMEPOe1cjpKK53uz26iTailsdBcafHgvGxUf3QN3XPSmRWk0agovTkjGCP0q5E4C4fBG0Nt6jt2rQjnjDKuSAww5A6+1RyzjrI8+qlLQqwW9w6EGJtgbGWXjp/wDXqhcQrHOSiv6fMAvp0HPfNdokwKKDGGXbszk/KcYGcf54qVNMiuGZgqluGXaMj3oV7XZw1Oam/dvqc/payxJ1OD1UkdDn/wCtXsvgpJftELup+8OFO3rkmuMsdGdtwCnKg5HUD3PtXtngHw7LNcxLIyYLhioBYgd/rjNaxneKsediJ3VmtT9ZP2frxl8FackYkUQMyLuJLsp5yB1wT3oqL4OeXYaLb28L+ZLDCFIYCNSPUL09fpxRWfI5+80cDjLmdmfA+i/8ExP2vZGuI5vhpYWBtiUZbrxXprC5PP8AqmWYqRx1zj3rprP/AIJi/tbvtA+HemWxkw4N34y0gRLx0IW5Lg8+n5V+nHhT/grF4B8Z393puhfA74s3V1p0uzUFjOnXS2w5IOYpnByBkZwCO9dBqH/BT/wjp1/a6ZN8C/i19uvH8u3ttunidycAAp5pIzkYHWv1+lS9tFOhSjZet/8A0pH4/N1Kb552/r5n5mL/AMExP2t1XY/grw6m5gjGDxlp0iKCSCx3Sjjvxk+xq7J/wTB/aziOE8LeF7uIpuJg8YWkUgOThcSFef0561+nmtf8FM/Duhy6dFc/BH4iO9+N3lR6hYG5h6ZzEGLd++Oo9ao3H/BUbwda2k11P8FviRGYmA8h7qwSdge4Qvu/IHtV+yxTV/Zxv/XTmPUli7u7f4f8E/MiT/gmP+1oscd0/g7QzDEWEthF4t01rycYYLg+bjqVPDdiK8G+JX7Bf7VvgizudT1P4Oa1f2cKmSd/DWo2PiiWJACSxitJZXGNhzuxjj1Fftlbf8FQ/CN5bm4h+C3xDij8jzlk1DUNP023fgEhZJHGT1+6DnH5efXH/BWXSdUknsPCvwQ1+fUI45PNk1fxVbW9naspAViY4X3jr8uVJ7GuerhKtWlyVoKyvtp09WbUcwlTnf8AT/gn80YwwmjkilguYJnt7i1uUMN1bPGxVkkjPKsCpyD0qpNCu0g4xt3Lj5h9fzHSvcfjDM/iDxp448aPaw6RqOu61deINU0tZcW6C4mLs8HGCQ24uBg8NxxXhcm/aHXa6nq4bkg18HmOGlhqvJHY+uwNeMqSm97HOyZAbZgYIPoT3P8AWs6VgWCALtJ5C9Qa0ZYi4JHDDsSQx+nb864LW9dtdLI81JhMWAKKhcMCRz/6EPwrjlFJts5pTklzM7SeYiN3AO1TtI28Mc4zn0rL05jNeTGQjCBQgDbmyRg5x0HH61m2etR3sYA87YyghCh7jIOKtWMqpdrFiYibcokJ3KDhjhjnIz0GB6fjxxUrNzPbpyU25M2byO4mt5oFkA4Zot5wpO35Qw+veuA1XRWxcSKMjacsOWXbk8duMV6DMrKDGhJz90MSx59zVa9t8WMisDukBUbSHA3AjoR7iqhKSeiNKik3rsfI3inwFp9yk0jWyS75GcxbFJ3sTkjjoeh9fevLvg14YPgD44aL4oy0VnLq6WlzbBAItPSULGoj6fefbnI/iNfaD6AiCNVVwCOGYbhjJIHU9OnrxXmmveCLq81eK6tFeG4t7qCcOEKb3idJY3XjnBVee5BrshXkoNzd07mfs+WV/M+zdbvEmlR1BdHAw+eOnHNczGyPcA4QL3+XPbFWpboXtnCyRFF8gHeMjOAF4z+PSqUIWMksNx5x3xwev6fnXFJqfu9jrwfLyXZvxOEjOAGLH1OCPp0rTtgskbOdmQRjI5H+fSsD7cBahiiZU/KvlnJ59eg609btGX5WKsTheCp/D/GsJae70PcopySR0El4kaE7TlVwABwcZphu0KAFeQMjGAefUVyDXLAsQuBu5PXn3NT+fJw27CEBSBjJHSjScV5Hor4lGG50MzxGDssjr2GAe/8ASuW1VisO35snjIxn1wf1q35wMYO5uV4YcqMdaxNRvFaJ1CnzAMrxx/8AWrSfv6zInzqfvbnDalfrB5isxjIU7cqfQ8k/lXzr4s1wTzzQI7jaCjebyF5PIOOnGfzr13xFdNIHDkgqc7cd/rj2rym70i3u76I3MIl8yaK3G9Qy5lkCDIxggFgTnIpR5LJ9TeXwpPdH158BvCFnb+FrDVLq2V7nUIFuZJnyM7h8gBPYLgV7L4lhtorZSAIti4UCTcmfy9q5Tw34gtdN0a3s/LjhSC3RIQnCjAAxtA4xXP8AiLxfDcwSRvOiKu5gJH247kCrcZqS5jNQt77W5jz+NH0+WSNFBUnaGBw5wcY5+pqpP4ujkR3ncRxj96753DGCTwOeO/0rxTUPEtrLc3SPcwZiY5JlA8vt1z/n1punXKXMnzXRZXB53Blx1AzWyhTjFT11Cdr2Tuex/wBuoyobW6jZJQHEq5AA/GtKDxUkK7WcZzg7e/0rxqe9FqojSTgD5GA+UVTi1BjJ80hzjOGUAflW6kua55t5cqUlp0t+p9DDxEk6jyyoJYcscMT9K9O8KauxeJbhw6svDEcL6AfT+lfGz+JbTTnSW9vVjRnwMtwM969S8MePdIJhIvojG6/KrTBXYgckDOayqUeZcyO+MZykodT6Z8a+HtK8Z6BqGj6jDHcW9zbNGTgOhJUgEcY64P4V+WFnYzeEdYv9FdJw2k372eZUKG5VWZUlwRna4UEHJ4Pev0RtfHEHkmCKVHWZN2C24oCPX8a+VfiFYxXniu51OIrvuLWGR4w2QcM4JYccnsfTNZRlOMm+pCpfb0v18i/oOqiaGPe4AYYOUIAP48dMV6bpl6qRH5sjGd2MjFeSWUPkhEXkEgZx93I7cV22msYQMkED5ssckY9BWd3F37nRyTpS549T0YXkkjq2diqflK5Xj6Z+lbUTLJESXOVwRg56jNcSt2WwoPGehBAz69K0Yb2ZQygDBweBgcdajlS0ex3VGm7s6KyuwojVmcjPLDknkg49a7LQb4PcvGdgUjcNy4Yc4/zxXlkF6rLHhlAXkgsMjrzXb6BIDcIyn5gOd3y5BI6c89K1ur2ifJVnUtZbH0HpNgbmTdCgAckn356cV9D/AA505vtUANisKsDEzMSx5BwwPucfnXmvw6toriW3ilUAbgGJ5K/59a+r/DmkW8N4vlq4ULhdgGPTH6n8qz5G0olVqid09z6B8ARm2t8KjKOADkYb5W980V0Pg+yigtN0hDPn92jEkYPGfTPzH3GKK7KeDjOPM/zPJq4uVGbhLf0/4J8L/wDBOb/go/8ADr9nPwlf/Cz4y+D7uPRr/Wn1nTviD4b0w6tqiPMAJYNThXM0kabcxSJuZQzKVI5H6/wf8FQv2K5DDLD47m/efKZT4Rv42iHfdmDOK/i5g8RSRoWRmUryR1yMdCP89K6jT/FIkG2ZY+Dk4zgn3GfavqsLjVTT01/rzPzCvhvaNW3uf2iyf8FKf2HpRvf4u6LKyEBkfwzqTSR56bi1sMZ+tVf+Hl37CtxObN/i7pklzji3/wCEI1u4X8ZVsTEPxf61/HX/AMJBa3ES5jLo7ASqyArgEEHGecdce1aEXiC0V2j+UAr/AHDuP4A/WtFmlFd2/T/gnq/Uqb91/mf2FSf8FIf2ETEYL74yeHoUIBFtceD9YuVOR0KpYsB2+9jrx3rMi/4KRf8ABP2KNoovi34aih+bEK/D3Woomz14/s/bz79c1/INHqccslwWXbFPgMoQDfg5y30qyuqpkIriVeGO4sUYgKOFJ46dsfSh5vQd07r5f8EKWW8sbQvb5I/qI+Iv7ZH/AAS78XaHrUep3XgTxHqGoWEpjW2+FWo2Op3bTRthRef2fG0TSBmUys4xuJLcV/NP4vtvC1n4n8Qp4OvReeFZtXubnw+qmZzp9q08hitmeQBnaNdo3Hg+/WuDcwMmSi7vNMgVQOW9Txj/APVT97sylcYx93OAPxx0rix2PhiIrkWvU2weF9lUfNfp1OjBjYKd2CDkLmvPviZGLXwjql/o+jW+o+IINjWpltzOZFLgMgCfvGPIwAcDJPse3jkgwruCfdcgZOR/WklWNj5ZbDEEgHHI6/oB19q+VdOSk2/hPsa1NtKK2PJvh9cT6vosM2o6VBZTrEkTMEZDNJ0ICsdw4289812KWEUN1vEaMrLkBmIZWByCPXPvWukYgwWycYAAXgDOB+VVLpkaVJ1BwowWwfYDit4yinzQWjPPhaHutkkcHnysfLVQD8xXAAz2FT3MMCowJyM8KRtwOc5PTjGaW2Iy2SzbzhsH5D17+1U7raA6MVZXwvJBAycYI+tKSka6OVupiXFkwXCZQZDI4JLrhg68+5UfUZrPvbVpJ4pVbYU28p8sgwwbAPTBAxj3rqTFvswcbgi5xuLsMcY5PT+Vc/KjSSBUQrs+Z35VQB056c5A/GtITd21v1ucTUW+WWyOtt5DLaqVK7lABXH3RnqB9M/jT0lCROkoBZzlW5Kr68Umn26vYPndgkqxWTDgDHIPXPPWqc8yAqpKllbaQV2g9B07muSonLVHtYOTenQuSXe2MpgOM4POO9UVu0yTkAA87R90/Wm3ckXljYAGYkAFcY/z61gzTDlQNhBByO+Mj+tcja2Z9fh3yaLc24z5u5Q+ATu3Kw/DJ7VeS68pGhZ0PO4BkAcH69f8muZs7qOJcyM7Pt4Y9uewx/nirEtwjckMr+hXYT2yB+P61tGTjozmhJqV3ubU14YIiy7W3HdwMt2x0NYWoXTSIzEbcAE7QATnt+lMZmySeVznBOMfpVOch4ydzbyfmyfl79O/6VDlG9j13Na1KhxmposrOHBG5uGxnjnvXG3tpMClxbloDDOk3nqucMpyP616iLSK4lLHBCnHI4POP61pXWkQG0aIR8eX024THfjFZwUJRujpmuaKcehzY8XEaerRb2dYwIzIxRn7YPtxXz18QvEfiHU5Uihn+yeU2XWC45ky3c9Dx7Vr6us9pqFwsLTQ7XdUjbBCdAeOfTIxjrXL3gFwFWQEkElmTDHv7fWuuMWuVnOql9JLU8008agjZuJDM8khJcvvznpk469a9AsNYuLQxF5mOMDHTbjjArDjtGMuxcgFsYIxjnjHvW/eaSiRQyNEpc5/i24PB/PrXc6nLpI8GGs+WJ20OuNLbBgxY5ycDJaue1TxBduc27MkyjuMnk4BNc/YXEtu0kUjMwAJHGQBntV5Lc3EygBSQpRHzggAk49CMkn/APXQmo69zpVCpFOVtDP1Ke+vXUyzuzMRlI2IjY9On69an02G5s545PM8t1+UtHMzNgjn1HXHeuqm0ryVGASRzgHgfSs+2huVuQY1xtcFlIyTjrXHUqNR5Oh63O4v3T2bRPFL6fp6b5GkJiCiTGZPrj25FaVo0mrRvcSMWaRsAScHAAwM/iPzrzdILiW2RoJJMLIAyMWRVweTt68fTmvSPDsbxWuZTuYksOcEZABzx7CspXUdtDmc7y5Uy6YjEFDgBs9cj/PrWhbSIGDMAdv8Bbrn/wDVUMxZlOVGM8jOeaYhAOAvzDktgbh+Z/QUNzlrZaHI1JtKJ0qTIR8oyP4eM7ccVftrjLMMkcYJbpWHBIhUl/kXkbV6kfSp0hZ5cxligGTg4I7fX0/wrNOUXdnVV9pTlZ2N9LiEyYV8MDg54LemP8nrXo3hO58y68o87VC56ZyQQP0ryqZlQRgMRkDaeSx4Peu38MySpdoqg/Oodi3BGD/9emmrnDObSdj7/wDhR5j4CIruqLmQ8SICcfLnuen0FfZOjqRJbyfIo2B22OCDg7TnH+7n8TXwz8MtSSGG280n5iNr7zIBgFcfmCfyr7V8JXUcscMqlHDKBt9fw/Go5+aXoc+I1nz9T6c8I6OdQtCyszyPEzIn8Q2rvO3rzhTRSaDdi00d53fyI4o3laRW2MoC5Jz9KK+ly/GU1h1F9PI+Mx0Knt+ZSSv3P5uY/gd4VkBdrnVlTrJGl8FXbyNu/ZvGfY/jW3D8CfCTIIlfV4ItpEYi1Ft8JPoWBzjJ4bI9q9xs9KjfbGIRuPLY5yfrXQ2+jBHUBSoJ3HanuK6Y007NnyN0npsfPtp+z54chZZINR8QFnbMiS3sUiHgYGPLwBx0XFb0H7OvhV7lXl1bX5JAvybbmBYwMYII8oj154PP419IW2kjCIIizOMKAvJ/CukstEZHLGIZI+QouSOuaVSFyaav8J88Qfs8eFxA4bUdfjwu0mG5iYL3z88bc9PyqGy/Z08IXMjk+IfFVvICFQRyWbLxnlgYSeeK+s10d5EdWQjcpyCM5P1o0fw2Ypp3njJU8Rlmwckjp+HFeZyW0k3c9+nJ312Pm8fs0+E5IEifxD4p8xV5eOW0QngDJPkDJ71aH7NHhTySF8Q+LFG4N5jyWu4kA/8ATE9fQccdK+vLXSVXZmPeynJOOfXr7VtjTYvLQPGHXJYIU+7zWcoST0bO5VGtI7HxTF+y14eiVJbfxf4kldyCIri3sWC9c5Pkgn+fvU0n7Lnh15g//CX+JYXC/KFSw28jn/lhnp7nt9a+zf7GWUK0UYx0K52lef8AP51cOkA7G8j5lbjgdKcqNSTtJ6Lz/wCAYc11zI+Jn/Zg0VrVYl8Wa7FIpOQYLS4kuSCT1aMADHoDwKzn/Zf0GVZYm8c63btgqsMumWs65wcEMIwSemMKeg4NferaFCxRngi3jodgLKO+1uoz04qvNoFsekKbucZH3TTVKSe/9fcYuorXlsfBNh+zZpjXcVg/jbUBtdoHc6bGolwHKyMdvBOVGAVzt684rWl/ZMtbh8Dx3qaKnyo66XakyjOeQVzxgCvq3WNKfTrtLxYoGjjlU3BbGI0ZlV2H+1tJx71r6dtuVOI9hJGAFyT+NYKlVi7xd/69D041YybUdkfGyfskyNAFXx/KEUERi40JC45IGfLkAPT2PIrJf9k2TzWUeOZCwU4P9jRxWxx6rln556EYr78tNPLjAUcDgN2/zmqM+kzx3DH5Tkc4bDY9gPwrujSk23c8X2javHY/MzxB8H9S8AyXiXniGHW7Z2MkZhtPsjQZGQrL0zhV59xXg2rLJFMdhZNpY4xk+or9PPjN4Tlm8N6peB4oXgUTrIYg4kkYiJAy9wxdF5zjr2Ffmp4wgNrcN5fmbQzA7tyY5/u5weveuKrSaV0fS5ZVuuXr/wAE5bzZmDlmOSSc87T6jHT/APXVU3R6zdSNuCcflTCzFVI6Y9wRgYqvJGrEknnGa8ic1B2e59xRhJxTZML1127SeDwAcq1a4uVeLoFZhjryfp/niuOEjRkgyHIJUZFX4b1kljDBzkHPVlGPfp+fpVyb5UaKVlZGwHC5Yg7uOoyTyM/lk0SBVRiOB646VSkmil+Vw3zIMbXMbDI/vDkH3HNQS3TBxHuBVhg7m3Dt1J5/OtYuy5TkhOpBO1rM1LJUZmA2gA8vwT19P6V20FlHcwtHJIxyB9xMsPQ/pXGWnlxHG0YJ4API9q6y1uJB8qAMMdyRUWukkejOSUjyTX/BcUeo3M02/bL+8GCGDc8t7V5XrXhmeJ5Ps6N5ZOUbZtPHrX1BfR/bW3vGSyIMhWYE4PfB5HPQ8e1YU+nQM3zxjGORGvJ7ciuhQlZROXklUso7ny3DpkaBGmysgbnHAyPSrGphUiTbulHV8cMnBz9frXrPijQZHkszaQJArz/vpTDu3KByOOR1yM15N4skeyMVpaJJKVb983+rcAkAk84PGcD3rWNF6Nno4KlKlze0WrXQ4plkZ8IpODxkEg9vSumtXaKOI+X5bYJJZcHPHaskadezwm4VWEaIZWLYR8Dnhc54/pTftcwkjyDGoGSzEkuD+VdMoJO7BU048zPQxsnt1Oxj8gQZUbzxg57Z5rZ0TQ/OneVIwPlKF2HzAdwPTPtVfw2Pt1rEBGs3lEeaSpHlDtkZ6dBXqmmKsDLGsG0bcthdn/1qwqUW0pwPNxNKT97oZa6RDFGVWPryGYcZq1bRiFzkBQWwCTwMA44/z0robuGKMgq25WODxwO+PfvWRIo3bVxjJIGMVjyte8tznp+5KVgWUMGXOWlOC2MAkkAAfj61Xkl2sN3J/jOc46d/8KjnmRsQqNhQDcSu3kjgA1WlBIXBJ4IOGyTjvisnB6qx61KtyK0d2aNvMGAbhlA6gZNa8NyhVsDoOg5Y54rlbN2XcpccqOvB6Yq+JzF8uSDkZIyRx3qU50/dZ5NRtvne7OlV4nkQs6HzJCAyEOwI6jI6c46/lXo/h8Fp0QfMEXKyEDg9lIzk/ljjmvK7JVk2uIlQud7KRhmIABOOOcAfgK9X0GUB1wiq0YB5ON3v19qp/DynNWg2rxPqTwbcyQRxFSqDdu2hhjtk47ccfhX2T8M555Lq3jkJ+zvHlCFO3ghjk5x0zx/Kvgfw1qZjMQwArMc7edp59v8AOa+2vg44urm2ZZgFjbfjJLEA9h9BUUrx22OavT0v1PsXxt4gtvDHwu8X6zIYUi03wtc3gZ2AQFYXPzH60V8l/t9eP4fh9+yf441BXeK5161j8P2UZH726e5kEbqoGSflLHjsO/QlfWZPh5Sw8p2Wr7Hxma16EcQoVHql0PA7DSg7KY0CuDtZyhIzgHr9CO/eu70/w40hjfDhyOuzaW59Opr6K8P/AAfkvYmzbxwApuWJ1C7gNvUAZ7fXivVdN+FFsrQWb2m+Un93tBAPIGAAAMcj86v2c6a12eh89z05O8tz4/stFFtKECbyylXDZXbng4P0z3FdNHpLGPCKB8vzEKD1/wD1V9iWXwKRXjZ7bKkk+WQGJO055A7cda6iL4C+cVH2OTDLgKI9pwV69v7p9evFafVmnpuc0Z2Vz4TaHYnkFQZZGwCFBY4PQCr+l6dJPGZBkDJBDKAFxwea6/8AbK+Ht/8ADT4OeKPEvh5107VbKBIoL7eC9szTKAUU/eIGOc4xnrX4raR4r+NktvMyfErxWFkYOc3wKIOcY+Tj7x4Ga4cZB0IKTdn5/ofqfAvh9m3HVKrLK6kFyW+K/V+SZ+2ltZQxRgGJS2MAtFnI9f8APrVmOxRsssZPH3gOAOOcflX422/jT4420RWL4i68jSAKZZmjuHABxlQyEbjz1GKjHxD+OsG1P+Fi+IZHB2k/ZLGN8EDGCsIHpXkxxdO1lufrL+jtxXJX9tTuvOX/AMiftAttDGihSBMDyCvylQBj8etTPaAIH3rjsByOT0r8Uz8UPjkmU/4WD4ieNxscTW1o8inOTtcw7hxxnOPapP8AhbvxmtAw/wCFia/IhGdklhYTvGBzw7QFvxJNT9cXXYmX0feLVe1Wl98v/kT9r4YMhRlTnJznJH1qOWGJlYBiHUE4KEKfTmvxHf42fGvgt8QtYMfQbNL06N14IHIg5/HNMj+P3xogXD/EDUZDuK/vtMssEcYxshU8YPfHPSlDGQ1T26F0vo8cXTk37al/4FJfnE/ZG90yzu7a4trseaksbLtC7gxwcAj6gVz2gLby3kmnKyC5txllXJOCMg56fh161+O9x+0P8a4Izjx/fSEKQvmaPYzKpBwMBoSB1ArnI/2gfi/Bd/bR4yuzeM3zyrZW1qkhwAC6xou4gKFGQQO3PNbLEJux5NbwC4tpO0p0rdPef/yJ+75tJLdizxnA6sAeO9VRGZ5JnjcOIgC4B+7kkfzB/Kvw9l/ac+PxiAt/iPqG4jhJdMsDCvPQnyC5GOOTSx/tKfHhWMqfEW4jLxhJcaJp5kbGTtDGE8AkkemfrmpV56J25UYv6P3GVOnz05Umn/ef+R+xni/w5b6/aC0vAjW0jgSRMBtkypAPPTGchhgg4Nflr8WPDw03XNStVS4WGC5eFDPEY2cA8MM9VOOG7461xMf7TX7QL58rxrAT94rcaPbSBwTwpbZkYBPTn3rStPHXibx3HdP4ouLbUNV2f6Xdxotos6jiICMZ+6MrnODx0rGpjVHRvQ8rHeEnFfDdOOYY6MOW7Wk3fRX25f1PGro+QyowdcsQS3SjaxUEEZ6Dcfw7V0eu2apNygWZJMbSOG4PP+fWufIbcBgkeoGR+PFefPkfwnPSqOL5JrXYyZ7XdIpBxIgyu0kqAwx0ztJwe/SplxGDnJJGAw4/H0q0nmQurbMMTlQw5AqKdi78j5jkj+6OeapxWxEHJ6paGSWZYkAYM2c9RkfhWbeXT+anzDGQMKCioOOv9ce1WLiQxocLuBXDgLyPpWTKYidzMVz8zEHk47H9apvl0OGyeh2cV7GkSkBGz91hy4461uWmqKihdxBIxuJyOleVTXyxsMyhUDYBLAH8u3SqbeNdMtFmaW7iKW8ZkZdwDtj+Ec4zSjUi0md8qNTnb6Ht9vebt580D5SvPJ/H/Gsy81rTdOV5LiaNFDbXZjtIJz/ga+a9d+O3hixtmk0/U4p50iYiFCM7gMjJP5fjXietfGg62yCcT7JD++CrtgAAwoUf5616VOonDlS2M6d4Ttf3bn0z4t+J/mXRhtIp2totyxMm3ErKcZPt0x9K8cufFct7dSSzbg5Ytl33DJ7AdcDivN4PFv2iVwGfy2BCxFSdwzxnNRXOomVsqHQ7iSCu79av2l1dbH2WHdOdkk7eR75pXiTTp4WgkWSNxGCDlWRj7D3ritY112uXSJoyEfbmMZZfbj+Vee2+sG3jaQyOXY7RmM/48dazbnU7NA3m3Lbm/eDYMsxz0xnqaIzT99na6cY6M9h0bxtfaTIJIZQ6MB5kJIAP1x06167o3xWs3SOLypRdOQpVuYVyePmr4+tvFljDFPDbwtdTlANsv8JGew5/yKqWfjB5HltbaynSYDH2jaQB04HbjnHFHNKonzbGGIpqMLR2P0Jg8a2N+8VskZaQgl5ZNqwpgZ59M8gVI9/DcxOyHypUBVyH3LnoCDjoa/O6bxhrumXKyxXVzMUPMJbDEZyMnv3rqtN+I/ji9jYRM8cM8ylQImZ8KcFQeOvH+TUzXLHmjpY+Fq0p1JNx+Z9l3t/Z2qGSe4SJicAyOBuY9gKdZXxuFZwu6NzhXT5gfoe3/wBevlO81DW7i6ga7dpnikEkaOTtV/UgHnr+td54d8Tajaq8F0ZGKPvJC4XnPBH515fO3Nym9WdUIxirwPdJN4miEchCtn8/c/8A6q1rVWcksC5wBtx179R9K4XS9Ue+e1EbYQkM4KZcc/d59sivSrKB8IQMZHzE8H6frWcUua7ZnOXNJvqbWmQSYJdicnCqf4ME9Pzr0LSUZGILAk9Bt5IHoe/WuXsLYDkgMpOVA4Iz3/WursUdpowqDcn3XJCk5Pqcccc1uqfMtiqk0rpbnsmgSoqoGyW3BwW2jGSSOPxP1r7O+DmoRieGP92wZwg3Nh1BDcDn618R6OxJiRiI2LBN+SGGOmMfUfmK+sPAF1baTpV9rd4WistDs3vri6ZhGnyoWbcf9kDPFaUqKb5ev/BOHFtKN1/Wh8k/8FW/jGl/L4E+Eq3Qkg063Pim9VDllmO6KBG5wAB5h7nJFFfkf+0n8XL74s/FXxf4yneeS3n1CTTdCU5EcNnA7LGwyM/Py3vnqetFfo+XYVUcHCKXQ/JszrKpjJykf6APh34WgKNtsVdjsZtmFH0PX1r1nQ/hQJphG8KBFKnLLuDFeRkY56Z6HmvobRtBtYY9xhChMheO+c5x+NdNbWUUJbYABnIIHze+TWjo803Oex4salNKx5vYfDKxgVjKkZcAIDgjaO+OOPTv1610cXgjTUUqsSElMZKgnPr0+ldwSWAAXj2FSYA6AD8KmMYOFlsdsqs9mfjp/wAFX/DsGkfs5TuF8ttb8Xado0QiAjD7rgTOCOpykDd/4j1r8HvDvhWGKwgLgBQuF8xA+eDk4xj16+lfvV/wWM1dbf4P/CTQSqsdc+LMc8gkXKCO00+5ZiG7NmZcdjX5MeE9KaSzsY7W0F5MyokECReZPI3IVVXuTjPHrmvguM8wo4WjDCwb5opyfa1n17/I/wBBvom5ZTxPCOLzGW6nNO+2jR5fYfCtNU0DXPEyXax23h+GK4uLQWzSy3HmEghXGAu0FW5ODn8/PbvRNNtgtwYJCGIQERyOilsAZABx1HXGK/Vfw5ZNpWhv8N5xogu/FOmXF3rp+wfbDbCa2kjiKOcLlWiGThj8p6ZBrwjQmg+H/ibWIPFthpl5LEjWqWMFrBf2cieaxjn2MApDhcbWA6HpyK/HsLxbH2tdSV2tvRf8HqftuGx/tq+JgoX5VeCUvijqrr3VbVNddNeqPivW/BwtdGsNYe1YxajO1tEfLbgoCTzjGMgrye3vXDyeGpJmVTYPnjIaEnA5OTwfX9a/Xzx98TvDNp4X0KyvdKtpbXX9Hzo1h/Y1qscOxI2+5t2oTvTABI44r548F+C/DFzYa1rvivVDK9xqogi8kXBa3M5LIAsYyzfMP7wUDnAHOGG42Tw9WvVoyVtvPfb06nLQzPEVKFWtiMPyqN7K972vptvofA3ij4XappFlDqV1aqtjcwwywyiNon3znasTIQGDggcY6OvArgLjwFfySWivasovh/owK5D/ADeX6+uPzr9FvjgfCr6YNEg1GZ9dV7a/tInsbhbQFVUoJJljaMZjJJViCAytgZBrkIPhpoyTaTqHie9EMtrYWlrYwW0zJFNdPPLL5RVVDHLPGNwIBHU9a56PGsqeF+s4hWlJu1k3te3VfN/gePTz2FHCe3xEdZN2VtfI/PbxZ8OdQ8NXCQ3qoftOZLeSBt8brtBI5weC2Og6V51L4VumczLDNIjH5o4YZJpH542hQT3r7S+M1jol3rkMdjeM8tkJbO4hdSI4W3KylQ3JLD+IZGFHPNcz8PJNP03VjFLFDJJeNDZiSRQy25aXarDdwOXGTxgCvosDxFiKuUvHunefK3a1tr/oevHEVqmV/X1T96zdnp3PnS6+Hetaatu80QeK7hE0KxRyu8S4GRJ8gUHJ6AnoeeKq23hOW8lMMMbs2AEUALlumP0/Wvsnxl4pk0ewnttRs3tbu4vZrHTgqHMwj5E3OeNoPrnA454878DaXcXOu2syxF4zMk1wxGYo1EiE7pCMDOcevOe1cmS8TV8VRqVsZBR5dmrtPXz/AKZw5PmNTGYeVTFU+W2zT3/4Y8Xh8NtFI1s0TmRCVbcMEHkH+td9oPgq7tL027XEEbS2yzshByEYMygkgf3ScD0613154cjj8Zara2MYCXGuFbQne8TPOsUhbedx2+bO4J7bW6Ace7aR8LYbq+1W7vdXhsSujx29tBE0TsyNFMJJHGQ4EbHIJ5xnPpU5vxTDAQpVJ2tPyb7dD0s8r4ZYJYeuk41E01a+6sfF3ibw/cJJFcSQx+TJAGSRSdxOOAOoIIGeuea82uLLyZnUllGSVPQg19fan4Ut1eXQopBM1mXht5zCYVBQj5lUjjIOMEf0r568SaF9jnljfLSRsVYnPK5GAB0Oc5r7XJcb9dwsa0GtUntbc/iTjXh2eRZlJ00/ZyfMna2+pw0kcbNkyklD/GjKwDAH7xXafwJqnJCzMx3BiDkAt0H0q/tRmOFCgHgdNv41AygFsZJPfoTj3ruqJqN4niUqyn7vYx5VwvzAEYyQDgN+deZa5NNHMxViFzwoUBQM8dO/+NetiJpI5DsDKoJbOMk+36/lXl2uW4a8cKxzuJAGMgDHB455yalSbsVzyqK0NjynUprmRtyvJkfKoR9u4EcnA/Af/rNcLf8Aha6v7adFklgikyd6HdLk16/d6dgo6LuB4IwS316Ugg8kbXXKv2x+X41b5eXsZJaXifImqfCHUbm5ie0cyoWP2md1KhFA64xjPFU4/A+o2M4j2PLarwk7KSGwPSvtuzsVkUoYhsHONnXjk/hitGfwrYXiRs6KgjBICxhRk1cK0oxshc0k7o+MtM0ZUuFAJL5ClTyoxn/HtXpVp4IgvAJWJLMMAjGB9eK9duvhdpTSm6gmnhmOGCR42Oc8sc9Cfals/Dd1ZEoJi3lnCqH2pjoNx9TitadRuKZ7GExMV8R5RL8NWkZWkuFS22jei/LIM49/cU5fhnYRMHBLDdlDKnmMD0/nXuX2WeOPZKsYAbK45J+nIpfs1w8n7gKAV5AQKoxnJ/8ArinOpJK8Uez7ahK84NfdqePWPw802yc3M1lBI6ncrmPqff1qbU/DUGx/sdskbO2XWKPg8fy/xr042F9JKsZDeVkD7uVXJwK6PTNAty8pnfzuBsG0KVPfJ5z/APWrF1Fzc0jlq4qjVi4QV9Ox846f8OrzVJFY27W6yEqJJIiRn2H1r1DS/AUOmW0aSsjTwjA2geWeep9+P0r1JrM/KtuiqqN8oxgjr/jWolrLsQkKvO1juHUf/rqqtaVe0mz5dwjB3lueUPo6um0wxqd2BIqgsp6/1/WsmTw43mNIkhQqMtgZyOvXrXtV3ZYi8xEG1U+YH7x9OK59bRnYl418wkhsLhWBPGeP51hazcludDqcvxbGRoEYiMa8bYVC5xkke/v3/CvaNPljmRCvGV6P8pbFed29kFk2siqRgYXAJxng8dM13dghUJGqjlSFJGABx3qqdpbnLUrXT5Uzq7ZSyqAQAPl5UlhXaadas7IQ4DkYU4OT1I+nauS0tGwoZN/zYYgFgc8GvVNHsvLKMuS0mOAM/TAr0aNnZHh1pyk+a2vXQ7XQ9GupvshixJKdsaRN3OB/+r8a8X/bS+Ot18LPhx/wr3wrcBfFPim3Y6osbFlsLdE/eu/fLFtqg9QT7g+xav440X4a+GtR8X+JLm3sotMgaS2ilJDSS7SUGOp55yPSvwK+L3xb174jePfEHirVbppk1W5cWcBJCWtvk7UCk9eck+uea+hyjBKpVVersunnfQ+cznMIRpuFN+91MzU9dvNXP2i6EKs0QUiICKMAADIHUdM0V5rcauEZVO8xk425IVc9aK+sdVJ2Z8XNTnLnvuf68MUaRgIvyjHOMAVKB8xCnjHXrRuBUjofT8aVAQSSCOO9RTlCTcoHBLm+0WxgYXPIGaU8An0opjuAG9QPpmoO0/FL/grzcx3Vp+z7oMoWRG8U6tq8ymPdhYrGJBk5wAS69vxr87/AFxb6NNp+pCNZJbRvtUCMeNyqcAdOuWH41/Rn8WfgF8HPjZd6dd/FHwjL4luNEhkt9KLazqWlJaiUqZAi288aktsXJOSQg7VwFp+wr+y5bSwXVr8NWhmgYSQu3inWJWQg7gcPdMOvPPrXynE3DM88k/ZTtK3K7vS3l2erP6Y8HPHrh3wy4LrcMZll9WrUqznNzg4JWkrJWbT0W769kfltqUy2Gqa1r/2WKS907wMt/AXO5NyNdyBc4BGc7OD0H5fONr4r01fFuoeLNb0JtdEpLTaQipeRuSiRxhVkG3auwt3OSTX9CWp/st/BjUbeeC68O6i0VzarY3CR+I9QjWeFclYmAmHyjJOOnJ9a4+0/Yn/Z/wBMMjaR4f1vS3lx5jQeJry63YJYcTvIBgnOAAK/NaPhJHCynD22rW9797LY/Q8B9JvhLD4etGrgq7lOPLGyirR10b57rfofhV8Q/iZpPiDS5dMuvhvf2FzdaUE0zVLiO0vn0iKZngSUc7oCpD8JyuMkDAwngXUtOsvDMtrLbTyPq99cXMchjQwW4ttOjlJOWJABiY8DOWJ9K/ZH4i/sbfAe40HWY7tvE9tK2jTRRqNaWZWVA8oTY6Fiu5zkKQf3h5FfzLfBf43eLPFfxh8VfDWfQifDWh3+q6foN/bWbN5MJurrT0uLlyCQXVPLJBAODmvms/8ADmrlOS1ZYeSkldyfN2XRP9D1eHfHDh/iK+U4ahUpyk1um99FrzPW/l5nv3xzn0/T7vwvp5F0J7m+/tKZ7dzG6xRwxIgZyVOxvMVmwccDpwK7i1htrrTHa5WS4uI/s32aS63meJ44YrgSqzDJz5keMZxtPOa5D4seH49S8caNrGs3CNpt7NaeFoYjMY0EZJeWUnPygqSCTj/Vjrwa9Ajl0+/htZtNkglEkR8ncxVmVD5TEKeSB5TLux0B5wTX4zj6tOnl9HDu7lFu/r19T9LzGvh5ZbQjG7bb1Phr4tw26eMfKhiSJYtOjkuJoY9nnyyvI2Hf+IhcHJyRvFX/AIe+DdE1G7Go6tdTmO0lSY2MLLCbnByAxb7y5HReTtIzUfxf0+bT/G11FOIZbm+so9UVoHLiGJnkto0JIDAgWu7HT5yBWV4HWc63Zfui/krNcuxUtsSKF3JLfw524ye5xX6nhW58HU1hari+Xddd9L9Ox9VQpSnwxTp0J2XLv9+mp6D8RNJ0Lx/p2oeK7eW/sh4cWUw2sjAhTADFMGQblO7Y5Dbt3zDnAxVXTc6b8Ob6OG58uZrGW+hmdcAEKoRiRkhMhc9sE1yOqyzpo+hx2lw9rZ6vPe3V40bfJcr9pcANxkgHGdvXAHPFd49vZ6zot3p9gXvYv+EXtrC5MNsxl82aSSOQKu0HARIu38fOK+Rw1LF4fArmleDd99Ek7/nc8jCYTFYTCpTleLfqkk+9luzk762Emk+DL21aSC9ine3vrzT2aEzMgM0J3qFJyCo/4Ea+iNL8OBru41GaW5lkltV02OSaTzbR42hR2xGcjAaWQHI5Kt15rxzX7O10E6P4VtWll1G3EWsy3DwB0hWVCnlPnPUqy4xlduflyAfoPRNQuhE9u0cUSw+ILKysZGXcZ1Vba6u15B6RtJFyOpxXDm9R1KVOcNm2dGYUp1KcJx2voeD/ABSs5bPxrc2VmgiSezhviQio0hkDJnb2H7oDIABwa8i+JegRabcWweaPF5YLPIhwzROVCs24nkMQ2BjgAZPTPsOuajcePfHkt1Hbn7PYb9Hmlj/dwJbWs8odw33Rklzu9XHpX5oftL/tX6FpfxPkj0OGTVfDlnAdPlS1ljE900EjIzRAgHbwzDnBJJHXJ/UeBaOa5hCjgMOtIK877JdNT8u8YM3yrKsgoUswcfrH2YprmfNp69b9FbqdvNBtkfaBHsXBBOM8/Ssok7mGRgngDr+NZXh7xxoPjjS7bWvDt+t9Y3cYckfLPbPjDRyr1V16FTzWlJKqFmkjdlC8FULbuOnFfpVXD1aEnTrqzXY/lmOMwtT+E38/Mo3t2YomVJWQldoK5jYZP/164+W0Msm8lyzHrnkfma3bsNNlyPlyMAHOP88VHEoc4IPAx8wx/npXO5KTszuhU5fci9TJNmFwvlrluMOODT/7Miz85j3AZIcfKvpjiuja1XO7IJ24wH5P6e9QCNPMYFQ27CjceeegH+e9cNTmhK8tmejGrK13sYUMMUaBAV35JGzaCf0zitYWzEbmII5IUjOP85pWtIm2SNFGWj3eWx6ruUhsduQSPxq9C8SMySKzkDhVHHB/z2rojUnsiIVLqz39BkdsoiDbssF/iOee4Ht/hWFcQxCSQ53MGyQVPHfk11FxFNMI5DtSMfu41yASQATx17frWdd28sNuTh2aTjpnqQK1hLlVn1O6nBuV4o468EcpXeoy3yBwOV+h7VnrbQoSRIFJH3SeD6Vqvbz4YlVxnGAoOP8ADp69qhEchGChI/vYJxWrfIlYUY1HqlYSz2OuQwQbsOSoXcR6810lpGio21iwbjOzDIfr0rAsElUOJEJQn5AAeldBa27KwchsbuQVyR+FKpLRNnHXjNu76m5bqWVmKMoHOQPnY57VJdTSR4UQkhhgtnJfB4rUsoWdgWUrsGAM8GtJrMOThFJIzs2ZDf5/pXFBKV5o6Zyv7qZgS2rtbK+MAgFkZcZ69f1rP+yM7lYxgKu4jBA+grt1s2mj8podmB8r8gDAPHA9qLLSyZcMjHI4IGc/jV86ilTl8jnk0lrucI9pK7xPgo6HO719QTXUaXAjOiNIDLsMmzByFyBkdutdJJo0QUDy1b5s/MApHOa17KyWHaqoucbSw9DXoU6aur7Hz9ao6SunoaWm2pCRlGAyR947RivXNG0uWK2huPKkm8sNPKqLu2hcnPHtmuAtUe1iknVVgiQeY80xCJgdTn065NL8JfipFrXj6LQbeM3HhmW3uIm1NIjKbi4RsFMZwExvwf8AZ/GvXy3AyxM3KmtOup5maZl9Xg3FXf8AwD8jf2z/ANqR/H3jm78C6TNLY+HPC0nlTWbkpJqc5yQ7qcFRgdCM4avhF/E00rbpH8uMk8IDI4+mOe3pX3P/AMFEP2dNF8D+PL74s+A7y31Twj4t1KRPEFvDdRyXHhjUmcK8U+G+VHJymQACCvPFfmw97BYnySUu2dNwkhIfy+2054z1r7PDQo0YKED4SriamIvOW7O3i1ktwCW2sQrAZDn7vIOO+KK86luLiRlYHAC/wjaQOx4orrMlTqLdH+z7VjIPQg1wtt8TPh1emFbLxt4Ru3nUNFHbeIrKaRtwyMASe/auhg1vSJmPlappsit8ylL2N8j8G9xXLSwuIheU42+//I8WWNw7ko86v5Nf5mjTADvY9eMcCo1uI5AGhkjkU/xIwYfpUijLFuhIHPr/AJzW8lVTurWOSFSE21F7FpgpXkkYOc4yK/nf+Kv/AAW517Tfjh46+H/wp+F+keJfCfgzX7vwpaareveTaprtxZzNDcToIiYxHuhkIUhSFIJY1/QVr9x9j0TVbv8A59rGS46Z+4pb+lf5mniSa58SeOPGuvvqusWJ1Dxvq2pK+k6jNp0gW4vp3xgMCoKkrg8/Mck8114PCqtTlVavbT8Dvr4tUasab6n9P+q/8F0viNp95Bp178I/C2mj5hqEt9HqgntsbTkbSEAAD7txGOueDX7rfsv/AB4i/aQ+C3g74uafp8Wmf2+lzFc2MbvLbLJbXU1qXiLANsfyQ67uQHwc4yf85R9HaKSe5i1/xMYRERJHeatc3kcpyPvJvYANgR8ADkZB5r/QC/4Jj+Hz4d/Yl+A9m8TRtc+Fn1EhgRvE+oXskbH3KFCfrWOLVKlGNlZs6qblOm5vY98+NMmlWXg3X9e1K1zqljotxFZX0cTsbRZAvmqCPlGQmDuyfTrX8XP/AATd8T3Xirxv8dPE11LPc27QHyBO+ZIUm1S7mHB6blIJAwc9q/sP/bb8QN4W/Zj+M+vwzra3GhfDTW9Ztp3fy0iks9KvLqMlu3zQLX8Y/wDwTCkg0vw78adXvBLCtxDYxq20yCb5JZnVfVizjaq8kdvXx85owrZJXhJatxS+e/4H6L4e4ihh8wqSqN3tH8z3C9/aAT4l3ep6X9mitH8I6/d2huYSAs7RzzwRsELEkiNMEtg8txXVW3xHuorqS9hX7K/9lJptkI2CvaAGcO8eCcbhIO+QQc9BXgvwz/Yw/bE+267rHh74Ja1rWlavq0+oW88Gq2cdy8Mk8kwc25l8w8TDqvJOK+jH/Zd/aA0q1WTW/hN4/wBLkIDkzeHbp0wD8w3KjDv14HIr8ZzbgHCYqq6vIpKX95b6X0t5H+g3B/EnAM8koYPEYyl7RKzi5xTV7XveXf8A4Y8r8ceIH8UaxLq7XBjuZNOi06JyFkSERmSRWKtkHDTPweoHarWleKo9G8P69plshiv9cihtk1NLeJZbONGLSBTj+MFlxjAzWrdfCr4h6azpd+DvFcADlUNx4bvolcZ4IPknvj2965u4+H/jOVmMfh3WZlUgYi02eVnz6KFyDkkc45xTp8Lung45bTpv2cel3/kfZPOOFPqsMJSxlPkWyVSG26+15lXXdbsL3SvD2laatzCugWUtnM8+0GdpZFkLLjk9DzgZrq/AHxAfwXJdzCzj1JrqJFWKSTyVj2ls/NgnkHHQ/hmuXbwF4tDywt4e1pJVTAjGkXTSE5IwVEZ5GCcf/Wqq/gXxfaB7ufSLq1t1BkllvYHshGi/ecq6ggDIGegLCuSfB9KWGlhalJyhLR6vvfpHQ7K+O4TqYT6vicXS5Ov7yG2/SR1k3jCTWvEtxruqQxW9vc3qSm2hwXigVow0YY9W2q2OnzNmvUb/AOLyG9kbTLGBLGysZYdPdIsXFzczQlWnlViNgBbkJ82VPLA5r52SfT7eS1s5D/aN5MNxttPR7p42CklSQu0HGepGBXoFtZxaZfeHtM1PQvEFvrfirVv7J0HTbnTEkEjhkjMlwwf5It0qEMOWAbgYOO2PhosRSpOVBqEdI+9bT9fuPzLiPxa8I8hoeylmEZzpqyhT9+Wzsvd7tWu36nrfwv8ADsGoeC/GGp6zbRvp+pxPo025ykl0JWDyHg/cYmQEnrjvmvzv/as+A3w41+wnNh4Y0jR9QFuVstT0mxjsr1ZFUKoJRQWxsH3gR9a/U3x3qq6Bb2PhfT4BZWWn2kcM8cA+zxvcH55iUXAb5zuJOfmYk818f/FvSI9R0ppiX3xxyMp8vzFb92xUAdix+X3yK/RcgyqnktJQo3vaz100P4k8SeMavHufVM1pQ5aF/cT+JRiuVL7le3S5/M5pnxs8X/s+/FjV9ASGO80mGcHV9OWQbbyHOFlIOAJsc5GOuCK/T/4c/GXw38UNDGreHdStprUBfOtidl7A7D7rITx0PXuK/Gf9sYyab8ePFMZJVBaQLFsHzDI53c8dAP8AgPevXP2FtUK6x4yhT5muYbaRGVVVITHufk4+8TITjnPrxXRnFKFTD+3+0tT4jKKv7+NF7M/X1b9HjWJAzORhn4A/wq/bRISxExLMMAEgD/PWvKrfV2txsO5ogAAzLiRiTznGRW7a6yokVhJ1wQCcZr42aU7H2sPcdonfKAo4znHIJO7Haodo3uGbl+FDkFTntj/PSqtvqMc0ZL/eI4IIy3WpYopJDu3M5xkgfqCP89Kfs5K9zppVUulzYJVECgjcOCAeT6cf41qWMKSyKzxoxHykgZbGeMn8axFEiyEkMCvUEYJHUZNdTp4GFIfgnB55Oa5I0+V8y2PfjLmba2NwaVZbRI6RHyh1AVypIHQj64OKJNPsmikUhRwAvIz3FNWfy1ITncMbcYI6HHHWp4U83c2SODyV46ZwOeo/rWqn7qsEKvs0nHc5d9ItixwAQRhiP4vr7/41Tl0PYw2KRG3XJBI59f8APSuim2RyyKWUAnBwMD8aSVI1XexySMrg8D2rSHK3d7nowxKnDmqbrp/TMCPR4Vi3napC9+B9P1q7BbxxuY0VGGMgjpnHOKes/wC8WMMNvRucrzzn3q3CgMoO9gxx1OIx0/E9xjp+NDUVsefVr+1pqNiaCEf6t4wq4wWGRn2z0/8A1VYPlo22Mb3GOhy2Mf8A1v1qdlKEM3I9uee9Rm38yXcp4YZORyKG4pXR5dR8ur6mza2Y8hAcMWAJVh6881tWenQwsbiTaqqejLtY4GcD9Pb+VUrCJTEom+UIuAGHP4flRqWtxWUDRRocv8qbW69Mk1nbndzjlD3Uo7FfVGDTqUclWYkrGmMZ9T+JFXLd44kd5Mqq/MS33Rjk4rg38QW1v5lxeTiGFGzJK5ysfXP/AOqvH/E/xKe/a5j029MWnQEqLlPkMnGTnv0IOPet6TfMreX5nFWhywc/J/kc/wDGn4632t3cfhDwq80NjZTmLVLuOMxPd7M/Ie4Xjp3r1H9kxJ5PEMTTNbpaW8i+WxuMyK7byVCYPy8n5iwOQBivzX+F/iafxX+0vqvw4vLi7u7PxddJNps8ahXtWWNpplwd2DtyuenyDj0/q1/Zt/Yj+F1x8P8A7Snhs2viCHTxdQau1zIGeXaXG/btJycdDx0r9KyFKlSftNnt82fm2dYunUmox/I/mk+LesLpv7VfxQ+FuuGDUvBPjzWsahb3zmWzgXULbz4Z4znCiMuAHHTrnjNfmt8RPA158PvHuveEdWXyGtLx5dIuHIVL6zaRhBLuwNxIBUn+9Gw65x9r/wDBQO2u/C37Y/ivT4ppLeKGysUDQkiQKsUajnP3lCg/Wv0E8B+Lv2YviN8EfAfhX9pD4aL4l1trRtN0vx/Y20R8SR/Ki+W98HinReBIFMjISfmXjn6KWFpzpKdn30/X+mcc66gldaH891zdG23RbEYofKDHO4YJB/zn1or9cfiJ/wAEzvAvjGc6j+zd8e/DljHds0kHgv4wZ0C7sSWLmGO/iik887nKqDGv3T8/BwVMMFUlHm/X/gGf1ui9b/gz+7Pwp+wn8BdQa0gtPjFq2sX+dkX2PV9KN4525JCom7PJ5ySMY6V19x/wTj+F6tFJpfxV8d6NIMlbyx1uOG4iIIOVlGMYPODnoOle0eCtA+DHhK4OraL4Rj0zUY4mxeoJ7p4wwIbbvZuSMj5RnBxnmvbdL8G/Dfxrpq3zWU13bTsVMEmoXunKzKTuZrfenOSeSpBzXsPiziCL5vrUvujb7uWx8TS4I4WqRaeFS06SmvxUz5b+FH7DV/8ADHx5ovjPTP2h/il4n0uwuTdz+Hdc1x7rSrxSjADYkgQjJQ/OrcL+I/QoSKoCFwMALnpWL4e0DSPC2k2ug6Daiy0uzLi2tvPkufK8yR5n+dyzHLux5J68cACuB+L+u+J/CfhiTXvDl/p8M9vcwW00OoWjXAb7RPHArIRIoypkB2kHPPI7/P5vnmMzOqquYT55RVk+WK0/7dUV+B9FkeSZdlcZ0MvhyRk725pS1/7ecrffY9Kn+zTQSW8rpJFPG0ci7uGVgVYcdMg1+ZEv/BG3/gnRfTTXs/wDM1zdyNPczn4ieJ0aaRjlnKjUAuSTngY9q7K5+MPx0IjFt4k8LfJuZ2ufDjNuBwRkLOAccjtmuU1L46ftJQR7rXxB4ATYuCT4VubjzScDp9sG3v0LZyOlebRzqthZNUajjffluvyOyWX06i5pxuzk/EP/AASN/wCCb3g61XxNc/Ba8sbfQ3F/Itr451+/afacBWjlu3JGWA2rivrz4f8Axb+H2heHdG8FfD/wX4sTw34S0yDRNK0/StDkmg021gQRwRjHYKmASedp5JzXxVqn7Q/7TLWywx6n8OLtkA+XUfDl4YpzxliFmbHr0P1rEi/aP/aRskkiurf4eXJlO9pbDRbyNEAUnAQyqSfy6+3LxGd1a0I89Rykv5rv7hUcLCnsreh6T/wU7+J0UH7BXx91iWw1HQZNR+HuqaRbWmtQC1uZTd2c1qQ0W7ONsjHGeQTX8UX/AATi+PGr+I/j74O+ENmLK90rxx4g07RdcjsoQ2kyeWyvLerIw3AxxKBgDaTAcnGMf1GftKW/xP8A2vvhT4y+CfxB1DT/AA54R8b6Yuj3eq+H4JjqemDzEZpYllJj3lA6jI4L5JIG0/nl+y3/AMEcvhv+zB8TdG+KWhfFjxzr99oolNrZaxptgrN50E8OVmhVShHmhs4JOCOM1nLG5ficulRxj/fdFZ2/U9GLxlDFe0w+ita/9WP6W9M1Ky0bTLb+xobCKeO1WJI4SE+6uArlTkAng9xmvR/A+uS6n9obWEjtpFTPkiUzxHDEH73XIwfxr8x/gH4C8R+ANb8UJaeIvH/xNvPEl4l3BpupTy6mNFUPI2Izu2Ip81R/CAFXgDmv1P8ABPwwuktVu/FLi2e4CyGws7g7owR92WYYIbLHOw4+UfMcmvLhRpqKp0/e87WDmkm5VNH5HjPxzs9En07StR/tEWIstWhkvI4o3VLmIzRBlZQM4A3cqBkZHeu0v/H37POl2yDVNa+HtpKiZSCWG0W7kDDcuIyu4kg5H+9nmvcbjwf4Wns5dObS7C7t5/luI7yCO8WcZziQuCW5APzZ5FfkR+2R8N/2ZfhXrS+IbrWdWbxdql0ZLjwdp2qiHSLddoRXaOLbKj7miIjDktkkrzmvawmWRqyUKja9LP8Ay+88atms6OlNvTza/XU9e+N/7U/wx0bwzqOh/B2w8P6p4tvo5LUeIpNDiGl+HVKbjOA64ml+ZQiKCgI3OcAK34h/FbxBa3c9/rPj7WNV1/VWO63a81gaRoIO0uRJEDt4O0/KrDHvivNfij8ZPBHg6HUr3UJX0qzkZ5tP0uSSQGd5CI5JJ2Dbj97AUFztRQAM8fln8R/2rbbUdQ1S8fRrLxehuGi0+HXXns9A0+AEgRw2TqdxOFJd8M5JJxwB7NDKHRVsPG8u79NthTzHF1HzSlo+mv8Anufqf8OviR8JrOY6xqviPw/4as7a8MgsLBFS31efGWyRE0kiLkhpCArMrHOBx758NEHxZ+MknijQvFlrqXhHwhox1YCxZHgEzBrWKFjHwP8AWPL+9y3y8DaDj+a7V/2r/Fc5S103wb4YMG5beG0hRrd4A5EflxnOxV+bAHTA6V+vXwW+P9/+z58ApF0rwtDc+OvGm3X9fMqBbTTwQkcVqpBDFVicbjgYOcdSRyYnC4qk7Vfi7XO6hX9pN8q0Pp74zai114puPLLoEmMUePlWT7uW5554/ADrXj3jW2P/AAjcplcO5gUgdNhZhg49v0xXzdoH7Yvhzxhq8qePY28L3v2lR9qWKW+0+YuCW5C5TacZGCORz2HXeO/2ifg7/YMvl+MILhZEaESQWdwYIXKnAZmQKpIDEbmxwK8OvSqRqLnWp61CdoqMj+Yz9u+wu7X9oLWpmAjg1HSYTGASWkaOSVXIxxj507/4Vf8A2L7+50fxl4gtzI5S90VLox9Y/MjkKq27JxlSRjjhPaov2x9ctPGPxNt/EWmDzrRbeewlnUBzd7JtySfKSOc9cnvjPbnfgXqY0vxfp00ghRGQRMSxR8MyIcgHkAMWwc8A8V5ubxTw0oPtp9x7uUpLHRaP2Us8X1tHLGFUvCHKFNyowJzwcjsKyZGurS4Ab54xkq+wjIHGP17Vj+FNZS4ggO75Wh38HKgAEgD+X4127xxXaBdwJbBUlQAMDFfnkW4vkkfplN3vG2iRWs/FEcLeWzMDnrg5BPXrXeWfiW23xKJTkjG8A7c+/wCXWvJb/TJ4kf5o3jz8rLhymOmOKo2moSwyqpTDLgMVGI+D1GP5AV1xvzWjqYKSb5enQ95ivUuSJDIoJPK9GNdLa6hFHGEDbTgAHHP1r5/h8RPGwYKY9p+bByTn8PeuptvESTqgVyjlcnPBJHf2zXRVSueTaTeh6y104cHzdpZs5B34rXF/IiALKdrA4Oegz2/SvJo/Etn5aJKxeUNjKsMVsw+I7YlUWXcjfcDEK/0x+H6UQ5OVQ6+ZspSirNHpbRZQyqxYZ5H3WGO9M8zeMB9y4PBO4VzT+IowhjD4U4J5yBx1FMj1i1hy6yli5y+0lh+XQfWuWc5aRZ7rvdo6RJoyyheG7npzzVtLqRWGw5GMcDIPA7VyQ1qxIdtkZfqrMSu3rTE1+3ebLTKEA+fkYUjv+VS1CWhSbku56PHO0ilpHGDwBtDAAVorKgCtEyk4wWA2/nXld1480azjXFynL7CxUsScHoQD+eK851b4m3KNLHYedDGJdySq4CzKOjdcjnPBHp0q5wTSi9Hcyi5xm3JaM961PxbZ6ZDI1wxxGCSFI7DJ7/r7ivFvE3xIDmc2M8Ut3JGHgiJ+RAeBn8s/WvDtc8V6lqE7mSWRUcYcAlWkLfe3H/CsS2gvr64WTAhhYCMzM21SM857nGM4FWotysc83JLXY79Nd1PxHfC1uxKsCJvmKHZaqQfvE5wSRnA68flwPjPV7LwvZXLgRxWMCGaYO4VYgAoLHPGOFGT7VtXuoJpEAWGdAQpkLgg7ieCSO3oAeeK+bPG8upfEy9sPh7pEks1/4iv47Aw2y/aHYO4GWxzwvzHB7cnmvWwFKVeoqcVZf8E8PMJqnQk723/I+vf+CZ3wLuviZ8aL74y31iLjSNIju49Iu5YTi8mnl2ltx6KsbOoIr+yD4WzWXhfwSsl6osCLYTNC3zbTyGycYxgDmvyn/Ym/Z8tfgt8O/COhRRukVjpaR3QQKY5S2wu0jY5PyZzn15xX3B8R/HtnYaBe2CXCxu8flrBvxIDtYqCo7fLnJ9K+zwlGVOdpeS3Pz7ETUpup1Z/G7/wUN8JT/E//AIKE+NtLsnEel6tfRR+fHJviiVHZp40YeixsAe9fU3jn9nnR9M/Z41fxFY3F9BD4f0RdQMDOZ1eJZIJJJgSNythCcZxgV5bIYPGn7RfxK8YvClxPF4surOIthvKjVpY/kbHVmQd+jN61+k9l4K1P4j/s9+J/B+nQ21xd+KfD97oM+nm+islUSW0kARZHXaMO33m4JA+lfZYetOmoxi7LT8z47EqM5+0qX8j8c/BPxlsvDdxp8M8F3N4ZjRMTIj3l1EOGDque2SxxjODgc0V9v+Fv+CXXxN1TTreTUPip8FdFvUJC6LeXd9czB0+UJKsUTx5IBOI8gbGyBwKK9mOJwVtZ6hKpK/urT0P7p4Nf0CPy7a60o27xyKrFpgGO3DqdyvznrgnPy817H4R17wKLYRpexabcmXfJbXWpbfNbaihgrPgDaigbT/CRjivE9P8AFKJGWl0i0ILApJPbjDAY9R14/wA4r1Lwze+Hbu6hur7RtJhvQ4isriOzRpl3kAlW25GSzDg9B9a+ScOa1zyo1KUJbn0TbtG0cUiPlGUMCTuzx614P+0jqAtPBFnZIuZNa8QWsCMTgJ9mLXmQO/8Ax749ea92tkUwoiqQFGBjvjIr5a/aku1Gn+ELLzQpk1W5vNgcK+6G28teP+3hh+NeBjOb2soy3X+R9NT5asVKmfBvxb+L1v8ACjRItcu9OvtZWe/tdMt9P00r9uupbq4ht0CBiF+UzBjk9Aa93tfhL8ftRtI7k/D/AEa2FxAsq2d74mtor2AOoOyReVDjoQDwc8nrXxN8bFj1zxr8AfC9zC17Br/xv0O1vbfy/NV7ZLq3a4z2wBgnOeFPHFftR8Xfj58IfgZ4fbX/AIl+OtE8MQHMVna3M5utUvZAHwkVnEGmcZQgsq7VwcsK4cPgVXjF2vJ/8MejKsqdNcx8RzfBD43rHJLP8PdPiYA+WkfiqwnZjzwBvX2xk15CtxrEPiPXvCHiHw63h7XvD0NvPeWstzDdiRLnd5TRyRsVbhSTz2q3cf8ABWTwDr13PpfgbUPCry2arHe6n4nttQ0m3kzkNNAHXy2jOMgiQnDLkDIr4++KP7bPw/svEPiTx9PrGgeJvEGtwWtndWGhTBQwtg0EHlqWAAG5ixLc5Y5649BZNe8HCSn+Hl0F9cVlKTVj680rw3qevzta6LYG+vywRLaHYJHyQvJYqqgdyzAAAknive9K+Ffw68JwWuo/GX4k+HNEUZaTR18QRaZYRYPyrNeblYnG0sqsFByMsOT/ADBfHP8A4KweKfB+najpPgq8h8PeJLiR44L7S76a3jsuN4wQSJMAMoDjbkAlSOD4l+z5rXiD9oPRNU+JHxV8TeKvF9/faxNDp9trut3FxY2KKUYtDEXMZDluy4XylAAOSfYwnDOIhD2mJVvmfP1c0ppuNHU/tX8LfHH9mjRIp9I+HvxJ+EXmPJ57Wmj+J7Bbi4dgPnkKuS7EDl2JPFWv+Fk3PiV5U0nxHot0srs1jJpzyTwooUH95IoIOGJyATwB3OB/Hb4rvtA8DKbHw3ommQ3MkAj/AOPWMSBlKnc0yrvJYbc4OOTgV5xpet/EKS4lk0HX9c8M311tENx4c1y601rZFGHXdGed23zCHB+9wfSpZRGnopP+vQ6aOKjVvJqx/Xz8YP2ln+CPw08Xar4u8U6Fb6mbaaw8O3cLpZym4dRHGib40DOp8yQ5+6iFiw4r+Tv40ftU+DrM6je6ReS/ED4hX+qXt/c+JdTkebTLeWR3kkMlw4BmkDFEzFuBIdiwwAcvxD8M9S8ZR2mqfEPxT4i8W3ltAIWfxPr99rSxsR0SN3KY+Yru2jhm7Zr8uvix4yS58Z6no2hARaT4auG0qI+X9m3yx/JMYogQFUHcnTJ2ZAAr6DKcBCFL2knds4sbifaz5afwruJ8Ste8Q/EjV5vE3i7V7i+jS5luLSCVjDp1mGVVCRwA7eAvDNk4bivDdc1GFovscRUFCc4I3vnjk49qzfFPi28sNwaaWaMjKwBwIFwMnjgEnPNedWutPqt20pwQV3Oi8IADgAde30716FScoN2Mac6k5J1LWWx778IPh6viXW9P1G7SNojqcVhpFrcF3i1C5Ykl3jVcFIFPncnqnY4r9RvidJFpXg6wsYYkcrZx21w8khimKhAXcMAf4lUbc9zX52/ssa14i134teE/Dmm6bZTaPp6G9vp5lht10mGESzDyTtyHmdBG+3kpMSewP6L/ABItZ9XuzYTKogjt1h8rIJblmJz7btvPZRxXk4iUnJKT0OeMkpX6M/PW8WaW6laOVZt8pTzEGGXAClSOOQcg/SuH8aTXk+h3entK8UO0h40DIJMjadwP4YPSvobxP4WtdEvpEtlJyS7FApXexyQGB56jr6V454+ik/sWYhCiBl86Uj7gLDA455O0fjXjVaMKiuz6+liOSEVD4WfnT490ye93iPMrxDKKqg9s/Lzjp0/+uK4jwai22uIZWYNACcB9mTgqBkdOufwr6I1qwnnF6YZCFUnymGNygBQOCOTkV4BbpNouvSrdMC6vksDywba3PTHX9BXzub0OWClBd/yPpsqqNVlOS7fmfpV8OvECXmnWbhgghgVQjuN4IAPJzyAGHNe9WMsjIsiyDarDAPIYHPTt2/Wvif4W6szR28EbM0UoUlThywfB4PbHHftX1voN8DGysgKnBCk/KPTHoOBX57WpKMuaK1ufp+GqRnCz7HXWU6XReKUAKwwBINikcEnJBHr71WuNIi8t5oNsgYFtwO0IA2OQQD+Y71BYlZC+FAHmbgAM4yMcf5710cIXDLlSANrKWGOQOCPow49DVzeqseZbTzODaGWEtx8o4Az8hrUtrqEAox2yDhQRjr0x611F1ZW7qoVeW+95a7u38qyn0NQfMOCw5UdMnsKL80b2LUpqKTJFb5gGIBPQA5IA6U5HR5QyMCY8gHI3LkFSP1PSnLaOpU7SQVCBfvAYpJ7DKnyw6SOCF2DcSTwOKzfwpHWlbWIjXc6ZjlnfG/Py8Nj61Rl1S7tzu3GSIHg9znPX8qkFs8MI+0lmk+6zbCCetUrllkR4hGwRlJBTk/QZ/wAaIK7szi505a7l6HVby4DNHKYzjl1AdxkEHg5H6dayZ754rjyGu5naQYWNckHrnd27Hr6VU0611BI5IwXO9sE4A2rzgfT/AAq4uiSPKJptikfKG4dsAcd/w/P8dVC10tzuUX8UEZ9zeRxplzITuOGYbhk9MVCxlnUIIGIzlpCCVXPQHsB7107WdlHFsnET5I/1gwCfT6Y7Vj319bxggBUIOCRFjgdOn9aaWiiy5zVrIqLp0CNvk2MQckcEH9frWFqeuR2KlFkjiWIMF2qAOTknn0/xrO13xJFYDO58sf3YUZ2+u79fyrxPxR4qjubaWS2kHmQIzyJLKpkfaMkAZIJ61UMPJuMY7XJr1oUYy51qkWte1y4upTb2c5dZmz5YYyK5JJzk89lGM8bfavSfgYt1pHiuPV7azTTtbjK29lqzR7/squcy7QcrkgLnr0FfIEGs6xdXsdtpyMbm9n8i1jhAMpeTK/LkEZ5PT0NfpV8JfCreHvDenR3UU95qLWokuLzUB5lyM5J3H7oJwcA84I96/R8ryqMaCqW1fn/wD8qzjOKk5+zg9H/Xc/Xz4A/tU3+m2kPhHxtqGmXsF1Ktpp3iCRVsZ4JHIRYplXapDMThupB5zxXf/ErxjPHa6rqjTK4gtZZpLl84jRY2IGPTAr8XPG3im80uFYbAHJkBwjlWUoQyurDoQQOgNfRPj79r74fR/AnWGvddz4wl8PyabJpd0pS+ll2mIOOqsHIBBBOd1erCjOlOzV1ofNzrqcb9T4H8G/E3wb4M1bW9R1y4uZNV8ReIbnUryO3tZJhbgzyEAlFbHLck1+sfwc8c+HPEGhaXdeGdatXjW08+SG0uEMoyFZhIgOeBgEEHGD3Ffzl6XfXbX0upXZkurm8uDcyl3Plw7zkhV7DkdK+r/h54hvPC93ZeIdB1W60fUbc/a7S8sIh5hkHLKVx84YbwUIwQe+a7uRpqNPbzOao4u86nxfgfqr4quP8AhFPFwuLeWVdL1ib7bDMJBKRK7M7wvG38PIZcDv2wKK89uPiFp/i/SLK7a6MmqwRJJfac0JjS4Uxxv51q5AWT5S2VzuVkYYAwXKmUoxfK9zKEZTjzR2P7X/D922oQ2yL4Ym1O0EQMtxaXdtbAHjkmWaPOf9kk17folppqS20iaRJCEKbc+Wvk/MBnAbGB1OCfunGa/O20+O3hy8uLfSdC8R6TDIs6x3M8+vLplnp0YIDvMoYSfKAwAVDzjpXk3xe/bG8X+DtVHhb4YazbX9ssJj1HxXfxpcWyMUDN9gDfO20kDzWwuRgA9alUq1Wbgo2dup89orOT0uftlqfifw74Z0xdT8Q63peh2BQObrVLyOziO4A8FmGevavzM/ab/aG+G+veIdPHhzxJBq1poFjd/b7xInttPinZo/3Zml29BDywBHQ9CCfyS8W/tBeJvFuuzS3954k+Iutw2vkLCJTe2NsET5I5JpXVUQ9T5QkK54XPB8S+JVh8U77QJdY1/RfFElhcwLcy+F7DQNUtvD0O53KPNcmGOSYEbcq6lQAgwepKeRSr1ObEytfotP8Agm0MzjQpqMEew/Gf9vNNAmhX4WTG+8f2bsNM1DR/Dya2NH3Mom2Syw5DBRnhhkryOMj8VPjz+0T8avHPxE8Qah4817XPGXjGzn/eal4p8U3OoiNHVZIoUiQFYhGu1WjA2gjC4AxX3j4O8B+J9Z8Oa/rOhaQ+k2Gi2775WshpNjNdSlUgi3MqkEtIpz1OCcGvEdG/Y78MXN5feIPG3jfU1mu7x9RvrHTTDDayvJK7hTNJE0zggnOOmcZPf6nLMDgsDFxUForJ7vz1Fi8xrVnyt/d/w+p+dF344+OV9by3OreN9D8HaM6iTVzpGiJIZggxxNMGcnhQMY5fGDwK4Hxn8eBZJBZWtyt+yWYD67e6i+q3t06jDsUbeQPlZsR7VXdgAZr9RfiN4f8AhlbabL4e0rwvpn9nQIbYQtZCUXA6NuypzuHUnlhnPWvkr/hm/wCEfifUrl5fCg0ud1Pkz6dcS24tNxJzFHu8tcZGPlxx0r0PrODSfutWPMTqp87e5+cwutc+JOv2OmorTXWqamq/aV4SFXUIzNIfugLuPSv6PPBeg6N8J/hH4V0WwlNq+kaYgKxyAK2VLgy4OSevX0q3/wAE0/8AgnD8HPEvxkTxDq0es67o/hdP7dmg1C43QyyqrJEjtGEwokaMlSDuEXUDFftx+0l+zL8APEGhXmkR+BNH0y8MLC2v9OhNndwOxAc7kHzAhjkNnH8OCAR4eJxmGdSNJt2PTgpu0mtz+bzUfEy+IfFLw+Z573F0VXynZkT5TnJJP93PA7175oz6bocFtFGgluzHln+9Jls53HnHJI/CsW++AHi/4PeI9buD4V8Qaro11P5tl4lt9Mn1DTo7bgRh5V3FcBgG+Uc9zXq/wy+EnxJ+JmtxW/gzwHrut5dDJcy2E9pZrhhvPnsoQAYGQxXgcVvOkpL3bcve4+dP3Tyv4q+NU8FfCT4heOb421umhaBNJAPmkU3Fwy2lkNpxyZ54BjI5ORX4JaC9/wCIL+a8lE97c305nkcK81zfXFw25jjBYksz9Rzkfh/Q5+3j+y98SdI+GegeBPENxpGlt498RJFdw6JetdzLFZqLtfNJiUDEgiY7d2GjX5uTXyn8KP2XvBfwaik1qdX1nxE0Bij1bULc7LWMrtZbeNmZVLjcrMBuOcZAJB78O4YfD3i07/PY8jmi5NPc/I7XPg/8UtennuNM8C67Np0PztNKbaxMgzyyLNMjsOc8Kc+tYug+BP7Bu5NK1WV21K/Cu1vHF5psEXzCRJhSo6MM5OWBGSBmv10+LGvW2h+G9Y1CIzwSR28kVikUG6aaeTckK8HcBl0BxjjPPSvz6i0y4s7aXU7xHS5vvnmn8truYsdz7XKqcYLEjcR7CrwzjiLzirGc6k4ytHY+yP2EfhTqet+P9ZtvCum3Os3sGibpNPsLJJdRkkuHReZOCFAWMkuQqqq81+rOs/sGftD6lNPfx6N4P023niLLDqmvznUxuUD5fKt3QHBxww+nNVf+CBlj593+0Jrl9brdS+bpNvY3k0GGiTdcKiKcDAAjKnHdK/oA8SyxSPPujV5FUhQwyo4wc96+ZzCvKji5QSV9D6vDU3OOj3P5Dfjr+yn8bvhvHcatr3ha31SxjG9p/C162piEoSWDRyxxOW2AthAQeBnNfnv8TLW4u/DWr21iskt8bZmjt1k+zSM8Zbaj7gu350C/NgDIr+y/4l6ImsQ3tpfWa3GnXDNGYmjLxMpyuD6cY9DzX5Qfto/s9/DjTvhT4q8c2HhzTrLXtOjF99us40tbo7ZUlwZIwshGFb5WYhj1BrjrYiU9WtRUsNUhFdl5n80a+CfHcugrrZ8I67Jpcsjn+1beKDUNPkVXaNnHlyNJt3I4yyjgZ9K+ZvG2lT2mp2t5JDLEjFo2Dx+XKHUgkOCM9NoH+7X9N/7Pvhq11L4E+CL8LDLHeW97LPCoVo4pBqF4Dnj+IZbkZ+cetfnL+3n8JfDuleG7vxZouk29hq2nTRG4ms4PKSePzo9wfAwzlMgHI6kHPFfNVG6jnGS2v+R9pllWUYqS+F29dz4F+GWrx/utisqq65I42jOBhv8AP0r7K8N3aMhCyMXxuYEjIBGR0JHrX58+E9XaxKuiuATvwRgt34/DH0xX2H4D1fzYYQxZjcgMS6gqmdoUE9eo/DNfF4+DUmnuff4CpJpcx9M2EzrGkgYZbByxJxn8a6BJUDADBLHLEqg38AZJAyeMVxGlSp5PI/iIJHOef/rV0iXT74wABGNuQy9ffoe2a8NxbilLofTe7y3ga8dyyqQQpOepTGM/WpzNn5CQS3IHUY7/ANKxoXWRTlj8o+UHoD7cU1bkiYkBi4GDkcY4PA/z0reMYpaHArJWkdHbqwI3NFsLDIGQ/Q5ye31FaLzRIchgW+oJH4jnv+lcguoyqzK0bbd3JLYBHNI+pBSQD1Pyle3NaQ5ZO3Y3i4xhqb120TRqp2tuPbmsx5Uc7AkY2jHA+f8AzxWE2sNEDJtJIXAycjJGDxjHr1rNbVpDK8m3huvy5B/StJ05SnzrqcM7WU5HUNcRLlYygYEqcY3cZ71nteACTBGCOA2Np9c8Vzc2qIhIywMzEA+U7jLc/NgcDPc8Vzd5qvlAhpmRiflGxgDkZODj6Uowtq0aOS5eY6K+1GCKQ+ay5UFt2Bt+vX3rzPXfEgIkMJwM5ErseAGA4598DPrXPa9q9xNcpLLPMUEP2doRGgT7zndwMkgMAAT29+fKNeuZbhTBuxvw5yxGMMGXocHlee1duGpyqPmt/VzmrYuFOF2Wte8V3V4DZ2xEruzLJIVykancMj346D6+leeXcIhjlmvJyTlmWNGwGOCMY6k8EYHPNdVYafHEk15dTrDFbQmaXchZkCruOB3ODkDua6z4KfBrx5+1P4y/4RT4VWE1raWEn2jxBrmrQM0NhBuAGWAK73zhVPPX0r6zLcvlTSxNVJX8/P0Pic8zhzk6FPTz+R0PwH+HkOs6kni28sJIoraTbpclxja7N1kVccdQA314r78gnitLGSFIwCcKXQghMAEdsjhh+dejQfsT/GH4UeGLWyvrWw8VWUNu3myeGHnl1KzTAyTE0afMiF2wrFiUwBzXmEmk3KOsf7xrQuA0sqHZJhgG3ZOS2FPXJJHNfY01Hk/d7HxU2nO73ON8QWLyxtdyMjQOzCF5GGEO7kYPPGO4r4R+Mlt5urQSKN9sJUgmdObMOMEJnoSTkDpnB9q/S61+CnxK+K2owWPgTw7eazEyk3t3co1jpUDcKHEzDYOABgEk9q87/aT/AGP/AIl+APh3bR33hyCC/ufENpdG6bUYHtZJ94kWEOG34YK3LAfdx7iKdSDtpr1N8S4xnbqfm1ZweY8O6RBHuBkGQqsCc9fXnrXvvh/XND0+0iguruO0l81FhNzLttAWKA4PbrzgdqG/Zp+Mlhp8+onwgLyGzJeZNJ1WzuZ49rEMUiaVHfHX5FOfQV5r9ltrmZbHUojHeWj7pLGdWtZTglSp6Y6Z4PbgmuqDc1aBxSbb21PtbwRf3OovZvAS5YkRS206yQxgll++SvykZGACfmAxRXkXhDWJ/Dtkl1phFq9nA1xNbSyl1jAyxILE5yMYP+FFZ16M1U2+8qhWSppSWp9L/AHVdbvPH2nR3Nvr3i3U9x+yaXbCXVdX1udz5UcCRAkybi5+8CvygnkDH9Yf7Mv/AATp1v4meHbTxR+0RHe+DbNJEbTvh54f1QCURqA3+nXEY2/MTnZExwQDuGOfgj/gi9+yZLc2l1+0F4xtVt2uL5dM0FrqAP55SUCMwgg4QsFfe2CdwPAGR/TtB4hbSNONtbxhlCgBm+VTjjj36CvQzOslXcaOklZXPncPG1NJrQ8i0P4Afs/fBrw7BpXg/wCHvhnT7ixDPp17JpsGp39vNJ9+4E1yJGMp5O5iSSOcjiptN8C2niWVLq+gjltiNrJLBGscig4yURQvA6AACpryTVPEV+odGkiRsso579s+vtXrdisGl6eiyMI1igMkzEY2hF53A9sd68/nqOXO5Ny73MbQUFG2h+S3/BSHUdD8Iaf8P/hvoNhaWI1iWbxPrbWKCKdYLVWS2EhXAAaR92CDzED2Ffgl8UfFVpptvLbpcyAPE7AEqyjywDwCOSe2K+0P21fju3xN+NHxA8Q2d2t1pNhcHwz4Zkify0extCsW8EcjzXDueefM4r8fPiL4rvtR1KW3cyq0T4ALFRg4bAPoc/XmvSh7elh1zPff5kwp3qOKWiBNU+0zXM0hYxs26LdgHGQOccZJJP5fU+peE9JivbYzw7zdMu2OFV3hju4HrzxyOma8L0SxkuFi80OctxnDL3wP/wBdfeH7LPw/m8d/FHwN4S+ytJb33iCCXUZGkEcSwRBppQxwRjZExIwfvfnyOdaN5Rasz0Xyr3T94P2FvgpL8F/gdB4h1KBU8QeOIxqlzIw2usILGCMgjOACx/4Ga6XxZJPrGsPG8m8CQjAAO4kj5gDxngV9EeKJ5NK0XTdJtX8uz0uxjsYYInwoRIwirgYyF2/T+njWi6ZLq2rq3kM+ZduQpxycdfXA/OvOvKU3OJSaWrPcPhV8OdHfTopLzTrSSTYG23cAmETEk5G4n0J2jgZ4Fer6slpoVm1ppdtBZfxEWkawgn1wB14/DNaHhKzi0vRI1cRwBY/m6hgQWwefbHfvWfr5tpwZCV2nq2eApxknNXOp0b0MvZxnL3UfiJ+33q9vrXxF8F+H5oWkXQtDm1iSXed5ku2WPAOODtiY5/2q/Nnx3qcewWaovkQKqREqoIORxnnjJxk8k9a+x/2rfEtv4h+JvjzWJLm2Uafqsvh3RmtnV99rZDyVk692jLgr1DHjivzQ8UeInkupYWmmmXeSGZ2Ytz647YGK9CnCSw8YFP2ftJJ7o8g8f/D7xn8SLzR/Dnhi40iziuNUVtTv9T3NHaWq5LmJQpLSkhQvAXBOWGBn7I+Hvwm8LeAPC1pof9kw3t8qLNqOq3EX2q91Kcgb5G4OR0RUwQqoqgYFch8K0gmea+uos+QqrHuUGSSRscAHAx84Oc9K/T/9lr4c+E/El5YeP/ibeJceG9K1IR6L4L06L7XeeJrxZDHGkqhQzQh1bdjIPlYz1roeJdCio32/4c5adKUqj5T3b9iH4TT/AAw8Da94puPD50K88eTxXltHJYJp3m2UO6OzLKoAO/8AeShj8xFwOAMV9Z6h9ito573VLm1s4ip3z3NysESDPOSSOM+nqK5bxV8TvGPi4afdXFzo3wu8NWlr9lsbPUbT+1tSkRX8tPs+mxRggGNeGkJChSdhB+X5G+Mf7QXwu8J3ML6vqdr4kubGRvLPie6jvZQ/7sN9n06NiBGxCkNJ5WMdCOR5NerLEVHVqbs9DB4eo3yrpb8z2nxJ448GM01vbNea2BI0Uj6Xpc93bEj5SgdlUN1PKZHHB6V+fv7VElh41+DPxM0MwX2mxSaFLIPtli1tdROiO8b7cn5VcRk59Dnqa8U8fft3asLu+g0DSNS1TT7e8P2K91HU5NDiBTutnbOIwgIBXLE9Dx3+QvHP7dNhqmmaxoGqeEdajl1qMxO+ka+8ltEWYF5JTJ5TDO1+hO7PII6+VVg3JJdD6uKST5jm/wBjfxK138PL/wAITzkTeHLqSSCOQguIZJG3AHkEK+4g+jj8eu+JnhXQfE0WoaNr8Fjqlhq8X2WW0uoVKzgqHKlDg5BXIIx90d6+eP2ctejsviXaWVk8Ulpq808LIJRJFbwSWrgRswJAPmRptHPzSe4rQ/bG8Wav4N8S/C6/0ewa8hTxDcavrNrC/wBnkubaygQtsfgbwsjkDoSMEc15+LVqza2f9MnDtU6fkfkL8fvhNL8D/iHFpFowk8Ia4rXHhuYkl7Z4xme1djjhMMygFvkkUcdK6jwRrFvLAgV0V4woxHtQyZ78DPGMfh719o/tE+HNK+PlhY6XpcN5o+uaXpb+I7R9V077JLau0KfZVcspZo2LuHC8DDDPPP5f6DrV7o8mzakc0bm2mSU48koSrEAjPXPYdjXgYzDurFStofX5TXpygqc+mq+8/QHRtQCWyli2W5AXGBkDk+/H6CuwjlVo1fJbHUM2McED+lfN3hXxpbzQ28dw0YkdDhVbczEFsE/hg17RpOrRTY5BBBJxggD/AD6//q8GpTcbp7H28KsZxjKDOmhnO0EtyWyNp696vwXigs0iDIOAxyGGPbODWOk0IUiEh+eFBPX6/hUM0hU7sMF/i25wSSD2xx0rSMLN8h5sWpTfNude9xCwOzkgZB3gL6d/zqlNCvzkSKxxu4I2jrwDXKTXsh2s29TkMBuJBx0BHTt39apXGrNbbVd94kUkghWwBjvj3H51koXWm56U5cquzdnTZHuMhKnhkYBh3yeneqMtyqxu289cAk7WHbof88Vyk3iJBAzbVV1GTkEcAjJ4PUjPXIrnLrxRJ5bqsiMJFz93k9R39we3etOWUppW2PLnWhZXWx0F1cyImY5gzg4ySO/P6A1yupXqxsBM5aTBxk4Kn8B3/pXL33iZxkny+flTL5MZxjPXHbvXE33iVpfPLKxdE3HuWbngdOOn512xpTSSS3OSVWL9+R2Gq3yT4RWOVY4OflyOP8/SmeCfAHiX4heKrDR9LhLSXpIe4nQyafYwofnmfB7BuB1Yn6mrPwv8Ea18R9XsooLa7i0hLwR6hqRgd4EReHSKTBBk5TgE4BzX3x4y1nwz+zp8NLa18GWNtdeMNevV0izMCfb9TgiYEmSTgszKegwASw4IFexluE5F+9Wq2/4Pkceb5gm3Spv3j5c+IXwxtJNetPhX4a0ybUjHb266vf2MuzULm4IG8KuDk7SuRg9enFf0FfsUfBP4WfAT4f2Hh/TpNM0XXdZijv8AWpbi5VrwyyISgfcQxOA3Psfavwt+B/xZ8IeBfiho+tfFHS9Y1nUdRha80cWW19RtLwH5ZrhA3zh0J46KcHjBB/YDQf2xfhIEtbnXPB+oLarblP7Z1bQLbWGhVW/iiG6XABzlQQc98ce5LEuSVOeyPhG01rufq83gWHUdPS803UraRHG5MsJRJkY3AgHg5wMjvXzrc/sA+C/GHjZPGGvSXtihmW51DRdOuEXTtYlUkmWVVXgsdu7aVDEHI5Ncz8M/2qP2dPGlrHcfDL4teGdKvJdguLOPxAdLmt5flJjl0y5KhCQgGfLUsF74yPu/SfH9zqMNjNoqaNrAuIk8xpL5IFui21Q0RQso3fMeex6VcKrTvSejG6ULaIztN+D+jeGLOGw0HSYLOwgTaIooth+UAZPPPbqa/P8A/wCChPg+/t/gm2rPbjy7TxTZuqhS0rFW2rx/wI+1fqfpPjG3V7uLWNGvNKuYVPmKoXUrIgNkMk0ROc+hUNwcgYOPjL/goXLp+v8A7N2t/wBjXtubhtUspYJg6gKouYgxOenGRz05rqjVTfK9zOUarm+XY/G3wRuciW+cpE2JI0Mm88ndtPXIPCnOOteT/FX4JeDfF00s13pCWGoXBMsGs6cTbXmSvDjacE56hh/COua7DSNWeyghIjMyJGAGzuJABXOfwBrpdR1/T9RtRE0xjmiVW2yJJGT0PDFdhHY4Oevpx6HtZwSlDc8OtTgqj5T89/FXwO8QeEIHuNNe68WaRsZJEWBLfVrVQAcNEgCypjI3L8xIIKd6K+7VvEgMLzJHNbi8EE+XKtBGzgGQKBufkgbRnrk4AJorohjarjeok39xtGlNx9zY/sM+Fvgqw8KfDL4beGtGIsNJ0TTIJIbayiFtHKBCyoSOezAn3Nes6trEjeRDbJJJLt2lSd+cY5wBz0/Wvxo1/wD4KBXVtNc3fgTSLi+gNjFZ2F34lu5LXSLJIo0/1VohViSxYFiFPyD1wNT4Rf8ABRzx1Je3TeKvA2i6tLasPKuLHUX062XjPIdXJB7c8etRKlXm3Nrr1PIhZQSWx+53hGwuobSO6uY4yZE3hGjG/jjJHavB/wBtDxxP4D/Z6+JOuaXJPDq0+gPplgYc4ilunjtkce4acY98Cvzov/8Agqb4vGpG1t/h9pMtqXMbw2urSQyq2CDiYxsrAYIJ2jpX5Vf8FQf+Cpfjo+CLT4a+HbPR9A1bW/M165jtrqTWb+yijD/ZTJEUEYbLGVc5GYlO0hhiMPhK1XEKDWu51VGuTmex83+N9QvbWKWe6v1YS7mlZkVEy+edwHqQBgCvizWNUudR8S3CW06ThZBumOSiAqoweM9uOudw+tfm74q/a4+MlxeG5uPEMOojBiaK+hY206hmO1oUKqDkliVAPQZIAruvhx+1zY2dxG3jbQ7uadW3NeaMyvBOGVcERM27cDvJByMKD7V6uJnKM2qm/kcVFQa5j9WPCenxulssitJlFyqEh2IXkDpgn/PrX7yf8E0PhXpES678TdQW2VVjNloZvZE8+CUARTSpu6HZlMqQfmPJya/l88O/tXeHNShgPhjRdWvrieELZwTwpbRmQnbtbfh+vA2jnj1r9OfDHxI8bWfw80rSrrxDrmkXTWe+/h07U57eAvKTKVCA7fk8wKHUbjsHpXPJVZU+SOiZC0lzM/px8WalGVnIlWSJWZU2N5qnnjp9O3rWX4DmkbUdyqrBmH3lIzk+nbiv5rvhz+1L8W/hbqs7x+ItT8X6JHI6nw/4jvnvEZS3HlzuS6kYGOcYB65r9Y/2ff8AgoH8JvEFpYWnjiWXwT4gMS/aYrqOW4sJXAXPlzqhBHP8W0jB4IGTwypyi7WOiMYtabn7JGC8ubWNUn8tMDKoQM+2a8l+O3i1vh38LPGPijzxb3OnaX9m09mDSAXN4RbW+MdfnkX2Gc15tbftr/s6WUK+d45jv5QSsNnpVnLeT3BXqFyqqSACfvY4PNfib/wVl/4KeWOp+EPD/wANPhDaXtgt5cPqOta1rFtEt+jIWFskUSO6IRtaYMW3cp8oOdsUMPWrVPZ043f4fed0pxpLXc8E+LviBlmmub2S3hu52IeKSUb3kLHzCq7snmQ+/rzXxvqd/wCbPIyzQzBv3rGOXAjTqDj068+lfi/8Uvid4t8U65eahq3iPWdYuWutsct9fyyyRqVQt5YZyAOeoHJFeh/sv2fjj4kfGTwz4WXxN4nu/DdrDJfeLY7nUp5rCPToF3eTI27btkYIiqwI3BO1ejiKVWnGKk1p/kRTjGVz9irfxLd6N4YtoNOu7aLVblfssErsfLh3F8zOT1IGeccEZ7Yr9M/hR+1R8Hv2e/gR4G0XWNVsdS+KniDTZdQTT2kij8TEz3EpIFy3+ojbcyjDCXaq5TkMPx2+LniC38O+FPEmoaC9pYjRNFnuI1ntUt4oYLdJGmlWPAHG2bacYJUe9fiH4a+I/i74gfFm48S6lrU9yto8moaZp4nkFrCATHEm5gAw/eM27k5/CsMRGc6aSfqeThKb9q1FaI/q68fftNeNPGaGTUvGNnoVg6tmz0vVPIManBxPdM/mzOAMGRiMncdozivijx/8dvhp4ViuYJ9fk1G+urlmuhpiPqVy8hyzF2bBJBJJbJXrznNfmNeXl5eQSgm7YXQYSh76Z1TcBnaN2FJ7kAdKw9cgWO2gjZiZYYjs8wljtJz+pyPw5rgo0XC8W/1Ppp1oU6iUH959UeKf2p9At7CWLQdGvNWl2kG41ACxRDkH7oB3DGefYda+S/FH7TEkj3b6n4atVt1jdnmgvSJoV2gn5PLAJyDj61gyW5awkkXaGxlgx+8OPb6/lXhPxHis7fQdVu51ViLVkUgszZPyxKAP7zsinpgMeaylSUqnvndDEupdacp0umfE3W7bULDxt8PfHGsaYVvhqVq0N89sYHjcnZIiuOhQnGSOcjNfoN8QPj9P8YPAngjW9UtIJJNMtbmO71OWF4XmeWDypYyrMccwueTz0wQM1+MfwV8T6RF4p07w74pihl0bV7hdNiN5ElzZ28hLAK0ZUqAcgljxkY5JFfrV4S8It4c8JL4aLW13YyzvNESvlqsb/OEwOMAk+3PSrrYelJ87XvI89WUv3f4n6J+HfDa+KfCvg7Ub9k/tq08JJa3twkaxCcSxI5PBxtyF4wCCDwK+A/iN+yNN4w1rWNU0G+Ojavcr5ir5X2qwvZhvUNIh5GRjcy8nHatzQ/iR47+G/iHSriC8vzoUdqlhNpMV8slk9svDboiSu5VPBIJBA6Gvtj4aa3F8TNEk8VeH4ZlaGdLaVJIhCZMkM316sMcdPfFfPV4SdSUWtEe/hcS6Wsd/+CfhPqmk+Mfhn4pvfC3i/TJtL1mxmMiLKjC2vY8nbNbSHG5Djjrgda9q8JeNjI0MBkA+Xc8jtjOAcBT15r6x/bA0ax8S3lppGsaPJ/aGjW4lt76FUivLWVyr7fOGSEYYyvGcnI4GPz3hQaXcS20TOJIGChiux5MfxYHvkfhXkY7CuEFVS0f+R9Tl2ZVMTUlTurq3TzPs3RtZW7RWibd/CWDYFdINSRt0bICxHUnI9SOnevm3wr4mEKxwzO7tvBUbiw5//V19K9dg1ETKjJIOBnOMhq8OULRuj6OlVtouhp3EkjwmSRViOcABgMkdcAc45rkr+8Cl3eTJQcL165x39q6We6KQ7mAdGAB4zt65wPy6+leda3OZnLrG4VRzxgDp/n8q3j7ySOKVeDheW3oYWp6x8oVZCilthZuMjB5HP061xN/rbwqzC4OFO0l2wDx2yR1PFd/4P8B658TdeTw9pd5o+nSNhpLrU7sxvCgI3TLGOXCgZ4xk45Hb6z0/9mr4aeDrzTr55p9e160dbiW81edZbQOu7mO3XbEvzE9s/KOeor1MHlsqtva/meHjc3oU5csLv5f8E+E9H8NfEDxmYf8AhG/DGs6xbXRWSKeGIW1mBwrfPIwPBGCMV9ifDv8AY08TSx2/iDxzpWr6jK0AltPDlgpNix4YC5m4V2wpUIzBQc5zxX2HoXxI8NeF4kuL3RLNNK0oCS9vmle5uZ/JViz7ApJKjcdg+gFeyap+1T8Lrfw1r91p13qR1DSdLk1FbGHTmt94jQlSJXCxqCSozk4BPB6j6HD4elSgqcVotPPU8atmFbESutEfGmv+LB4D0G80HQtG0nTfEUCG0j0pYI47TTshUaWUoNryhkZcAkHywc18teI7zxNc6Xf3dlLLqnif7NM1pdyIs86XEjBd8OQVXCs+OwpfFPx08O32r614h168t9S1bU7x57iy0xvt5VlyqxIVyMAkjnoQa+dbz4keINU1PzrKS7sLFhn+zHuWwo37iWkQ4PC4Cjgc9etdroKEUnsjyazqud4b36n178J/gvcWATxL40luNT1u6AdLi/YTtbjALLG5xgHpnHOOgzXrHxQ8QR+FvCOt6qF2i00uRowBhUwpUYHbGVr5f8M/tMT+HrO0s/FUMl9YQYilu7ZQ15bgKQTtC/PjA6kE14l+0n+154Y1jwRqOgeGk1OfUNVQ2sc32N4IIUBQur5jwcggAcfezu+XBumoXemonUVnDqfOIkkgvBOjz21+JPtRvI7iXzQ7FiGLbvmOc/p9K+k/hb+1b8ffhbMjeCPjL4u0dImEiWV1q5u9M3ISARbSlo8YJGCCMA8V+cV5421W7YHMjbl24GN3OeA2Mjjj+tZ7a1eTybnTbtyykE+vauqNJNe6c3M4aVduh/UZ8F/+C1Pxg8OwWdj8WPCeleN4IdjT+KPD9x/wj1/OP+WiyW6/unI42hUQcHIOeP0H+I37ef7PH7TXwM8R+G9P1zT9D8V31kl3Do2vrBoWpXTZjlWEOX2OWKYyGzzzjBx/EFY+ItZtiktpqeoRhGKyWpu5EikwFO4Y78n06V6f4K+LPi3R7yZLrUhfadMu57PU1M4Rl2BSkh5/hHB45J60lTjFX6mdRuommrJn9DFhqd14fsTMbiTVtKRvtMMUmHvo0CjzFLHCsFCkrsY7scZrpdH8S+HvF9vdRwu8Vzbr5d1aXcZt5Y1ccEbuGU4ccHseK+Bf2bvjPbeP7a8tb/UL3To/D9tFDcaVdr9u0qSGQSENDOSzxldjNsAC5YcHkL9cS6dCTBe2Jhae+t2gsNRs5S1pMI958uQrnjd8u7BILAH0q1BVLTkctSEqTVN7I7jU4rjT5tNk0pw/k30IuFlugEWHcochSPm2jBwOcZx05K5S2u5p0NpIGF4FVmhKliELIu8Hpt3IwoqKlOHNZG6qr7T1+Z9zRTNLptoGjFtE8SkiVvLYc4PGM9c9q7vSpItLsZEt7olXIkZoz5fmEjHbr0A5rjooH1V43mVClvgRx5BY44IA7gg4x6U/Ub4WUPlAYVEYnjaEx6D/AA9K+ipuUYuUep8h7Nzdo9C3e6xb6XaXut3si21hpsMmpX85Td5UUas0jcewNfzYftJ/GDV/HnxN8deJRerdLc+I7iPTleX7VDaWMLmOCOPGRkRxrjBxnjNfrz+1p8YZfDfwZ8W6ZpcaSXHiCzbwwzH5mjS9V4mZQOwU53HoT7iv52da1cxXE8Rd2mYjcdnygEuuQfXINd1CSoxaqbnJCjKau/UytZ1RppWbIOXOSuCCeeg6Dqa2/C9m88gllYhc7gMnLc56/ifyrmjZpcSIyMRDKcknlx3OeuT/AI16T4ds4lnjt2XCSKQNuSV9+D6ivIg1UquXQ+jqVKdOPv8AXyPtn9lDwo/if4jeGo7lSdH02YarJsjGxvszGQByRyoIjyB13Y4yK/bnxJNbyxx+RsWOC28sRwoY1kAxgnnr/QV+dv7DHg+3hsdU8SW6Qma0jOjWhPykrvUzEKRxlgQTjkgc19yaxMywtCiMXUMGZeFOcZGfwIrtxVSNRpR6HlUW5HEyXMbzlWIjDSYOSByT79//AK9ek+ENEW5uEmOx0hcMGJ3Ek5wMenTOfQV5NM0cLrKUJKtvwoyx+le3+F5hYpDcDeMqHVS2N3cZ7fhzXL7Ny96W51SlyycbnvdnqVrpOkz318q28OnWU2oTyLHtKRxwvJJj6heSME561/PD+0V8Wrz4n+OvEPiZ7qJba5uXg0yxt/ng0+2hAhtxlQFLmONSzNuYknkDiv17/aQ+I8mg/Bvx1PZ3T22rXulrYacsc4tPMMl1bRyq0pUqgMczDJ554HUj+dbWb64s0+yghShbzChDZPHOcH14zXoYFRjGVSW+w582ja0Ob1m68ySQtICXkwH2lcjoOPoP0r9U/wBhPw7pvhL4dal42eOa98QeMr9rQSwKDBaW9qzxQ2+MDazuNzM7AMJI/u4Jb8ir2cyu7tvG593TOSe57dPXNdxoHxJ8f+GdDvvDfhbxbr/h/RdW3f2lY6RqcthFeB0EbhjGQwDhRuAI3YFefiJzrJqmzup04TVraH27+2H+0PodvpPiXwJoFza6z4t1qA6Zqt3pl+sen+F9PG15YvMXcstxKDIjKuQN8oLZQCvzq+CcU1z4xuERnjiGmSTeUADu2yoACcbsDjofSuA1+5ksttvChEZycKpYc5PB6/X1967/AOBV8q+LLgSIyyJppeJ1iJLAyxhgwAz1C9q55xq0Y8jW5xKUGlHax90IkuI4iCx+6zA45BHT17/lVDXyu5GCgnyREyMSxUgk7s54zuPHSuj0yeSbYDCFTJdm2kSDrz9fakudKivi6pIzvHgq0+UCng9BzgEY+ledUiou67nu005txlt0PM7iLytOlZyiEqxBDEs3HyjGO5wOB/FXzJ8ZZ/I8N3vm7l8+aKCMKwLsfNQ4GDngAnnHSvtabQILiIrcoQ0a4TaxIX+79cYFfHH7R1iNP0vTAYh5dzfSYceqq5GPUfKc/Wk3GUnKWw2qfK4u94nw8JxHcNKGICSGSMgZJOeCD6jg8c1+t/7GPxg1D4l6U3w2155tS8Z2svn+GGu7pDf67G5YC3VyQzsjbQgYkkOBk7QK/JV4EjQFhhWA4PTHOcj8q3vBnjPxN8PvFWk+MfCmovpPiLRLuO/0nUbeUxyQPFKsi9DyMp+GcjkA1m3a7ielTnTl7q2R+6njPT9XtbjV9L8V2tzpfiGxRre102QZADACKTjKlTvySvXb16V90fsKar4d8NeBPGum65qdnJPp+pR6hb2kiAtJby2sbb1ycZEkUytjnI5C5Gfzp1r9tHwL8ZfgxpvjDxDaTaB8atJs10bVdIi0+S607xPcTLDFDdwXCIyqSXjkZHMYXDYJBUD5Z8J/H7xJ8IdXfUdFgTUX1IvLqlvdXDQpfJI0jmJnzz8zFvmyBgYAzxytcyu3qXFzvaHU/Yn4jx2HjrxBrutPbJFFf37TW8e0gRxIFiiBXJGSsYcgEgFyM18efFX4KjV4JL/SSIdWtS0kTKgQSKACEOOCuQ4wwP3z0IrtPg3+0foPxOex0y90u58N69qcKvFZO5u7G6dhuVI5x1LAEgEDt1zge/3ccc8qxMB8ynDZ2kEY4/X9K7VTUoXtucKcsPUU5qz6fI/IzTbm6ttVOnzBYb2CUw3Fu7AFSMgjPBx/jXteh6jvYoZCBGPmQj7pra/bA+A95q3he58ceCp1sPEeiIbuRFGyTVogYW8k7QMnKnbnI5AOM5H47Wnxq+KejSfZ4vE6Mscn723ltklQYIAAbbu6Dt6Dn1+XxeTVatdzpSV30b2/zPo8LxHhuR0qibkt7LT8z9m7jXEEWWlUqvyj59mOOP1wM+4rwD4nfGVdBifT7FreS6kjKF4pFnEC/KMuuQxJyMbSOlfEekfGb4h6yVF5rh2B13Rx20USNyRnO0n359KztY1e71G7aWWXzXf5pNygZJ5OTgZ7Hqa1wOSV6VVutZxW2prjc9hKl7PDX17rp953Wp/FDxff32n6rp+s3ujX2mOz2d7pVy1vfRsdwJ35JAIPQH8TXoXgf9rL4z/Di9vr/TvFP/CRT6mq/abPxlaJ4j09GRzIrRRTbgrksQzD7wwDnAx8z3EzxeWYUcNgbxjKVXaSVlZ2IOzqxwrDoMgY/GvoFSpU42S3Pmp4jm0Z9ieI/wBun9pvxWo0+bxnpGlaeyNHLFp3gjRrONAygElhaBjgbsZOPnPXjHIXnxB8XeJLR4dV8QXl+k4VpAJ2t0lZc/M0aBV6+2OOlfMVndtJOu4ttZwCCSxJ/r/9avoHwRpxv3hnuRtEZUqiAKCoO7a2APpn0oUYxVpFe2XPJS3R6D4Y8NTpYPcAkunyIFdESEkqCW3YzgOGOCTXpl5/Z2nWvmQlGVIhJLKeWJA+Yljzj26DtVCxhtY7ZbeCNo06MOfvYALdT/dH4CvOvEMlx9qa2WQsn8D5wAMDg1SUG+Zi9vSq6xu2UfGevLqsawWc8gBU+aiKQT6ZIwcH0zXzT4pW7e5EMzv5aru2tyr9R0/CvrLwv4MbUEEj87nCncxVcnjORzzj6dK8d+M/htPDWv2tvGy+Xc2IcL5gfJDMxx7/AD/lipdreZS5HJzm9Txi2jFvEdzbsjcwK59f845q0GGwHjOMZbgdRQF3RL8imNCMjPJ5PUDpyBUMU5EwWRBIhwDkY2jjGOnSocU1dbnZLEKMn+GnUmgTIRw/PXA4Q55JNbZiOxEjP31yRjdjtwc5FY1qiyOzsjAtypGQq8Y5H/6q0EczSBYufLByQSCO/rXcloovoeFKcZr95uux9y/svyR2Vn4oe4cwwt9khM2/ac7Zs9ecHHHuxr688LfEZfCl99iC3BsdQRZ2tow0lvayDMZkVMhQzhVDHqdi+lfDv7Oria28V24mb9zBaTPEzFpFYmdUGOykAkEcHPevp61hLSw3HysUICO6nC4Oeh68+1ZSu+W+5NRydNSe59raX45txbG6hhjvIXwzyCL9/Fu5O3K56jpn8aK5fwXY2Or6R5E8GGMeWKfIMkBd2RyOOmO4HvRWtmna9jNOMveluf/Z",
#         "/9j/4AAQSkZJRgABAQEAyADIAAD/2wBDAAEBAQEBAQEBAQEBAQEBAQIBAQEBAQIBAQECAgICAgICAgIDAwQDAwMDAwICAwQDAwQEBAQEAgMFBQQEBQQEBAT/2wBDAQEBAQEBAQIBAQIEAwIDBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAT/wAARCAHgAWgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwDw23jRd+84YcgAjk+4q5EmXBB5YjbnjOOv9KoliAD94Oc5xyM59vpWlDLGrZm27hnackjB65pO19DKVKnKXqWNitGwKKGkXBYk+ufX3/Sr1qmNqow2jkgnG3nNVhtmi3ggqR1IGKfG6luOAOMsNv8ASuum5crT7HmTwnL70Vr6/wDANNJm3YDdDycjnj/69dTYFXKkHO0FSSe/HQVy0IQhj0brx2rY0258ssOCS2Mdx9aunXgopSOecZS9+Wx0d0NmApUfNuyxxkj+XerFluSTzGO7I55Awc/n/OqYukkYySABhnoMZGRxViI75AQwVBwQWGep7Y/ziqp1uVabGqpOWtM6iO7IBVWUK5CsH4z3yK2LKRyTwNuOPb/GuUiCxIvy7sHOerfpWtBI2cK5Ug5GD0J9PrW/tU3ddTjkpSk39511tOsYbe4245OckVZOo7TtAzzjJ4zXKxy9QeSeSM9eetagdVaIFCwZQwxyv06fStFd6GCVOTa6nV2t0zL1VgWJGRhl5zmtQOxKnJ99ozmuWhuV3LtTaAcFVHLVorfZJUoQAvTGQOnFO8ufQ2aUrwlujoIX2fMrZ4zkHFXhd/vG5yMY5PDZPX/PrXLpcbsBiQpztBGB71caeLaiLuZgCdwGB7Zrb27Sstwily8j2OyS6jwAxA2klSeCM8j+la0F3Gse1iCCMnnG305rz5Z5HPz7sDtgc8n/AOtWt9sdEQKOgzu/Gs41U4naoKLXMjo2uowCEYk9TkYBNSG4LsilhuVCxx2GR1rmorh2cOTznON3tii5vfKcDcTuG0nG4dOgNP283HlRFnF37m3cSooVjjDjCq3ykjFVZXWNg5ZQeuFPIGMCubkuWkO8EccDseOBio3nkkAZyRgZOOp59KmU3HSe5zxpt6NGtNeE7dgBHBBYYP8Anp+VZVxcZ3OSuV5PPIHU8f561jtesuMht4Py4HDf4d6fk3CH7gGCWDHr9P0q/ap+6cThFy5ZFyWVDhyw5PHoPrUb3iBHByWK7cAYB+n86y7hgpf7pA6Z4HHv9cVRMrDD7sHbwTyPwFcUk1HmezPfo4eFRu/YsTzkxuFJUk5yoBC/59KyZZGbIZiw6DOATStcMPlIDL9zBPvj+tV5I3dgiDG8fKMgE9K5ZTklY2UKsIqCtZGVcTiNlHLEtwOoOewqncmQLvRCGOcB1I/z/wDrq9PH9kmVJ1IdMdSG6qCDkexqjeXnmAxxJgsNoYnbgnJ9PatnUsrPdHNZSXLLddjGe5cFV3D3KtgZ9iRVOabewDNnK/LnqvP0pLpJoNsjpgNz7c9P5VSAEznOQ235cn5RUe1k7m8oczi5EzzquCuWG7LE9BimiTKu6gKOuGz157dcc1WctCdpBdV4YKMnt09aaZnKhlwpIwckj8PXtXmVbytGnujtlFqVx91KdsSoABuG4qAfTPH596oTxO0rFTjcg5x0/Efh1q6xKqWCqcckMcZPpVWe5WR3EaMjbcKwG4H1/lWFaK5byer/AK+R0+yqTk5JambJcNxGpUrjaDnBOev8+nSleVlBjGAWBGQvJFNKsCTsBYHPXHTNMkwrq5AyO3DVCp07Wn0HefIoszlWNzkqxYAfNwQ3Bx+HWs5yC0h25YnnB2nnHQZrQnAYiSIdThl6Z96hmjQDzFXYytzjIBz7UOm2+ZbeZ53s7Wmt2TWiRomH4VjkksBjH/66qYXzCIiTg9SOTV+ZlKBhjLKA2cGq6K8asScI68H2GRj9ax5IpuXc7nFrXqMj35kU/MrfecgAr+vvUkMat5iFztGcg8Ecnof604RRgR7GDFiAS3I4B5/z60+NVMrAA8feHZ+AT7//AKqhQhHWO7E5PRS2FVmfEKLtRD95lwTz2/Sip9mwFtp+Y5B+lFJU42tb70VKavqeZeZIFChiM/fJyRnuP5d+1PVmJ3SNhcBTt6j15+lRbRI5bYXVDgqBjdjqCasJufEYjQfwnDc8Z/Ltx7V7rknFLqcdnb3ehqRzhY1jjeTyyuSN3QnrgVchZdy7m2gcglsbTWYigAKRhgcYHPP1q0kBkzztyOpbGc+lJN2Lp1XNe98R11pOgGASAOMk4PvWjaMqSMQRtyDyePw/OuVskGDG2FyCOSCMe1bkG7csZIaMOSdrlSR1xkc9cd6Ss9S6qlFJSWpZcEkOsj7G5wOM55FX4H5+8cdQAefT9azUTO3AC8/KM4Xn0H4Vo28YViCwywBP8XrXWnFN9j5+MXN+0kdHCTIAI3O9RknqMdxjHvWhbozSbzIx2jG0DjPPXvWFA5j+bGNrZBOc9a0LeeXe0kaBgOGHIXjFaQtHWOxrKE5yd9zsBubC7zuIAbBz6df89q24gHRPnDbflHPTFc1FOGC5TlW5zz2rpIHQIhyoOAMdM4HFSk7uS2OlQje72NaOwYqsiyZYnJycDH+f51dRMtxyeMkfeas9JyNoU4GOS4yFyARz/SrfnLGQQdxxliO3oBVKSbsjZuktIdSTCgDKglByQOn0pwGGDKFK9VyCG9azftBUkoSwfnaclQc9OKaLqRc4woJzzwe/H610JTiuZHlyfKuWRtpcOWAIG0ep5qR7khgSSQF6dq58zGUdspgcnr7/AP1/ehnZgCxBA4zjcBQ1KTTYe78KOmFyQNytwcZ759R1qN7sTZG4KVz3xiueaRdxGeOgGMHvT1n8ollJBIzgZArOUm9jt5Wo6G89zEgK+YST1JBznrThKzLvaXapGFVcc1zH2hS7MwGSTng9+vWplvVUkPucBQFHJU9+f0qW7u7LhG/vRNCXzWkALAgdMnOeM8fp+VNLTYZEYqoX5/myM9eD2qjLc7o1TBGeSEbgZ9arR3Eu5wCB/wACznqOfzpptbHRTlUdlLYiu7mRcqO/AZun+eBVBriRsgucAYIHANOnuS7PvQE7iT3K1lC7ijcxkgSEjapGC+TjAzxnqcZFTJJrU3SlzO+w2eSQ/dY5z3Jzx9aIdSZZlDyMpI5yRnuazLnUYI2I+crjHyDjofT/ADxWVNe+XJ5qsjkghegPr7UpOXxI5JRV1bc6Od7m9aWRZFZYiwYyMRJhAB1APOAPrjFZJdvMwGJC85K8rjoR+fpXH3ni8WG4tLsc58yFZHXcCT6delVT4tsjKrQvnzIxMWR1MQyeQe4Ixkgj+IVyXdV3+0bcjWrOw1i4MsMMYYMEUAAKq4JJJyQM9wOTj5Rx1qnAfLBKgFiuMDovX0rFGtx3A80MmOgIJIx61p2kys4y+RjLc4Y9eufTOfw5rSV0mcLmuVd0V5jukYOo+bkYDf1rTs9OSVGdnVGPQAcfj61m3EqsrFGVyxILKCx4rRtbn92sSBmYnoMDA+tZy53H8yZOUnzMxbqArctG28rngqCEI5w2emOMfjUMiLHhtuT6r2HvV/V7po8BSWZgC/GCvQ1zz3kpGNxwQScYAyK8qdOF7QZ6EJyhFS7mkUdgMFiTzhRk/lVKS3l3g5wCckEYIINWVuxEC5O4/dwRkqetMSdXyS/Kk8DPGK5qSiuZS3PWhOTk0xpikXJH1JJI3VHJbOxGSOTkrxx+P41ZaaNsDc3XBUjPrTvP29Nrbu+ATxzUTjUktDaopJafMyXsg5UspyvKsMkD/OcULBKchQRnCgN6kgD6ckCtFLpkQ4VSxzkkA7R7cU6GbLM4AVs5C9M805c9NJy6nBGUZ/CZEVgzJnByeV5xmmfY5In5KjP4Adq6RCXwq9Twozkd6q3dsC4YKSU+8c4yM8jtRJWfNczXNFsrSAIoDcvjggZzj8qKvCAFcNGhLfNz7f8A6/1orm5b7J2OtVIyV3+R5HMvllCgIRhkjIDE8f5H0qWEkOzIdzgcB+c+veqeXdv3eCyjduySDx6VowMPvFcSsuCSPSvdhP3nUo79b9jCM+aOmxKFUKJT87EZKdQM8nH+e1WQ4ZVAHyqMejDn0qtGwyRtGAAM5x6/4VaUhdj8Aqc4Lbc5rVVIxl7RdTz5c+0TThiYNyOhOGBymeOorRs1ZJixYYPQcgEnpxWVBdyISAoO442jkD6H8K11k3lCCVAGRxyOhqG3ud0oxn7sjpI4WKJKc4+U5YBg3IJGD2I4/GriRAuCrDgYUk8D/wDVWPDcOm0MzSIRkgKSBkduPetGKUFiVUqRyMjaPrQtWOMElyLYtP5oIBHzNz8pDBs/StGBzlUJ284K8AZ6flWOWlDK2SScdOTWrFtbYQrFj8xzzjnoPX8K60oxvY5KkE7U49NzdiEigGTauG6buowf/rVr27S7snOCMqvQ9Oc1g2Uoc7XVhg5Xcx4Iya2I7j94NijGMcnp61dNx5FydS3GnGTjK/kWY3Yv1AX/AGeCT7/57VbUNknPBxwBnPX/AD+VZyNwGx958kAAe5+lWN+GBUEKRyRg4rujG0mfPznaKUtkWklZHC5O0tg85A79AaWQu7A5I3AkqpxuwQR2qMhiVYEbc4IPUdecY/r3pVKpliOnQA7Ace/H+FWYuSerLygqCpfKsOCThgcnNKZgM7WJCj7vBB/HrVZrgMvyjG0A/M3P+elUt+A3J6ZJxyMnj+eKhySVonoXiSSSM7Lgkc9ckA8Ec889f0pgkkV8MU2jBGR07etVTPskJKblUfdKA7cnG4H9PxqjJcN5hYfKNvduPwH5U4qaXN3Od3T0NlpNwOWAx8wYHBP+eaVjtBO5CpXPzcjt/wDXrM85xtzuVsjOTjbwfbNSPOAFJICsOMnHHH+NVZbjiue7e5Isu5ThgTnkq2e//wBes6WYpLlpQBnIAYkj9PpVG4voYwwicqeSeikDuRz/AJzXM3/iPT7Jlaebgv8AO7e55wf89aGlJ3kcSUU0nuegC4iaMncCx5bJ5Fc7cyxLOXZRIzdE27mU54x789feuGl8d2CiU2xeXyiUCt+7LdOQc9K8p8TfEm4bG2YwypITttkCsByRubqfxqUozV2en1ue06p4jsYLaa38yMT7WRssoMecgkZ68Hjj39q8i1zxotjcRzC9CKG3KPMyGIPfvjp+deC6l4v1i9lkeR2BldjuwcKCRgcf5zXn3iDVruK3c+YZGPzZdmkOc8evGT61w1uV/EdtP21T3o2sejeJ/ixqty9wix2MSs/kkrF5sqKCTlT6nJzx3rm9K8eW9rCIj5oikz5qIThWYkk8nv1r56m1mciVpGVzJIVKoWDDpuDcAHnoR+tQRX0gDEHAPOR94dun41lJclpQejLjdppn1vp3xXSzdLUX6pDKcFJ/vxjn5gT/AE4r3rw143j1PT4ruG8a5gkBQXIPzOM8j3r81HuIllR3kZwWOzjAH4k+wr1Hw18QrvR4BYxYki3ACMn5IgTliAPzrlqzcLOJ1U+SK16H6P6dco6RSROrrMu/P3yM5P4Vu2sgLOZCqInAI+VgO/NfKfhX4hrLYAwBzIm1RAWx5jkdvTnr/wDqr2CPxfjTYVuSsN88QeSGKXeIiRnaW79hx1x0pOneTkzaMvdTkbGr3qkswZ2Uv800kgRIuuSxYg9gOATkiuD1fWmtoPLju4yC25vLcMScjABHODxn6CvH/GfxBSzuRG9xJMssgjjggLSJEQMlmP3R+ByeODXkV78Q5xOVK7kkPUSEBF7D9arnldyPK95O8dmfVC+Ib4S77e4VVzhomAdR78jrXU2PiBZNgnZQx6kDkevA618lwePtPhtyJ5mFyQXXAaRF54BYV02l+PtMeztrsX1vLHKwQOJhIFJbZ68gHrjNeNK9+bofSRj/AD7n1bFcRTbGjdmBXAOSQT34PT/61TkOjfMxUEZAIIPPf/69eX+GPFFrOVjkvIG+cAQmUbyTzwK9USdrmNCArMpKjao3rySOg9CPy6Uk1ZyXU5mrJKRcjRyuSdwPzA/mcYqRl6Mg25HOVx79B06mmqHGDuPyk8Nls+3T/OKcoLsodDtA3bgPX/JrONtbHU42d49STe8KoVOSxDDGQz/WrFvOs28OXAWXy23IVI+VWyOmR8w5HHUZqtJJHAjq6EoR8ueSTzge2f60+2DBAwAIPPJyRmqjJwXvdTJKMJy8y8skS4DkgEDDYyR7E0VWKJJjPfkqBk89cDP+c0VcZSStHYySlbQ8csolkJwmMDcCTjPTt9anEZDtmPkHPLAdfb/PSqdsxj3BCdxJxkjDc9OfwqyJHAYtgux5xtBH4ivak53XKeZCUW+aXxPfsWRE2CVGQPmwhCeg7kD0pgjfOWJAYcBuSKSKVkKv3xyP6cU9pFkbLEgDgdNvX/69aSU4y5qe737GNm3yrobEEgR8knaOCQePpW5bkTMjhwkKlg6Fc7wQcc4yMHn8KxEQAltqyDrheF6djitKKdmUqBImw/P0BAwCCpGc9a5JQxEY3Vj2HFKpKmuhZWaJFTaxPYZyd3H0rWt2U7SSvHIAJJPP0rAikhdUVY3AxgllAb3yPzrTj25XDA4HQHA9/wAsV3U3zK9RadD5uSSVzrIANykjcd2cCtBGyec4U9OpHX/6/NY6S/KCV6HnGea1YmDZGcbhn5vboKXvRXMj06Scn7R7MgTegBLBMjOMnNbMMZ35DEkjIBGAO+Kw164k3EKSFAOCvPGDW9bMAqkksDxljyeo5ya76alJ3PDxCi/j26evmdPErOu0PsODx03ZP+fyq4iJEpLMCTkgFh1/ziq9ojsWZVB424LYI71eSIgsSMYHzAH7/uffrTaaVzqbu7sppKx2gkBAxPAyent+HX0prg7mYFvU4PFW4o0JLFWBB5BXIPX25NJPGRgIm4c5wu05/wAKp3cVcizcWpfIzWRmwwxjHXHSkaJOQAhcgI0gUByByBn0BJI9yauCNo1GFUc4wDgH9Ki8sl+MYPdq05pWSkctp8quYMqscEEEKMMec5qv5ZLbiSR1OBjae3TmtC7hKBQBncMnvz+VZF7fR2UEssrBFiQszsCQoHJzgfWtk3ynDG9rF57qOOHEjMwAJDsFWQjBPPT36+leP+KPiXp+muUimErZMaRMm4nGM/KT6Z5rz34jfFMQTvY6O8cm1QZpvO4Ut/cA6jFfJniHxLcX2py6jId8rKEaBXOBt4wB2z6isrdDuTUWz6a1v4qzTPax2xP2aZd7z7ysyndyCOvauP1LxlJcMkl3dh4iP3eW3hSPYd/1rwKbXppPKJjaNMYfGSwznpxUsEjzvtAzuUshlYgKcZ54rOUXT+I6XaSsj2GTxHeXMYjs5BCDkeYSFkPHP+ev5Vz9ws8UW555JnlZpGMr73bnJHXPGcfgK5htTW1AjjfzHzhmAKjOOefTt07VHJqaIpnknZ0Khfs0bLJICSeRkg85HUgcVcWnsFNpLk6ou3M/lwsJTnjYdvJHavKPEurzIZlQt5IQ4BkBIwAe568H8q29Y1+3ngc20dxGkchjLXK+UZNo+8g3H5ckjJAJxXjeuakxLKJZAhBzgEZHfIHrmuOpDm17Hs4enam5d0RvqPmjMTBlU8kg4OOCPwINP+2MpVyd27sCMDp/Wuagl3qWx3OSFIyc+nbrWlEBNtA4wTgkbe/P655rk51e63LhGMbI3LW6FwypIiqBgk7tx7ZwK1EsZZ72KewS4a4WMwtFFIziccbQI+mcjqAPvVBoGgTXjpuTCvKIw4Yg+5A68ZzXrugaDJoSDUZzH+6m+zxxyOpkucqpLnHQDfjnn5DWclOUnOO5i6cFLnd7sboV7qXhjUDa3Fy1xNGySmMtuWEsBlM9MjGOM9K7u+8bXEke5ZVUbT5jYPmDjPTH8s15nNftd393PK3KEErt2vGhOAemcZz1rCvdWhiJAkTY4xwHK554IwSOncY6c+uUeeXvdzROUb9jotX1r7W6SMxYjLdSiMeRyDyfWvE/Emv3g1Dy7a4eGEIFEcQHludxPOQeSAPwx61Lq2vEAxxuPMOcjA2j8SM+tee3epCSO5OWa6yUVwRtz2PqcfTHFc9RqL903jycicDZfxCbOyffON20qIzlmZiMAYA45I5OAKxNM1r+zDG0UjWwErTeWhZYg5JJO3P06j8K43e8sxRx8+d7Bww4OCDyOeuPxrQ/coBJMd5VSMBTg89M03LmfKtzlhBvWR9D+HPi/qWn3lkZfsc0C3StKZAVkKDOdp9e4PvX2v8ADT4yaD4puXsrLUNt/F/rLe7kEchQ4yQCckDofwr8nFvkDIsKSFlUMSwKnPfB59R+ddToWoXVlqEF/E7RXkTMYLiF2jmiyOcEdsZyKmUek+h1Ob1ifu/YSJcpG6yI4fnghgc5PataW3jWMEOgYfeU5GTjPfr/APrr88vgz+0La6WbfQPGeoI8BmFrbanK2WUsflRznjHQE8dM+/37pmpWmqWUd5p8wubKZQ0U0R3hs9zz/nFefLmUtNj0IP3Uupi3hSQoMkq0sZII2pjzEL88dFywHOSBWlbOqAqgLhgAT0Vvw7f/AFqQ2olZQ6sNi/u4iNsQLLnJAPXB6np6VPEiIShOH3bs9cHPOOK0cVN3R53JJxS7E+D5gHSQjICnGByM59j/ACoq+salScHcOFzmit40ouN2dh4NICqghwGzxg9ealt2k3MHy2VzhmLE/wCeKdIYkV1OTtBC8EMOQOn50ka5GOgxu3uOPp+P9K6PZK3J1W/oZStpJEwmySvDDJUdCv1rSgtvNQ9RxxxxznnH4VlIAqMBhQuX4A3N+FaVtclUAXnIwoOQB06j8K6o1IQSUepxttu7IFWWFQpcIN5AB4J9xx0q/CUc7CCr5DbiQAfU+/1rKkd5UVn5O8A98cf/AFv1q4hdlBRwWQYAZACvbGa2dRKb5jyVdK/c3lyCPukY9SelXrYhyRxwehOAKy7aSRFUuvzDkc5A71fQFmVkG5iMHJ2jP1q48tSPMzapCLevQ6uAsgyzKwHA2nfj/wCvWtDIzBQQdxyVBGAR1zjvj/Gsi1TBPmsA2AwVWDY6Y5x71u22xsgnafulgOcciohy213PTqTcEmti5C4cbuOPl46nFW4YmeQjPIGFHYcVQRCo2qCc4yeOOxPJx71pQP13AgBdpJI5/wAa9Ki5ci5jxa1Xn22Ojsg4barnJJ4H3m74Hb863hbqRzzg5y3Y1zVrIgZHUfdP3SOOODXSxOsu05JBXqODWtON07mcXuupmAYKkYyvfrmh9u5huXnnHarXkEjeiltpwQvJ/wA81F9mcNgoxJGeRgHv1qlo7HlK/UNqMpVeHYY+YAHPtUTR8HgKQeRnFXkt9hzgnnOBjiopJUkjLgkRsSQzIYioUlTwQDgFTzQ6btqjvak15HMajPDbxPIXA2rvBZsIo9z/AJ6V8cfGT4oX5/4lemPOlnEc3V3YRkzXPOPLBHJHPPHaux+LfxTITVdB8LXsL3EINlLfY3iCQghwoPDFRx6BvXpXyBdS3BgEbStNscGRpZAX5I3HJ69z+FV7KbV1sc7cYqzOV1PUjPKZFmZmY7ywznJJ4JNc1K7yT/aG2F4xtDsQ2Bnpg1ZvtkMzlFOHbEmBlRk5/wAPyrMmll24AAU8nJChiOh6c9qpRcVc5Kbp6rsb0eo2yoFMW6Xd9/8AgXknpuHv245obU5IF8yRkVQp8tU+Zn4ztIHPb6VyZleNyxVV3MACzbdvf6DP+NY+oagyTqqOjuAedwfbwpx6Z5rklaya2PoNLXO0u9dh3qwYxxMgy7tkgnrkf061VXVxCuINjx4+SSRdpfjJxk8Y5x64rze4vEcbm5IbAZwVGee/4HmqQ1pUJBVuBwwA29Pz6+lXypO6OeEVGGmx0etawbg8OEVBtZVIXHBHX/GuCuZZZpDIJS+75AnUYBx3yP8A9VXpobjUFaSNXZZHyFCkqxPTpz2zXS2fhF3gjnVcOCSVY7WxjJPpjJ+vsa5qsofDI66NGc5XitDiIbOaUjyy2GblcbgMnPTv0rqdM0+bzY5JHYKTgrsZACpAONwGe/PTg4Nd7p3hOfMZMGwM5UuUIRTgnBzxzx2717f4a+HL3Eavc2bSbYt0bOASVUg8LnOOvUdq86vVhQTb6nbClOc1Gxn/AA38PLLd2MkkfmwTHCzMuXzjKADH8TYXP/166/xho0sMmoRwReZp2mhpSsRZ7q6lMEMxjiU5+6CAQMfM3HfHrHhbwVcaILS4it5Y4xOuBGWQoWOxcBR3Ljj3rsdQ0CGW0eV7fzJHcsS/zNkgcn9Bz6V5qx8FK97tnofU6k37y2Pzy8QyS6bPcbYRGZIVicDgttdnCscZIAYcZ9fpXl+r6vNHH86xxbwSoGWYY9ea+4/E/wAO1v3fzVgMZRmVFQiRWbdglgvbIPXtXy/4x+Hl5becm5WWIllIV/u7Thfu9cg/55rpji+ZmMqM1H3lotj5p1HWUDLIWy4YKCoPzEnAx37nnpWBcXjlyyspHlgqccZJ/pxXT694avYTPJBCZFXc7eYgQDI57c9+etcWYpUVxMrKRkKMcNj8Kc5U6lpR3MlGSk00Tw6iwZWmcuWPViBgYJ/z9a1mlSVVVJNyso5BJwfmBHPpwOlcYZ2Uq7DYEAUgN6Y7ce35Vqwakqyovy4KEgEgL0yf5GiooxnyxIinzOR0Edo6xiTDAK2d+fmxgdB6g5rbtpjI6IvlZGcs/wAr9COcZ+nNQWupwSwwWzohQny5Gcs3kk91GOvzBqfKi2pEkBLKwyCFJcjIGe3r3pui5LmhsW7WNVdLh+0CdXcP5u87W+T3/wA+5r6z+C3xf1b4ctaabcXUuo6Hd3yyTwTO0j6ejkZMQycbTltvTk8eny3a38duiO27LDd8o+bpn8O3Wt6K8aIJdxMc9QTgY9yPr/OuSSlNX6HXJSajyH7aeHNdsfEukRa1pV1Fd2lxufzBwflJB468Y/KtVy2dhQAN1baARkHpX5ofBT4tXXhW5trKW7uLiwvb7ybjT3cCKFXH+tjLEY5I3c+vFfo/pN9DqtlFNBLG6SrvjdW3/wAjXBycsuaJ3Sp3d1uacOECndyzbVU/KMngZPYe9FQSRmHIyx4/hHX8vpRXpQ0ijzmrOx4a8TFiSu0Z5PGanCgIFO0knnjGOR/npVyK0kRflwxAJO98k1MYGQjzICN3Yqeen+Nb1KnN7reqM2pS22MRIC6qSSCmMMGPY1ZhiCnIOGzkc4zT2j8rKqgI6rzjHb/P1pA77AGOcc571rhpKcpcq2Rwe63yroaNssh2s5BUkjkc/hV1AhJCIinPJ3cn36VlLM0TKqFnOc85wOvSrsUhY7mGOpIwevIPH4VMpte9G1maSTcnY015ZcgOFIBA4A4rSjnJG2PAIXoDgsfrWZEwYcYUDpxg1dtQm7HUnoc8jtWsJXgnIzsk79y/bMWwSjJju4Uvxwc4yD+BrVSRt4ClcdCPSsVP3eCPvZyATjBwc1fi+dwwwBjP3gefQ8Z6AV0UqjdR8ux505KC1Ozty2OcYI+8ecda6GJQ6g5xx0AxXKRSuuAqkjdgA8jj+lbkNzJuCmNFyOkY2r06+ldsJxva5vNSevQ2bGPAWQEHcOh4A/zxXWafpN3csTFhoynmsyEbUUEglgSD24Az/WuNtLmJBl0dWAy5CFhgZJOBzxjtXtPwl0y98U+OfB3g3TZIkvvGfiO28N2Ely3kwJPdsI4mY7ccu0Y+bgbsngGrejuca5r2ZtaD4Lvr6HfFFNkfOyso3MCcB8DOAT2POMHFdBqHw/1HTrYXd3D5dqygxzCWM7iWC42g7gQTzkCv6Gvgt+wH4A8E6XFdfEMTeKtbuIgbvTLa9e20CBjnjMSxyykYXLOQCeAuAK+gP+GU/wBn3IJ+GPh+QAYKXAlvEbpg4kdsEY4Ix1Nc7rU0etChLl5pH8pVn4A1C8Tz4opVhkk2I7xuqscLjGV6HeMHnJHGa+Uf2gvHTfDyS68NaW9vceIokBvlOTLYxuBnIH8RBOB+Nf2J/GT9mz4F+GPh3418aW/hW20IeEfDN54l3acxCYsbaWfYEYkfNsIwB34xX8HnxU8V3+veOfFninV2im1PXdWkmHURQRFmMKKDnhVxgemK9HCJ4ms4w6Hm16fslzWsePXUzXFzNJufzJZDNM0n+skY8sfxNc5qc3kMDI4fJAAHReO4PH5dxW5quqB0VmESso+9wHbPqe9cRqCyXxRmbcoBKnow/D3zXtOEnHVW/I8qdWMpW6+hkXzLK7FXBAPIyADWFeNLIoG5VCEgLyA2fU1climaSaIhl2ZwCR81Yeox+QSrSnzMbvlY4HoPQdf0715GInFvlj0PXpOMXaJxGqXLnMQkw6jLFGPy56dvx/EVyskrh22HcT/GxDcnrnnNaF5dRTSyRsrsxYpuC7t/pk/Tv/8AWpsOkvIzbYWBbuQcAY9DxUuouW8tzzqNKdeXLFGSyXs7BcuctwR8wHOehrpNM8OXN0xZwGCDex2g4wOSee3FdNpegNI8cItZZmYgYjTIQE4yeP5+lfQvg/4Y3d1NBCYPLWZQXBRQSq5JHTryfzryMVmFHDqyabPoMLlFWs1FrY8w8P8Ag2e52GJflZ9oKrtKnnt1xz+te/8Ahz4YSXEaKSd7HgCISEdOMY7f1r6D8EfBnYbS5EUiAvlV8gSRSnGBk9ABg578CvsjwN8LLNjbAW8FvJGpMtwsQbLZPGO/QV81Xx0q/vxeh9dQwFOlHla1Pj/w78EmuIIobi2MayBR5rDywAMdV6Z56gd6+lfDfwKtbSztoB9rnKBj50qCRh5hPAJHQZr7U8O/DLTzDCskCsVILyTxK2/njAI+lejv4e0y0SFYolYJht2QPMwcEZHI6dPpXmVsRJqzeh10qUYvVH5/a18PItJtGt7e3iiKzmR5Bu3qWCqdmc8naowMDJPFedSeFpH8yFozjHAxlhkZ5P5dB3r7u8X2NjeXUolSOOIybQFHCgDBI9+Cc579a+bNato7S5kK7eDtDcYYAnGDge3WvJr1kve6HqUMNCfvHzjrHg1YQ4CgMB8vAUHnofrXhnij4dzXrOIYWLHKSFhlcE9OnccZOO9fZWo2sU0aMQGySWA5YAD/AD+Vc1PpsUuV8vB24AYYxnA6/lWNPGVYvmgzqlhION7I/LvxX8LLrT96zWqFZJCI3bezkHPPT3OP85+dvEPw7Z7m4cqE+bEYC4ZyQDz1wMg+nSv2j1PwLa6nDh44nLJgoUV/LyMcccH8R9a8Z1f4NWcslxC1q77wH84KXKjLAZBPB6/nX0GCzu0W5anzuNymM9Y6fI/GnUfDE7iZYUYPEGjIIyDtJ7/n+dee3tpe2cyxzx4C5G7t1OQfToPzr9efEX7P8BkkksYltJbhwfNcAxzMSCS6DPX39RzXyj8RPgrqWkfaJHsbu65GHt7UrAoOf7rD0z07nNddLMadWVov7zlq5ZOlHmi9T4ysdRlspFRy7o5DOCwYcjqOvOMV6NZailzGsYIZnjxG3UgkYHU1yOt+GrmwEsjWrxJHLtLMpjVcnABz0OeMGs7TtUis5dt1E5gPyOYneJlODnJUhhjI5BzzXqxqRnecu3Q8SrSkpefmemvFOkZlR92W+RHXcCQM4HPTntUlve3cj7ZcwhgdoyFCgdgv1yfxqnZahFqEYeK4DB1yVffJJknH3iDnGe5zU01ud0cpkkGw5Cpxnud3f0qI2loL2cUrnothMIShXBAPBUFQCOOOa+t/gf8AG7/hHtQh0PxDcyHTboiGCSQmVYAB94dSOOuOuK+I7PUnW3jxGzBcAAd/TNdbpmohZo5SSrIQVJGH6cY/xpOk2vZrdHUnduR+41tcwanZWt7a3EV1bTxiS3ubdxJBKh6bTn6fnRXx/wDs7/EXydL/AOEev723NjCd1pukImhZ2OV2HkrznI6UVjyxirS3BSjayPXI9vlNy5ZRkYJ5/DFOSaUuCQWAOMNyR2zn86t4UBgIwx6HAGX6c1SmFyjq+8rHtJZI1BTuOSRkevBFbOPtG/Z7LXU82UnFty2Y+VVIDEAHGMjqPpVIIql1Byc5HGAfepo5Cxj81SUBAbqGKnv15x196l2oT8w43ZGBg1tCM5JOPzOBQi3puiIRlYgxG59uF2cgY4qReACTgr1z39SfyomAhyE5JGdo5x7VAA7su/8AiXB5PHIHQkCsVyuo0j0lCMrs1Ymc4wCAy9Rgjp+NaMG5CSW3hmAAGAB17YqgkTKEKH5eCecYz1rVi2qrEjJwAM9T2/pXS6KlpLZbGbaWxajkLtweF6tjOO2Oc/5FaMeRIuxixB6YG0A+/tmsmHChWJB5weA2BWtaTfvCF4T1wMZOK6OZ6LsZ2lza7dDqbYScMMHauSccj/H8a2oWwdzEbtgBHcfX/CsazmMbNgfKRnGQDnIrVtgN0r7Rkkj7vPr1zit6Uot3e5liW3N3NGCUDBBJOPmII4/T6V6B4Qu72x1vSdT0y7kstV0nVbbVNLnikWOSKWCZJAyk9wFzxz1ry8SOdw27cttPOcV0ulSyW80UkY+c7SNx+Ukc4Pse/tXfzW1R50YXa8j+2v4S+L7b4gfDXwR4ysnEkHiPwxZaorBgTult4zIrY4DK+9WX+FlI7V6AWUEgnGOuegr8nv8AgmZ+0doOrfC2P4ReKtXstL8T+ENQkg0KK/uY7eLVrG4Mc6eU5YBpRPPOpTg7QhAJ3be0/wCClv7bugfsmfBTV7XRr21v/i748sp9C8FaFBdL9s04So0c+pzKDuRIAx2Ej5pCowQGxjGjOrW9nBXb2MfaxhBNdD5e/wCCof7deiWvgzxV8A/hb4i0u51DU7abSPHGtQXiONuzEum2jgkF8kCV+g5QZ+fH8gfjGIySNGGMjQzNcS+YOdwyAwbuQNwx/hXe+KPG994guX1O7ubmS+usS3RkuGuXaYtlirdFxx/kV4/rWpOcoxLHHToecYz+tfV4LLlhbQu3PrtbVGeKxiq6SWi8jgrwSvKXkL7VP1U1Qu7ryIzIu4YGXPp/kkVrXOqQfMkkG3K9sHJ5ySPyrjr/AFFJhLAqJ5YPBAwxzzzW2LqRpQUUtfPU5KdO8nJdTM1C8QwNJ5pUyfKhBGSepzx/hXD3U880pzKznsWILfTnrwfwq/cNJPujRR8v3SRkDPX+VbGjeHZr2RXkgchzwV5YnoeCeOwyR9K+axdWUG51P60PUwWGnUShRWph6VoE15iVIlwGDPI0e4545z2x05x9O9eveG/A11eMZGjBCr82ByoPc9vWvRfCngvPlWxt3kRiH2ohB6AYJ9sV9Q+Efh/BpzwTzwNDiIxmIndCynONynv948evvXx2Y5rCS5aW59llWUex1qLseVeAvh3AZRAlmJDcDMk0igrjPAU4znr09K+y/h18LbaK5t7iW33OwW3hWSPzEIJwRntxkZx/Wr/h3w/a5iEEKrsOxSF2qPw96+kPCulyWL2hYRtEoJkDrlh1xj6HFfOr2ldtyd/mfVOHskklqTeFvA97ElzFcafb2dpFOY7Ly2DtPH97cVA+UZOR65Ney+HvCFvA8Usu9dsgcKrEA4HQjuM0+DUrSCJlcvlTj931znnjv0rM1Px9a6ay/NAryv5cFvJKY5blhg4Rc8nrx7V006cnHQ0qSk3d9T2EzR2UKuAqqi8luAMelcXqmsuS32fks2c8DAzn5cHrz6V55P8AEKaWJI5Aqq8QwjuVJ4Gfr0qK3162ndzIyooX5ixHJOT7ZrmrJRbjMwpUXzGd4iFzdxtIrM77udoy2T6f5714jren3E0kzREukZG4kBiCc5JPrwa9q1C/s3Ty1mYbidro+wr6cjB4wMfWvLtUuooJ5onkXkk/P8pJ5715OKTT5juoOUYuKPOxpryfMzEAcAYGe/pWdPaImVPyshWXK7shlYODwexAP4V0321Iy2GygkPyg43DODWBckyTmVQFGSQQeg6j/PNcUYzV35HqUY+57xSWP7OHDMcEZbg55OcY/HpWrY2kNxIf9HjmBbymJypBwDg++Cpx6EVUmmMmSF5BBU9CO2fX/wDUK1dLBV/3e5ckFwfkGe2Py/SssKpqbb20/M1rpWJrzwfpt3EGeFWbIkYFySGCheOoHAHQDpn1rwTxv4IthFcR/ZI57d2LYaPLMcEbenB5PPuK+ubBoZbcrJgt1AK5Y/161574uhRVk+UsnG1SmfU/0FexCs4tpHkW5vdZ+R/xX+ElvLZ3FsLJWEspmWNYlVWb74V8decZJxnFfn94o8Capot7dxm0CRw5klXbiONQBgsRnsB69q/c7xloMGqvMwBjZ9yqwXaynkA8cAYx7g5r46+IPwxNzJcxzwM9uWDRSxy+dLLkHKtn5gARwOQQetelhMbCKVOq9TPG5aqlHnp7o/NjSbkWRQBf3cpLHaR1IHU/l+XSu1WU4XdJnzEJBbhD04/Wn+NfCk2j6jO1tbyRQFzGIlXYm5eCVU9M4/zmuctbgxyIJPlK4yM5Zfwr35So+zjKk9z5iUFRfLNam4A0Kq28qpILhcEHj6VuWd1byyrEJgkzDKLnbu29Tnp71z6XJk4RVLAemCcdSK0bSXyZDIAVfAG4NgDOcj1rpUVFczPLTlKTjPoet+HtW1bSllbT5WabzdsMqtlonUhsd/bIPrRXNaJeJEuVYkSvuddxAL92I45O0DPfj0orNaKxopRsfrqFZgCWGeeCcUjDzF2cDaOQTgc+9T+dbsqgow2L65J4AoZUibcGxuUZBB2gfXp61jeSnzR2ZwKMeS87lUREABsHA4JGaf5BIyNwYcc8DFW2Efys+4jjaAvPOc/yp/mg5IygQZGOc59RVVZ1FJqe5cPZKP7vfqVXiVUaTJ3IdxGMinr5XykBuQR90AmrjRxOpdABg7drEAk9frTI4ljw20E9eDuA4rkipWTkdyUFIiQqUG3cDjAT6YzVyJCSGBb7uCMgFajVAwkIUswBO0Ebz+JIAAGT+FWoyRwmAQMHdwfyr06P7z3H02MH+8qNvqJHAy7JJFIUnjPQDpz+dXoUQhihCMTwTwE469D09MVSQyMBuQEg85G38auxEqS2Oq8KD1/GvSs0nrqeDKDhK0zatiUAErfMT1AwO/tW9aTJuIyOgzu6HHQZ/OuajufMQYAxnkgc/wAq0oZGUgodvIbg45Vg2DjqCRgg9iaqg5KnepaxpXo865kdjCVckAjjJLAZx35q9FMquArFcDAUDjJ56/pXM28k7KpUJgcOWchvbAA+la9p8sse4gAsNzZznB7V2xnF2S2PPlFRSXU9f8OamLTQde864ukmu7IMLpJvLktPK3NGyOMMPXr6V+WfxA+KPiPxh4o1DXda17V/ENzuewsbrW9Rl1EwQIxVTGzsSMjn054AFfWvx8+LFr4N8AXmi6W0ra/rkDadaSIAqwCRQHYc9lLHPTgV+ZUWpsF/eFyFQKpzk8Dv9cV24KVR1m72jG35nPVlPl5I7o6GfVnSU+VLGih8kbQXJ9yTz7cfjWLqN2bpxukdJMhiY225xjr9e/1rIEsV1LmQgSON6p3IAJIAwP7pPPqax729iEwDPsdeFJfgDtx2r6uOMpRi431PCnGu7XS37lnWEYwNMrLnGMMcEDjOPy/SvO7u4bcAG2AHDKPvE5/+vWhqOsTM0iyFDHGACoPXBPzfqPyrn4Jnu7kOETAYABAG6YwOnPrmvHxmJnUgorY9DDUb1FFvT/gnS6VC11LEifMHZUD4LFcnB4A7DJGevt1r6t+H/g57iSC5kjdoJT5cqtHw4x/D/EMZ615D4D8LyXUyThSu9w+XjCqCxx1x7n8q+3vBOlLY2aFTltwZlZgQCQOnOeo69K+AznGqK9nF+8j9SyXLoU/3rO68OeErDTlhmSELMigMCAwxjggetdu0QXGNqDvgcN1qHSrgSIXcKoBIyR1H+TUt/dwxAgAMTz0wCM18ViHKpNyZ9fBU5WUDrtE1AWfltKR5eQSyqFbHXIyR7Gvb9M8VQSGBbeSNSNrHeoKtgg4ZT27EfrXypaahEoaNhtXOQRwvfr+leh6RrKICGY/wgKDv3cHpxWWFlCjKXN1O6slLZH0RNrjxRqWuIw0pzIoYKoxgnaO34Y4rnNQubS4kWaRYJHiO+KSQBnjYcfKTyOp6V56mtz3DeWQfLL4UtwcDpwRWwJPMiGZQePlPQEf/AKq9SNZxjpseZ7KM5tszb3ULmZ8ROI1VgyuAkmFDfdwwI5GR+PFQf23LBG489ySAWx82cZH9e1WkhidNnGC3JFVdQh09ElbGZcbQSpGAOBjnH4kVzV5yb93YypRkk1HY5jUfE10FQLO+x2yCZNpB6gj0x7VzFxrtxdEkszOeT1c9O5xzVu6W2R/mJxn5T1z1rDllhScFAPLPzZJIJ6dQK5ajbd2XhW3G7LS6hOiMHdsE9CMjnH/1qadZEaMuQG9T94Z44HeszUbmOJCcnk5A3nA44ArkZL7Mu5hlgOepPY1wc9pNM9hQcUprqeqWeoCTDF85+YZXIrqYbqOPy3IOBkAAEDjv7dOteCjWh8hQlQpwQ4Ixgf4ZrootekjjCAuVcYfPykY6dvc04Sg5OHY6asHLVHuNn4hiCsGaMKxKxnB3H29c9Kw9d1y3a3nUosxlRlhYk7UJxyec/hXj02tSkDyCysvIbOCP8/1qSLU2kP7/AJJxubJbHua1klBcyOGUJOTZRv4lnZg6j5upHUGvL/EOgNeEog+XO4rja2eMjP0zXqd4wCFk+YKN2Oo96w7kpOCyJwx2MSu0qwAJAB+o596iEpKXMjmdJyhyyPiD4mfD5LrekVqAys7SvIV8xzhlGWxjAHpX56eKNHuPD2szWc8boUJJDkFMbuDnPcDjjrxX7ca94Vj1e3lztJKbTubBUAjIH4D9K+Avjf8ACyW6N5dW9pHi2jZczqIg4XDsyY5PPT2FfQ5bjqfIqVR/eeVmOXSUPbU1qj4thu0R43Dsqk/NhsDoRgfr+ddKzRyxr5e7OMhsFc9Oa4pLCS1fbLGUJJVCylVfGeg9q6i0EqNEC4EfBK8bsj3I6cetfZUlFR5odf67H53OD3W52WmTmPy1aT94W+Xdktnk4OOeM/pRUMMamXcEKsG3CVVyEA5J9T36UVySo4jT2SVvM9NXtqftMYydpXGCowM8t1P9f0qWMBsqzAbVwEYEdv5fSrqR+aB/eXBA7D+tSJbBnwQCQOSvX3x/WvKvKXyOq/NHlW6GW0Pl7SxDFgNu7gdM/wCfpRt5ypUq2SGQcn5scHv6fhV4xhCpRmcYx8y4APpgdgMdaka2OSF2tgZURAhV9sY/lxXS7RV5bs5LuT5Y9NzmzFzxkE+uB7VJEwUsoCllG44Xd2zwehJ/LNbBhyFEkahxyAgyn6knt3qtPAzDEK7SR83J2/h/hShrJ3OAiG3cSpK4GDsYkn1zVtSqnKHLkchu1VYkKuTk7mPIPKjr0qbyzGAIyWyd2MY5x3Na0fbXk6dr21CaXNtoabPmPcGXcoyFPOSB0qsZnOcgnBwQDwMdajjAlT5kIYsSR/C36c/T2q4IYhhi21u6qp6D3xiimly89Q0lyxkkihE7Kpy6cEEKT16+3bFbNncqrEO5JZgowd2C3HT05+grMym8BArKVAJxjaeauRRFHGFG08ljgnPBH869Ck1K8V8J5jhKb5jqbe6bYVXjjqSFJ59sVHe6p5NrOwJBVQQehPXv27VmRsVbcTk7cY3kAc56A479TXDfELWI9G0K8v5pJFWC3aaOONsNKwBCj8yP8a2pVKdN8qOSrRbk09j5B+M3jhvEnju9j8/z7Tw7F/Y0YMgMplysk7Few5RR6+X2zXj9xetC/mo+VdcIOnT0P9K5jUtWa9v9QvLoCG6v7uS7ufLzku7FjnPXr/KsG41OZlKndIEOE3fLjJPOM4H3uceld9Go1qup1TpwWqO2fVtx3CQxOOhVyGHUfn/jWFf6gh3y+azuy7QxbJGOB9AK5aS7YhQAAc8jPI781k3l7v3AqRtGFYPgt3q7u9zptfQknvZBgSXAdnbAywLnnpXpXhHSYrmRWkIDSLkDjng5I/M9K8e0KGTUbuNBFu+bkDlgAO2favsz4a+FEnEJkco8YDlnQnKscfTt0HrXDmWLp0YNTev/AAC8qy721ZSa931PV/AuiTJaIVXA27wCdox94kZxnpXvWmMbcKWZQVUBsAY4x9c96yNK06CC3RI0YtEuFJOWbk9c/U/pWo+UU7VwWGPlHJ+v51+e18Qqk3Vm9z9MwlCNOjGFPZHQLrbRBRG5wOMjgmq82qSXLGNWXB6Yzu/Ouda2lmUM8TFfvDbyo/T3rUhi8iMEqQfXpkADsPxrn5oyukd9KMlHlaNhBKuG8xhghSBgDJ9c11ekyNHMHaXauMYOMHkda4gXPzDCnGCBjJ4/Grtpdqk3mOGEYG0gYz7ZHXtXL70XzrVHpuLkrQPX01UssSeYuEOODhjgHrnP6VpTeIPLjVUfGE7sNp6D9K8oGpLIwePcFDE8/JjrxVW4vnZwC52g8fMdyj145/EelaupdeRgqCT5ZHocfidPLVZZoFbLEmN84wSB19iP1rK1TxSmGPmbgELHy3Mg49hXlt1dkAquRzk7XJU+4/Ks9rpvM3bm5GCA2QcEHn9K3nWpW0PMjR1vY7t9ZLjd5rOWPHO04PPcZ/A1BJe7oi6EllI4bnk/l6VxkkySYJZkBHrhW9KYb7KNGrNhPuliMmuOVVR0l+B6lOLtqdJe3ckqsS5bLZwTk85z/SuaaWYysnGSOBs5GeetSpeBo2HljJfOduSPxx7dKY867ipUBv4SOT368cV5c588rHuqEVTVtwLFj0GFPQnIb861EuDs3MfmPcgYXr2xnvWYMvj5eMjOeh9v5/nWxbQbiPlHK8BeT/k1UfcfvBebbXQhzuiRo2JcNk9gakj3lzufGRwAev1qybHCA4xjvkAHJ4qdEUgZLDbwMHPHFbOfv8p4yhC2u4yAMQ2TuzkYbt19KlW2UkgA5b0ctjjJ4J+vNNiXYrADCtxjpxn2rTSJCqFSzHHPYfgf89KcpNzscEqDbvD5mJc2EkauM/KwwctsDDtmvJ/E/hCDVI7osX3MjKUUrhwR83Ud8d/avf5LdZEYOqnjIzyDmsDUNJlnEgQKisOrZz3zxXTSfLKKdyMRSgqdkj8ffjR4AutA1WaWysmksXbdHLGir9nJb7jINu3I3HIBBwPQ14Xa3bxSCKUZljOQuOEySckf571+tHxa8H/atPuZzEZEjbNxHt2llHygrjknpX5meK9GtrLVroLGYxCx/g2MQSTg985r6/LsQnT17HgY7DSo1OfoyrYXDuy74jIWIJARQsYxzwMflRVXTbtfMUBnAyCCR0/A/wCeaK9lVKv2bNHz8nNPofuHgKEYg4HyA52njjn8qnTZuJVgSRnnJA6j6ev508p5seGJBXjGMAc5yOPeo44NjHAzuxknIFeY+eT5X0OWU4RvHWwM0aglyuVGQOdzHt2xj1781aSbA+U8N8oAPTtUbWu/PyY+YnIOQfwqzDanbnAXAPGDmlOCW+5hGMOXmVymZgWZRjA4POad5rldvAGc9Oc9Kka3TaGKuDnnIIGec4PegKR2GCAAM4C9e/5frSTSSkwpp1PeexRb5lY/LhRgADsM9vyqmZZAQeCW+U7lwPrzWusEPlsQTxwyspU4456fyqgQpYxopYDoSN3of1xXUpPmcn8LOZ0vsxHRlgMna2QFyFAOCD2pySTgYX7pHGRj1pikjfGUwQ2MbcEcen6/jSYkRirKN2P4u1UpQi7xKUG4qHU6CNlVAScO3XHT6VbFwTkNgnjAHBPGKqR5QAtx/sjkmlZjuD9gueTznnjFclSpKpp2PehFU5NLcc5ZBneM9cbgc56e1fJ37SXi28tNBjsrJnjnurxbaVoMKYEXJ3kkHOcEY/2q+m7qbaMpnnkDoR6cCvz4/aG1eSfxF9lE88lrbQEtCCFjZ+T8wx1GSMn3reM25xiu55s6fNFwpo+YNTvN7PJNI5kkkywzwx5bk/UD8q5x9cWSeSMyAshHHqew4P8AOqms3iFskAHecBT0wP8AP51yZnkLMeQc53buTX01NtwXMeDWpSpStPY7U3u1XnDBmZc7WOO39ayDey3kyIqqPmw218jBIGcnp/8AXrmZ72SEId0khZg3L5VM+o9cZrqvC2myahdechkKIDuwp54HQ4xjJ9e1TWrexg5Lz/IVGhOrNU6Z7R8PPD8txNEEMJMjA+YFLPHnkjpjGO+e/wCf3x4R0K30y1iJ3tI0a4V2C5x1469RxXz78MfB0mLaZo+GBbaw6khvvZ6deg9a+xbC1SGKCEc7VAyVBbnPGAOf/rV+fZtjJV53i99/kfouUZdHD0VdG9aEeXjcMt8wUcKOvatNFTdkgMAuMnPzcdhVGOCQqiqAVU/eXIA4zjOK3re3WSMNIrNjKk844wf6/rXhOLmuaotT6mEI7IgixHuA2hd5O0gkHt/QflTbqNXQKSFIJACgc9zkVotDCq4CbgMckYqq4wzMzYAIzlgB61MlKWvQ3gpRirnNeU8T5ZiUzkHG0ZyTxiplkXBOeTx0IOO39ajuZc58tSQpwFyKryTDAJAyOF9fyrqcptabHHGLkrI2TchY9pJIAxgEYbnNY8l6qSM4fbg4ChycH169+aqXV02AEAbI5AYAp+HrWNLKS+MAckntg59etclNpycT14RT1kdDLfNJxkZJxgbRjrxUYulDBWlVSASFP3j0z9T1rn/PO9gqkfNnjpjHc0yS4LyZA3SL91gfu/pWVSFm7bnpRpyUtDVluiF27iACOV4LnnPH4frURuBGNx3FmI+Q8MOO9Yr3IVkXJyoyCGwoOcdfX/GnmTBVsruPOe/4fnS5XKN3uckYq7l1OihuAQRk5LBMBGwCQD1x0ww56VaQb3AB9s8bgciubhmc+W7MuUbdg8se3T8a07eaTzVPO1j1YbOPWoUpR91nVJxlBdzprWFCFMbfd67uc8kH9c1uWSKjh2+bH3gOcemAf5/SuctrsBwpQ5LkFgcqcZ7+lbS3Ksy7sqSewyB+NXKTbszzOVP3pG08YYBvNUKRk/NtVMe1UJLdklOSzHJ6g/jn25q1HJu2j5NucFXYHeCKjGfOcsFxgqCBxgdv0rJ0pu10RJRjexoCMkAkqFHbGK14LdlCsCGGOhAPT05qCGHehOMnJI28t7fT/wCvW9BBhFGwjAxuYdeaiCtJpHoXuZEUaiRCX5LYYZ6jk+/tVw26OCzDIJySw6YHSr0FluUFwfqgyVq6bXdtByyZAboSPbHtXZFyc+aXQ+eleabPJfEmjQ3Fu58pHXYVdZELow5PI6f/AKq/Lr9oDwUbTUbie2tnjM8heObyyBhiAOOeOMfhX7M31gLi28pYyEb5W2j5hjjIGPavi39prwRJB4YudUCeTb2owZUGXQfKCOQcklgRzX0GUYtzqKC20Pn81wlSdLna03Pyy0m1kguI7e4ERLugkUqJEYnBUDgcZKn2oqz5ojnwE3vC5+ZgQQQ3X8xRX17Te54LlFOx+4iAfMxCkIxGWXGecUycktuRQFPoACev+P8AKlUkqwK7RuwcjGDj8qWCHcXaZiw3sIhGAuwejcDPIPPJ5HSuCVWm212Pn/e5uSOyNmNschRgjGCDz65q1Ekjt8hGB1AGPc8VTYODwowegPrznn8aeAVXJLdSSeSMHsPyrzvekrwPoOZqK5iwEDcblAcbAARnPuelUngCuwHIAyGU5C8A9hV2IJIpWFl3MNxV/lbP5Uv2ZQW3phh3PJP9M/StEqThyv4zPn9662MTyN5bDNgNypHDeuBj9KcYFDjaCHJznoCffmtBIY1wV6gY561XmRxJuVhjqBj5fwpWlHTuYOEuZyitxj27hjJkBj3PDH3pxjyA+RknJOcc57frV7IYL8pJzjjg+9WXt12KwXCk7AcjPQE+/cVME0jvUGoq+5hsFj+aJgwwDyMk/T8aR4yQHLYJ567iO/Na0kIGAmGA9uVPrVSVVAJclivAB5+tRNzi9LWCSvscTr2pf2bp93dlWJggMpEQG75AWzyccY7mvym+KniifVtW1O93zCS6kYSRN+625YLyM8fKeg71+jHxf1620XwveS3EckiXSCzjiQ7ZJJJOAF69snp2r8p/H1+s19cpCiQxrIJPOOC0mcEgDsO34V3UZ02ud3+44pRlNcsXojyS6lmkyNxyWw3Rse4P/wBeqhkJEhDAsM5wQG78/jVOa5kRmVgSC5AbcSeMjg9f/wBVULi4ESHaFG7oHO5hz65z+de1Tq6c62PDnh5OpK/Q2Ii08iptDMMHJ+6OOTkn/Oa+0PhR4Ia5gs3EEIeRVkBMCISVIYHJBHAK4r5w+EfhuTxFqsYmtBJbJgPK0e5EU7gTkjGeBxntX6n/AA58LJDpcMkcMjps+RnQBk2qCOMk42g+/FeDnGZu3s09ttD6bIMHr7Srovv1udf4c0G3022gVQVygEgDZGcYPvjI/wA4Fem2OnmVlUbjg5BAyBnr1pbLTvL8oFCN/TaPlGTuPb3ru9NslDRqQAq4BJYAema+Hq+0m7y6s/SVeMblPTtCJURpvkYgMeMr05rQuNMt7ZGQny9owUDDamK2LvUYdNhW3ieLew3sY+WJOe/+NcBqHiOE+akrwxkDaFL/ADPzXZGhKMVzLToeJCrTd9Se9uo0A24CA8AH+f51iy3SOpZWZsngLkD8DWTe6tbpH52+OUO2xV87bIxC8YHcZrKh1SHYrF4kLjDIjBgCOoH0q3Cd7SR61OpFWb2LM935bMiFQRw2c5OTk81lz3f3SWYfNgZ4ycZOOenvVS7u4ncyF0zxuGcGqE1/DJIAHyQMBlbgfX8qboN9DSNWm7pM05G3qHRgSR8xxyMVVeN2JbOSRkEY46/549etQ21yDkEngHBXBY+wBOM+nNacwVUxjO/ocg5qO9zWNXQ5iZZEJK9FJ4UYDfn/AJ4pgchgQdpYZ6CrzxseWC4LdByRwOMf560xrfYRwCcZ2kkEfWuZ021sW1opJlYYJD5Bz15yP8/4VJtJOCPlYYx1HUYx/OpI484+UDDdAOKufZmClm2/Kcg5yD9Kp0NFykrlTbexKihUXGM4/i6/5/wqZp5EKK+4hAQDk8c9aQTR26hpQNkYaQP5e51AGT05PQ8Vh396iyt+8YK3OQNrNnkduO9bKlJr3dzXngr23OuW9k4EUxK5ywOMjrW3Y3zhmMu9uMjIzx7GvH38T29nJ5LvtiwMnIJ6fh9aE8c6daSNGLkFw3yPvGzkZ6njNKODlJ+0FUzCEZciVz32KcMA6sAVOeeefpWj9rVk2DBJ+9jhTyc9/avnqz8eQO5U3CAhiNqOCT9P1rq4PGmmLAj/AG1S24BkdwJV9cg10VMHNrRHi/Xpa8qPZrO7Ma4Izxweh/L8q62yvYXUAKwZjvy2SM4A4BPHTOB6181z+Mrc7XtZ2kZeoPIHX9KuWnjyaLaQ28p8xDNnHcgf57Vn9RlF8yWpzQxTk7tbn1OtwoBZZNvJTZ94+ueOatRNv4LEMeW+baB+BrxPSfHdtdXkVvOxiaUEw/KfnKhicfQLnn0Neu6XPJfYlRVKgDLEn26Y+nT3rinTqweq0PdpVKc5OMrnWWMYJUcNwoPcnrnNeTftB+FX1z4eavZxogkkeMxGQEITuG5TgZ6c8ele5aPCkyIpjHmIwwSmB7CrfjnQhe+FL+Js7ntmYKFyS2CBjjtnI78VthJuniIt6O/6nPjoU6lCUF/Wh/MlqETaZruoWVxktZ372sqFgPuSd8+2KK6L4maFPoHjPxBZzyyTzpqkhnEhCFmLn5xx3A/HFFfd0oRcFzXufn9SDhUcHpY/bZ0h8v7zF8/MGGAOexoiVNwRmVeCVUnDNgZOPXufpS+SytlkO0kADGMfjThFGWR2SMvFu8t2QMybgQcHGRkHHFcbScEpfL1PKlyOfMvmNKq+CC67T8pHP50u6JVZQ+HJ5CggjsOcYpWbhQyHC43c5x26fhT2twVMiICTyARz7EVTU4I0hJSVkU4hLCEYkruO1cSYI/8ArVLHcPI+1skfdYEZI96nitpC28lwwQjb5aMr4yQCSMjBOeMflTpVhVvmDZIyRgAfTj6kVjK17omKkpNIe0sUSOgPIfLHyipJ+uOarNLC+4EkAnhnB3D29Kf5QYllTJBI5XGfxqJMu/zRqu4YGOCPU85rCbbimzt9nedo7oEniHzKRhTkBjjd+tXRd2+WEkyqWXIDHCHJ6ZwBn6+tU2t4ixRQSFGSSAWPqelMksQQ3yiROhOAQMHPP0OD+FRsatSlotycyxgtiRCScAA4D/Krcf8AfWPqDVO7ngAKl08xcjCnBP1/L9apS2wQcbC20ZGSD0HP6/zqhcL5K5kBIUcY+Y+4P5VpKMEr63ZyKTjvuzwz473kH9h28JijmuPPWVVkcbMYO7aPULur8nPH+s2p1e+USw+TI2YoFHEJARWB+pVj9WNfoh+0HdGO90uOO3nnk+zXF5BIp2+WAyoysexOfyxX5aeMpoL3UZ1MaELMxcsASCTyM10YJQi/f+7puelrFuJybXvmq++RlCkgMGAAw3PNURK6zI7uHiyGClhkjPB/UdKY0oihkVQCACpDDC8n0x0/Osl7oyyFcAvtIIWLCqADjgAA8Af5xXs1JRo07L+tzw3Sk5Lm6M/QT9l7S5tYs7tYYsbLwAKVKgIAvJ6ddrdPav1L8P2P2CzhQJIhRQAhOAuMjKnOfXOfeviX9kDQTP4ZsNSa3BchtxT91EcZVcqMZHy4HB+8a+8gsiIVCK2AcqvIxx7f/W5r4PMKrniZJ7H32V0XHDKf9WLPmIqDcqqQfvknPHrk1j6942tNFsSLVonuW/d7o2DeUePmYfjXL+JtTu7SLbDglmyig+38Xfoe3evC/Fep3zAG3sXuLq5m4jhYmOIbUy3HOSVP/fXWng4OLu2a4mTtdI0te+JuqPcMVuZSQMFwckEnOM9OmDjtmuGuvG+oeYbme5uZAxwUeQkgDuBnpWZp2maldCaa6t54neQho5c+WCAACO3pz9K5XxJoWtGdIrW2nkVht3xk+X0HBr2oVINe8cDheN5HWXXxRCogRySo+UjLDjPX8j+Vcm3xPvRcI0dv5nlMWDIzDd7n8f5Vzr+C9Z+zLKqAsz7WhIJK47mtS18BXsMaT3MQZ8BlZV+RT6H3pKrh7uK3RsqFaVrG7J8RdbuJI508qKRl2yL8xGOg7/rXRab4v1WTazIQd2JAFO4dMkHPvWFaeDpYmWSbDAsMqRggeo454/lXTQ6CsDjy8gFdw6HcPf0NcVSrBpuFzsjhZx9+R6NofiMTlC2VIODvO0n/ADmvSVvkkWPbtAIy2cEqeO9eLWVl5XzICWDZIyOnQ8HjnJ5ruLWSdAsRD4xuYg9OneuGpOC1Peoc9k5HUu5IBGzpkH15/wDrUIN53u4AxtADHAz3P5Vn20v7jfISQOMk5I44qYy7QGA6nORhgB2P8qylGS97oy1Nc1kTNFsBIJG1t2V4A/Gp2vfNRVGQQDyRjrjODj29ayxNIQQvKgYCgZH60hlkyQ2duMkA8j6VUlKCSewRhKepNeSAK0rEhR0H3SMV5nrt5K/mJAzZVSxIBYjsB1/zmuuuXST+I+WoPytxjNc9dWRZjIMMrLhlA5HII9f6Y4rtjUaV4nmVKbnfseIX8V8GZJJrhlePYzb8gdzjj3PWuJvILlHYJPcBOoPoPr7cV9DS6bE6szxqwJPDDGOvTvXP3OiWUjtuiC8DJC59f89a1jiuRa/keNWwkXK0DxuyvtRstqwPKYosmV3PIOMHnPqeB71vabfaldysq3T+SH3lIwoYN3JbqSff0FenReBlvGUMFht2YMmxQxf2OO2PX06V1dj8PrKGQTrbqpQfKI1KliMdfrnP4Uo4zV6I7vqUorllscxoUOoSeWTvZQnlq2cuwO4cnHuf0r0m2srhkVQmG5yQ3P8AnPvXVaL4Yiig+ZFBflSAFI/Dt0P613tn4etXwrLlShBG37w+tZTrKerWi1ClQhTXKr3PNdPWRbiFGSMTQKBDJ5QVxyQ3OD2yM8/pXvnhDxOttLHaXEjFW/iI4bjIBA4HbpjNYUfhOwMkZNuZOMjeCRz/AE4rs9O8CTyItzbJOjK/yMoKpgYwOOD24rCpUhX0l0MZUqlNJp6H0t4eImWDAAViCPL+U4I6816dd6fHcaS8LAOrAqSx+b5uOv49vSvGPBMWpWdoY9TtPLlhmKx8Euwx/XjmvfNEjXUrfyHBHzcMVJIPINcN4xkuXuj1pr3dD+bv9rPwjL4Z+LWuPIC0V/MLuNypVmL7mOR0I5xn27UV9qf8FI/h7NY2mk+IUie1hSdkW+tgDMXaVfkLf7Q6A+hor7DC4iTw8eWSX4nxWKShiJJI+hZbULsYYC9enTjsKppCBKfmOM844IA69q0ygbaCSVJ+YOMjFLHEqvIREpyM5xkNxnGK6JRgrTfxXPm4VZJ2XUUW4w7KwGflVSCW/wAKWKNh8pYnHTJrT2Bh8oG1eARwev8AnpQYwvTcfwNc8qlSbcpdT2+aVOKuZ5tsoq/KMD5nAwT3xVVoBIUUYJABGRkduK0ni8xdoB3Z+Ue+KqujRDcBhgvUcg0pu6SOOOquY6wDJVxjBx04IHbp71RvbUwKzoS24eoYA9sAc+vPvVxp2xsZMEuQMcgHr1p8oWVWDHDKhKjGRJ3C+wOMU5x1utzyJNxtYzIZDgszAZG3kYz0I9KtqJSpUhthySFJx1qZbVzGxChSWIAyABz6de1QtuxsJyAOSBzXHe71R7ijdXexA0axKCC3zLld2SoOAPw+6Dgd81j3MY2MGBI6KB6fXitZlG0Y3MQeFHKjp2rFvGZty7dxxsG4lVHbn9fzpqPJJtbMwVkvU+OfjpZzTG5mW6eRbbTn+RUjEisXLHDJgABWAyeSckmvyO1lla+uyFfAuHQpMoDttYg5GD6V+s3x6Eg0jXkZoiTYuxRlxHkxqRnp0GCP97Nfklr9251W+DISPtDZ3KARycHg13U24xTJcHB3Zg3UsoJyqLhQrjPHA9B9OgrLRvMlKoXDONmUYLgtgAk5OAMgnPbNLqMzRhnjwoJwULZLcAc/kTxTfDbpNrNgsj7Wk1GGLYAWVsyxL098kVvCc1Fvo0dEYe9zdz96/wBmDRDpvw40OaSERynS4onSM5U8Z3YPdt2T3Oa+gXkd5JFQbVKZIPCgdfzHHSuU+GumPp3gnQ4kQJGNOjl5+WViwBBPHoSMegrt7aNGcsUBy2PmGRwT2r4vETVTEyb2ufaUJKnhoRh21OPvdEuL1zI8RKMdqcHac9MZGD2rNXw/ZWpDSKDKrZHILD/P0r0bUb8xYAOSvKcgYI6EY6Y4ri7295YylQMnBPTk9/061vOvJRUI/wBIyjG8tNjlzbW0TSxmJYozIwDGFpQNx2jO1WPvwO1ZsmkwyvtWGPBJztXOfdT/AIiurV4Wy2UO7oc4Hf8A+vVd76ygaXOQVG5gV+bgE8Dqfw9acalm3fQ6adL3mn/X4HE3HhmON/ugiU7lKr8qDGMZ9Risu50MRN/slfnDDcpwQQe3pXYvq8e5gFkZdpZdseMAE46gf5Nc1qerByTFE6xKhaUmMKV55xzj/JqXUk3dbGdOmv4fU566SP5U2KPL+UEL9eT7nNUVUKeQOvB6YqhqOrQxqG3EKZCwHRwO+R26CqdvrEU8mMhRtyMDd+ePzrJV5KmotHsRjyx5WdpFAjlXBxkZIK7t3NaMV20CMJEbDcqvO4fXP1rCXUIgqlWY5BKZGC36U836z8Nt44BJG76fpn8Kwk017ysei4wjFSijoUvXcqCAFA44yT7n9K2I5laFTjZ2JZM/lz/j1rl4JkUKApZ8bsqckVt26OXJww+Xjacqc57dOtJThBb6k2lK3Lr3J1u9uCy7cDGMhQDU6vuXcWABOSRx65qpPEyIMk8nuM+vsPSpSEjUO0pdlXAVQAp6dKtVHa73ZpyxvdGffGPO5QFXGeGzuHb/APVWc8gCccZ4A28DuaZqMvyNIGUHk4IwKxYrxiVRgrKcjCgk/Shq7SMKikpXS0NrzCIPLAAVmBJ9MEHOevVRWXJFG8hPX0PTOO9PuLoRqS5A3ISSWBHX9PpXKXXiCOBztZNzNtO5ue+DjFE+e7YVLq10egaaU3Qrkk7gFB5I9DXo+n2lvKUZyQ68434U/UdDnPevn/TvEEUrRCRt2SC2MDA/D+lejWGvgRqLYxl1HylvnXp3Geee3oauPvRSZ41k3ofRdhYRGNSTHIwPy/NyB6YzWxBpzx/vMsEG4LtUAHPI9B19SOtePWHjl4N++3CSlgAYZA0IBzkFSd3YEYr0bSPFmk6gCHkMM7P5S+YhiZicEHkd8j865lVUX7OJ7lSk1K7PQ9KsFmSPDgMAu/JBHpnp9a918HWpmMVpKUMC4Dq6YIBPOB64zXhukkBAQxMbLn73LD/P867PRvFtp4aujezl3i4SSMNhWyeCWxx65+tbK6fuHnzioo+itT0yIWolhjRdmD8y5YkAd+vb9ak8NX5iu47YsqLKwEbKvQkgDn9PxqX7ak+mTOMlyCF5wGGSQPfjFYOnSJLd2UhdEH2gGLDbHZlGcAA8jAz/AIVMpSTcbHDJNR93Y8G/b98GNq/wC8U6hDF5l7pdumqxyN84hEJDGQDsQCefaivtH4reC7Pxz8GfG+j7EuJtZ8JXWnQoVDku9uyfnls/hRXu5ZWjDD8k3szwcdSqSrXitD84pY1AcdWDbTkVB5kigsqfKqksVQnAHfA/GtiWGRLp0mhmtpEJjkhmUckcHB6FcjhhkEU37PKMOGCE8hkO0t+NfRuXJLkn8X4H51GEk+aOzJorgrFxGo3j7xXB/L/GrCyA7mAdR93qV6/56VZgs/N2iQhcnLZ6r7k4Jq39mIyvylQNo2s2fbjgfn615tVJpc3xXPoWmmlIz45YNoSQfeYAMNwBLEKF45GSwHbrUEiJklgQDxkjk57f59avtbDKpFGQc4JYY21ZlsY1jJZTI5Tjc7bVx2HOO+ahqUbR6or3+m5zktsCWK5ZBzvUfKOB/jUJXAVQBkAgkdSM9xW35TAFpCB3wuNoHXrWKzZlwqsW6ZII9K5Z805cx1wU1KysUWRpQMErgdSKDaSjGxckjJyCP1rUijO4MxOcEEbefSqszNG7c5QLtIznB/z/ACpznzW5N/MxaUnoc9cbIwyk4bcdw2gL2/8Ar1jXSpLG4bk8kYGR9a1b+Qli/Q8YA5HXof8A69Y87MiOdp+6TnHFUqkUrPc51Fq6W58NftI3ken3lzYvthXUNAYkhNsKs4kj3t+CoOOu0/Wvya1gSNf3b7t5EzFnHCnJOD+PNfqJ+1reXEuv2MCW85gOkJDLOkPmCZnedmIJXjClV49K/MHW1R7qdEBiCk7eTJjLV10LKmrm0o6c0jza/mR42wc7WIznKggVvfC20XUPHnhm0MX2o3WuW0X2YNh5f3y/dO046E/h+IwLqKGMSLnEh6KAcsc/5P417j+yr4ej8QfHTwJYRpulS9e/ZXOUIjV+cHvkE/hXdXnai7K+/wCR5dHldSPN3X5o/ot0rSjBoWnwBSogs4kOckZVVyAfwI71TuHFu4AO0owyVwc+uB1/SvUG0pYLG3ijRRtjBYhfmJ2gZx+dcBrNmPOUhHDplerbeevHTJ46818Gk5Sc5b3v+J+lU6cfsrSxwep6gWlZYXEi8KwkJXJI56c9a5i+u4g8SykMM5bHBBxx3ra10LbIXVT8nXI/DPPvXimt6/5LTuC3lxqTJIozHGAOrHsK0UvaSbOmnSi9eqOzutUlcSQQtscnakmQdg4HTkHv+lZD39rpaG61jVo1O7afPcQhsgkBR36fQ18s+O/jVcaU66ZoOJb1mxdXLKDBbg/3T3b9OK4/SYNT8UTWd7faldaibmQTq0szHy8kBlA7YwRxit4UIyd2zqqVYx+FH0/4i+Nnw+8P2zyXd7Cr5CxPJDtR3YcfN1P4V5Fqn7Tnw/likgmuLa3mAyj20nnecCOcjORXmXx78PKvgvzrazt7i4tbhFldwxNkgIzIhJ+926cjP1r4OurWK4s/nJiZfmEyYBfOOM/gTXXDC0viqXOR46s5Wp/kffln8VdC8TiSbT7yMBZSFQvsDdcHBwex/Kun8MeK7e6vEhjuYgZm8pFVhKz8EgAde36V+WVhPcRXccSGZY94A2OUx3DZAzn/AAr23Q/EGp6Dd2d/pVxPJcRukjmZi8bDGGH1OevtWlSnCCutjhhia80nNan6it5otdrF41ZfLwg2uu5ThlPXIzmn2jTvLtBIDLwp5OBxn+VYfw88Rr4q0DT9TP3Wt1iclt7+YuQ4PHY16TBaOGLLHlX6Z749f1rwajjHZnvUruCUy9pNjPkMzF2BGMjIH4f5616RaaY84j2jBx0VefrWFodhNK6/KGiPy8nkfUfiK9T0y0RSIwhJUbRgevPWsXKVlbY6ItxlrocLfaXIkioocDdhmIwMjOfp9Kybqz+RkEm1hweMkcfX/OK9l1OziZTujCgDJJwuenSuB1PTThni27So+6ckcdvTrWPtJQ0Z3xlFu61PFtTWVN6CTdglG3Nkj1xVC2dFIGVUp1LfLmuy1C0MTGRlYKz5IznDHrXM3VusrMTE6x44ZRgH2+tdVOolaTsU1B3ucb4m1qGCyuZsrF5C4c55dumBjv1/KvDj4ge9nYHfjOFZfT3rP+Il7rMviW70q0WePT7KJJFEUhKXTMNzMR7dMVjaPqjRMY5LRY5AAGdkLY44JHH8/Wvaoyp1I3keDioVfac1INe+Jlx4PurbFtLdGdiotuVZs5IIJzgZDfkfSufT9prXYL6N10xbGzhG8+Wd8kpGcK5I5B6EjHU1kfFxm1HTYL6zhWa+tXVZWRW2xwjghBnk5OcnpzjFfOlxY318sPzyRBHyVAKFh6E/56V2RjhqmnbueW3ineEunqfYel/tEa94s1LzoxJpyQlYo4Wh3CdlYYAA9TgGvaPCnx2t7rVLXR9YWWynnORcqxW3jKjoxzlemQeMZHNfEHwu0yefxJG07MlrpzC5eIKSHcH5c+wIyce1fRF94EsvEt8upTwzQyg5DW0pjifOPvKP5/WvOrrDpts9OlUquWqP0n8E/ESRDDFfX632myoFtrvzFfYG5UB/4h25OR6mvoWIabq9si3KiSAlSwLFGAXkHgj+dfjv4P07xrot5Ho9lc3t3YLMJ4IGRmVRnO0Ac9ug/rX3L4B1L4iXNtDcXVjczWQBEKXELI+wDDAjjHTvziuCq4OdofCVO/Iktz780fxeZIks43MysEhUsApB+7lunHTmu30ZBcXNoi+XLItwsiGQ4NtnhinXnaSPevnvwnNM8dvNJbNEzASNkfMCe361754ZnQXURwQQc9xkg8ZOc0NRmlHotTjkrO259peFtPivtG+x3bDIgkgdI8P5mVAGcf7xH0oq78Nt2p20MG4HzLn7MFORlgnmOSwHTBH5UVVPEShddOnQiSjGTi4/19x8Y+Pf2b/jL4IXV5/Evw68fR2ulRvJFql14TvYFa2Ds8YlcxABgrbec8gfMc14Ha232uET2gLwrw+PnaNskYbHAIIIP0r+3m6+MHwcubWaO6+JXw4lsnixcrc+MdKktXjYYIcGYqVIPfjmv5hP27fhl8LtH+OninxZ8ENT0eXwjqYtrjVtK0e9gn0SLUHUi7msjHlQrEJIVU7SZm2hVCiv0PE04L3os/KKNeSqukvvPgyG2KZLxrI+chGkKBiPujI5Ayf50427Lg4KgjAUcfzrSKzhxkB1LnCnkAfXHpVkRQujl1AIJAy2MD0FeVK0XzRO+MdeZ7mCEcEgdAev+fpUUxwNoOPUA4zWxIAm5V2gFf4BgH/PSsG7RhuY/NleAMgn6UpzcjaC3RlmAFXcuuwvtGThvUDp71nNFiQjBBzngf1qaeVgwwGIBBVdgG3HuB396giuHZcOAGIzuPUegrCUm9vmSrQt32NOKMEqHI2rjgAntjmsfUoQjOVcbWPGRg8Ec1eaSQHlgseDhsZPuB71RnAuGbByABty3XjNcLcb83RnppSTaRzEsSODIpyV4YE/Kcc4qhcsgjZZN+QpKGJVPbpk47+hrUubN4g2ACCckA7iv0x9a5y/leFCdpzGuVB535Gcc9quLUZOL3OSFKfs76HwV+0xcXLeJ7HTrWNrhRpv77ZIpkgLhigZT1zvc5JwAor8vvGFqtpd3sAkaEsxAkjC7kPDDkdeCOfev1a+N9ol7qDXzRmS7lI3MFLLhfMBVTj25HsOK/MD4kQFdfu9rD7O67oWVGBQDcrBlIGDlPyI/HvwqNsRCy1PGJIWlkKxlj8xYyzOzk5y3XOeK/QX/gnh4QGr/HIautuXXwl4dnu1ld9pMtz5cLMTjLBUkkwpOATnHOa+FBG4kCRxlmLcdFX169vWv03/AOCcgu7f4maxCqGGO40ETucFTPmRYyMn2UdfSpxdvYNvs/yZ2YS7rxS7r8z9w3sS1rCwBchTuOOCPp+FcJqunM7M+wcg9B0+n69a9mtbVTbAFCoUbRhvmbAwcZqP/hHBeu6iIkN0YrjJOe/4V8k9VbsfXQUY00o7nxD4u0jVrtpI7FAsn3RgncT26d6+ePEHwM+KHiNLr7ZYXUFpcDCJNMI2eNTks0YOSOhwa/Wu28CaPY/6XcWMEl2B8zsgLt12545xmub1998zBIgq7SAMhRwegH5flWiTaumSqUpK7PyBf9la3gtppNXvZ2uceZFHCGKljnrkZrJj+FmueFUtfsVuzxc/MjhhEeuTnpnnrX6Y6xYwySt5kC5DZ6Eg9elcDqWnWjO+63UdAVCkg++CfbNUlJK73OmnBpn5veNdM8S3mn3Wk3thdTRXEZhNsF2mUHjIYdR618o3fwV8RT/6OLaWJUbzBGYdwkXn5QODx6+1ftFf6Bp95FKj2keWXYshH7xB144rnZdB0+LCxWsW9UGGMAd1GfU1aryjFQaO14aEtUflDo/wB11pIn+zw+Vv/efaEeNmUHnBx2r3Lw98BrWOVCW87OSY44NyKSMAHjoOa+138OAq6xR4EhCnZDktW/pfhhbEghC4ZQdxTbg91/T3rnqTmk7vc1WFVkzhPA3w7h8OaRBpdvEiJGxlISPZtL/MQMe5/Ou/tdBkjnO5WZACcY6Y6dq7e2jWB0TyQQRhmPT+VTXaNFIPKJYOoy6gjqOQf15rhSclZbrc9WCsrSMbSrExuBFGWGQWwOnp/OvS9HtPtU/EW3I3FiuM/p60/wAL6JM/lvtXadsjEjAUHGOfX2+te0+HPDkNzqMUJjfEhwWEe5emeT26d66o2Z5NSDd2eEeIbKeHClN2B02kEj1/SuUFv5sbdPlG5lK4I/ya+wvHHgzyba2Z7bKqSqyAdscBv8968E1Tw6kCybF2Scktt+7WsqdPZI48M1E8H1PTI5C25M84JC9KxJdDkdvLAPl8MFC4UZHX616drOnmNwERgGOA68sMVkTQOUVVGOMZIzn8K5FG7uj3LzaujxDVvhrp8xnvooLQ300Yj86VfMYKuSFHpgZxXAy/DO3ZZE8hEdl+eUW/zntn/OOlfUMScGN4h1K8KML9R6du9Rz6bDuV1UbwCAu3p7fqa6oymouEWcLouS5mfEEvwm1K6SeJYFi2SMgnmX92y84OMZ71x0fwPnhmktzZESs5EcrqRF/vL7HrX3+NPJLOYcBnBwQdv+TUq6VbmQq8Z3q3IyNpzz2479ulVCdZ6y2IqYSMldf1+B8c+FfgBJFKstuRFPI5FwyxgJIcnAJ9P/r19SeD/g1Yx2sdtqsMbSkkyfZ5GIcnpz1444FeiabYRwvEsajJPyo2VAOTwePb9a9J0qJQ2NoBI+6Bx6cmurm1c0zieC93mX9fgR+FPhboenG1dLG3lntpFeGeeJXkQjkYJ6Y/pX0ppuk2aaetvNDAdwOSka8Y45I78HivMLGcxGNVX5gcnJGDwQf516JZaovlICQFwQSOQK45WtzHS8M3JtG9a+GIEDS2oUrgZTeNzegI68GtvSbF0mTau0K2crVDR7zrJvUb1wBux37139jFFOqtEpE4OXULw2e/+fWstXZxOedHk0Pqf4I2tw0iFJI1kMhKRuMlyVIY+3y559qK6v8AZuto7zXZbO8tDG8UCmzuE/eSOZDtkGOg49DkiilKm5pNI55Q55N3PyRFjZSqClqrRpgKMAnp/dzzVqErEDFFFFbKRtby1WNmGRkE4yfpntVSF5FxsyAOQSM5+tacRDffhz3LgryT06479ea/QfrE4ppbH5hFJOyNazY7FjkLBN3yk/dJPf8ASp5bZTkKAvbjqPpUFqhbDyHbtHCEHafTmrOWZxxtAAxggg9/8K85NPc7XFcqMue18zhJGAC4ALFj+ZyfTgelYtyiwBkkRnOwgHPKkg4I+h7H0rppisa+Z82V5IUZrndSJnbIIRcfM7dienTPoac6jimRRpc/ociwWR9qqM7uSRn8jWbOY0dyyk4wAPuhs5OelTTuSzqCwKyFMKwHTHI9uf0qjKHGScD3xgmudyS1CGHklZA9xNI4TJAJLK2CNuc8frVcO6TFFIDFeWyavSkRQk43EjAPvWbKQxYqCCTlgVwwI9Prn9K45VZKNrHtRocsnFle5nuFT5mKNnGF/irjdZYpGXDbvM++rNhgcEdfyrcvbyRiyBSWAABBI24rC1K3ZlVXxuYbshunepVVJXluEKb+FdD5q+LWmM2iNfRqqGOcydNyqT0OewJOCPb8vy3+LljHBrEgUOzSx+cCVxhHVR17fMsgx14Ffs94tsPtelS2UiM8ciqhA2qq7W3DJ/Cvyw+OuhpNrEsK2s0c+nq1qCY1Axu35DZ5yrjv0xXdhK8ZS5U9THF07U7xep8l2KLNK8e2PzEYtl2IJA+nHv0r9Uf+Cbjo/wAQfE8N2oac6NHEpJCmFI3LJtwBnPn/AJg1+Vg83TbqWIoVcnyy7A5Gcc5/L86/Tj/gmvqLSfFTxZDN+8I8Oo8Eqpv3sZIQc46YH5ZrrxspLCuXr37GODivrMH1T/U/dkSp5yREg/LyEOSBkgZOOpweBnj9e2tJoViGCnyr83GG7/4V5s/yzJKW+VHBKMuCemfqOPWt9bxYYGKuAXX5R0x7/wA6+RqTemm5+h0Epxu9i/e3ysj+UvC8jOcnsOf8K881HO6Q4Chh94EFQc88fWpJtaJleN1GcHO4/KOvP+f61yepX6qW2tuUgZCNwxOAOM8fnXQ5csVbYinSg4vc5rV0lc+YqF2U9Rhl+mB9f1rh720kkLM0YDgcLtxjNd5NMwidggdSnAz82M59M1lSbpRloVRM5yBkc+5qVKLjzdClSja8b3POLqAAMvRwSuF5zjoeD/I1QWxMznA524yQASPfPWux1WOLzFiiUK8uVRgp5xkkE4x+dLZ2TEgyFi2eh6CsJVItJo9Syc25GFb6WIgGzvb+HuBntV+LT5kOHVSPvdQCe5wK7BbKOEeYqou/r8xxWfdnaWMZQrgggkBeOvPvmsXBOXMelGCsnLboY/8AZ8EsKsQRhdzFVA79M/Sr9lpkDuqsA5ByA2CTj1JIHT+VZklwIwjI3yHDbcjC+34Zre0w+bsd1IBIDEcnGcE1q4216HBKKseseHtNj2RIW4cgAAA8DmvevCenpa3NuVjEjuwCBhtAzwMn05rxTwwhZINqgkndkAZ9P8ivpbwlEIbq3TaX3AKSq7sEY5x+f5GinHoRKg2nOPU6rxjoFreaQuSouCEKgn5S2VDH8ia8H1fwJavbTu0bGYRlmC/LtI6YB+nevrLX7GSPT42eMiKQjaSvK8cc9u1eY6rGhiaPYhXBH97IPGcD060VLuV0clBOLbkfBXiLQpYJZC6IFDYCcZ69QK4OW1gWYIyrzyGOB9fr3r6S8Zacd00hieNo2YNFt5GMnHHHIxjFfP8Aq1s0hk2jYw+ZeeG+vFTJOyaPThCLbkcnJZRKTIAdwORtPHFMTT/MyVBJAICkZwP8mqwvVmR4mOHjUq2Qdoxx1rY06UxSgNtyVywByMHBre2mm558oxaSprXqMW1lw8RQlf4sg5/A9qkWxiBdijKwH3flP8x/nmu/ghinyTHHkkA8ZJLMAD07kgfjUs9jGgdfKDIe6rzjvXJFp/Fuj15KUFanqkcHaQKpLqQMDBx257+/Sumsp2ilJIRlIATa3zZ6nNOt7OCIf6vcCAPmXJXOKvCyhI+QkMDk8YFbKsrXexF5NJ9TXt5iFVyAT1J9B7mul0+9hddpbGwAFe5964mJJUQBkJj6AgE/5zTobja+AGU4JC45IHFRUk+VN9RSlLc9c029WORGLrtBIUDuemDXuHhecSzRJgOXACnOduP8+/SvmXRZZVVXeNZQ5DAA/jyPpX0F4Ju1N5bMLiOOQnCEnciHoM8fhTtKVO0Njx68pRT8z9R/2X/Cxu9Xg1O4kCQ6dmcRrFzOSrDAf25yBRXr37OItE03TpiirHe24SaWDKxK6owJ6/dJJ5I6tRXE5VIJRieYlGTdmfzu28+YwHBYqowT69+1bUDSOh4KqRggg/pxXPWzxyRKqKSTgNn5cdT1xj/IrprMySq8YG0jBJI4IJ5PT8fwr7fmUneT94+ChBRbS2HwyMnA3sF9yw9hk/54q2r733KAWAw4DYHGcY/WoYATncpxGdo2ggNjIyf1rZgiG3ftAAwAI1G5x3znA/OtpzfJzPcyjHWy2M5mWQNmNQwHzZH1rltSLCQKgwSpAcDI5wRk/rXYXrEIfKHTr8uGPb8f/rV55qk8jMysjbTjgqTk/WuOpONlJrVnZThztJGI6kFiXJb8yfwqOdSAF3qVHHqQTQTtQbgc9CByaiZ8LsLZBwdozXmzbuz3qVDkirlQxrtIZw/y5DA8VnTgoDtLMSegxznir0krthRGAAOcDGRx3/Cs+Z2ZgABkHqOmOO9ccrN2PQcU3aJiQWw5mkUtt6AHDHPXOeAOvUis248qS5EZOQBkAdD0xxXQZdMk/dPC8kdjWBGGl1EuchkiCFjuO4AkjjoOWbJrbmUaljy401axia9aSLZXDfJs8kg7wONwwDz6bgfwr4L+O3hBbi2m12PIe3VjeLj/AFyoDggAckD0I4Tv2/RXXLYSWriSBZU2kfKPvqMjH86+c/FWiR3mn6jGLJppShwm5uVHVdvTlcjGOc124WvCk1PrcyqUJzvKNj8WdfsAlxcSmHBJKjzFBIG4nbjrwSeo7V+h/wDwTbEGm/FLUrRo2mTUvDMyxsVKrBJ5iOc8Y3bY8jPYmvmz4g+A2t9XvLyFZJrCSV7iNDEIjCgADqOBkhldiOSAa+mf2C7u2074yWWmkRRC+8O3cdvITtkeUMpIYH+LG8D2r28RUhOhL0Z89RoVfrClbZo/bjVLjyp3cssao3ygHGe9YcutCTbiQnDYJPAbHpTfE1wyPImSwJ3bV4B5rzt7mVWVUDAhupyRzmvjoNvSZ+rYP3o3e51d5eRynzAxGRkYJA5GOlZpEjO5Dtgnn5ioP+IplsjuiOAx4ySRxn61qxxAA7yWz3UdP0qrqTcex3wlOVosxorZ5kWIyDoduF5A7c/56UuoWUrBYkJ2hQMclfatS2i8r58A+u44yBmrJkUMOAc+nT9P881ryxUnc4YxbWpxk2ksqgumWAwCOh69D0qSKwjjG5wGyAShOD7iupmYMSGChc7RtzgZJ5z2rCu3MZcnaqLzkHcTXJUVpabHXGHMrszNTkuDA+yHarDCNyevv61xt/OsIJclQcFsDqT9a6C81HeTGkhEYbO3OFNeReL9fjsUeIfNICHBHCD15oTT0id3Io01Jbs6SS9a6lEMEoRQRuOc4B6DB/zxXpej2RuIEUSAbQGLbcDpgYx9K+fPCt3qHiK8EdlaspgUbiWG1z656fhX1XptlJp+lW/nQqbn7PztG1WbHALE+vGamUp6J7HTOMJaRvzdTrPCjiCeATHKqwAyQFbt0xX0ZomoWttdW8s7uqZBKxn5zyPb/Oa+ZdDkkS4SdAEaM+Y0bPkRnn8PXnGetdNP4ruLeUSO8Z2ZUbDtxjkYx1rb3OZx6mSg4xWmh9veI9Tt59Ittt0DAABtwASFHHGeK8ovNShIEUUifMCASfu56Z9P/r14K3xKvbu3Ft57CMMOM43c9OtA8UmcBTKqIDuKkdOtVfl93oY+zp8zvt0J/FMqvdSeYwkLsW4UDsB1/D9a8C8RWEtsZJkSRly2Co3EgDivU9R1ATTqWJJY5DD7g9s/561ci0n+1YzbmNAzAPG4yT0I4Y8g+wyOawfLJ2ZHsWnzM+EZNZjt7plZDiVyjEj5kOemMfX8q7fRb+GVFbKt82RyCD2rB+OPga/8EvH4jRZJdKlugl4+3yzDvJALY7buMnpmuB8MeII7nabZn8ongfxAjqP/AB4c+9egrctonHSs1eR9TWl1DBsZGxK3Jx1TH/666i2mSQAuwKEEAHjB5weB7mvJdHllKbpN2OFjYnOQM121gZGZJB5ny87cMEPOe1cjpKK53uz26iTailsdBcafHgvGxUf3QN3XPSmRWk0agovTkjGCP0q5E4C4fBG0Nt6jt2rQjnjDKuSAww5A6+1RyzjrI8+qlLQqwW9w6EGJtgbGWXjp/wDXqhcQrHOSiv6fMAvp0HPfNdokwKKDGGXbszk/KcYGcf54qVNMiuGZgqluGXaMj3oV7XZw1Oam/dvqc/payxJ1OD1UkdDn/wCtXsvgpJftELup+8OFO3rkmuMsdGdtwCnKg5HUD3PtXtngHw7LNcxLIyYLhioBYgd/rjNaxneKsediJ3VmtT9ZP2frxl8FackYkUQMyLuJLsp5yB1wT3oqL4OeXYaLb28L+ZLDCFIYCNSPUL09fpxRWfI5+80cDjLmdmfA+i/8ExP2vZGuI5vhpYWBtiUZbrxXprC5PP8AqmWYqRx1zj3rprP/AIJi/tbvtA+HemWxkw4N34y0gRLx0IW5Lg8+n5V+nHhT/grF4B8Z393puhfA74s3V1p0uzUFjOnXS2w5IOYpnByBkZwCO9dBqH/BT/wjp1/a6ZN8C/i19uvH8u3ttunidycAAp5pIzkYHWv1+lS9tFOhSjZet/8A0pH4/N1Kb552/r5n5mL/AMExP2t1XY/grw6m5gjGDxlp0iKCSCx3Sjjvxk+xq7J/wTB/aziOE8LeF7uIpuJg8YWkUgOThcSFef0561+nmtf8FM/Duhy6dFc/BH4iO9+N3lR6hYG5h6ZzEGLd++Oo9ao3H/BUbwda2k11P8FviRGYmA8h7qwSdge4Qvu/IHtV+yxTV/Zxv/XTmPUli7u7f4f8E/MiT/gmP+1oscd0/g7QzDEWEthF4t01rycYYLg+bjqVPDdiK8G+JX7Bf7VvgizudT1P4Oa1f2cKmSd/DWo2PiiWJACSxitJZXGNhzuxjj1Fftlbf8FQ/CN5bm4h+C3xDij8jzlk1DUNP023fgEhZJHGT1+6DnH5efXH/BWXSdUknsPCvwQ1+fUI45PNk1fxVbW9naspAViY4X3jr8uVJ7GuerhKtWlyVoKyvtp09WbUcwlTnf8AT/gn80YwwmjkilguYJnt7i1uUMN1bPGxVkkjPKsCpyD0qpNCu0g4xt3Lj5h9fzHSvcfjDM/iDxp448aPaw6RqOu61deINU0tZcW6C4mLs8HGCQ24uBg8NxxXhcm/aHXa6nq4bkg18HmOGlhqvJHY+uwNeMqSm97HOyZAbZgYIPoT3P8AWs6VgWCALtJ5C9Qa0ZYi4JHDDsSQx+nb864LW9dtdLI81JhMWAKKhcMCRz/6EPwrjlFJts5pTklzM7SeYiN3AO1TtI28Mc4zn0rL05jNeTGQjCBQgDbmyRg5x0HH61m2etR3sYA87YyghCh7jIOKtWMqpdrFiYibcokJ3KDhjhjnIz0GB6fjxxUrNzPbpyU25M2byO4mt5oFkA4Zot5wpO35Qw+veuA1XRWxcSKMjacsOWXbk8duMV6DMrKDGhJz90MSx59zVa9t8WMisDukBUbSHA3AjoR7iqhKSeiNKik3rsfI3inwFp9yk0jWyS75GcxbFJ3sTkjjoeh9fevLvg14YPgD44aL4oy0VnLq6WlzbBAItPSULGoj6fefbnI/iNfaD6AiCNVVwCOGYbhjJIHU9OnrxXmmveCLq81eK6tFeG4t7qCcOEKb3idJY3XjnBVee5BrshXkoNzd07mfs+WV/M+zdbvEmlR1BdHAw+eOnHNczGyPcA4QL3+XPbFWpboXtnCyRFF8gHeMjOAF4z+PSqUIWMksNx5x3xwev6fnXFJqfu9jrwfLyXZvxOEjOAGLH1OCPp0rTtgskbOdmQRjI5H+fSsD7cBahiiZU/KvlnJ59eg609btGX5WKsTheCp/D/GsJae70PcopySR0El4kaE7TlVwABwcZphu0KAFeQMjGAefUVyDXLAsQuBu5PXn3NT+fJw27CEBSBjJHSjScV5Hor4lGG50MzxGDssjr2GAe/8ASuW1VisO35snjIxn1wf1q35wMYO5uV4YcqMdaxNRvFaJ1CnzAMrxx/8AWrSfv6zInzqfvbnDalfrB5isxjIU7cqfQ8k/lXzr4s1wTzzQI7jaCjebyF5PIOOnGfzr13xFdNIHDkgqc7cd/rj2rym70i3u76I3MIl8yaK3G9Qy5lkCDIxggFgTnIpR5LJ9TeXwpPdH158BvCFnb+FrDVLq2V7nUIFuZJnyM7h8gBPYLgV7L4lhtorZSAIti4UCTcmfy9q5Tw34gtdN0a3s/LjhSC3RIQnCjAAxtA4xXP8AiLxfDcwSRvOiKu5gJH247kCrcZqS5jNQt77W5jz+NH0+WSNFBUnaGBw5wcY5+pqpP4ujkR3ncRxj96753DGCTwOeO/0rxTUPEtrLc3SPcwZiY5JlA8vt1z/n1punXKXMnzXRZXB53Blx1AzWyhTjFT11Cdr2Tuex/wBuoyobW6jZJQHEq5AA/GtKDxUkK7WcZzg7e/0rxqe9FqojSTgD5GA+UVTi1BjJ80hzjOGUAflW6kua55t5cqUlp0t+p9DDxEk6jyyoJYcscMT9K9O8KauxeJbhw6svDEcL6AfT+lfGz+JbTTnSW9vVjRnwMtwM969S8MePdIJhIvojG6/KrTBXYgckDOayqUeZcyO+MZykodT6Z8a+HtK8Z6BqGj6jDHcW9zbNGTgOhJUgEcY64P4V+WFnYzeEdYv9FdJw2k372eZUKG5VWZUlwRna4UEHJ4Pev0RtfHEHkmCKVHWZN2C24oCPX8a+VfiFYxXniu51OIrvuLWGR4w2QcM4JYccnsfTNZRlOMm+pCpfb0v18i/oOqiaGPe4AYYOUIAP48dMV6bpl6qRH5sjGd2MjFeSWUPkhEXkEgZx93I7cV22msYQMkED5ssckY9BWd3F37nRyTpS549T0YXkkjq2diqflK5Xj6Z+lbUTLJESXOVwRg56jNcSt2WwoPGehBAz69K0Yb2ZQygDBweBgcdajlS0ex3VGm7s6KyuwojVmcjPLDknkg49a7LQb4PcvGdgUjcNy4Yc4/zxXlkF6rLHhlAXkgsMjrzXb6BIDcIyn5gOd3y5BI6c89K1ur2ifJVnUtZbH0HpNgbmTdCgAckn356cV9D/AA505vtUANisKsDEzMSx5BwwPucfnXmvw6toriW3ilUAbgGJ5K/59a+r/DmkW8N4vlq4ULhdgGPTH6n8qz5G0olVqid09z6B8ARm2t8KjKOADkYb5W980V0Pg+yigtN0hDPn92jEkYPGfTPzH3GKK7KeDjOPM/zPJq4uVGbhLf0/4J8L/wDBOb/go/8ADr9nPwlf/Cz4y+D7uPRr/Wn1nTviD4b0w6tqiPMAJYNThXM0kabcxSJuZQzKVI5H6/wf8FQv2K5DDLD47m/efKZT4Rv42iHfdmDOK/i5g8RSRoWRmUryR1yMdCP89K6jT/FIkG2ZY+Dk4zgn3GfavqsLjVTT01/rzPzCvhvaNW3uf2iyf8FKf2HpRvf4u6LKyEBkfwzqTSR56bi1sMZ+tVf+Hl37CtxObN/i7pklzji3/wCEI1u4X8ZVsTEPxf61/HX/AMJBa3ES5jLo7ASqyArgEEHGecdce1aEXiC0V2j+UAr/AHDuP4A/WtFmlFd2/T/gnq/Uqb91/mf2FSf8FIf2ETEYL74yeHoUIBFtceD9YuVOR0KpYsB2+9jrx3rMi/4KRf8ABP2KNoovi34aih+bEK/D3Woomz14/s/bz79c1/INHqccslwWXbFPgMoQDfg5y30qyuqpkIriVeGO4sUYgKOFJ46dsfSh5vQd07r5f8EKWW8sbQvb5I/qI+Iv7ZH/AAS78XaHrUep3XgTxHqGoWEpjW2+FWo2Op3bTRthRef2fG0TSBmUys4xuJLcV/NP4vtvC1n4n8Qp4OvReeFZtXubnw+qmZzp9q08hitmeQBnaNdo3Hg+/WuDcwMmSi7vNMgVQOW9Txj/APVT97sylcYx93OAPxx0rix2PhiIrkWvU2weF9lUfNfp1OjBjYKd2CDkLmvPviZGLXwjql/o+jW+o+IINjWpltzOZFLgMgCfvGPIwAcDJPse3jkgwruCfdcgZOR/WklWNj5ZbDEEgHHI6/oB19q+VdOSk2/hPsa1NtKK2PJvh9cT6vosM2o6VBZTrEkTMEZDNJ0ICsdw4289812KWEUN1vEaMrLkBmIZWByCPXPvWukYgwWycYAAXgDOB+VVLpkaVJ1BwowWwfYDit4yinzQWjPPhaHutkkcHnysfLVQD8xXAAz2FT3MMCowJyM8KRtwOc5PTjGaW2Iy2SzbzhsH5D17+1U7raA6MVZXwvJBAycYI+tKSka6OVupiXFkwXCZQZDI4JLrhg68+5UfUZrPvbVpJ4pVbYU28p8sgwwbAPTBAxj3rqTFvswcbgi5xuLsMcY5PT+Vc/KjSSBUQrs+Z35VQB056c5A/GtITd21v1ucTUW+WWyOtt5DLaqVK7lABXH3RnqB9M/jT0lCROkoBZzlW5Kr68Umn26vYPndgkqxWTDgDHIPXPPWqc8yAqpKllbaQV2g9B07muSonLVHtYOTenQuSXe2MpgOM4POO9UVu0yTkAA87R90/Wm3ckXljYAGYkAFcY/z61gzTDlQNhBByO+Mj+tcja2Z9fh3yaLc24z5u5Q+ATu3Kw/DJ7VeS68pGhZ0PO4BkAcH69f8muZs7qOJcyM7Pt4Y9uewx/nirEtwjckMr+hXYT2yB+P61tGTjozmhJqV3ubU14YIiy7W3HdwMt2x0NYWoXTSIzEbcAE7QATnt+lMZmySeVznBOMfpVOch4ydzbyfmyfl79O/6VDlG9j13Na1KhxmposrOHBG5uGxnjnvXG3tpMClxbloDDOk3nqucMpyP616iLSK4lLHBCnHI4POP61pXWkQG0aIR8eX024THfjFZwUJRujpmuaKcehzY8XEaerRb2dYwIzIxRn7YPtxXz18QvEfiHU5Uihn+yeU2XWC45ky3c9Dx7Vr6us9pqFwsLTQ7XdUjbBCdAeOfTIxjrXL3gFwFWQEkElmTDHv7fWuuMWuVnOql9JLU8008agjZuJDM8khJcvvznpk469a9AsNYuLQxF5mOMDHTbjjArDjtGMuxcgFsYIxjnjHvW/eaSiRQyNEpc5/i24PB/PrXc6nLpI8GGs+WJ20OuNLbBgxY5ycDJaue1TxBduc27MkyjuMnk4BNc/YXEtu0kUjMwAJHGQBntV5Lc3EygBSQpRHzggAk49CMkn/APXQmo69zpVCpFOVtDP1Ke+vXUyzuzMRlI2IjY9On69an02G5s545PM8t1+UtHMzNgjn1HXHeuqm0ryVGASRzgHgfSs+2huVuQY1xtcFlIyTjrXHUqNR5Oh63O4v3T2bRPFL6fp6b5GkJiCiTGZPrj25FaVo0mrRvcSMWaRsAScHAAwM/iPzrzdILiW2RoJJMLIAyMWRVweTt68fTmvSPDsbxWuZTuYksOcEZABzx7CspXUdtDmc7y5Uy6YjEFDgBs9cj/PrWhbSIGDMAdv8Bbrn/wDVUMxZlOVGM8jOeaYhAOAvzDktgbh+Z/QUNzlrZaHI1JtKJ0qTIR8oyP4eM7ccVftrjLMMkcYJbpWHBIhUl/kXkbV6kfSp0hZ5cxligGTg4I7fX0/wrNOUXdnVV9pTlZ2N9LiEyYV8MDg54LemP8nrXo3hO58y68o87VC56ZyQQP0ryqZlQRgMRkDaeSx4Peu38MySpdoqg/Oodi3BGD/9emmrnDObSdj7/wDhR5j4CIruqLmQ8SICcfLnuen0FfZOjqRJbyfIo2B22OCDg7TnH+7n8TXwz8MtSSGG280n5iNr7zIBgFcfmCfyr7V8JXUcscMqlHDKBt9fw/Go5+aXoc+I1nz9T6c8I6OdQtCyszyPEzIn8Q2rvO3rzhTRSaDdi00d53fyI4o3laRW2MoC5Jz9KK+ly/GU1h1F9PI+Mx0Knt+ZSSv3P5uY/gd4VkBdrnVlTrJGl8FXbyNu/ZvGfY/jW3D8CfCTIIlfV4ItpEYi1Ft8JPoWBzjJ4bI9q9xs9KjfbGIRuPLY5yfrXQ2+jBHUBSoJ3HanuK6Y007NnyN0npsfPtp+z54chZZINR8QFnbMiS3sUiHgYGPLwBx0XFb0H7OvhV7lXl1bX5JAvybbmBYwMYII8oj154PP419IW2kjCIIizOMKAvJ/CukstEZHLGIZI+QouSOuaVSFyaav8J88Qfs8eFxA4bUdfjwu0mG5iYL3z88bc9PyqGy/Z08IXMjk+IfFVvICFQRyWbLxnlgYSeeK+s10d5EdWQjcpyCM5P1o0fw2Ypp3njJU8Rlmwckjp+HFeZyW0k3c9+nJ312Pm8fs0+E5IEifxD4p8xV5eOW0QngDJPkDJ71aH7NHhTySF8Q+LFG4N5jyWu4kA/8ATE9fQccdK+vLXSVXZmPeynJOOfXr7VtjTYvLQPGHXJYIU+7zWcoST0bO5VGtI7HxTF+y14eiVJbfxf4kldyCIri3sWC9c5Pkgn+fvU0n7Lnh15g//CX+JYXC/KFSw28jn/lhnp7nt9a+zf7GWUK0UYx0K52lef8AP51cOkA7G8j5lbjgdKcqNSTtJ6Lz/wCAYc11zI+Jn/Zg0VrVYl8Wa7FIpOQYLS4kuSCT1aMADHoDwKzn/Zf0GVZYm8c63btgqsMumWs65wcEMIwSemMKeg4NferaFCxRngi3jodgLKO+1uoz04qvNoFsekKbucZH3TTVKSe/9fcYuorXlsfBNh+zZpjXcVg/jbUBtdoHc6bGolwHKyMdvBOVGAVzt684rWl/ZMtbh8Dx3qaKnyo66XakyjOeQVzxgCvq3WNKfTrtLxYoGjjlU3BbGI0ZlV2H+1tJx71r6dtuVOI9hJGAFyT+NYKlVi7xd/69D041YybUdkfGyfskyNAFXx/KEUERi40JC45IGfLkAPT2PIrJf9k2TzWUeOZCwU4P9jRxWxx6rln556EYr78tNPLjAUcDgN2/zmqM+kzx3DH5Tkc4bDY9gPwrujSk23c8X2javHY/MzxB8H9S8AyXiXniGHW7Z2MkZhtPsjQZGQrL0zhV59xXg2rLJFMdhZNpY4xk+or9PPjN4Tlm8N6peB4oXgUTrIYg4kkYiJAy9wxdF5zjr2Ffmp4wgNrcN5fmbQzA7tyY5/u5weveuKrSaV0fS5ZVuuXr/wAE5bzZmDlmOSSc87T6jHT/APXVU3R6zdSNuCcflTCzFVI6Y9wRgYqvJGrEknnGa8ic1B2e59xRhJxTZML1127SeDwAcq1a4uVeLoFZhjryfp/niuOEjRkgyHIJUZFX4b1kljDBzkHPVlGPfp+fpVyb5UaKVlZGwHC5Yg7uOoyTyM/lk0SBVRiOB646VSkmil+Vw3zIMbXMbDI/vDkH3HNQS3TBxHuBVhg7m3Dt1J5/OtYuy5TkhOpBO1rM1LJUZmA2gA8vwT19P6V20FlHcwtHJIxyB9xMsPQ/pXGWnlxHG0YJ4API9q6y1uJB8qAMMdyRUWukkejOSUjyTX/BcUeo3M02/bL+8GCGDc8t7V5XrXhmeJ5Ps6N5ZOUbZtPHrX1BfR/bW3vGSyIMhWYE4PfB5HPQ8e1YU+nQM3zxjGORGvJ7ciuhQlZROXklUso7ny3DpkaBGmysgbnHAyPSrGphUiTbulHV8cMnBz9frXrPijQZHkszaQJArz/vpTDu3KByOOR1yM15N4skeyMVpaJJKVb983+rcAkAk84PGcD3rWNF6Nno4KlKlze0WrXQ4plkZ8IpODxkEg9vSumtXaKOI+X5bYJJZcHPHaskadezwm4VWEaIZWLYR8Dnhc54/pTftcwkjyDGoGSzEkuD+VdMoJO7BU048zPQxsnt1Oxj8gQZUbzxg57Z5rZ0TQ/OneVIwPlKF2HzAdwPTPtVfw2Pt1rEBGs3lEeaSpHlDtkZ6dBXqmmKsDLGsG0bcthdn/1qwqUW0pwPNxNKT97oZa6RDFGVWPryGYcZq1bRiFzkBQWwCTwMA44/z0robuGKMgq25WODxwO+PfvWRIo3bVxjJIGMVjyte8tznp+5KVgWUMGXOWlOC2MAkkAAfj61Xkl2sN3J/jOc46d/8KjnmRsQqNhQDcSu3kjgA1WlBIXBJ4IOGyTjvisnB6qx61KtyK0d2aNvMGAbhlA6gZNa8NyhVsDoOg5Y54rlbN2XcpccqOvB6Yq+JzF8uSDkZIyRx3qU50/dZ5NRtvne7OlV4nkQs6HzJCAyEOwI6jI6c46/lXo/h8Fp0QfMEXKyEDg9lIzk/ljjmvK7JVk2uIlQud7KRhmIABOOOcAfgK9X0GUB1wiq0YB5ON3v19qp/DynNWg2rxPqTwbcyQRxFSqDdu2hhjtk47ccfhX2T8M555Lq3jkJ+zvHlCFO3ghjk5x0zx/Kvgfw1qZjMQwArMc7edp59v8AOa+2vg44urm2ZZgFjbfjJLEA9h9BUUrx22OavT0v1PsXxt4gtvDHwu8X6zIYUi03wtc3gZ2AQFYXPzH60V8l/t9eP4fh9+yf441BXeK5161j8P2UZH726e5kEbqoGSflLHjsO/QlfWZPh5Sw8p2Wr7Hxma16EcQoVHql0PA7DSg7KY0CuDtZyhIzgHr9CO/eu70/w40hjfDhyOuzaW59Opr6K8P/AAfkvYmzbxwApuWJ1C7gNvUAZ7fXivVdN+FFsrQWb2m+Un93tBAPIGAAAMcj86v2c6a12eh89z05O8tz4/stFFtKECbyylXDZXbng4P0z3FdNHpLGPCKB8vzEKD1/wD1V9iWXwKRXjZ7bKkk+WQGJO055A7cda6iL4C+cVH2OTDLgKI9pwV69v7p9evFafVmnpuc0Z2Vz4TaHYnkFQZZGwCFBY4PQCr+l6dJPGZBkDJBDKAFxwea6/8AbK+Ht/8ADT4OeKPEvh5107VbKBIoL7eC9szTKAUU/eIGOc4xnrX4raR4r+NktvMyfErxWFkYOc3wKIOcY+Tj7x4Ga4cZB0IKTdn5/ofqfAvh9m3HVKrLK6kFyW+K/V+SZ+2ltZQxRgGJS2MAtFnI9f8APrVmOxRsssZPH3gOAOOcflX422/jT4420RWL4i68jSAKZZmjuHABxlQyEbjz1GKjHxD+OsG1P+Fi+IZHB2k/ZLGN8EDGCsIHpXkxxdO1lufrL+jtxXJX9tTuvOX/AMiftAttDGihSBMDyCvylQBj8etTPaAIH3rjsByOT0r8Uz8UPjkmU/4WD4ieNxscTW1o8inOTtcw7hxxnOPapP8AhbvxmtAw/wCFia/IhGdklhYTvGBzw7QFvxJNT9cXXYmX0feLVe1Wl98v/kT9r4YMhRlTnJznJH1qOWGJlYBiHUE4KEKfTmvxHf42fGvgt8QtYMfQbNL06N14IHIg5/HNMj+P3xogXD/EDUZDuK/vtMssEcYxshU8YPfHPSlDGQ1T26F0vo8cXTk37al/4FJfnE/ZG90yzu7a4trseaksbLtC7gxwcAj6gVz2gLby3kmnKyC5txllXJOCMg56fh161+O9x+0P8a4Izjx/fSEKQvmaPYzKpBwMBoSB1ArnI/2gfi/Bd/bR4yuzeM3zyrZW1qkhwAC6xou4gKFGQQO3PNbLEJux5NbwC4tpO0p0rdPef/yJ+75tJLdizxnA6sAeO9VRGZ5JnjcOIgC4B+7kkfzB/Kvw9l/ac+PxiAt/iPqG4jhJdMsDCvPQnyC5GOOTSx/tKfHhWMqfEW4jLxhJcaJp5kbGTtDGE8AkkemfrmpV56J25UYv6P3GVOnz05Umn/ef+R+xni/w5b6/aC0vAjW0jgSRMBtkypAPPTGchhgg4Nflr8WPDw03XNStVS4WGC5eFDPEY2cA8MM9VOOG7461xMf7TX7QL58rxrAT94rcaPbSBwTwpbZkYBPTn3rStPHXibx3HdP4ouLbUNV2f6Xdxotos6jiICMZ+6MrnODx0rGpjVHRvQ8rHeEnFfDdOOYY6MOW7Wk3fRX25f1PGro+QyowdcsQS3SjaxUEEZ6Dcfw7V0eu2apNygWZJMbSOG4PP+fWufIbcBgkeoGR+PFefPkfwnPSqOL5JrXYyZ7XdIpBxIgyu0kqAwx0ztJwe/SplxGDnJJGAw4/H0q0nmQurbMMTlQw5AqKdi78j5jkj+6OeapxWxEHJ6paGSWZYkAYM2c9RkfhWbeXT+anzDGQMKCioOOv9ce1WLiQxocLuBXDgLyPpWTKYidzMVz8zEHk47H9apvl0OGyeh2cV7GkSkBGz91hy4461uWmqKihdxBIxuJyOleVTXyxsMyhUDYBLAH8u3SqbeNdMtFmaW7iKW8ZkZdwDtj+Ec4zSjUi0md8qNTnb6Ht9vebt580D5SvPJ/H/Gsy81rTdOV5LiaNFDbXZjtIJz/ga+a9d+O3hixtmk0/U4p50iYiFCM7gMjJP5fjXietfGg62yCcT7JD++CrtgAAwoUf5616VOonDlS2M6d4Ttf3bn0z4t+J/mXRhtIp2totyxMm3ErKcZPt0x9K8cufFct7dSSzbg5Ytl33DJ7AdcDivN4PFv2iVwGfy2BCxFSdwzxnNRXOomVsqHQ7iSCu79av2l1dbH2WHdOdkk7eR75pXiTTp4WgkWSNxGCDlWRj7D3ritY112uXSJoyEfbmMZZfbj+Vee2+sG3jaQyOXY7RmM/48dazbnU7NA3m3Lbm/eDYMsxz0xnqaIzT99na6cY6M9h0bxtfaTIJIZQ6MB5kJIAP1x06167o3xWs3SOLypRdOQpVuYVyePmr4+tvFljDFPDbwtdTlANsv8JGew5/yKqWfjB5HltbaynSYDH2jaQB04HbjnHFHNKonzbGGIpqMLR2P0Jg8a2N+8VskZaQgl5ZNqwpgZ59M8gVI9/DcxOyHypUBVyH3LnoCDjoa/O6bxhrumXKyxXVzMUPMJbDEZyMnv3rqtN+I/ji9jYRM8cM8ylQImZ8KcFQeOvH+TUzXLHmjpY+Fq0p1JNx+Z9l3t/Z2qGSe4SJicAyOBuY9gKdZXxuFZwu6NzhXT5gfoe3/wBevlO81DW7i6ga7dpnikEkaOTtV/UgHnr+td54d8Tajaq8F0ZGKPvJC4XnPBH515fO3Nym9WdUIxirwPdJN4miEchCtn8/c/8A6q1rVWcksC5wBtx179R9K4XS9Ue+e1EbYQkM4KZcc/d59sivSrKB8IQMZHzE8H6frWcUua7ZnOXNJvqbWmQSYJdicnCqf4ME9Pzr0LSUZGILAk9Bt5IHoe/WuXsLYDkgMpOVA4Iz3/WursUdpowqDcn3XJCk5Pqcccc1uqfMtiqk0rpbnsmgSoqoGyW3BwW2jGSSOPxP1r7O+DmoRieGP92wZwg3Nh1BDcDn618R6OxJiRiI2LBN+SGGOmMfUfmK+sPAF1baTpV9rd4WistDs3vri6ZhGnyoWbcf9kDPFaUqKb5ev/BOHFtKN1/Wh8k/8FW/jGl/L4E+Eq3Qkg063Pim9VDllmO6KBG5wAB5h7nJFFfkf+0n8XL74s/FXxf4yneeS3n1CTTdCU5EcNnA7LGwyM/Py3vnqetFfo+XYVUcHCKXQ/JszrKpjJykf6APh34WgKNtsVdjsZtmFH0PX1r1nQ/hQJphG8KBFKnLLuDFeRkY56Z6HmvobRtBtYY9xhChMheO+c5x+NdNbWUUJbYABnIIHze+TWjo803Oex4salNKx5vYfDKxgVjKkZcAIDgjaO+OOPTv1610cXgjTUUqsSElMZKgnPr0+ldwSWAAXj2FSYA6AD8KmMYOFlsdsqs9mfjp/wAFX/DsGkfs5TuF8ttb8Xado0QiAjD7rgTOCOpykDd/4j1r8HvDvhWGKwgLgBQuF8xA+eDk4xj16+lfvV/wWM1dbf4P/CTQSqsdc+LMc8gkXKCO00+5ZiG7NmZcdjX5MeE9KaSzsY7W0F5MyokECReZPI3IVVXuTjPHrmvguM8wo4WjDCwb5opyfa1n17/I/wBBvom5ZTxPCOLzGW6nNO+2jR5fYfCtNU0DXPEyXax23h+GK4uLQWzSy3HmEghXGAu0FW5ODn8/PbvRNNtgtwYJCGIQERyOilsAZABx1HXGK/Vfw5ZNpWhv8N5xogu/FOmXF3rp+wfbDbCa2kjiKOcLlWiGThj8p6ZBrwjQmg+H/ibWIPFthpl5LEjWqWMFrBf2cieaxjn2MApDhcbWA6HpyK/HsLxbH2tdSV2tvRf8HqftuGx/tq+JgoX5VeCUvijqrr3VbVNddNeqPivW/BwtdGsNYe1YxajO1tEfLbgoCTzjGMgrye3vXDyeGpJmVTYPnjIaEnA5OTwfX9a/Xzx98TvDNp4X0KyvdKtpbXX9Hzo1h/Y1qscOxI2+5t2oTvTABI44r548F+C/DFzYa1rvivVDK9xqogi8kXBa3M5LIAsYyzfMP7wUDnAHOGG42Tw9WvVoyVtvPfb06nLQzPEVKFWtiMPyqN7K972vptvofA3ij4XappFlDqV1aqtjcwwywyiNon3znasTIQGDggcY6OvArgLjwFfySWivasovh/owK5D/ADeX6+uPzr9FvjgfCr6YNEg1GZ9dV7a/tInsbhbQFVUoJJljaMZjJJViCAytgZBrkIPhpoyTaTqHie9EMtrYWlrYwW0zJFNdPPLL5RVVDHLPGNwIBHU9a56PGsqeF+s4hWlJu1k3te3VfN/gePTz2FHCe3xEdZN2VtfI/PbxZ8OdQ8NXCQ3qoftOZLeSBt8brtBI5weC2Og6V51L4VumczLDNIjH5o4YZJpH542hQT3r7S+M1jol3rkMdjeM8tkJbO4hdSI4W3KylQ3JLD+IZGFHPNcz8PJNP03VjFLFDJJeNDZiSRQy25aXarDdwOXGTxgCvosDxFiKuUvHunefK3a1tr/oevHEVqmV/X1T96zdnp3PnS6+Hetaatu80QeK7hE0KxRyu8S4GRJ8gUHJ6AnoeeKq23hOW8lMMMbs2AEUALlumP0/Wvsnxl4pk0ewnttRs3tbu4vZrHTgqHMwj5E3OeNoPrnA454878DaXcXOu2syxF4zMk1wxGYo1EiE7pCMDOcevOe1cmS8TV8VRqVsZBR5dmrtPXz/AKZw5PmNTGYeVTFU+W2zT3/4Y8Xh8NtFI1s0TmRCVbcMEHkH+td9oPgq7tL027XEEbS2yzshByEYMygkgf3ScD0613154cjj8Zara2MYCXGuFbQne8TPOsUhbedx2+bO4J7bW6Ace7aR8LYbq+1W7vdXhsSujx29tBE0TsyNFMJJHGQ4EbHIJ5xnPpU5vxTDAQpVJ2tPyb7dD0s8r4ZYJYeuk41E01a+6sfF3ibw/cJJFcSQx+TJAGSRSdxOOAOoIIGeuea82uLLyZnUllGSVPQg19fan4Ut1eXQopBM1mXht5zCYVBQj5lUjjIOMEf0r568SaF9jnljfLSRsVYnPK5GAB0Oc5r7XJcb9dwsa0GtUntbc/iTjXh2eRZlJ00/ZyfMna2+pw0kcbNkyklD/GjKwDAH7xXafwJqnJCzMx3BiDkAt0H0q/tRmOFCgHgdNv41AygFsZJPfoTj3ruqJqN4niUqyn7vYx5VwvzAEYyQDgN+deZa5NNHMxViFzwoUBQM8dO/+NetiJpI5DsDKoJbOMk+36/lXl2uW4a8cKxzuJAGMgDHB455yalSbsVzyqK0NjynUprmRtyvJkfKoR9u4EcnA/Af/rNcLf8Aha6v7adFklgikyd6HdLk16/d6dgo6LuB4IwS316Ugg8kbXXKv2x+X41b5eXsZJaXifImqfCHUbm5ie0cyoWP2md1KhFA64xjPFU4/A+o2M4j2PLarwk7KSGwPSvtuzsVkUoYhsHONnXjk/hitGfwrYXiRs6KgjBICxhRk1cK0oxshc0k7o+MtM0ZUuFAJL5ClTyoxn/HtXpVp4IgvAJWJLMMAjGB9eK9duvhdpTSm6gmnhmOGCR42Oc8sc9Cfals/Dd1ZEoJi3lnCqH2pjoNx9TitadRuKZ7GExMV8R5RL8NWkZWkuFS22jei/LIM49/cU5fhnYRMHBLDdlDKnmMD0/nXuX2WeOPZKsYAbK45J+nIpfs1w8n7gKAV5AQKoxnJ/8ArinOpJK8Uez7ahK84NfdqePWPw802yc3M1lBI6ncrmPqff1qbU/DUGx/sdskbO2XWKPg8fy/xr042F9JKsZDeVkD7uVXJwK6PTNAty8pnfzuBsG0KVPfJ5z/APWrF1Fzc0jlq4qjVi4QV9Ox846f8OrzVJFY27W6yEqJJIiRn2H1r1DS/AUOmW0aSsjTwjA2geWeep9+P0r1JrM/KtuiqqN8oxgjr/jWolrLsQkKvO1juHUf/rqqtaVe0mz5dwjB3lueUPo6um0wxqd2BIqgsp6/1/WsmTw43mNIkhQqMtgZyOvXrXtV3ZYi8xEG1U+YH7x9OK59bRnYl418wkhsLhWBPGeP51hazcludDqcvxbGRoEYiMa8bYVC5xkke/v3/CvaNPljmRCvGV6P8pbFed29kFk2siqRgYXAJxng8dM13dghUJGqjlSFJGABx3qqdpbnLUrXT5Uzq7ZSyqAQAPl5UlhXaadas7IQ4DkYU4OT1I+nauS0tGwoZN/zYYgFgc8GvVNHsvLKMuS0mOAM/TAr0aNnZHh1pyk+a2vXQ7XQ9GupvshixJKdsaRN3OB/+r8a8X/bS+Ot18LPhx/wr3wrcBfFPim3Y6osbFlsLdE/eu/fLFtqg9QT7g+xav440X4a+GtR8X+JLm3sotMgaS2ilJDSS7SUGOp55yPSvwK+L3xb174jePfEHirVbppk1W5cWcBJCWtvk7UCk9eck+uea+hyjBKpVVersunnfQ+cznMIRpuFN+91MzU9dvNXP2i6EKs0QUiICKMAADIHUdM0V5rcauEZVO8xk425IVc9aK+sdVJ2Z8XNTnLnvuf68MUaRgIvyjHOMAVKB8xCnjHXrRuBUjofT8aVAQSSCOO9RTlCTcoHBLm+0WxgYXPIGaU8An0opjuAG9QPpmoO0/FL/grzcx3Vp+z7oMoWRG8U6tq8ymPdhYrGJBk5wAS69vxr87/AFxb6NNp+pCNZJbRvtUCMeNyqcAdOuWH41/Rn8WfgF8HPjZd6dd/FHwjL4luNEhkt9KLazqWlJaiUqZAi288aktsXJOSQg7VwFp+wr+y5bSwXVr8NWhmgYSQu3inWJWQg7gcPdMOvPPrXynE3DM88k/ZTtK3K7vS3l2erP6Y8HPHrh3wy4LrcMZll9WrUqznNzg4JWkrJWbT0W769kfltqUy2Gqa1r/2WKS907wMt/AXO5NyNdyBc4BGc7OD0H5fONr4r01fFuoeLNb0JtdEpLTaQipeRuSiRxhVkG3auwt3OSTX9CWp/st/BjUbeeC68O6i0VzarY3CR+I9QjWeFclYmAmHyjJOOnJ9a4+0/Yn/Z/wBMMjaR4f1vS3lx5jQeJry63YJYcTvIBgnOAAK/NaPhJHCynD22rW9797LY/Q8B9JvhLD4etGrgq7lOPLGyirR10b57rfofhV8Q/iZpPiDS5dMuvhvf2FzdaUE0zVLiO0vn0iKZngSUc7oCpD8JyuMkDAwngXUtOsvDMtrLbTyPq99cXMchjQwW4ttOjlJOWJABiY8DOWJ9K/ZH4i/sbfAe40HWY7tvE9tK2jTRRqNaWZWVA8oTY6Fiu5zkKQf3h5FfzLfBf43eLPFfxh8VfDWfQifDWh3+q6foN/bWbN5MJurrT0uLlyCQXVPLJBAODmvms/8ADmrlOS1ZYeSkldyfN2XRP9D1eHfHDh/iK+U4ahUpyk1um99FrzPW/l5nv3xzn0/T7vwvp5F0J7m+/tKZ7dzG6xRwxIgZyVOxvMVmwccDpwK7i1htrrTHa5WS4uI/s32aS63meJ44YrgSqzDJz5keMZxtPOa5D4seH49S8caNrGs3CNpt7NaeFoYjMY0EZJeWUnPygqSCTj/Vjrwa9Ajl0+/htZtNkglEkR8ncxVmVD5TEKeSB5TLux0B5wTX4zj6tOnl9HDu7lFu/r19T9LzGvh5ZbQjG7bb1Phr4tw26eMfKhiSJYtOjkuJoY9nnyyvI2Hf+IhcHJyRvFX/AIe+DdE1G7Go6tdTmO0lSY2MLLCbnByAxb7y5HReTtIzUfxf0+bT/G11FOIZbm+so9UVoHLiGJnkto0JIDAgWu7HT5yBWV4HWc63Zfui/krNcuxUtsSKF3JLfw524ye5xX6nhW58HU1hari+Xddd9L9Ox9VQpSnwxTp0J2XLv9+mp6D8RNJ0Lx/p2oeK7eW/sh4cWUw2sjAhTADFMGQblO7Y5Dbt3zDnAxVXTc6b8Ob6OG58uZrGW+hmdcAEKoRiRkhMhc9sE1yOqyzpo+hx2lw9rZ6vPe3V40bfJcr9pcANxkgHGdvXAHPFd49vZ6zot3p9gXvYv+EXtrC5MNsxl82aSSOQKu0HARIu38fOK+Rw1LF4fArmleDd99Ek7/nc8jCYTFYTCpTleLfqkk+9luzk762Emk+DL21aSC9ine3vrzT2aEzMgM0J3qFJyCo/4Ea+iNL8OBru41GaW5lkltV02OSaTzbR42hR2xGcjAaWQHI5Kt15rxzX7O10E6P4VtWll1G3EWsy3DwB0hWVCnlPnPUqy4xlduflyAfoPRNQuhE9u0cUSw+ILKysZGXcZ1Vba6u15B6RtJFyOpxXDm9R1KVOcNm2dGYUp1KcJx2voeD/ABSs5bPxrc2VmgiSezhviQio0hkDJnb2H7oDIABwa8i+JegRabcWweaPF5YLPIhwzROVCs24nkMQ2BjgAZPTPsOuajcePfHkt1Hbn7PYb9Hmlj/dwJbWs8odw33Rklzu9XHpX5oftL/tX6FpfxPkj0OGTVfDlnAdPlS1ljE900EjIzRAgHbwzDnBJJHXJ/UeBaOa5hCjgMOtIK877JdNT8u8YM3yrKsgoUswcfrH2YprmfNp69b9FbqdvNBtkfaBHsXBBOM8/Ssok7mGRgngDr+NZXh7xxoPjjS7bWvDt+t9Y3cYckfLPbPjDRyr1V16FTzWlJKqFmkjdlC8FULbuOnFfpVXD1aEnTrqzXY/lmOMwtT+E38/Mo3t2YomVJWQldoK5jYZP/164+W0Msm8lyzHrnkfma3bsNNlyPlyMAHOP88VHEoc4IPAx8wx/npXO5KTszuhU5fci9TJNmFwvlrluMOODT/7Miz85j3AZIcfKvpjiuja1XO7IJ24wH5P6e9QCNPMYFQ27CjceeegH+e9cNTmhK8tmejGrK13sYUMMUaBAV35JGzaCf0zitYWzEbmII5IUjOP85pWtIm2SNFGWj3eWx6ruUhsduQSPxq9C8SMySKzkDhVHHB/z2rojUnsiIVLqz39BkdsoiDbssF/iOee4Ht/hWFcQxCSQ53MGyQVPHfk11FxFNMI5DtSMfu41yASQATx17frWdd28sNuTh2aTjpnqQK1hLlVn1O6nBuV4o468EcpXeoy3yBwOV+h7VnrbQoSRIFJH3SeD6Vqvbz4YlVxnGAoOP8ADp69qhEchGChI/vYJxWrfIlYUY1HqlYSz2OuQwQbsOSoXcR6810lpGio21iwbjOzDIfr0rAsElUOJEJQn5AAeldBa27KwchsbuQVyR+FKpLRNnHXjNu76m5bqWVmKMoHOQPnY57VJdTSR4UQkhhgtnJfB4rUsoWdgWUrsGAM8GtJrMOThFJIzs2ZDf5/pXFBKV5o6Zyv7qZgS2rtbK+MAgFkZcZ69f1rP+yM7lYxgKu4jBA+grt1s2mj8podmB8r8gDAPHA9qLLSyZcMjHI4IGc/jV86ilTl8jnk0lrucI9pK7xPgo6HO719QTXUaXAjOiNIDLsMmzByFyBkdutdJJo0QUDy1b5s/MApHOa17KyWHaqoucbSw9DXoU6aur7Hz9ao6SunoaWm2pCRlGAyR947RivXNG0uWK2huPKkm8sNPKqLu2hcnPHtmuAtUe1iknVVgiQeY80xCJgdTn065NL8JfipFrXj6LQbeM3HhmW3uIm1NIjKbi4RsFMZwExvwf8AZ/GvXy3AyxM3KmtOup5maZl9Xg3FXf8AwD8jf2z/ANqR/H3jm78C6TNLY+HPC0nlTWbkpJqc5yQ7qcFRgdCM4avhF/E00rbpH8uMk8IDI4+mOe3pX3P/AMFEP2dNF8D+PL74s+A7y31Twj4t1KRPEFvDdRyXHhjUmcK8U+G+VHJymQACCvPFfmw97BYnySUu2dNwkhIfy+2054z1r7PDQo0YKED4SriamIvOW7O3i1ktwCW2sQrAZDn7vIOO+KK86luLiRlYHAC/wjaQOx4orrMlTqLdH+z7VjIPQg1wtt8TPh1emFbLxt4Ru3nUNFHbeIrKaRtwyMASe/auhg1vSJmPlappsit8ylL2N8j8G9xXLSwuIheU42+//I8WWNw7ko86v5Nf5mjTADvY9eMcCo1uI5AGhkjkU/xIwYfpUijLFuhIHPr/AJzW8lVTurWOSFSE21F7FpgpXkkYOc4yK/nf+Kv/AAW517Tfjh46+H/wp+F+keJfCfgzX7vwpaareveTaprtxZzNDcToIiYxHuhkIUhSFIJY1/QVr9x9j0TVbv8A59rGS46Z+4pb+lf5mniSa58SeOPGuvvqusWJ1Dxvq2pK+k6jNp0gW4vp3xgMCoKkrg8/Mck8114PCqtTlVavbT8Dvr4tUasab6n9P+q/8F0viNp95Bp178I/C2mj5hqEt9HqgntsbTkbSEAAD7txGOueDX7rfsv/AB4i/aQ+C3g74uafp8Wmf2+lzFc2MbvLbLJbXU1qXiLANsfyQ67uQHwc4yf85R9HaKSe5i1/xMYRERJHeatc3kcpyPvJvYANgR8ADkZB5r/QC/4Jj+Hz4d/Yl+A9m8TRtc+Fn1EhgRvE+oXskbH3KFCfrWOLVKlGNlZs6qblOm5vY98+NMmlWXg3X9e1K1zqljotxFZX0cTsbRZAvmqCPlGQmDuyfTrX8XP/AATd8T3Xirxv8dPE11LPc27QHyBO+ZIUm1S7mHB6blIJAwc9q/sP/bb8QN4W/Zj+M+vwzra3GhfDTW9Ztp3fy0iks9KvLqMlu3zQLX8Y/wDwTCkg0vw78adXvBLCtxDYxq20yCb5JZnVfVizjaq8kdvXx85owrZJXhJatxS+e/4H6L4e4ihh8wqSqN3tH8z3C9/aAT4l3ep6X9mitH8I6/d2huYSAs7RzzwRsELEkiNMEtg8txXVW3xHuorqS9hX7K/9lJptkI2CvaAGcO8eCcbhIO+QQc9BXgvwz/Yw/bE+267rHh74Ja1rWlavq0+oW88Gq2cdy8Mk8kwc25l8w8TDqvJOK+jH/Zd/aA0q1WTW/hN4/wBLkIDkzeHbp0wD8w3KjDv14HIr8ZzbgHCYqq6vIpKX95b6X0t5H+g3B/EnAM8koYPEYyl7RKzi5xTV7XveXf8A4Y8r8ceIH8UaxLq7XBjuZNOi06JyFkSERmSRWKtkHDTPweoHarWleKo9G8P69plshiv9cihtk1NLeJZbONGLSBTj+MFlxjAzWrdfCr4h6azpd+DvFcADlUNx4bvolcZ4IPknvj2965u4+H/jOVmMfh3WZlUgYi02eVnz6KFyDkkc45xTp8Lung45bTpv2cel3/kfZPOOFPqsMJSxlPkWyVSG26+15lXXdbsL3SvD2laatzCugWUtnM8+0GdpZFkLLjk9DzgZrq/AHxAfwXJdzCzj1JrqJFWKSTyVj2ls/NgnkHHQ/hmuXbwF4tDywt4e1pJVTAjGkXTSE5IwVEZ5GCcf/Wqq/gXxfaB7ufSLq1t1BkllvYHshGi/ecq6ggDIGegLCuSfB9KWGlhalJyhLR6vvfpHQ7K+O4TqYT6vicXS5Ov7yG2/SR1k3jCTWvEtxruqQxW9vc3qSm2hwXigVow0YY9W2q2OnzNmvUb/AOLyG9kbTLGBLGysZYdPdIsXFzczQlWnlViNgBbkJ82VPLA5r52SfT7eS1s5D/aN5MNxttPR7p42CklSQu0HGepGBXoFtZxaZfeHtM1PQvEFvrfirVv7J0HTbnTEkEjhkjMlwwf5It0qEMOWAbgYOO2PhosRSpOVBqEdI+9bT9fuPzLiPxa8I8hoeylmEZzpqyhT9+Wzsvd7tWu36nrfwv8ADsGoeC/GGp6zbRvp+pxPo025ykl0JWDyHg/cYmQEnrjvmvzv/as+A3w41+wnNh4Y0jR9QFuVstT0mxjsr1ZFUKoJRQWxsH3gR9a/U3x3qq6Bb2PhfT4BZWWn2kcM8cA+zxvcH55iUXAb5zuJOfmYk818f/FvSI9R0ppiX3xxyMp8vzFb92xUAdix+X3yK/RcgyqnktJQo3vaz100P4k8SeMavHufVM1pQ5aF/cT+JRiuVL7le3S5/M5pnxs8X/s+/FjV9ASGO80mGcHV9OWQbbyHOFlIOAJsc5GOuCK/T/4c/GXw38UNDGreHdStprUBfOtidl7A7D7rITx0PXuK/Gf9sYyab8ePFMZJVBaQLFsHzDI53c8dAP8AgPevXP2FtUK6x4yhT5muYbaRGVVVITHufk4+8TITjnPrxXRnFKFTD+3+0tT4jKKv7+NF7M/X1b9HjWJAzORhn4A/wq/bRISxExLMMAEgD/PWvKrfV2txsO5ogAAzLiRiTznGRW7a6yokVhJ1wQCcZr42aU7H2sPcdonfKAo4znHIJO7Haodo3uGbl+FDkFTntj/PSqtvqMc0ZL/eI4IIy3WpYopJDu3M5xkgfqCP89Kfs5K9zppVUulzYJVECgjcOCAeT6cf41qWMKSyKzxoxHykgZbGeMn8axFEiyEkMCvUEYJHUZNdTp4GFIfgnB55Oa5I0+V8y2PfjLmba2NwaVZbRI6RHyh1AVypIHQj64OKJNPsmikUhRwAvIz3FNWfy1ITncMbcYI6HHHWp4U83c2SODyV46ZwOeo/rWqn7qsEKvs0nHc5d9ItixwAQRhiP4vr7/41Tl0PYw2KRG3XJBI59f8APSuim2RyyKWUAnBwMD8aSVI1XexySMrg8D2rSHK3d7nowxKnDmqbrp/TMCPR4Vi3napC9+B9P1q7BbxxuY0VGGMgjpnHOKes/wC8WMMNvRucrzzn3q3CgMoO9gxx1OIx0/E9xjp+NDUVsefVr+1pqNiaCEf6t4wq4wWGRn2z0/8A1VYPlo22Mb3GOhy2Mf8A1v1qdlKEM3I9uee9Rm38yXcp4YZORyKG4pXR5dR8ur6mza2Y8hAcMWAJVh6881tWenQwsbiTaqqejLtY4GcD9Pb+VUrCJTEom+UIuAGHP4flRqWtxWUDRRocv8qbW69Mk1nbndzjlD3Uo7FfVGDTqUclWYkrGmMZ9T+JFXLd44kd5Mqq/MS33Rjk4rg38QW1v5lxeTiGFGzJK5ysfXP/AOqvH/E/xKe/a5j029MWnQEqLlPkMnGTnv0IOPet6TfMreX5nFWhywc/J/kc/wDGn4632t3cfhDwq80NjZTmLVLuOMxPd7M/Ie4Xjp3r1H9kxJ5PEMTTNbpaW8i+WxuMyK7byVCYPy8n5iwOQBivzX+F/iafxX+0vqvw4vLi7u7PxddJNps8ahXtWWNpplwd2DtyuenyDj0/q1/Zt/Yj+F1x8P8A7Snhs2viCHTxdQau1zIGeXaXG/btJycdDx0r9KyFKlSftNnt82fm2dYunUmox/I/mk+LesLpv7VfxQ+FuuGDUvBPjzWsahb3zmWzgXULbz4Z4znCiMuAHHTrnjNfmt8RPA158PvHuveEdWXyGtLx5dIuHIVL6zaRhBLuwNxIBUn+9Gw65x9r/wDBQO2u/C37Y/ivT4ppLeKGysUDQkiQKsUajnP3lCg/Wv0E8B+Lv2YviN8EfAfhX9pD4aL4l1trRtN0vx/Y20R8SR/Ki+W98HinReBIFMjISfmXjn6KWFpzpKdn30/X+mcc66gldaH891zdG23RbEYofKDHO4YJB/zn1or9cfiJ/wAEzvAvjGc6j+zd8e/DljHds0kHgv4wZ0C7sSWLmGO/iik887nKqDGv3T8/BwVMMFUlHm/X/gGf1ui9b/gz+7Pwp+wn8BdQa0gtPjFq2sX+dkX2PV9KN4525JCom7PJ5ySMY6V19x/wTj+F6tFJpfxV8d6NIMlbyx1uOG4iIIOVlGMYPODnoOle0eCtA+DHhK4OraL4Rj0zUY4mxeoJ7p4wwIbbvZuSMj5RnBxnmvbdL8G/Dfxrpq3zWU13bTsVMEmoXunKzKTuZrfenOSeSpBzXsPiziCL5vrUvujb7uWx8TS4I4WqRaeFS06SmvxUz5b+FH7DV/8ADHx5ovjPTP2h/il4n0uwuTdz+Hdc1x7rSrxSjADYkgQjJQ/OrcL+I/QoSKoCFwMALnpWL4e0DSPC2k2ug6Daiy0uzLi2tvPkufK8yR5n+dyzHLux5J68cACuB+L+u+J/CfhiTXvDl/p8M9vcwW00OoWjXAb7RPHArIRIoypkB2kHPPI7/P5vnmMzOqquYT55RVk+WK0/7dUV+B9FkeSZdlcZ0MvhyRk725pS1/7ecrffY9Kn+zTQSW8rpJFPG0ci7uGVgVYcdMg1+ZEv/BG3/gnRfTTXs/wDM1zdyNPczn4ieJ0aaRjlnKjUAuSTngY9q7K5+MPx0IjFt4k8LfJuZ2ufDjNuBwRkLOAccjtmuU1L46ftJQR7rXxB4ATYuCT4VubjzScDp9sG3v0LZyOlebRzqthZNUajjffluvyOyWX06i5pxuzk/EP/AASN/wCCb3g61XxNc/Ba8sbfQ3F/Itr451+/afacBWjlu3JGWA2rivrz4f8Axb+H2heHdG8FfD/wX4sTw34S0yDRNK0/StDkmg021gQRwRjHYKmASedp5JzXxVqn7Q/7TLWywx6n8OLtkA+XUfDl4YpzxliFmbHr0P1rEi/aP/aRskkiurf4eXJlO9pbDRbyNEAUnAQyqSfy6+3LxGd1a0I89Rykv5rv7hUcLCnsreh6T/wU7+J0UH7BXx91iWw1HQZNR+HuqaRbWmtQC1uZTd2c1qQ0W7ONsjHGeQTX8UX/AATi+PGr+I/j74O+ENmLK90rxx4g07RdcjsoQ2kyeWyvLerIw3AxxKBgDaTAcnGMf1GftKW/xP8A2vvhT4y+CfxB1DT/AA54R8b6Yuj3eq+H4JjqemDzEZpYllJj3lA6jI4L5JIG0/nl+y3/AMEcvhv+zB8TdG+KWhfFjxzr99oolNrZaxptgrN50E8OVmhVShHmhs4JOCOM1nLG5ficulRxj/fdFZ2/U9GLxlDFe0w+ita/9WP6W9M1Ky0bTLb+xobCKeO1WJI4SE+6uArlTkAng9xmvR/A+uS6n9obWEjtpFTPkiUzxHDEH73XIwfxr8x/gH4C8R+ANb8UJaeIvH/xNvPEl4l3BpupTy6mNFUPI2Izu2Ip81R/CAFXgDmv1P8ABPwwuktVu/FLi2e4CyGws7g7owR92WYYIbLHOw4+UfMcmvLhRpqKp0/e87WDmkm5VNH5HjPxzs9En07StR/tEWIstWhkvI4o3VLmIzRBlZQM4A3cqBkZHeu0v/H37POl2yDVNa+HtpKiZSCWG0W7kDDcuIyu4kg5H+9nmvcbjwf4Wns5dObS7C7t5/luI7yCO8WcZziQuCW5APzZ5FfkR+2R8N/2ZfhXrS+IbrWdWbxdql0ZLjwdp2qiHSLddoRXaOLbKj7miIjDktkkrzmvawmWRqyUKja9LP8Ay+88atms6OlNvTza/XU9e+N/7U/wx0bwzqOh/B2w8P6p4tvo5LUeIpNDiGl+HVKbjOA64ml+ZQiKCgI3OcAK34h/FbxBa3c9/rPj7WNV1/VWO63a81gaRoIO0uRJEDt4O0/KrDHvivNfij8ZPBHg6HUr3UJX0qzkZ5tP0uSSQGd5CI5JJ2Dbj97AUFztRQAM8fln8R/2rbbUdQ1S8fRrLxehuGi0+HXXns9A0+AEgRw2TqdxOFJd8M5JJxwB7NDKHRVsPG8u79NthTzHF1HzSlo+mv8Anufqf8OviR8JrOY6xqviPw/4as7a8MgsLBFS31efGWyRE0kiLkhpCArMrHOBx758NEHxZ+MknijQvFlrqXhHwhox1YCxZHgEzBrWKFjHwP8AWPL+9y3y8DaDj+a7V/2r/Fc5S103wb4YMG5beG0hRrd4A5EflxnOxV+bAHTA6V+vXwW+P9/+z58ApF0rwtDc+OvGm3X9fMqBbTTwQkcVqpBDFVicbjgYOcdSRyYnC4qk7Vfi7XO6hX9pN8q0Pp74zai114puPLLoEmMUePlWT7uW5554/ADrXj3jW2P/AAjcplcO5gUgdNhZhg49v0xXzdoH7Yvhzxhq8qePY28L3v2lR9qWKW+0+YuCW5C5TacZGCORz2HXeO/2ifg7/YMvl+MILhZEaESQWdwYIXKnAZmQKpIDEbmxwK8OvSqRqLnWp61CdoqMj+Yz9u+wu7X9oLWpmAjg1HSYTGASWkaOSVXIxxj507/4Vf8A2L7+50fxl4gtzI5S90VLox9Y/MjkKq27JxlSRjjhPaov2x9ctPGPxNt/EWmDzrRbeewlnUBzd7JtySfKSOc9cnvjPbnfgXqY0vxfp00ghRGQRMSxR8MyIcgHkAMWwc8A8V5ubxTw0oPtp9x7uUpLHRaP2Us8X1tHLGFUvCHKFNyowJzwcjsKyZGurS4Ab54xkq+wjIHGP17Vj+FNZS4ggO75Wh38HKgAEgD+X4127xxXaBdwJbBUlQAMDFfnkW4vkkfplN3vG2iRWs/FEcLeWzMDnrg5BPXrXeWfiW23xKJTkjG8A7c+/wCXWvJb/TJ4kf5o3jz8rLhymOmOKo2moSwyqpTDLgMVGI+D1GP5AV1xvzWjqYKSb5enQ95ivUuSJDIoJPK9GNdLa6hFHGEDbTgAHHP1r5/h8RPGwYKY9p+bByTn8PeuptvESTqgVyjlcnPBJHf2zXRVSueTaTeh6y104cHzdpZs5B34rXF/IiALKdrA4Oegz2/SvJo/Etn5aJKxeUNjKsMVsw+I7YlUWXcjfcDEK/0x+H6UQ5OVQ6+ZspSirNHpbRZQyqxYZ5H3WGO9M8zeMB9y4PBO4VzT+IowhjD4U4J5yBx1FMj1i1hy6yli5y+0lh+XQfWuWc5aRZ7rvdo6RJoyyheG7npzzVtLqRWGw5GMcDIPA7VyQ1qxIdtkZfqrMSu3rTE1+3ebLTKEA+fkYUjv+VS1CWhSbku56PHO0ilpHGDwBtDAAVorKgCtEyk4wWA2/nXld1480azjXFynL7CxUsScHoQD+eK851b4m3KNLHYedDGJdySq4CzKOjdcjnPBHp0q5wTSi9Hcyi5xm3JaM961PxbZ6ZDI1wxxGCSFI7DJ7/r7ivFvE3xIDmc2M8Ut3JGHgiJ+RAeBn8s/WvDtc8V6lqE7mSWRUcYcAlWkLfe3H/CsS2gvr64WTAhhYCMzM21SM857nGM4FWotysc83JLXY79Nd1PxHfC1uxKsCJvmKHZaqQfvE5wSRnA68flwPjPV7LwvZXLgRxWMCGaYO4VYgAoLHPGOFGT7VtXuoJpEAWGdAQpkLgg7ieCSO3oAeeK+bPG8upfEy9sPh7pEks1/4iv47Aw2y/aHYO4GWxzwvzHB7cnmvWwFKVeoqcVZf8E8PMJqnQk723/I+vf+CZ3wLuviZ8aL74y31iLjSNIju49Iu5YTi8mnl2ltx6KsbOoIr+yD4WzWXhfwSsl6osCLYTNC3zbTyGycYxgDmvyn/Ym/Z8tfgt8O/COhRRukVjpaR3QQKY5S2wu0jY5PyZzn15xX3B8R/HtnYaBe2CXCxu8flrBvxIDtYqCo7fLnJ9K+zwlGVOdpeS3Pz7ETUpup1Z/G7/wUN8JT/E//AIKE+NtLsnEel6tfRR+fHJviiVHZp40YeixsAe9fU3jn9nnR9M/Z41fxFY3F9BD4f0RdQMDOZ1eJZIJJJgSNythCcZxgV5bIYPGn7RfxK8YvClxPF4surOIthvKjVpY/kbHVmQd+jN61+k9l4K1P4j/s9+J/B+nQ21xd+KfD97oM+nm+islUSW0kARZHXaMO33m4JA+lfZYetOmoxi7LT8z47EqM5+0qX8j8c/BPxlsvDdxp8M8F3N4ZjRMTIj3l1EOGDque2SxxjODgc0V9v+Fv+CXXxN1TTreTUPip8FdFvUJC6LeXd9czB0+UJKsUTx5IBOI8gbGyBwKK9mOJwVtZ6hKpK/urT0P7p4Nf0CPy7a60o27xyKrFpgGO3DqdyvznrgnPy817H4R17wKLYRpexabcmXfJbXWpbfNbaihgrPgDaigbT/CRjivE9P8AFKJGWl0i0ILApJPbjDAY9R14/wA4r1Lwze+Hbu6hur7RtJhvQ4isriOzRpl3kAlW25GSzDg9B9a+ScOa1zyo1KUJbn0TbtG0cUiPlGUMCTuzx614P+0jqAtPBFnZIuZNa8QWsCMTgJ9mLXmQO/8Ax749ea92tkUwoiqQFGBjvjIr5a/aku1Gn+ELLzQpk1W5vNgcK+6G28teP+3hh+NeBjOb2soy3X+R9NT5asVKmfBvxb+L1v8ACjRItcu9OvtZWe/tdMt9P00r9uupbq4ht0CBiF+UzBjk9Aa93tfhL8ftRtI7k/D/AEa2FxAsq2d74mtor2AOoOyReVDjoQDwc8nrXxN8bFj1zxr8AfC9zC17Br/xv0O1vbfy/NV7ZLq3a4z2wBgnOeFPHFftR8Xfj58IfgZ4fbX/AIl+OtE8MQHMVna3M5utUvZAHwkVnEGmcZQgsq7VwcsK4cPgVXjF2vJ/8MejKsqdNcx8RzfBD43rHJLP8PdPiYA+WkfiqwnZjzwBvX2xk15CtxrEPiPXvCHiHw63h7XvD0NvPeWstzDdiRLnd5TRyRsVbhSTz2q3cf8ABWTwDr13PpfgbUPCry2arHe6n4nttQ0m3kzkNNAHXy2jOMgiQnDLkDIr4++KP7bPw/svEPiTx9PrGgeJvEGtwWtndWGhTBQwtg0EHlqWAAG5ixLc5Y5649BZNe8HCSn+Hl0F9cVlKTVj680rw3qevzta6LYG+vywRLaHYJHyQvJYqqgdyzAAAknive9K+Ffw68JwWuo/GX4k+HNEUZaTR18QRaZYRYPyrNeblYnG0sqsFByMsOT/ADBfHP8A4KweKfB+najpPgq8h8PeJLiR44L7S76a3jsuN4wQSJMAMoDjbkAlSOD4l+z5rXiD9oPRNU+JHxV8TeKvF9/faxNDp9trut3FxY2KKUYtDEXMZDluy4XylAAOSfYwnDOIhD2mJVvmfP1c0ppuNHU/tX8LfHH9mjRIp9I+HvxJ+EXmPJ57Wmj+J7Bbi4dgPnkKuS7EDl2JPFWv+Fk3PiV5U0nxHot0srs1jJpzyTwooUH95IoIOGJyATwB3OB/Hb4rvtA8DKbHw3ommQ3MkAj/AOPWMSBlKnc0yrvJYbc4OOTgV5xpet/EKS4lk0HX9c8M311tENx4c1y601rZFGHXdGed23zCHB+9wfSpZRGnopP+vQ6aOKjVvJqx/Xz8YP2ln+CPw08Xar4u8U6Fb6mbaaw8O3cLpZym4dRHGib40DOp8yQ5+6iFiw4r+Tv40ftU+DrM6je6ReS/ED4hX+qXt/c+JdTkebTLeWR3kkMlw4BmkDFEzFuBIdiwwAcvxD8M9S8ZR2mqfEPxT4i8W3ltAIWfxPr99rSxsR0SN3KY+Yru2jhm7Zr8uvix4yS58Z6no2hARaT4auG0qI+X9m3yx/JMYogQFUHcnTJ2ZAAr6DKcBCFL2knds4sbifaz5afwruJ8Ste8Q/EjV5vE3i7V7i+jS5luLSCVjDp1mGVVCRwA7eAvDNk4bivDdc1GFovscRUFCc4I3vnjk49qzfFPi28sNwaaWaMjKwBwIFwMnjgEnPNedWutPqt20pwQV3Oi8IADgAde30716FScoN2Mac6k5J1LWWx778IPh6viXW9P1G7SNojqcVhpFrcF3i1C5Ykl3jVcFIFPncnqnY4r9RvidJFpXg6wsYYkcrZx21w8khimKhAXcMAf4lUbc9zX52/ssa14i134teE/Dmm6bZTaPp6G9vp5lht10mGESzDyTtyHmdBG+3kpMSewP6L/ABItZ9XuzYTKogjt1h8rIJblmJz7btvPZRxXk4iUnJKT0OeMkpX6M/PW8WaW6laOVZt8pTzEGGXAClSOOQcg/SuH8aTXk+h3entK8UO0h40DIJMjadwP4YPSvobxP4WtdEvpEtlJyS7FApXexyQGB56jr6V454+ik/sWYhCiBl86Uj7gLDA455O0fjXjVaMKiuz6+liOSEVD4WfnT490ye93iPMrxDKKqg9s/Lzjp0/+uK4jwai22uIZWYNACcB9mTgqBkdOufwr6I1qwnnF6YZCFUnymGNygBQOCOTkV4BbpNouvSrdMC6vksDywba3PTHX9BXzub0OWClBd/yPpsqqNVlOS7fmfpV8OvECXmnWbhgghgVQjuN4IAPJzyAGHNe9WMsjIsiyDarDAPIYHPTt2/Wvif4W6szR28EbM0UoUlThywfB4PbHHftX1voN8DGysgKnBCk/KPTHoOBX57WpKMuaK1ufp+GqRnCz7HXWU6XReKUAKwwBINikcEnJBHr71WuNIi8t5oNsgYFtwO0IA2OQQD+Y71BYlZC+FAHmbgAM4yMcf5710cIXDLlSANrKWGOQOCPow49DVzeqseZbTzODaGWEtx8o4Az8hrUtrqEAox2yDhQRjr0x611F1ZW7qoVeW+95a7u38qyn0NQfMOCw5UdMnsKL80b2LUpqKTJFb5gGIBPQA5IA6U5HR5QyMCY8gHI3LkFSP1PSnLaOpU7SQVCBfvAYpJ7DKnyw6SOCF2DcSTwOKzfwpHWlbWIjXc6ZjlnfG/Py8Nj61Rl1S7tzu3GSIHg9znPX8qkFs8MI+0lmk+6zbCCetUrllkR4hGwRlJBTk/QZ/wAaIK7szi505a7l6HVby4DNHKYzjl1AdxkEHg5H6dayZ754rjyGu5naQYWNckHrnd27Hr6VU0611BI5IwXO9sE4A2rzgfT/AAq4uiSPKJptikfKG4dsAcd/w/P8dVC10tzuUX8UEZ9zeRxplzITuOGYbhk9MVCxlnUIIGIzlpCCVXPQHsB7107WdlHFsnET5I/1gwCfT6Y7Vj319bxggBUIOCRFjgdOn9aaWiiy5zVrIqLp0CNvk2MQckcEH9frWFqeuR2KlFkjiWIMF2qAOTknn0/xrO13xJFYDO58sf3YUZ2+u79fyrxPxR4qjubaWS2kHmQIzyJLKpkfaMkAZIJ61UMPJuMY7XJr1oUYy51qkWte1y4upTb2c5dZmz5YYyK5JJzk89lGM8bfavSfgYt1pHiuPV7azTTtbjK29lqzR7/squcy7QcrkgLnr0FfIEGs6xdXsdtpyMbm9n8i1jhAMpeTK/LkEZ5PT0NfpV8JfCreHvDenR3UU95qLWokuLzUB5lyM5J3H7oJwcA84I96/R8ryqMaCqW1fn/wD8qzjOKk5+zg9H/Xc/Xz4A/tU3+m2kPhHxtqGmXsF1Ktpp3iCRVsZ4JHIRYplXapDMThupB5zxXf/ErxjPHa6rqjTK4gtZZpLl84jRY2IGPTAr8XPG3im80uFYbAHJkBwjlWUoQyurDoQQOgNfRPj79r74fR/AnWGvddz4wl8PyabJpd0pS+ll2mIOOqsHIBBBOd1erCjOlOzV1ofNzrqcb9T4H8G/E3wb4M1bW9R1y4uZNV8ReIbnUryO3tZJhbgzyEAlFbHLck1+sfwc8c+HPEGhaXdeGdatXjW08+SG0uEMoyFZhIgOeBgEEHGD3Ffzl6XfXbX0upXZkurm8uDcyl3Plw7zkhV7DkdK+r/h54hvPC93ZeIdB1W60fUbc/a7S8sIh5hkHLKVx84YbwUIwQe+a7uRpqNPbzOao4u86nxfgfqr4quP8AhFPFwuLeWVdL1ib7bDMJBKRK7M7wvG38PIZcDv2wKK89uPiFp/i/SLK7a6MmqwRJJfac0JjS4Uxxv51q5AWT5S2VzuVkYYAwXKmUoxfK9zKEZTjzR2P7X/D922oQ2yL4Ym1O0EQMtxaXdtbAHjkmWaPOf9kk17folppqS20iaRJCEKbc+Wvk/MBnAbGB1OCfunGa/O20+O3hy8uLfSdC8R6TDIs6x3M8+vLplnp0YIDvMoYSfKAwAVDzjpXk3xe/bG8X+DtVHhb4YazbX9ssJj1HxXfxpcWyMUDN9gDfO20kDzWwuRgA9alUq1Wbgo2dup89orOT0uftlqfifw74Z0xdT8Q63peh2BQObrVLyOziO4A8FmGevavzM/ab/aG+G+veIdPHhzxJBq1poFjd/b7xInttPinZo/3Zml29BDywBHQ9CCfyS8W/tBeJvFuuzS3954k+Iutw2vkLCJTe2NsET5I5JpXVUQ9T5QkK54XPB8S+JVh8U77QJdY1/RfFElhcwLcy+F7DQNUtvD0O53KPNcmGOSYEbcq6lQAgwepKeRSr1ObEytfotP8Agm0MzjQpqMEew/Gf9vNNAmhX4WTG+8f2bsNM1DR/Dya2NH3Mom2Syw5DBRnhhkryOMj8VPjz+0T8avHPxE8Qah4817XPGXjGzn/eal4p8U3OoiNHVZIoUiQFYhGu1WjA2gjC4AxX3j4O8B+J9Z8Oa/rOhaQ+k2Gi2775WshpNjNdSlUgi3MqkEtIpz1OCcGvEdG/Y78MXN5feIPG3jfU1mu7x9RvrHTTDDayvJK7hTNJE0zggnOOmcZPf6nLMDgsDFxUForJ7vz1Fi8xrVnyt/d/w+p+dF344+OV9by3OreN9D8HaM6iTVzpGiJIZggxxNMGcnhQMY5fGDwK4Hxn8eBZJBZWtyt+yWYD67e6i+q3t06jDsUbeQPlZsR7VXdgAZr9RfiN4f8AhlbabL4e0rwvpn9nQIbYQtZCUXA6NuypzuHUnlhnPWvkr/hm/wCEfifUrl5fCg0ud1Pkz6dcS24tNxJzFHu8tcZGPlxx0r0PrODSfutWPMTqp87e5+cwutc+JOv2OmorTXWqamq/aV4SFXUIzNIfugLuPSv6PPBeg6N8J/hH4V0WwlNq+kaYgKxyAK2VLgy4OSevX0q3/wAE0/8AgnD8HPEvxkTxDq0es67o/hdP7dmg1C43QyyqrJEjtGEwokaMlSDuEXUDFftx+0l+zL8APEGhXmkR+BNH0y8MLC2v9OhNndwOxAc7kHzAhjkNnH8OCAR4eJxmGdSNJt2PTgpu0mtz+bzUfEy+IfFLw+Z573F0VXynZkT5TnJJP93PA7175oz6bocFtFGgluzHln+9Jls53HnHJI/CsW++AHi/4PeI9buD4V8Qaro11P5tl4lt9Mn1DTo7bgRh5V3FcBgG+Uc9zXq/wy+EnxJ+JmtxW/gzwHrut5dDJcy2E9pZrhhvPnsoQAYGQxXgcVvOkpL3bcve4+dP3Tyv4q+NU8FfCT4heOb421umhaBNJAPmkU3Fwy2lkNpxyZ54BjI5ORX4JaC9/wCIL+a8lE97c305nkcK81zfXFw25jjBYksz9Rzkfh/Q5+3j+y98SdI+GegeBPENxpGlt498RJFdw6JetdzLFZqLtfNJiUDEgiY7d2GjX5uTXyn8KP2XvBfwaik1qdX1nxE0Bij1bULc7LWMrtZbeNmZVLjcrMBuOcZAJB78O4YfD3i07/PY8jmi5NPc/I7XPg/8UtennuNM8C67Np0PztNKbaxMgzyyLNMjsOc8Kc+tYug+BP7Bu5NK1WV21K/Cu1vHF5psEXzCRJhSo6MM5OWBGSBmv10+LGvW2h+G9Y1CIzwSR28kVikUG6aaeTckK8HcBl0BxjjPPSvz6i0y4s7aXU7xHS5vvnmn8truYsdz7XKqcYLEjcR7CrwzjiLzirGc6k4ytHY+yP2EfhTqet+P9ZtvCum3Os3sGibpNPsLJJdRkkuHReZOCFAWMkuQqqq81+rOs/sGftD6lNPfx6N4P023niLLDqmvznUxuUD5fKt3QHBxww+nNVf+CBlj593+0Jrl9brdS+bpNvY3k0GGiTdcKiKcDAAjKnHdK/oA8SyxSPPujV5FUhQwyo4wc96+ZzCvKji5QSV9D6vDU3OOj3P5Dfjr+yn8bvhvHcatr3ha31SxjG9p/C162piEoSWDRyxxOW2AthAQeBnNfnv8TLW4u/DWr21iskt8bZmjt1k+zSM8Zbaj7gu350C/NgDIr+y/4l6ImsQ3tpfWa3GnXDNGYmjLxMpyuD6cY9DzX5Qfto/s9/DjTvhT4q8c2HhzTrLXtOjF99us40tbo7ZUlwZIwshGFb5WYhj1BrjrYiU9WtRUsNUhFdl5n80a+CfHcugrrZ8I67Jpcsjn+1beKDUNPkVXaNnHlyNJt3I4yyjgZ9K+ZvG2lT2mp2t5JDLEjFo2Dx+XKHUgkOCM9NoH+7X9N/7Pvhq11L4E+CL8LDLHeW97LPCoVo4pBqF4Dnj+IZbkZ+cetfnL+3n8JfDuleG7vxZouk29hq2nTRG4ms4PKSePzo9wfAwzlMgHI6kHPFfNVG6jnGS2v+R9pllWUYqS+F29dz4F+GWrx/utisqq65I42jOBhv8AP0r7K8N3aMhCyMXxuYEjIBGR0JHrX58+E9XaxKuiuATvwRgt34/DH0xX2H4D1fzYYQxZjcgMS6gqmdoUE9eo/DNfF4+DUmnuff4CpJpcx9M2EzrGkgYZbByxJxn8a6BJUDADBLHLEqg38AZJAyeMVxGlSp5PI/iIJHOef/rV0iXT74wABGNuQy9ffoe2a8NxbilLofTe7y3ga8dyyqQQpOepTGM/WpzNn5CQS3IHUY7/ANKxoXWRTlj8o+UHoD7cU1bkiYkBi4GDkcY4PA/z0reMYpaHArJWkdHbqwI3NFsLDIGQ/Q5ye31FaLzRIchgW+oJH4jnv+lcguoyqzK0bbd3JLYBHNI+pBSQD1Pyle3NaQ5ZO3Y3i4xhqb120TRqp2tuPbmsx5Uc7AkY2jHA+f8AzxWE2sNEDJtJIXAycjJGDxjHr1rNbVpDK8m3huvy5B/StJ05SnzrqcM7WU5HUNcRLlYygYEqcY3cZ71nteACTBGCOA2Np9c8Vzc2qIhIywMzEA+U7jLc/NgcDPc8Vzd5qvlAhpmRiflGxgDkZODj6Uowtq0aOS5eY6K+1GCKQ+ay5UFt2Bt+vX3rzPXfEgIkMJwM5ErseAGA4598DPrXPa9q9xNcpLLPMUEP2doRGgT7zndwMkgMAAT29+fKNeuZbhTBuxvw5yxGMMGXocHlee1duGpyqPmt/VzmrYuFOF2Wte8V3V4DZ2xEruzLJIVykancMj346D6+leeXcIhjlmvJyTlmWNGwGOCMY6k8EYHPNdVYafHEk15dTrDFbQmaXchZkCruOB3ODkDua6z4KfBrx5+1P4y/4RT4VWE1raWEn2jxBrmrQM0NhBuAGWAK73zhVPPX0r6zLcvlTSxNVJX8/P0Pic8zhzk6FPTz+R0PwH+HkOs6kni28sJIoraTbpclxja7N1kVccdQA314r78gnitLGSFIwCcKXQghMAEdsjhh+dejQfsT/GH4UeGLWyvrWw8VWUNu3myeGHnl1KzTAyTE0afMiF2wrFiUwBzXmEmk3KOsf7xrQuA0sqHZJhgG3ZOS2FPXJJHNfY01Hk/d7HxU2nO73ON8QWLyxtdyMjQOzCF5GGEO7kYPPGO4r4R+Mlt5urQSKN9sJUgmdObMOMEJnoSTkDpnB9q/S61+CnxK+K2owWPgTw7eazEyk3t3co1jpUDcKHEzDYOABgEk9q87/aT/AGP/AIl+APh3bR33hyCC/ufENpdG6bUYHtZJ94kWEOG34YK3LAfdx7iKdSDtpr1N8S4xnbqfm1ZweY8O6RBHuBkGQqsCc9fXnrXvvh/XND0+0iguruO0l81FhNzLttAWKA4PbrzgdqG/Zp+Mlhp8+onwgLyGzJeZNJ1WzuZ49rEMUiaVHfHX5FOfQV5r9ltrmZbHUojHeWj7pLGdWtZTglSp6Y6Z4PbgmuqDc1aBxSbb21PtbwRf3OovZvAS5YkRS206yQxgll++SvykZGACfmAxRXkXhDWJ/Dtkl1phFq9nA1xNbSyl1jAyxILE5yMYP+FFZ16M1U2+8qhWSppSWp9L/AHVdbvPH2nR3Nvr3i3U9x+yaXbCXVdX1udz5UcCRAkybi5+8CvygnkDH9Yf7Mv/AATp1v4meHbTxR+0RHe+DbNJEbTvh54f1QCURqA3+nXEY2/MTnZExwQDuGOfgj/gi9+yZLc2l1+0F4xtVt2uL5dM0FrqAP55SUCMwgg4QsFfe2CdwPAGR/TtB4hbSNONtbxhlCgBm+VTjjj36CvQzOslXcaOklZXPncPG1NJrQ8i0P4Afs/fBrw7BpXg/wCHvhnT7ixDPp17JpsGp39vNJ9+4E1yJGMp5O5iSSOcjiptN8C2niWVLq+gjltiNrJLBGscig4yURQvA6AACpryTVPEV+odGkiRsso579s+vtXrdisGl6eiyMI1igMkzEY2hF53A9sd68/nqOXO5Ny73MbQUFG2h+S3/BSHUdD8Iaf8P/hvoNhaWI1iWbxPrbWKCKdYLVWS2EhXAAaR92CDzED2Ffgl8UfFVpptvLbpcyAPE7AEqyjywDwCOSe2K+0P21fju3xN+NHxA8Q2d2t1pNhcHwz4Zkify0extCsW8EcjzXDueefM4r8fPiL4rvtR1KW3cyq0T4ALFRg4bAPoc/XmvSh7elh1zPff5kwp3qOKWiBNU+0zXM0hYxs26LdgHGQOccZJJP5fU+peE9JivbYzw7zdMu2OFV3hju4HrzxyOma8L0SxkuFi80OctxnDL3wP/wBdfeH7LPw/m8d/FHwN4S+ytJb33iCCXUZGkEcSwRBppQxwRjZExIwfvfnyOdaN5Rasz0Xyr3T94P2FvgpL8F/gdB4h1KBU8QeOIxqlzIw2usILGCMgjOACx/4Ga6XxZJPrGsPG8m8CQjAAO4kj5gDxngV9EeKJ5NK0XTdJtX8uz0uxjsYYInwoRIwirgYyF2/T+njWi6ZLq2rq3kM+ZduQpxycdfXA/OvOvKU3OJSaWrPcPhV8OdHfTopLzTrSSTYG23cAmETEk5G4n0J2jgZ4Fer6slpoVm1ppdtBZfxEWkawgn1wB14/DNaHhKzi0vRI1cRwBY/m6hgQWwefbHfvWfr5tpwZCV2nq2eApxknNXOp0b0MvZxnL3UfiJ+33q9vrXxF8F+H5oWkXQtDm1iSXed5ku2WPAOODtiY5/2q/Nnx3qcewWaovkQKqREqoIORxnnjJxk8k9a+x/2rfEtv4h+JvjzWJLm2Uafqsvh3RmtnV99rZDyVk692jLgr1DHjivzQ8UeInkupYWmmmXeSGZ2Ytz647YGK9CnCSw8YFP2ftJJ7o8g8f/D7xn8SLzR/Dnhi40iziuNUVtTv9T3NHaWq5LmJQpLSkhQvAXBOWGBn7I+Hvwm8LeAPC1pof9kw3t8qLNqOq3EX2q91Kcgb5G4OR0RUwQqoqgYFch8K0gmea+uos+QqrHuUGSSRscAHAx84Oc9K/T/9lr4c+E/El5YeP/ibeJceG9K1IR6L4L06L7XeeJrxZDHGkqhQzQh1bdjIPlYz1roeJdCio32/4c5adKUqj5T3b9iH4TT/AAw8Da94puPD50K88eTxXltHJYJp3m2UO6OzLKoAO/8AeShj8xFwOAMV9Z6h9ito573VLm1s4ip3z3NysESDPOSSOM+nqK5bxV8TvGPi4afdXFzo3wu8NWlr9lsbPUbT+1tSkRX8tPs+mxRggGNeGkJChSdhB+X5G+Mf7QXwu8J3ML6vqdr4kubGRvLPie6jvZQ/7sN9n06NiBGxCkNJ5WMdCOR5NerLEVHVqbs9DB4eo3yrpb8z2nxJ448GM01vbNea2BI0Uj6Xpc93bEj5SgdlUN1PKZHHB6V+fv7VElh41+DPxM0MwX2mxSaFLIPtli1tdROiO8b7cn5VcRk59Dnqa8U8fft3asLu+g0DSNS1TT7e8P2K91HU5NDiBTutnbOIwgIBXLE9Dx3+QvHP7dNhqmmaxoGqeEdajl1qMxO+ka+8ltEWYF5JTJ5TDO1+hO7PII6+VVg3JJdD6uKST5jm/wBjfxK138PL/wAITzkTeHLqSSCOQguIZJG3AHkEK+4g+jj8eu+JnhXQfE0WoaNr8Fjqlhq8X2WW0uoVKzgqHKlDg5BXIIx90d6+eP2ctejsviXaWVk8Ulpq808LIJRJFbwSWrgRswJAPmRptHPzSe4rQ/bG8Wav4N8S/C6/0ewa8hTxDcavrNrC/wBnkubaygQtsfgbwsjkDoSMEc15+LVqza2f9MnDtU6fkfkL8fvhNL8D/iHFpFowk8Ia4rXHhuYkl7Z4xme1djjhMMygFvkkUcdK6jwRrFvLAgV0V4woxHtQyZ78DPGMfh719o/tE+HNK+PlhY6XpcN5o+uaXpb+I7R9V077JLau0KfZVcspZo2LuHC8DDDPPP5f6DrV7o8mzakc0bm2mSU48koSrEAjPXPYdjXgYzDurFStofX5TXpygqc+mq+8/QHRtQCWyli2W5AXGBkDk+/H6CuwjlVo1fJbHUM2McED+lfN3hXxpbzQ28dw0YkdDhVbczEFsE/hg17RpOrRTY5BBBJxggD/AD6//q8GpTcbp7H28KsZxjKDOmhnO0EtyWyNp696vwXigs0iDIOAxyGGPbODWOk0IUiEh+eFBPX6/hUM0hU7sMF/i25wSSD2xx0rSMLN8h5sWpTfNude9xCwOzkgZB3gL6d/zqlNCvzkSKxxu4I2jrwDXKTXsh2s29TkMBuJBx0BHTt39apXGrNbbVd94kUkghWwBjvj3H51koXWm56U5cquzdnTZHuMhKnhkYBh3yeneqMtyqxu289cAk7WHbof88Vyk3iJBAzbVV1GTkEcAjJ4PUjPXIrnLrxRJ5bqsiMJFz93k9R39we3etOWUppW2PLnWhZXWx0F1cyImY5gzg4ySO/P6A1yupXqxsBM5aTBxk4Kn8B3/pXL33iZxkny+flTL5MZxjPXHbvXE33iVpfPLKxdE3HuWbngdOOn512xpTSSS3OSVWL9+R2Gq3yT4RWOVY4OflyOP8/SmeCfAHiX4heKrDR9LhLSXpIe4nQyafYwofnmfB7BuB1Yn6mrPwv8Ea18R9XsooLa7i0hLwR6hqRgd4EReHSKTBBk5TgE4BzX3x4y1nwz+zp8NLa18GWNtdeMNevV0izMCfb9TgiYEmSTgszKegwASw4IFexluE5F+9Wq2/4Pkceb5gm3Spv3j5c+IXwxtJNetPhX4a0ybUjHb266vf2MuzULm4IG8KuDk7SuRg9enFf0FfsUfBP4WfAT4f2Hh/TpNM0XXdZijv8AWpbi5VrwyyISgfcQxOA3Psfavwt+B/xZ8IeBfiho+tfFHS9Y1nUdRha80cWW19RtLwH5ZrhA3zh0J46KcHjBB/YDQf2xfhIEtbnXPB+oLarblP7Z1bQLbWGhVW/iiG6XABzlQQc98ce5LEuSVOeyPhG01rufq83gWHUdPS803UraRHG5MsJRJkY3AgHg5wMjvXzrc/sA+C/GHjZPGGvSXtihmW51DRdOuEXTtYlUkmWVVXgsdu7aVDEHI5Ncz8M/2qP2dPGlrHcfDL4teGdKvJdguLOPxAdLmt5flJjl0y5KhCQgGfLUsF74yPu/SfH9zqMNjNoqaNrAuIk8xpL5IFui21Q0RQso3fMeex6VcKrTvSejG6ULaIztN+D+jeGLOGw0HSYLOwgTaIooth+UAZPPPbqa/P8A/wCChPg+/t/gm2rPbjy7TxTZuqhS0rFW2rx/wI+1fqfpPjG3V7uLWNGvNKuYVPmKoXUrIgNkMk0ROc+hUNwcgYOPjL/goXLp+v8A7N2t/wBjXtubhtUspYJg6gKouYgxOenGRz05rqjVTfK9zOUarm+XY/G3wRuciW+cpE2JI0Mm88ndtPXIPCnOOteT/FX4JeDfF00s13pCWGoXBMsGs6cTbXmSvDjacE56hh/COua7DSNWeyghIjMyJGAGzuJABXOfwBrpdR1/T9RtRE0xjmiVW2yJJGT0PDFdhHY4Oevpx6HtZwSlDc8OtTgqj5T89/FXwO8QeEIHuNNe68WaRsZJEWBLfVrVQAcNEgCypjI3L8xIIKd6K+7VvEgMLzJHNbi8EE+XKtBGzgGQKBufkgbRnrk4AJorohjarjeok39xtGlNx9zY/sM+Fvgqw8KfDL4beGtGIsNJ0TTIJIbayiFtHKBCyoSOezAn3Nes6trEjeRDbJJJLt2lSd+cY5wBz0/Wvxo1/wD4KBXVtNc3fgTSLi+gNjFZ2F34lu5LXSLJIo0/1VohViSxYFiFPyD1wNT4Rf8ABRzx1Je3TeKvA2i6tLasPKuLHUX062XjPIdXJB7c8etRKlXm3Nrr1PIhZQSWx+53hGwuobSO6uY4yZE3hGjG/jjJHavB/wBtDxxP4D/Z6+JOuaXJPDq0+gPplgYc4ilunjtkce4acY98Cvzov/8Agqb4vGpG1t/h9pMtqXMbw2urSQyq2CDiYxsrAYIJ2jpX5Vf8FQf+Cpfjo+CLT4a+HbPR9A1bW/M165jtrqTWb+yijD/ZTJEUEYbLGVc5GYlO0hhiMPhK1XEKDWu51VGuTmex83+N9QvbWKWe6v1YS7mlZkVEy+edwHqQBgCvizWNUudR8S3CW06ThZBumOSiAqoweM9uOudw+tfm74q/a4+MlxeG5uPEMOojBiaK+hY206hmO1oUKqDkliVAPQZIAruvhx+1zY2dxG3jbQ7uadW3NeaMyvBOGVcERM27cDvJByMKD7V6uJnKM2qm/kcVFQa5j9WPCenxulssitJlFyqEh2IXkDpgn/PrX7yf8E0PhXpES678TdQW2VVjNloZvZE8+CUARTSpu6HZlMqQfmPJya/l88O/tXeHNShgPhjRdWvrieELZwTwpbRmQnbtbfh+vA2jnj1r9OfDHxI8bWfw80rSrrxDrmkXTWe+/h07U57eAvKTKVCA7fk8wKHUbjsHpXPJVZU+SOiZC0lzM/px8WalGVnIlWSJWZU2N5qnnjp9O3rWX4DmkbUdyqrBmH3lIzk+nbiv5rvhz+1L8W/hbqs7x+ItT8X6JHI6nw/4jvnvEZS3HlzuS6kYGOcYB65r9Y/2ff8AgoH8JvEFpYWnjiWXwT4gMS/aYrqOW4sJXAXPlzqhBHP8W0jB4IGTwypyi7WOiMYtabn7JGC8ubWNUn8tMDKoQM+2a8l+O3i1vh38LPGPijzxb3OnaX9m09mDSAXN4RbW+MdfnkX2Gc15tbftr/s6WUK+d45jv5QSsNnpVnLeT3BXqFyqqSACfvY4PNfib/wVl/4KeWOp+EPD/wANPhDaXtgt5cPqOta1rFtEt+jIWFskUSO6IRtaYMW3cp8oOdsUMPWrVPZ043f4fed0pxpLXc8E+LviBlmmub2S3hu52IeKSUb3kLHzCq7snmQ+/rzXxvqd/wCbPIyzQzBv3rGOXAjTqDj068+lfi/8Uvid4t8U65eahq3iPWdYuWutsct9fyyyRqVQt5YZyAOeoHJFeh/sv2fjj4kfGTwz4WXxN4nu/DdrDJfeLY7nUp5rCPToF3eTI27btkYIiqwI3BO1ejiKVWnGKk1p/kRTjGVz9irfxLd6N4YtoNOu7aLVblfssErsfLh3F8zOT1IGeccEZ7Yr9M/hR+1R8Hv2e/gR4G0XWNVsdS+KniDTZdQTT2kij8TEz3EpIFy3+ojbcyjDCXaq5TkMPx2+LniC38O+FPEmoaC9pYjRNFnuI1ntUt4oYLdJGmlWPAHG2bacYJUe9fiH4a+I/i74gfFm48S6lrU9yto8moaZp4nkFrCATHEm5gAw/eM27k5/CsMRGc6aSfqeThKb9q1FaI/q68fftNeNPGaGTUvGNnoVg6tmz0vVPIManBxPdM/mzOAMGRiMncdozivijx/8dvhp4ViuYJ9fk1G+urlmuhpiPqVy8hyzF2bBJBJJbJXrznNfmNeXl5eQSgm7YXQYSh76Z1TcBnaN2FJ7kAdKw9cgWO2gjZiZYYjs8wljtJz+pyPw5rgo0XC8W/1Ppp1oU6iUH959UeKf2p9At7CWLQdGvNWl2kG41ACxRDkH7oB3DGefYda+S/FH7TEkj3b6n4atVt1jdnmgvSJoV2gn5PLAJyDj61gyW5awkkXaGxlgx+8OPb6/lXhPxHis7fQdVu51ViLVkUgszZPyxKAP7zsinpgMeaylSUqnvndDEupdacp0umfE3W7bULDxt8PfHGsaYVvhqVq0N89sYHjcnZIiuOhQnGSOcjNfoN8QPj9P8YPAngjW9UtIJJNMtbmO71OWF4XmeWDypYyrMccwueTz0wQM1+MfwV8T6RF4p07w74pihl0bV7hdNiN5ElzZ28hLAK0ZUqAcgljxkY5JFfrV4S8It4c8JL4aLW13YyzvNESvlqsb/OEwOMAk+3PSrrYelJ87XvI89WUv3f4n6J+HfDa+KfCvg7Ub9k/tq08JJa3twkaxCcSxI5PBxtyF4wCCDwK+A/iN+yNN4w1rWNU0G+Ojavcr5ir5X2qwvZhvUNIh5GRjcy8nHatzQ/iR47+G/iHSriC8vzoUdqlhNpMV8slk9svDboiSu5VPBIJBA6Gvtj4aa3F8TNEk8VeH4ZlaGdLaVJIhCZMkM316sMcdPfFfPV4SdSUWtEe/hcS6Wsd/+CfhPqmk+Mfhn4pvfC3i/TJtL1mxmMiLKjC2vY8nbNbSHG5Djjrgda9q8JeNjI0MBkA+Xc8jtjOAcBT15r6x/bA0ax8S3lppGsaPJ/aGjW4lt76FUivLWVyr7fOGSEYYyvGcnI4GPz3hQaXcS20TOJIGChiux5MfxYHvkfhXkY7CuEFVS0f+R9Tl2ZVMTUlTurq3TzPs3RtZW7RWibd/CWDYFdINSRt0bICxHUnI9SOnevm3wr4mEKxwzO7tvBUbiw5//V19K9dg1ETKjJIOBnOMhq8OULRuj6OlVtouhp3EkjwmSRViOcABgMkdcAc45rkr+8Cl3eTJQcL165x39q6We6KQ7mAdGAB4zt65wPy6+leda3OZnLrG4VRzxgDp/n8q3j7ySOKVeDheW3oYWp6x8oVZCilthZuMjB5HP061xN/rbwqzC4OFO0l2wDx2yR1PFd/4P8B658TdeTw9pd5o+nSNhpLrU7sxvCgI3TLGOXCgZ4xk45Hb6z0/9mr4aeDrzTr55p9e160dbiW81edZbQOu7mO3XbEvzE9s/KOeor1MHlsqtva/meHjc3oU5csLv5f8E+E9H8NfEDxmYf8AhG/DGs6xbXRWSKeGIW1mBwrfPIwPBGCMV9ifDv8AY08TSx2/iDxzpWr6jK0AltPDlgpNix4YC5m4V2wpUIzBQc5zxX2HoXxI8NeF4kuL3RLNNK0oCS9vmle5uZ/JViz7ApJKjcdg+gFeyap+1T8Lrfw1r91p13qR1DSdLk1FbGHTmt94jQlSJXCxqCSozk4BPB6j6HD4elSgqcVotPPU8atmFbESutEfGmv+LB4D0G80HQtG0nTfEUCG0j0pYI47TTshUaWUoNryhkZcAkHywc18teI7zxNc6Xf3dlLLqnif7NM1pdyIs86XEjBd8OQVXCs+OwpfFPx08O32r614h168t9S1bU7x57iy0xvt5VlyqxIVyMAkjnoQa+dbz4keINU1PzrKS7sLFhn+zHuWwo37iWkQ4PC4Cjgc9etdroKEUnsjyazqud4b36n178J/gvcWATxL40luNT1u6AdLi/YTtbjALLG5xgHpnHOOgzXrHxQ8QR+FvCOt6qF2i00uRowBhUwpUYHbGVr5f8M/tMT+HrO0s/FUMl9YQYilu7ZQ15bgKQTtC/PjA6kE14l+0n+154Y1jwRqOgeGk1OfUNVQ2sc32N4IIUBQur5jwcggAcfezu+XBumoXemonUVnDqfOIkkgvBOjz21+JPtRvI7iXzQ7FiGLbvmOc/p9K+k/hb+1b8ffhbMjeCPjL4u0dImEiWV1q5u9M3ISARbSlo8YJGCCMA8V+cV5421W7YHMjbl24GN3OeA2Mjjj+tZ7a1eTybnTbtyykE+vauqNJNe6c3M4aVduh/UZ8F/+C1Pxg8OwWdj8WPCeleN4IdjT+KPD9x/wj1/OP+WiyW6/unI42hUQcHIOeP0H+I37ef7PH7TXwM8R+G9P1zT9D8V31kl3Do2vrBoWpXTZjlWEOX2OWKYyGzzzjBx/EFY+ItZtiktpqeoRhGKyWpu5EikwFO4Y78n06V6f4K+LPi3R7yZLrUhfadMu57PU1M4Rl2BSkh5/hHB45J60lTjFX6mdRuommrJn9DFhqd14fsTMbiTVtKRvtMMUmHvo0CjzFLHCsFCkrsY7scZrpdH8S+HvF9vdRwu8Vzbr5d1aXcZt5Y1ccEbuGU4ccHseK+Bf2bvjPbeP7a8tb/UL3To/D9tFDcaVdr9u0qSGQSENDOSzxldjNsAC5YcHkL9cS6dCTBe2Jhae+t2gsNRs5S1pMI958uQrnjd8u7BILAH0q1BVLTkctSEqTVN7I7jU4rjT5tNk0pw/k30IuFlugEWHcochSPm2jBwOcZx05K5S2u5p0NpIGF4FVmhKliELIu8Hpt3IwoqKlOHNZG6qr7T1+Z9zRTNLptoGjFtE8SkiVvLYc4PGM9c9q7vSpItLsZEt7olXIkZoz5fmEjHbr0A5rjooH1V43mVClvgRx5BY44IA7gg4x6U/Ub4WUPlAYVEYnjaEx6D/AA9K+ipuUYuUep8h7Nzdo9C3e6xb6XaXut3si21hpsMmpX85Td5UUas0jcewNfzYftJ/GDV/HnxN8deJRerdLc+I7iPTleX7VDaWMLmOCOPGRkRxrjBxnjNfrz+1p8YZfDfwZ8W6ZpcaSXHiCzbwwzH5mjS9V4mZQOwU53HoT7iv52da1cxXE8Rd2mYjcdnygEuuQfXINd1CSoxaqbnJCjKau/UytZ1RppWbIOXOSuCCeeg6Dqa2/C9m88gllYhc7gMnLc56/ifyrmjZpcSIyMRDKcknlx3OeuT/AI16T4ds4lnjt2XCSKQNuSV9+D6ivIg1UquXQ+jqVKdOPv8AXyPtn9lDwo/if4jeGo7lSdH02YarJsjGxvszGQByRyoIjyB13Y4yK/bnxJNbyxx+RsWOC28sRwoY1kAxgnnr/QV+dv7DHg+3hsdU8SW6Qma0jOjWhPykrvUzEKRxlgQTjkgc19yaxMywtCiMXUMGZeFOcZGfwIrtxVSNRpR6HlUW5HEyXMbzlWIjDSYOSByT79//AK9ek+ENEW5uEmOx0hcMGJ3Ek5wMenTOfQV5NM0cLrKUJKtvwoyx+le3+F5hYpDcDeMqHVS2N3cZ7fhzXL7Ny96W51SlyycbnvdnqVrpOkz318q28OnWU2oTyLHtKRxwvJJj6heSME561/PD+0V8Wrz4n+OvEPiZ7qJba5uXg0yxt/ng0+2hAhtxlQFLmONSzNuYknkDiv17/aQ+I8mg/Bvx1PZ3T22rXulrYacsc4tPMMl1bRyq0pUqgMczDJ554HUj+dbWb64s0+yghShbzChDZPHOcH14zXoYFRjGVSW+w582ja0Ob1m68ySQtICXkwH2lcjoOPoP0r9U/wBhPw7pvhL4dal42eOa98QeMr9rQSwKDBaW9qzxQ2+MDazuNzM7AMJI/u4Jb8ir2cyu7tvG593TOSe57dPXNdxoHxJ8f+GdDvvDfhbxbr/h/RdW3f2lY6RqcthFeB0EbhjGQwDhRuAI3YFefiJzrJqmzup04TVraH27+2H+0PodvpPiXwJoFza6z4t1qA6Zqt3pl+sen+F9PG15YvMXcstxKDIjKuQN8oLZQCvzq+CcU1z4xuERnjiGmSTeUADu2yoACcbsDjofSuA1+5ksttvChEZycKpYc5PB6/X1967/AOBV8q+LLgSIyyJppeJ1iJLAyxhgwAz1C9q55xq0Y8jW5xKUGlHax90IkuI4iCx+6zA45BHT17/lVDXyu5GCgnyREyMSxUgk7s54zuPHSuj0yeSbYDCFTJdm2kSDrz9fakudKivi6pIzvHgq0+UCng9BzgEY+ledUiou67nu005txlt0PM7iLytOlZyiEqxBDEs3HyjGO5wOB/FXzJ8ZZ/I8N3vm7l8+aKCMKwLsfNQ4GDngAnnHSvtabQILiIrcoQ0a4TaxIX+79cYFfHH7R1iNP0vTAYh5dzfSYceqq5GPUfKc/Wk3GUnKWw2qfK4u94nw8JxHcNKGICSGSMgZJOeCD6jg8c1+t/7GPxg1D4l6U3w2155tS8Z2svn+GGu7pDf67G5YC3VyQzsjbQgYkkOBk7QK/JV4EjQFhhWA4PTHOcj8q3vBnjPxN8PvFWk+MfCmovpPiLRLuO/0nUbeUxyQPFKsi9DyMp+GcjkA1m3a7ielTnTl7q2R+6njPT9XtbjV9L8V2tzpfiGxRre102QZADACKTjKlTvySvXb16V90fsKar4d8NeBPGum65qdnJPp+pR6hb2kiAtJby2sbb1ycZEkUytjnI5C5Gfzp1r9tHwL8ZfgxpvjDxDaTaB8atJs10bVdIi0+S607xPcTLDFDdwXCIyqSXjkZHMYXDYJBUD5Z8J/H7xJ8IdXfUdFgTUX1IvLqlvdXDQpfJI0jmJnzz8zFvmyBgYAzxytcyu3qXFzvaHU/Yn4jx2HjrxBrutPbJFFf37TW8e0gRxIFiiBXJGSsYcgEgFyM18efFX4KjV4JL/SSIdWtS0kTKgQSKACEOOCuQ4wwP3z0IrtPg3+0foPxOex0y90u58N69qcKvFZO5u7G6dhuVI5x1LAEgEDt1zge/3ccc8qxMB8ynDZ2kEY4/X9K7VTUoXtucKcsPUU5qz6fI/IzTbm6ttVOnzBYb2CUw3Fu7AFSMgjPBx/jXteh6jvYoZCBGPmQj7pra/bA+A95q3he58ceCp1sPEeiIbuRFGyTVogYW8k7QMnKnbnI5AOM5H47Wnxq+KejSfZ4vE6Mscn723ltklQYIAAbbu6Dt6Dn1+XxeTVatdzpSV30b2/zPo8LxHhuR0qibkt7LT8z9m7jXEEWWlUqvyj59mOOP1wM+4rwD4nfGVdBifT7FreS6kjKF4pFnEC/KMuuQxJyMbSOlfEekfGb4h6yVF5rh2B13Rx20USNyRnO0n359KztY1e71G7aWWXzXf5pNygZJ5OTgZ7Hqa1wOSV6VVutZxW2prjc9hKl7PDX17rp953Wp/FDxff32n6rp+s3ujX2mOz2d7pVy1vfRsdwJ35JAIPQH8TXoXgf9rL4z/Di9vr/TvFP/CRT6mq/abPxlaJ4j09GRzIrRRTbgrksQzD7wwDnAx8z3EzxeWYUcNgbxjKVXaSVlZ2IOzqxwrDoMgY/GvoFSpU42S3Pmp4jm0Z9ieI/wBun9pvxWo0+bxnpGlaeyNHLFp3gjRrONAygElhaBjgbsZOPnPXjHIXnxB8XeJLR4dV8QXl+k4VpAJ2t0lZc/M0aBV6+2OOlfMVndtJOu4ttZwCCSxJ/r/9avoHwRpxv3hnuRtEZUqiAKCoO7a2APpn0oUYxVpFe2XPJS3R6D4Y8NTpYPcAkunyIFdESEkqCW3YzgOGOCTXpl5/Z2nWvmQlGVIhJLKeWJA+Yljzj26DtVCxhtY7ZbeCNo06MOfvYALdT/dH4CvOvEMlx9qa2WQsn8D5wAMDg1SUG+Zi9vSq6xu2UfGevLqsawWc8gBU+aiKQT6ZIwcH0zXzT4pW7e5EMzv5aru2tyr9R0/CvrLwv4MbUEEj87nCncxVcnjORzzj6dK8d+M/htPDWv2tvGy+Xc2IcL5gfJDMxx7/AD/lipdreZS5HJzm9Txi2jFvEdzbsjcwK59f845q0GGwHjOMZbgdRQF3RL8imNCMjPJ5PUDpyBUMU5EwWRBIhwDkY2jjGOnSocU1dbnZLEKMn+GnUmgTIRw/PXA4Q55JNbZiOxEjP31yRjdjtwc5FY1qiyOzsjAtypGQq8Y5H/6q0EczSBYufLByQSCO/rXcloovoeFKcZr95uux9y/svyR2Vn4oe4cwwt9khM2/ac7Zs9ecHHHuxr688LfEZfCl99iC3BsdQRZ2tow0lvayDMZkVMhQzhVDHqdi+lfDv7Oria28V24mb9zBaTPEzFpFYmdUGOykAkEcHPevp61hLSw3HysUICO6nC4Oeh68+1ZSu+W+5NRydNSe59raX45txbG6hhjvIXwzyCL9/Fu5O3K56jpn8aK5fwXY2Or6R5E8GGMeWKfIMkBd2RyOOmO4HvRWtmna9jNOMveluf/Z",
#         "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAMCAgMCAgMDAwMEAwMEBQgFBQQEBQoHBwYIDAoMDAsKCwsNDhIQDQ4RDgsLEBYQERMUFRUVDA8XGBYUGBIUFRT/2wBDAQMEBAUEBQkFBQkUDQsNFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBT/wAARCAE4ATgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD6027s8DAqNsZwOcVMfeq7LyRnHvQAxieBimN90jNPbgDjdnvUbcnHUigBOFA5zURbt0I9ac5wPTFQscMSP1oAXJK5zxntUbttBznPX601nOcAgVSu7qKJsNII5Ae5GQME5x6UAW5ZAoySAAM5boK8e+LHxgj8OltJ025givX+aW6chmVcZAVRk8561ofFTx2fCWlmQXRuVdTtgwobeBx07eufavkq88UNeanPfakI7i8mcuZJ+vsBjtQBv6rrJh1BnuLt3kJ3F5TjJPXv7/pVW68XWP8AZl1YG4xdTfu/s0jggj1DY55xxn1rivGfi+e/v2lWeJo2GFSIL8vGMHua4OW4aWQ8nYecCgDpG1tYLydo2MN1vbITgc9QPbnpWa8wU7oh5eOijt1/xrMd8uH75zk+tWPODKSBk5zgdKAFnuWbgkn+6Dila4eRMbSMqu4e+Bn9agIDHC5PcVZijBRW57ZH4cj86AKuoyreSB3A3KMAnkgemf8APWqkIJbJIBz2q5PB5khA5z+dCWuxBkZI/OgCrK37z2FG47dwOM9KWSMsxbact0GaR852qM5Gc0ACysSwLZz6d6WAMGOecUqpsBJHPrU2Qqg5GP60AS7htGeRj061Ks4JzjrwPQVVjkzIm4gjFSj72RnDflmgDb0u6EMsbtiVUIIjYcHnuPSvZvC/xP1RrO3gjeGVyGVbOICOKBAcZOO1eFW8xiIKgEng5rc0mWae5O4KIkTqcAdR/gaAPoy48R3uoabaiytIkVv41O8Oce5wBVeytZJEtxcX1ujrkvHEqjYc8DjjNcjoMCzQxwyXU72pGEhSTaFB5ycde9dYkFlpgFtBvuXJBWNFLkD+gz70CPpf4T/E6K/tIdJ1KRReRIqxycATL2P1/wDrV69FdxvyGDDpwK+GrW8ewvYZYoyjxkMCSMZHbHXtX1T8NvF8XijQ4ZreWI3CDFxbZy0bc/ocUDPSBIGcEdO+Kn3ljy2BnNZsFyJOQw+g61ajbPHY+ppMC5HvJGFyPTFSI7hTlenpVdRhRhsN7UqcbjuIYc0wLisVXcW49KedzDMeCc9e5qsu3ODlj155qZX8raF6Z6UmBNHKoYhzgkcmpFbr2X1NV1bIPIH4UpYf3xxxxSQFhYvLUgNye9FVxJuGc+1FOwjzlgcjr04qAjI5NSvyNw4PaoSCq80xjW6YA71GQRn3qQ9QarSTFVJbgdM4oAY0nOG4/DNc1eeLlllubfTBHJJECGuZ8iIN2Axy3Q5qXxZr8ekaVLLuLzyHyoEjOWLHv/OucuNfuND0OEy6eBHBHkC8byi3rgAEfmRSAl1zxXrmm2s01o2m3kq9IQrYx78g9j3rxPxJ8WJNcvbmbXFjtPs2Yo4o2YRbgeR65471k/FT4nXPiqMM4hsbOL/VR2Eu4znqSSMZAArxHV9cmubYiWVpAv3Q5JK0wNHxl46v9X1MSZNvZRkhUi+Yc9TjvwB0rlbzxGjxPH5cMu7qyptYe+DWVcXpaXMm5kx1B6VSuni3bkfcvUMetIYss63LtuXk9xgfjUDReVymdvuaRrhWQ84J6nimCR48g4ZT270xDmk3LtX8cU6KVlPJHHFQllb7pAPsafGcHDE59qhtoZIGYdCOtWVuCqjPApYbFmGdn44p32Zlk54OOhqOaxaTEEoMpJGMDpT48SRsB09BUZtnLdMc4q3HatEq7Rkk8HHXrSUu4blN7c78EMT1GKVLb5iW5461praNM4GMZ64qQWTyA5XgY69arnuLlsZMkChRnAA7mmFEbB+X2FXrqzbeeuP7tRxWX7z5ulWmTYrrGsbEAZz39KduwNg6BsgVJMgiJKrx2qDLAKVGRTEP8wBgxZS3THWr1neYUEv6cDvWaVDsVBG7HenoMHGRxz0xRcD0LSfGhtERdqIzHLFiADzjknkfhXsnhvV7PWLa5t9JMhYKrTXJQIrDJ4BJzzz29a+adMuxb3Cu6h9rZCsu4H613ul+JY1fdMcxsAFRpQpX6DuKYHrckMb3cm64YunGzzCQBz6Gum8C+JJvDfiiyvVvjDbGRIrgc4ZDgdPavGbfxE0xmii3uF+YnAwccnnmtzSdZEsYWS386Yk7W83aF9OPagTP0QjuI7hUlRCiuoYfiKtxyBHyWHPSvFvgf8TH1nSIre9wXTYpYnjlcg/kK9l3xyN1B46r0qWgWpfD4HqfanxD5ST196gjDD0YY4xUsTYyAyj2p3GTxySbOgwOM1IS3yjGenSmKyhSM9exPFRrLtGQc+uTRYC0GwxAHB75/SjvliAM9qYpRs4HJ5JppkZXwB0PHNJICVWYKxwAo9TRUTXDFioAJopgcASGPBA9qiPGT/Onk7ScioixIOOc0wGyEDk4H1OKzbu+gjDFm3IvPGcZ7c9+atzEMgDCsnVnhtrQZVC4YbUYdT2x780Act4g1AW99Y3k6pGUzt8xWxubpx09a8a+LnxluJk1HS7C2e7MZKSXTrtjjfOAB0zg9z6CvVfEOpQaVeXmsahh0s4SBHuyoYKTgDu3WvmHX3a/sdLtYd0lxcO9zLycyscsenvSA5Ge1s7WztzK8nmnIlBzhzg9D0xXKa1MqtJ5X7uNmJRTkkDsM16qPDGo65fxz3UEcEkSEbZEJjXoeQOhOMc15d8Qmm0/xBLbSmJfLQBFhGFIPIOPxpIbOQubh0DAnNZzSMzZ3VbuE8wZB5qqYMsPlJI9DTbsG4i4zkHB9KnTeEAHIqSOxaXlBk96uQ6czEYB+nWsnJJ3NIwbM8EuRxz6DrVyzgZjuABA/CtCPSQ7AOpGc8YwRW9Y+HHJTA8zPAwO3vWEqjZrGkx+n6ajwrIg+VgM7h3+tTXOguCsgj3oFz0rsNF0FIE2IC6Pz5JXJU98GtVPD0iL8keVxjB6j6isHUNPZs83i0dskKyoucspGefartp4flmu44Y8nJ4/LpmvRo/C0cyKxXY+BkBhzWxpvh6CJ0LRAgHkkUnVutCvYnnKeGAgf91k47HpVG60d4I/3a85O0AivaZNAt/JkMfyFmyF4P4VzGraEFkYqpIHHTmoVTXcbpnlY0J5TvlBCKMk+v0qK6tBGCCg3OPxFd5eaY/l7RGSg6AD+dZZ0XzSDt+Y/wAPpXRGotzN07nCnTN/8WcdqqT2+1yFXIHcCu/uvC/B2DA9MHFZs/h4wDLfKfQj/wCtWvtjN0mca8BRQW701VAxkda37nSCin7xbtkEfzqi2kSx/MGGfeqU02Q4tLYoq4jOGxgn7ueauWuoLbTCTy0kYdpBuU/hmoJbeVGORyfWoxG2QTwR2roTTMrHoHh7xxcXEghOkxKhO7Fupz07nIraTX4mZ8QqpHDLn5l/WvMoJGEm0fN9OtbsNxJNnLHJPJBxTEfSn7P3jdJdZl0sjyzNsKg9CFBAXNfVuh6kqkRuCu5gAuegHvX5zeB9Xk0HWIrhTuPZs8jkV99eDNUXxTp1pNZq90WjQ5jG4g7RnoM0mriR6PDKgJBOVPFWISik5Ukms6CCeNf3trNCT/fjYY/SraNlshxu6YPFCVhlo7FOeenrTwFEYIzu7+lVhuA+8MClEzcY6dN1GwFxCTtYHIB70rSK7YPLZ6H0qsGJHXp3FSBtv3mApgSlo9+SMN6daKh+VgWPJ/WigDhWOe+aiJOeB+lSkAds+9QsCMEHBoAgnccAjv8AjXL+I9ZtLG4W6dHla1m8mNYz96RuMY74rpZFkUgjazDkmvNLKBddeyu7hEaLyyyW6nC5LYyQBzk5pXsBzfiDRDfaT4gv7uQ3F6EnkjhcbkXK545/CvF/Atm9zrej3UoZlzsMmMZ+U/KPUdM4r6h+ywMssbL8oJDoxBAzwc/iMV454Q8PSXGn3emXqMl9pc+xlVcGI5LKw+o4+lTJ2KRfWzGlSJLO80dszBxNIn8PPB/E/pXxz411o+JvGOs6ksRSK4uGMS9gg4X9BX1z4nv/ACPDN3pN6DGzoyRSbDskyG5z/vY718hNalFDM2HHDbj3pp2QtzKe2cLyM5qW304yck4PpVt5Ed8KPx7Yq9YR7nztB44rGcjWEdR1ro6hcZOfeui0fw/FOVDcEDIxkg1Lpun/AGhk+mT25rrtF01bfjocYzXBUqWPRp07lG28ORJhjEqsT1xzWxpmiRxuBtBXPStiG0XHTNXIYUjIwNp9q5HNs7FBIsaZpscbA7VySO1bS2SKjEc5PPFZ0DkNWlE5ZMZx71mpWG49EVmsVDnC4HcYq5BCAoIXA7D0pVV25Yg55qXG0ZzgUOVilBCSwr26elVJLJXByvPvVsv6cimljzz+lQpA4Iwb/SSFxtOD2rJbSRvP7raR37V2xCuMH86j+zqCcAH8K25iPZo5S30JJASdye4xj9aSXwkjnd8rA9c11RgAOSuPTilztOMZHr2qXNh7NHD3Pg5CT+6VtvTdzisy98GmRMxxn3AHT/61enCNepA/Ko3hVv4R+FNVWmTKmtjwrVPB8yFm8rYM/wAXNcre6RNb7sjPfgV9J3mirdxtub6A9K4bX/BxiBaNcxnJIx0rupYht2OKpQXQ8UaJgcFiPxq9b3UyY3YYV0OpaKEcjZtP0FYk8D2rFQB9O9enGakedKLi9S/YXq+cjGXywCDhgSPpxX3T+xn4waO4vbJbp7aKKESmQAFhluFXOcCvz+WUNk9MnoTX07+zH4kGl3zLESXaErIS33+eP58V007X1MJ3tofpjpvi63dR519GG6nzCB+eOK0nuNH1BcSiynDdzt/rXieh+OdENvGyWz3ExGGEnQGuisviBZmEEWMccfoXwPzxirlTV9fyJTdjuNT8DaXNG8kLGzB7p8yfl/8AXrldU8I3+kRtJ5a3FuDnzYuePcdRU+k+NbO6zJapPE/IKodyn861I/HVl5qLcytbyDglFJBHutZuFhqTOK3ewx6ZqT5SASSPQYzXW38GjeJvns7hLW8B5Owqj+xBHFc5qOl3mlSeVNFweki8qwHfNZuLW5ommVA4wQF/HvRSHIU7h34xRSGcUScnnjHeoWfPenOxU4xwRyajBwW75oAq6jiS0nRX2ZjZd45xXCeF7NU0+xZCD5cESf8AjmScfVjXcXP7xXXpng49K4zwwizyzwMn2R4AzyITwCDt/HGP1pMCW7t5JNVJZk+zhOp6s+On59veuH+JfhuTSNRfxRp9w1rI8axXKjPzkYAz6g8flXoseLsIy4Cbjk49zz9aDt1C+FmU862tsvONoYbiMKpB68EmiwHgfiCS98SzxaFaRLJMIvtEsiS4jUMCOCfZuOK+XfGmktoHiLUtJdcS2sxjchsjPt+dfX3inw8/gzXtR1PS3AgkaUvZkHbFhtqH028gj618b+IrhpdWvZp5zcXM0zPJKerEseaSVhmSp2yhRnGK39OBO04OfWueiIEwPUZ7V09ghIAwefQda5azsb0k2zsvDNv5u9mTPOAfauxtrQJlhnFZvhyx8m0UMMHA6iuighTaBk8H1rxpu7PagrISJtgAyPxqxE/ryfamNAg75FKNgPFZehsi5GQrjcMj0rTglyvNYqZHPWr1vcAAK2VPpT3GzVEgI6YphYjkkce9QxYfkZxTjHGBgnJ9cmpbsJD/ADgoznimmYZ61VkiAb5HbH6U0I6c7sj6UJFWZoJJkg0pZlXpzVVN6kZYAY/WpOSCd27HbNOwMk+04fnj608uGGRzUOQRy31zSoAM4P607AOMyr3xTS4YkZ+Y015Acg8VEGZTmkOSRfiBxjkiobq3WRWHQ85p8UuwDB5okl3EnjPfit4q2pzSWhw2seHoTIwCYGO3avNvE2kSWszkfMuBkkYOa93ubZZzkrg/yrl/E2hw3FpKSBvAyM120ari7M4K1O60PD9rRPnbkfSvav2Y0S+8cSWrSuqmHzAnqQwBH6ivK9TszbTnHQjt2r1D9l2+GlfEe2vZUDWvmrFJKekYbJ59Bx+le5Savdnk1E7WPtzT9LS4ZI7axjteFw17KUAPsg6/ia1x4InSzt7+S4Es7ztGoRQEUDuMnArqptM8L+JrkarqGto6kjyba0B+YAYG446/T86k1bxJ4Y1O1j0i5Y2UEWQog3AMD2IwT+tbOu21ZGah3OJm8SL4b5XXFkdc/uoFEuT6dMCr2k/FXxPq5Jt9MsVth/y2vIcHH4YrQbwfaRqjWEOmXVqegmiKOB65PJrmdb8M67f3JEMUJtl/1axkhcVvHkqasz96Ox6DpXj6NiU1G50yGfP8ELAD8d2a6aLxdoVxGI5dTiIIwY2Q7W/GvDU8Oatpu17iLEX8W0bsfjWpZ3koURiyWdl6EqaHT0tF6Am92tT0TUbOxnmZ9NnDp1MROSPp7UVycE+o3aKYZRZOB0AC4ormdHXRmqqdzBYMRgVC5IIx37U9t2D6Y45pkh2gAda5TYqXWcZPGK5m8SNPEA3HymdSdxGQ3Q7f1/Sunlyx4bB+ma53xLZ3S/ZrmLyZURz5xb5WAxjP5Z/SgBukyJOrPI3lOkjI0JH3ecj+dWdLjgkge8j+T7TK0zbh823OFH/jtYV3KttNJc3BMDqSAwJZSGViPrzj861bATpbRxyFDIiqjYUZ6Dg8+uam4HCfHm+msPhpr8sUfmExiJXVuRlh/KvgKYiYdSSedx/rX3v8f72S0+F+rvuGxpI02r1ZS3zD8s18JXUUWX8s/L7NmjpZjRnQgpKM13Hhmza7ki2/dABwf61xkCYkw244PWvXfAmkr9mEzIOm0fTt/KvPry5Uehh4XZ0unW7JGi7iP6mtiG3Izls+lNt7fABVc+gxV0xsAMA815Td9z1VoV5oWCkqcn0zTYYZXPI6dzVgwOf4sHPQ96ZsdTkN+BFZjQoDK3PFTQsM9TUCrKAc4NWIFIIOBgetVaxRfRTtzkH2pssyofvcCgSDbg8ZqMxJIcmhsEN+0quQT+NBvY1XPp+lWE062dcE7T3Kk5NJL4eidCVkIHQHJo0YyoL9N+Ac/wBanjud+dvQn1qu/hyZT+7nVsHGDmmf2Lcpxvx60Elz7zcE1Iu/GQSfWqsen3KEZkJA/wA+lTgPGMM2D+tMq4yaU9AQW96LeTeQOhOMg0jXG8jeVNW4Le3Jyh2nqSGz/OklqKTLCsnQ/KfehnQ9CCaQ2wOP3nPvTVtATksCa0MnqIQxAxWdqtqZrd+Bu64rWPyDaV4qrefNC4xyRxWsHqjGaueDeJCYtRlAIChsYr0b9nmxnOrR3ikPZyXiW90uAV29iR+PB9zXnPjORTq0wxnBIBA4xmvU/wBniOTQtTtXkG+y1eMuvI/1iHtxx3r6SglJpM+fqdT7I0/RNa8EoW0d1uLRvm2Sn7nsBnJFSXnjq/1T91NYWNu6kbrpI/LYn/Ip+geO4tRgRZUWI85JbORVrW9KTW7Y+QYQPvZHU/jXpKEY9Dl5m1Yq2Xje6tZBH/agkjH3lkjyPw4q9feIrWTyzK0mGGQ1u+zP+Fecajaz2TOCc4boDWloN41/B9iaJM5yg3BW+gzV8i3RF+h2dv4sigdlcCeMgALLIA/4nv8AlUkXxFfzFgsdNtbbP/LW5y+fxFcnNFNpT7hZBGB+9KufyrRsfELalC9teTLHAV2hHTlGx1UrXHXmoNaXO2hSdVPWx1U2u6tHGslxfWyJ2jS2Y/kaKqeGL6xWRImmDzW5KDz5Qob3Ax/Oiub61BO1rHR9Sm9dylKwUAk8elQySEMckqOnSpvMUDJx9aikbIOD8p9azMSs5AIyR+NV5RuhdQNykYwBnvVlgD3yKidEZGUjA68GkBxfiq1l0+0uWRB9lljAbcMshDKc/gCa0oZ7K5T7RDJDNuPE0QI3Djt3q3r0Mb6VOXyVjQtgDO4Y5+vSszQrCG30iC4VFJCBtw6EADt+dJoDzX46Qt/wg0wMXlhyVyCeRjnIJOOlfGl/bGEmPYAVwM96+vvjF4hXXPDSxRK2x5DlC24gDkj8q+UtaiUyuIo9qg4wTnmnYaOfghLzgDkewz3r6D8O6YtlYRoGU8An3OK8l8F6Mb+9bP3Fb5s/0r3WxtwkaoAMKOwrxsTLmlZHsYeLSuWI4fl65wKl8kKBxmlPysARxT96+nTrXBY7HYqToOeSo9uapuu1gd2fwrdCQsOdp/Gq9zp8co4Ix+VHKK6ZmgBgCCc1OiMg9aqtZvBKCSQcfnVhGbb6mq5S7koIHTJPpnpTJJCpGM0xvlAIqvJOQevHvRYd9S5HcFepP41ZOoHABbgdqxlmLHJPFP8AN545FTYo2P7VAPXp3p41JZDjHPrWN5gzTxKBT2Ebcc4PUUj+W6YP5VkpdbV55NPF3nOeKVrsLlptPid/lGO/WnCxeFvkcFc1VW5Jbg1dinJHP51cUKTJ4rd2OC/apjbsvNMgJdhgE+4rQ+yOIyTn8aq1jJ67FHBLYwTVe+gxbsRncAcVdMZTk8H3pLqPzISBzwacdyZbHzb4nkK6xeY5VHIxjjivePgN4fubfRdFlWCScmQXsZ2/LscFXXPt3+teF+L4RH4jvoVO4mVuCenNfSX7Pvi+30rwvb2l2xX7KWXpnHzcY9uTX0MZcsUzwHBzlZI9tsLWKKV4ZHit9uR7ZB6Zrb0/Sry6kXyVLxEZDKcDFcDD4itNR1hpY5Q0gO7ZIpAr0PT59QmtEkmuba3tiBgPKsfHYY6169KaqRujiqwlTdmi1qHg28njEj3NrHJj/Vv97H1rj9S8PG0n8ssAynO5Txmu4FrbmIE6hZDnILTVn3Wn2d38r6/YRDuxJY1tHTUz3OZ0zU/7MzDdoJoScrJIclD7GrtzHBLH50QyCQ2FxnFaMWg6ZZzbotZ0/Uj/AHZf8MmsbVkMcoms3EW04KDpn2HpXLOClLmN6c3GPKVWujDqCTwW7pGxw+7OKKry6pPfxGCeUu3YMOc+gorirYVzldHfQxfs48rO9YEoe5qBs9+asZbbjHPvULBmzgZ+prIwIjyPp2qCTCqffrUzZXjAI9qgIJOW+X2oAp3UHnQGOQfIw2kDqRVCGI2FlNESzxgZQtycHn+v6VqzuHRgvLdcVX2GSI5I2nqB1oA8H8eaTLAfsaxPNFHKJHuIgT1VsDH/AAKvmDVLaSG6kEqmM7mGD0yOvNfe+v6XbXt7LDKuyKa2LMy/eV12hcehwa+VPHvgf+ydSvoTbGNoXkkEgXAl78dcAVEnZNlR1ZR+F+jLJo6XRjDM0jckcjHFekRRBFOBgmsrwBp3k+GdP7F4/MIJz1Y/p0roZ4yjba8Spds96mkkUZSVFc5rfiNrQMsSBmHbNdLcxgxkdfzrltT0rziW2568Ypxiuo53MBfFd2CGPGc8DPH51qWPjVo3VZAw9yRWbLojgNiPP4jiqF1ps6dIWP05rVqLMLs9Bh1uC+HLAH3PNStPGAdhAAryU6lcWTn93IoHGSpAqePxNcsRs3Mc9FNL2aBVHc9Mkn46ZqvJJv6Yx61xNrr1zKRvLcevWuosJ/OAOcnuaylTsdEZ3ZcVWxTtxU4NS4JWjy+vFZtWNUxgwcHNKW5xTgny9qVUHGcCkkK9hFPTNSKBjrVHULxbSPqCe9Y58TJC3zIR261ag2Q6iR2MFtv59MHrV+KBY/mJH51xEPjmCIDae3IIptx40N3AUUqAegxVeyZDqKx6AdestL4klTcOqtxU0fi61vAFXCk+teMyPJNJvEm49cjmtWwtZyyybm69DV+yVjLnPUZJvN5XNTwgbVBOQeOawtILrEofccAda6KyjBI4rLZlt3R88+OdGe38WXqs+53mLZxjB9PpkV6B4RWTSr+GESlfPTLoTxuGMn/61bPibwo+qeIZ4kt0kMpMiybcFcsfzp1/4WvfD93pJlgK3YwcMOWOQMn+dexzXikzgpK03Y7a3i3Qk7iHOOf6V1HhnV4WeSFrfN1F3xkEetZB08woyr8wB5asu4uJdOlM6OQcFXC8FlzyP0FVhqzhLyOzF0PaQvbU9Y06WK8uP30h3nlY1HLVq3nhjUUTzvsLw23GX4fA6ZIBrD8KX6w6VHLbWa3mnTDfulUtyeDz29K7/wALadd6swOiG70xzkZk/eW+Pqen/wBavaVdI+ZdN3sZ0XwzmubNbuzu0l7gGLaf51jPo9yjMkqusg/hI5zXoFgt14W1drLVNS+0y3A3L5BLJ1/Id6sazbqGXyyokzgH1rRS5n5E2tueYHSpLVll+wf2h0JjXcGU/hRXpVpo9zL+8iWOGYnmQHG76iipdr6j16GA7c7e/cioWJUn5s07eR9elRP39a8nU7BrA7gT+VMJB4PWgk8HJ6U1jjr0pgRzD5TwOe9VJG8pMEfTHpViRwQcjHvVZ8k9yAc9aTAw79xPPDIyMoCkc++Oa4Xxv4Tg17TxFytyykPOerAjkc5r0C7ZmuHGfunp0/zxWVroVbNi2DIUOwn14H8s1DQ1ueV+HLMxaDp4BDKkW3cBjPzGlu1w3Tn1q9osXl2XlMwJhZoiCSTwx/z+FRXMOWOcflXhz0lZH0NN+6jHdSSRiqE0ke4pn5gSDx3rXnix1GRWXceTDIXY7H7nOAfrUaluz3IHgRFLEAHuRVRyG+VYy+PRSah1LXbazgeSW5ihQHG5mGT9BzXOXfxH8PWIAuZLmcE4LowUZ/MVSu+hDaia12IG3CRAMf31rMOnWauXjiUZ9uKqt4x8N6rEptdQVGY42SyYbPpyaqvcfZiGSTeh6fMCKtNrcjR7G6lhCAAVXjoKs2sKwsCvA9ulZmn3/wBqXOQGHBFaEExBOelHPfRlqNtTYhfKDJz6U8LuOapwXI25GDirCTs2Rjp3qG0jW5PtyPT8aaxwOuRTPOJQDtUc0hUAZH41UdiHco6jaC6JLZ6dqx5PDUb8hgh9iTW5LcADJG7HesG+8QYmMVum4D70jnCrVKT6GTiupA3hVSQBITmtTTfCtjDgvF5jjglmJUn6Vgt4osEE0V74htbWQDgw4Y59MgV0Wj6lpCwKy+KFcOAVMsJbd+JUYqm5dTNWOgg0W1C7RbxKDyCqDt71fh0iKMqQgz3PrVO0uXhto7jfBe2hOPOtW3Ff94Z4/DNb1vsljDIwZT6VNymtCS1tcHHbsK1rKHLhcZqpbRnnPNa1rDsIOM4FSmm7BayuWrHR72/8QWf2dEMJlKkO3WTnAwe309a6fxr8MtVCLrt5s8rIEcSZJQKe579DzW34O0XyJ7O5mh82yuFV5QOqnGVNe36zoTax4HuIpEWWNIwVbdncPb8K9ZpuKseTGfJO58y2FmZLZQSeR3rB13TjC4J6Z6dK9k0/wrp0i7F86HI6hgefxFY/iz4fkWhkt5/NZSCIyNpNcnK4s9r6xTmjk/hN4nl8L64bW5lZrCUHyo2yQrk+n0z0r2WDxLd634kg0pZFSyVtz7Bt+Ucnj9K+f9QsZbWQRurQyrhhuGCD1Brt/AWu3t5qUkkUaSXLQmCR3kCKhODuJPsDXoUpKW55OJpqL5o9T0zxTqdrJq32w+bPMpCxpGQqqB05PWtmw12LVNLie6ntLafOCJJVDYzxnnmuV8M+HreaRzf3CG3DcSQOSxPfB6Yrr5I/A3g6z82ZYgPvFZBvc/mP5V6HtoQVo6nmckm7so3Elo7hEuZL/kDyrOIsfxPQUVzmvfHm0tA8Oi6QrY+5LJ8q/wCNFYvEyvqaqkDEtnIOKYRu96lcAnIBHbpUL5DcDj1rAsiwQ2CCMd6ZJnPsP1qQ5weeahdyq7Rz9KYFeSQtkjpTAOPXNTMOnOfpUZOSaQGZqMOJPMAznGcD0GKytTja5njtwoG1iDj2/wD1Vu3TZV89AuR+YH9aw4Xae/Zm6cEZH5mk7AcMszXH2tzH5bNdSEDPYtnj8TVG4hycA8Y5z61sXq48Ra7/AHHuywB7A5I/z7VnzocspPSvDqK0nY+ipP3EZktv7GsTUfD0WohlcsmeCQa6U4X3qJow/wDOs0ymnueU618LoGd2F267u/rXLeNPhtPqNlBPbKhnt0O4ImPNHXgev59a9vu4BghuVNZk1ptTEZBB/hYcVtGpy6s550+bY+V9P8G3WqaglvbQyLdMcFSrDZ0ySfavUX8GDw9oqibUyz2+AXkblzgcY/Cu7utODyMwtvKdiGLox5x+NYWoaNuc5DPkdGPB/WtZVVIUaLi7nGWutCyv48YILbT+PQ13Ecm4MQQSec+tVLDR7aGdZfscQlQ/K+wcVoCzBfpnvXJOSk9DpjdKzFtxkgg/WtCAMRzipbTTsJnbya04NPDAcdagqxmMCi+wrPnncdK6mbSNyEDk+wrDvdKMbEhsqKadx2ZyPinWzpdkFUZklzgf7I6/0rzzXrCfVbFboSPJAN2+MN904z+Veuah4et9WhVbiJXdAQrN1GfSsW28L21i5VoMr3GThv1rspzUVsctWm5bHi8eizSuixoJGb5VEbA5/AV9KeFfANppHhe0tLiziln8oNMZkDEOQM49KpaTo+mWcqyQab5Eox+8UAE/Su0t5FujtVHjGOhYsfxNa1KsZKyOaGHkpXbOLsPB1/8A2tPqGlTixhDbVEik7+nGP1rsdF0XVrTBu9u1hjagxzW5pluIenXPeuggTeozyT61xSnc7YxsZ1pZlVB56elacUGBtHG47cmrIhVFJOKfZobm9hgH3mYH6Y5p01zSRM3aLPa/Cunyafodtbz7SfKUOAeVwB/h+tdvpOq3OjadHLaRSXkMjeXLbldyhT34H1rlbRi1vASCsmwAgmt/w9qVxYTgo/lqDnuM+1ezHRHhPc5ua3Ed7KiJhCxK56qM5FQ6mkklhcKBmdULJkcHAr0L4g6edRittes4sxFfLuQo+63YmuNkUSw7sgOOhqtNxHk9x4aj1FIZlnMt27BvMmOUHqMfStDWzB4eC2Nhp5ljWISSSxYUOe55zn6Vc1O2Onap5aJ/olwMpg8I3Uil1GRV0e4lOXeEDaufvDOMfrVOzC7I7HxJOujRLaINrJxv5wa5bVAkSG41G6EfOQZm5J9h/hU2laNqBSQrvtYZZN6Qhvug1leOfBjwPZXfLs+QwJJ5HfH41nZx0TKvfczbnxTaszJZWsl0eglk4TP060Va0Pw2WdCy4XPPtRVcsRXPYZCFbPU+tRyZIGCM06UcEkDNQsw6dPfNWSNcANywNQblI/rUkjbeuajbbGR/Ki4DWxnj9agP4/Q1MxDHOOfSoWxg55A9KAKlxGJSwboBjGapCPYAx4xweM9uavb8sAQCenSqsjfZnKkfJ2c85qWNHIeJA0Gs7uCk8K8sO44/rXPXJbeefrmuu8XQeZbW9yoIMZKMdvXPI/Dj9a5G5GOa8mvG0j3MM7wKxYYyRk0wsScggdqa74qHzSDz0xXJ1O3QdcrlOBk5rInLIfT0rWVgVx1HXFQXMSMMqoNLd2J5TEldn61VliLt061qNZsx4XHenLY7epp3YGXHpygAnirFtpiswOCc846VZkAUkDH4VZtW2kAY6VNrspFiHTVCjgYP6VZSwA5zxU1rk4GM+1X0hLKcrg5pvQqxRhstw6Cq97pKOoDrjH8Q71swQknaAT9KZeIyrgjBpehJx82lKhI6+9UbnSFckjg10dyq5qoIQ3IPJqyWYtvbtGdoGMcdK1rNyOKe1qM1NBCA3IouLU1LJ+B1zjvWzatg8/max4FCqD2rQhmzyTk+1Sw5TUeYkdAfpW/8ObcXfiuHcMiNGkzjIBxgfzrlGkJX/CvR/g3ZrcS6pMYgZEMYRiOn3s11UFqcmIkoxseoRLGiA9/Ujmlt3JmJyB+lAkjQAk5b+6O1AuFfIAwO9elHVanjvQ7rwlqLorQYWaGXhoWOQw71n+NPBK6bB/aOnxuLFz+9hY5MLf4fyrM0W/8AKuFZGAIIxjsa9O0TXY9RgNvdHzAyYKsM545FU3ZE2PnO/sY7qUwzqHjbrUkXh2300gwbkiYfMCc/zrsviR4SPh6+86LJspuY2OePb8KxLb9/YITz2NDv0EUYdOjWRSvzAcfNVfxVpq3WnEOANjhs46f54rQgUwT7T0Park9ut9BJEerKcfXtTEecx26p0XA6ZorTTSpyx4PynByMc0VomBekYtnP44qA42nPT0qZxwfSoSMAFRgVQDGwFANRFxwxGBUjDIOePeoGHuMCgAkcEgnj+tQvz7Ypzv64/GoyeSM9aAInADAgkc9RUbL5rAfripXGfmJHHSjnjaCfpUsDM1e0a4sJ4tu8bCQPwrzW8DI+D1Haup+I3xX0D4Z223UZjcag6bo7GDlyDwC390e5rjNK1yLxVo9vq0MaxR3SiRY1OduR0J74rzcSrWdj1sG9GivL8xyfvHNQmNuP51cKgZ9KY3HSuFWW56ZEkTcA4wKe0APU59qd5gFMaUg8cj6VDGhfLUA4496oXsoC9DjnpU882B6496yL+fEZY5zjOKW7KaSMu91TyZSvIB4wev4Vpaf5xIDo0bcZDdqwtIsJNa14yyOyQQ4KxrwGJ7/hXcDTlgX5ckCteW2xKRc0hCZkBBYdxXULaogBJyD6DpXKWr+W2AM/St+31AhRuyfVj3qGrF8rLht1jORx7CszxAxEZIHbrWjBeLcMVXCEH17VX1CMu+GHy0loQ9zg59SQ7geo4I71NbNvxzwaw/Gts+ka5DLkCCdDgAZII4b+laOlTB40Zc49auyH6m0kW4fMMn1qZLQZyBjNJAcr6kVdhbK471ItiNIyPlYcdRVuKMLjikXAx35qZVGfQUkQ2DEAH1Fez/C2xWz8LQuARNMxdyeM5OcV43HAZ5UiRTIznaFXqfavavAtjrMUUMd7EsFkFyI2wH6cDivTw8Pcvc8nFSu0joZbdy24Y9+aciMy/wBK1JoI9wbbsA9TxVK4nQjarD8K322ZyJi29wbY/KMGum0LxMtrOHnBYKONnWuIaSQS4AwO5NSJO6OApBJ5xWid0Q0e1fbLPxbYy6ZeKpglXKSA/Mh7Ee4rzPUPDs/hO9ksbgblLZjkx8rj1FRf8JMmkQxXc8cixqQuUOevtXaaTrtv4y0GNLqzkls25juU5eE9M8VSWhPU84ntmWcNjA/nUqfK/PFa+r6PNpNyY3YSx/wTDlXHt/hWWyESZH4ChICkyhLiRW4IPSim35ZNSXkDem4D6cf0op6iMRyT3zUDsowM47YFOlclhxx7dqicgglhgmr1Aj35yAScdDURDZ69qez7RjGMdxUEjfL160XAaQACWORSbwBkfpTGYngEketN3hRgUXAR2Jz69K87+PXjGbwb4AY2s7Q6lezLDAUcqyjqxGOeg/WvQGJZ8dOefavlX9oPWb3xX8TW0y2iluItPRba3t4kLF3OCxAA5OTj8KFe4HkV/dT313Lc3U73N1KcyTSMWZj9TXufwI1Vr7wRcWLsGksLllUH+43zD9c1V8I/skeNPEkaXetmDwrprY+a8+aYg9MRjnP1xXuHhv8AZj0f4ZaHqF3Z6lfahq72/WXaiSEcjCAZ/M/zrkxHLONr6noYbmjK7WhyEqlT2qu2MHnkc1POhSR85Uk5KnsaqSyEcdhXlO6dj1xMgevNMeVQDk4NQvLkd/5VWkuMcDnNO2hXmS3EgVT2NY2oOsqlSMg96sTXBGcnJqmFM746D1rNLUrfcteEoFiaZwwB3DgjO7rXTz3I2ZAFc1AxsUJQFgB92sK6+IksUxhm0org4BWY5/IirV27FOStY7VLnEg5x9PSrceoHHDce9cRZeKbK7bKymFuySdfz6VqQ6rG+PnXnodw/wAaGu41KyOus74I4P4Vqpexz5UsB7muAn8RQWMRaST5sEhEGS2PSqtt46hD5eGUJ0+Y8/zo5Xa5N1fU6n4jaZA/h5J/keWN8hwMnocj+X5VyPh+43QqvZcDNbt7rcet6esARtoYOAR3H/66wILY2MwG3YvtSV2tRN66HVQTgHFXo24yKw4pCQK1LaX5QCe9FtCWaETnaM4qwvIqrG+T+NW1OMcY96cdWZsvaKWi1GC4jXc0Dq/IyBz3/DNe63Gv+QifZyHJ5L9fyrk/hJoty+g3V3ZRwzzSSkPGT84A6cHqO9Xrm4KXzW7xtFLuOUcbcHPpXpR2suh5NWLcrsvajrV0UDCQnFZ1tqV5eTiNTk+uMD1pty+1trHP0GcVY0m4itoXbALA8ZrToYo1beBolD3b8+5qrf6NFJcPd6feNY3QOcMco2faqGo3E90oPKjOcClvNOuprSBra9W1uVHIflWBPQ1Ub3JkF/r95Fps9hq8Xls+GimH3GI/z+tbnw98YXsMEWj6dLi4lYncrZCr15P51ylt4ju7OcW2sW6qjHiUJujPvVLw7qw8N61cTl1aIhlj2cZOflxXWlpsYPc+pIdN0y/0OHSLmQpeEkxyOfmZzk15jrER0TVYrC5IWd9wx7im+CteFvcf2vqiP527dGpPEaepNb/xD01PHVhBr2ij/TbVd2cf6xOhPuRWdhnD+IbNJ5NPuJCySRSFVIbAIPJGKKo6jrKXkS2GWe5gYEygDBI4NFKzAoOWLED7tQuxBwxpsshVMknrwByTXceHfhlNJDHe6+xtYiNy2SnEhH+0e30olNRWpcYSm7I4eCCe+lMVtFJcyD+GFCx/Stq3+H2u3B/eQ29rn7v2icLn8Otdvq2qw6TaNa6VbxWMeNoES8n6nvWFpd9PcajmWQu5Xqee9Yuq+h2Rw11qzB1P4ea9p9s8whguolGWNtJuYD6YzXNHCrtIxIpwVPUV7C/iOPTm2y59lUdq5vXtY0HUpzPcaQk0+fvGUjd9QKFV7oiWGfRnK+GvDsniW9aPzDb20Y3SzgZx7D3ro4vDmgeEEe5062tftEYLyXUse+eRs9iemTVS68WiCEw2sUVjAOkcQwP8TXI6j4jaTTLgIpLSyhAGzx71jObk/I6qdBQWu50C6tLbQy6hqBSe/c/uYZOREvY+maybXUptY1MSSSljnJbPFcjdX73Ooyq5CqGIOee9belXYSRdoA9MVzs6lFLc5T4keHm0jXZJ4Rizu/3i8cK38SiuIuE2ZyK9t8ZW1tH4J1S+vnxFEm9Sx6H1FeDaTrtl4k077ZZsXjBKEPwyketYz7m2mzIpW49CapyuB3q/MigYPFZN/mNCQORWehaWhXllLSe39Kmh2gcHFc5d63JDKVWHewPXnB/WnxeJJYIz9os5DHj70Izjj3zVWYHTxyknnBx3qlqenRXbbtoDYPQVFY61Y3SkR3Uef7rAgj8xUs19DF/y0Uj1qW2iWrmDJoioQdvI+tR/ZGT7rMMehrZF1E2TvHXg560g08yNuLbKq7eoWexVtrAtGNzFyf7xzVyz0SMyZ2ZHv0p8EKmLbHOiSjkZHXrxz+FaltHsAGVJPowpX0sO3cu2dokSYCgYpt/bZ+cAcdvalkvoLVRvmRc9BnJP4Cqb6zazkhJ1J9OQalXQrk1tKFYc4A61pQSZIxWFHKvmZB3D2rbsyWZccZFNjTNO3ySDWpaQecwDBivG7b1qHRdKudXvY7O0j3ytyfRR6n2rv7nwpFoNmvlyl514d2/iPXgelUlbUhnR+DbhtPltry1+RG/dyqhxg9VOPwr0IavHe4N1aR3BPR2QEj9K8z8HTiVJoS6gl1K7umcEGrcuu6h4YvlS6t5IbVmOJPvK3PY810ryMpRT3PT7XU7VGykKRgcfcFX7hNJv7cG4s7eXcOTs2kn6jmuW0XU7XWosxSKWwOBVkTFJGjcOuPUYp3sZ8itawt34S0TUZAkTT2JHQxvuGffNZF78M9as7SSTTbmDUio+XIIb8jWnHqlnC433Me8dTmuh0jWYjxbziRh2HGPzrVVGjnlRUtjxseILrSJPsWs2CRhjyHTINZOqpa2OtWtxaIi2zlZdmcr1+YCvo6/sNM8R2xj1CzjlduPN2DPNeca98Gra2Z5IpZorcndvhPyfkc7a7IVYnDOlJPYxpNTuvFl4mnadve0QAymJOo9M/kK9Q8NjV9PtUit7YwJHgBZE4IzyK5zw14et9I06O3t5hGFPzSLwzH1Jrq9O0yATB31VkPQ8n/Gk532M+VrczvGXw/hks7nXLWw+z3w+aSJT8rLnlh2orutLW4hQw2uqRXy94Je49jRQpfzEs43QfBOn+ClW7nkF/qY6SuPkjP8Asj+tRar4j852ZgWOTkk/yri9Q+LVm5YiORwepI6/Suavviba3MoUERA9m4Ncustz3IwjDY668vBdOcgjPvzVLTZfs+pO+SWHHJrm7fxlCCHMq5PbrzV+08T2896JJYwAF4JI5NSaLQ2r7fcyO7dhnjoK5TULyO0DPLKqrjPJra1fxnplvpkq53zSfKFQ5JJ9MfSuUs9En1ucXGpLtjJzHadCB23f4UyZamPcX93qm42qeXAx5lm4z9PWrlnoxh06KWZ2fZNjJB+YkHoPTiu1FjFaQLtRVxwAAMCud8R3DSaPeRocsvIPI4z/APXofYa8zjb9DHeygHGGwcnNaOiS77pFbnB6e9U9VdZkSVTkOuScYpujSFblD0x6VjY10Zd/aDlMXwe1VAANxVdp54z/APWr51+F8C2+m5PG9snnH0r6O+I+lHxh4M1LTzuZjFviGf4l5H1r508CMYLArjDI5H0qKnw6AkrnY3pAY8YyOKxr5WddpGRWxdL58QI+8B+dZXmZJ3DBHUGsNy0zGTTPnyVyD39a1bfSYgASM/XvVyKKN0DL+VPI8tQD0qZStsUc9qvgy0vyXVBEx/uCsuTwdd2ijyrnKj+F+QBXZ7+c5wKRplJAyMn0NNTfUZwsmn3kRIeAsoPLRnn8j/Sr8BmaMJiaQ4wAEP8APFdO7qcYIFTwiFVBYAk8Zq3ND1ONi0bU55mVrYQDqpkfJb8M8VtWfhG/nIFzcqkP92Jsk+x9K6NHj7YyPSrCz8AA1nzO+grNmQPCNpah/JJQkDOSWzj3rJ1DwwkknmIm0nniuuaXdnuaQQ+aBkUczuJxOZ0u18nCOD9a6F7230mxN1dOIYgcLnqzdlA9TS3S2+mxtLMw2r0Hr7VxlvHL4/8AG2m6cGZYA/mGEcgKvPT34FawTmZylY+svhtocem6FHP5Y8+4w7yA5JBGQPwzVfxpLklVyoz0610fh4/ZtHS3JzsFcx4qZZJPlGM981XUpaGNoty1pBI4cZ81cp69a9LtrqO9ZrW6iSaJhwjLkH6eleVkFbdEPDNIBx1+td5Bdgaii8bM81okQ7XM/VPD174XvTfaMWmt85e2J+ZfpWZqPxJ1e5hMMlu8bEYOV2sPxr0DUFJjDDr39hXA65ZkTu4IIJOAe1WmupLOYa91C9n25EZbuSSa6TRdHuiVkl1SaNs9I1/qazIYNj7iOfWum02TKIDksO9XtsZPc7DQNZudMCq+rmdRj5biM5A+ozXomkeKI5FZCEuFOAfLIII9x1ryUQeehBAxUTebZtlHZMdCDStcdl1Os8d/DfQ/Gsb/ANmeIrvwxqJPRJCIifTbkH8jXini39nz4oeHc3OnavL4gtlGQ1ldOsn/AHwx5/DNep2/iifb5d6q3cJxkOPmH0IrY069u0mEuhXzxNjJsp2yp9gTxXRTqzp6bnJUoxlsfKmn/ETxz4I1HyZdSv7O6jPz218D+R3DNFfWt5rHh/4gQnR/GOiQST/cDSLskjPfa3VfworpVeD1kjjeHqdB86wRcgKC2OAoAH4Vyms+SQVlt4ZlHGXQGugvG/d4JwevP0rl9Tl4I5I9fWvPPYtY5a90DSpwZRaLCx4PlkjP61Si8NWYPzLLg8/LJj+lbiqdvAOfbFRSpwDk/WtLtgiPTNHs7WUNDAgfpuJ3H9a6bToCX3YyfWse2YooPBxXQaXKxXtyce9Q2NIZqcYVfVxXLXGzzZEl5R124GDnnPFdbqpAB9T0964vVZCsucBPmyQen0pWuJpHK5R7ErjJiJQnB7VX0xwsw5IPrV+ZFhv7uMYWKT94gHuOR+dZcB8ucEDAJrN3RunpY7vS4xJHhhuzxn1/OvmO7sf+Eb+IGt6XtaOJbhmiDdWU/MD+Rr6Q0mZWh2knBGeD0rzT40eGTKLbX7WEma3wk7Ac7OxPsKW6sZu6OcVtoAxx6VTvbPeN6fK4/Wp7K4W9tUkBDZAOae/PWuR7jV7GHDqH2SULISB9K1VkWcBh93GQapahapMpyMHPYVjRTT6XISn7yAnlD/ShxuWtEdG3J4/SmtCp+8Tj1qra6rbXYyj4cdY24YfhVlpl5HUms7PYtEYgyxCtweg9aEicEjd17elODLkhs/hUiZySDyPWrjoUWLe3IGSSatpbMvPWq0d2yALwfwqxJqEcEBlmkWCNRklmxS8wvoSiEg4wSaqaj4gg0ZBGw8yYjovRR71zes+PAC0OnhlII/fMM7vXA/rXLyXclxIzSMzMTkknv61UYt6swlUtojS1fW5tRd2lbhvQ44r0f9nHw6l7Nd69ImT5hhiLD+AAHI/H+VeOXpklj+zwKZLiY+WipySTX198JfDK+F/Ammae5DypGN7bcZbua617sTNLmdztLdxBCccdsmuZ1lvtL9MAcD3rbu7hYYjk+wzWM5ExJyOOeTUKx0dDMitxPqUMK5DIN/t2rfs1cTCQgEnsecVQ0xGcSTg7t5wOOlaFtlZMA8elaIzeh0sk3m24IPIGDiuY1HJc5A21spPtix2PcVj6m2QQB378U0hSMlovn9q07HOV2n8Ky2b5s5z9a1NNKkAENz16VdjOx0lkd4HTP07VJeRDGSAKSwixjHUd6m1YhIUyACe4ppg9dDEmAXvzVzSXZbhHXgis123uc/nir1gTvBPB6ZNWvMj0O3vtOtfE9gDNtjv0GI5x1Psf88UUaUA8Rydp9qKlOxD0KGoqoBbJDHseK5fUnDZGeO9b145JPcH1rEvIQynAPTnmoNjKiCuCAc02RMZz07VLbjLkbeO/FSTIFPH6mquOzK0bHGCuO/BrWsJTuAzz9azQmGyMHnnNXLdtkq4GCPShlGrdnMXFcnq8GFfBAB/GutkbzIj3x6cZrA1BAdx29elCEcVfKWSOcDJi+V9vUrWTdphtyjIrpLiBBIyPgxOCpX2rDMWEeF+ZEbAxwCKllRZpaTcBUUHGePwrWktYr6KSCdN8MqlGB9K5uwby5Qo69ema6O2ff/DwOuKzB76nhfiPQ5fA3iOSwPFpIS0Dn+JfT605syLkc1618SPB6+MPDym2IGpW3zxMejAdVP8AntXjGlXDhCkwKyodroRgg1m4rcz1uOuEcDkc+1ZVxD14/GulMcc/RgSOoyKoXNi2SQKj0LTZyV3brjnP1FVkv7q24SZgOyvzXQ3dlgk7eD7VjXVpknC5/GjRju0Knie4QfPDFIR0IJXipH8Yyqh2WsaH1JJBrLkt2H8JzUDQMAcjmqUETzsuSeMdTYtkxop6YQZrIutQub6ZnmlaRieMnp9KsGyLdufTFTRaaSeV/GtOVIi99yjDCzdjuPariRGIEnt61fttPdpVRE3E9ABkn6V6p4F+FEcnl3urDLj5ltyeF9M+ppqyeoWvsZnwh+Gb397Fr1+n3Tm3iYHAHc/WvomzAijAUEKO3pWdpsIihSJQFCDCgDAxV4ybUOf0qJNtm8I8qIdRn80MnUA1muhEJRfvvirGdkpLYK9ck1VtpN9w83G3GFzVJFbGiIdsaopIwOx60RDy3HP1pkLkkHdk96dIwU+hNWkQ2kXkkIXPIxVC9lzkdc1JHNngmq10yseOD71ZmncphcsDj861dMiG4eh71mIp8zOM1u6bEUIA5q+gddTptLjwAvr61DrpK4Tklc1e06MhQ3B7fSqWuSDz2BOT61mr3BrU50DDEkcVo2OC64qkw5wWyK1dMiG5cng1oTynX6WP3IwMhR0zRSWsoggbAypFFGpNjCuQcnryckYxVCeAlG5OCOa1psLuJHJ569apy/6thx07VJpbsc8imKQYOQaszLvXOCAehqLZtckEgk81cCArkjtSLWxRKYPvToz8y5yKnkhbgc9fSliiOeOe/PNPzEkzTtCJIiAcn6Vn3tuXdwF+X1J61pWTFRzjniq14o5B4xzQP0OS1CzwW2/w9MVhahbSArcqv3PkkwOx/wA/rXYXgyC351llcZ4yrfeBqWL0OaktWjcAKSDWvZsVATGD6Zp6RgO0UmDgkofVc8VJbRqsmPfgkVm0N6rQsvJJFGNpIPceorjviJ4Li1LSm1qxjC38C5lVB99a7iaDzYxyA3r7YpthdC0lKuuYz94UDab2Pn6xjieTz1GHcDOTWmgWQcfnXaeKvhDNLPLqXhl45bd8O1gz4dT329se1cVLFPp8zQX1vNaTpwUmRlI/Oo5eqM2+jK9xp6kHAzmsqbThnIAJ+ldAk0bDIkXH1qtOkM6kNIFP+9U2YXOYn00HtzVOTRiG6Zz2Heux+xxnC7t/0Gas2mgXF3IFgtZpSehWMgfmeK0SZL8jio9H2LyuPWtPSvDE+rSrFbRbgesh4UD+teseF/hItywn1kFADlbdH5/HFegpoFrYQiOCBI0Ax8oAOPendDjBvc4HwX8O7HQiLiXbc3eBtLDIT6V2TWwBDDH41YFosJwo2j+dShQOtZ7m6VtiCKPaeD+tJM3zYGc1ZAAzjH41lXd0Y5BHHzM/UD+EVSVwu7kN45klMKDHdm9vSlCqo2oMKO1NjQRDbjcx6tnNPJ7YwK2UbEksTfNzwM8e1T71PHGPWqyDaAMcU/cSMdcd6diX5iklXyDUE67jjmphGSOtTRwbh83WmSlqR2lvyNx3e9dDp1sAwXHH+zWdBGA2McelbWnRDPOc56ii5TRt6fFswexxWbriFrhvlHqa2LVfkA5BArL1TaZWHTP40kJMw2XDY7Vo6dxIueKqvHhqsWD4cY/OruO1jqIXIQDoD6mioLR+Bnj9aKL2JSuVZQD26VTuP9W3bHpVosSdpI9apz5PBzjvUGj0MTcwlOcHmrsRJQ8n8aoSHEpq/ak+Xzgg02uoo3F2sBk4PpxUiNgA8degoYAnt9KjB35xgY5NItal2JjnJzgmi6hGwnIIplthnGO3NWLv/V8DHvVXJSVzCuo8gg/pWZ5GWI5x71sTKWBPpVd4xvqbj2MSW1dvlwfNHKNjhge1SRR+YvTbIuQyccH3rUe2WRdw4I6EjoajhjWSQl8CccYzwalq4Kw2CJlB3ZxVW6jI+bHPpWsjhhgDDVWuY964x9amwzCE8tvIHjdlIP8AC2Knk8SzyoFuYorvAwDMgNLcWxLDC98cVWeyy3PIJ6+lJpMm6HG6sJsb9Isy3r5K/wCFSGWykXnT7XIxg+Sv+FRLYryM4P5042mz7uT7Umh2TJUnjTHl2kCE/wDTNR/SrkF27dRtAPQDiq0cLMue3fFWYoiOvWpegrJGjasxkBY89jitLIcY7nqKy7Xhx/WtWHp/Wk0aplOWL5jxVaQbeo6VduiseWLYUd/WstkfUDjcYLY9WPBbmrSJbRRvdQbeIYPmkPfqBVYQC35BzIeSSOlX1EbFo7VDtB+/jg0DTmCjuSfvE9a0SsQ3czwuCfXuaXGTxV5dPYMOM56nFSHTmBGBj8au7sJIogHjnBqSNMkY79xV6PSmPUHHrirsGnrjk4wOgoAz1gHB5/OnJCckYzWi1qq5xjHpSGIA5wfwpiSIoYiMfritbTlIbOdp7Z71RjHXHT3rSsFBPXHtilugZspymc7cjtWNfAq5JI5NbBZRAeeR6d6ybhhIx9PekhRRnFt78miNtrcHj60TDGSKSJ+QAP8A61VsU9dDoNMfKYGWbr9RRUWnHJG3jvzRVbmdrDCxBO0YPaqsrFlyRn1ooqdjQxp0IlOBjPSrNuzKvXn0oooKRMeAMCjqpoopWGTWxIUYH41Zc7k7/QUUUW1E9zMlB3HgfhVfaAT3zRRQPYdHkDkDHpUU0KnB6H26iiikhEfmBflmz7SDjFLIZolJ2iWFf4kOT+VFFJpAiMSLIoK4A6800xI7YIAFFFQNIf8AZRn5e/cChrUP15x3FFFJLUp6CJalRwCKkSDB+nODRRSaFEt20ABOTgfSrvmCGPPeiii2pT0KVzbCQLPcHJI+SIdAPes+QPMw3HCDoo6UUVqjJrUtwQqFGOCOwqcAEdMn2oopjEVc59BUqx+3XmiikUTbcgYI6etRs3JPGaKKBbETMT9ajZzvxRRVrVEscAcjjmtK0JwuOOe9FFHQzb1NAviPkZ+lZsuck5oopItIpzEs2f8AJqFH5yAVooqluJ6M2LOYjgfrRRRQmK7P/9k="
#     ]),
#     "idcard_image": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5Ojf/2wBDAQoKCg0MDRoPDxo3JR8lNzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzf/wAARCAB+AGYDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD3CiiigAooooAKKKbJIkYzI6oD3Y4oAdRQCCMjkUUAFFFFABRRRQAUUUUAFFFFABTZHSJGeRgqKMlieAKV2VFLMcKoySewrwf4o/EVtZaTSdFlK6epxLKp/wBf7D/Z/n9OoNI3vGfxigs3a18NKk7jhrmVSUBz0A7/AF6dOteTax4t1rXLoz6jfSyHsgbCL9FHH49axHV5HwBnNamn6FdXIBSPj3qJSSWppGm3sa+keOvEekxutrqMzxk8rKxfB/Hmnv8AErxdvyNanX22r/hT4/CtwLVhtUOfeuf1DR7qyc+anA7jmoVRPYp0ZLc9n8C/Fy3vgln4kKW8/OLofLGfTPof8PfFeqxyJKivGwZGGQR3r47gwRx1Fe0fCTx2z+R4f1Q5IG21l9gPun8O/wDXrqmZONj16iiimSFFFFABRRRQB5x8bPE8mieH1sbSRkur043KcFUH3sH9Pxr5281iwA5zXVfFTxBJr3i+8YlhDbMYIkJ4AXqfqT/SqfhLQjqFwJpQTEpqZSsrmsIXdjQ8MaC90yyzJ8vbNd/ZaasKgBcCrWm2kUYVIgABxxWwLbjpXBNuR6NOKijK+yjsKoajo6XUbK6da6ZLf2pZbbCkkcVmk1sVJp7niWvaM+m3BKLiP1rJhunglWSN2RkOVZTgg+or2HXtIjv7eRcAk8149rVjJp168Mgxg8V2UZt6M461O2qPpj4c+JP+El8ORXMgAuIv3cwHTIH+HNdTXgnwA1aRPEF3ppJaOeAuATwpX0HvkflXvddJxhRRRQAVX1Fiun3LKcEQuQfwNWKbLGssbxuMq6lSPY0AfGMha4v5S5JZ5PmJ6knrXr/h3Tja6LDFGu1yo3GuButB2azfxKHjkivzGsRHRN3X8sfWvXBGRAFj4PtXNVlc7aUGtylDZT253f2gVOfulgK3rB5gMTSb8985rl9T0K+v40MZwyyBic4yK27MyWsRSUbcH5RnPFc/Q67XZuZ2qSKzriW7lcpvRFP+3zUsd2GUKMc965zX7HVbyYNYyFSsnTdgFc/4UJ6ikjTNpcRSg+YJF+tcF8UNLAVLxV5HBP1Nd5pkV3CSk7Fl9SazfiBbLP4emG3JDKR+dWnaREleNjzj4UTSRfETRljdlDylWAONw2ng/kK+qa+Yfh9pzWXxC8NuzKfOkLYB5Hyt1r6ersi7o82Ss7BRRRVEhRRRQB4f45086d8TTIqsIdQjEu7HBcDn9AK6W1xuGam+Mdiy2FhrkYy1hcL5mBkmNjg/zqlaTCSKORTlWGQfauWqmmehh5c0bM3gR5WE/OsS/fzJdkWS2eWrVgkHkHd6Vj3BCOwDMqs2TtOKwaOuKFEUkOM4Prg1tWDblynSshHVvuSkmtbTgFU4780khTTJrkLgk9awdaQTWZjYZBYcVt3ZBY4rB126jsrCe4mI2ohYA9yBxTW5F9DkvhXbpqvxIaZoSYrJHeNhnCt0XP1Gf8ivoCvNPgl4ffTtGn1a6Qrc3+0gk/wDp/j+Nel13QXunmVXebCiiirMwooooAoa7YRano95ZTruSaJlI9eK8n8Mzq2ni3LZktWML89CpI/pXoPjPXjplo0FsR58inLD+Af414Bput3GjeJriNzuhuZPmUn+Ikc/WsaqutDpw8+R6nrXnssZA5rEuXvZpWAQBM9j1q8LhG4B61dtI1cfMa5LnpQnZmGpu4eUTOPetzS7yZogZkCN6A1a8iMLnNV22o2c0mypy5i1I5IzXLX1i3inxVZ6MgaS0hHmXhU8D0B/zmp/FOvf2VpUs8QDOSEQHj5jWp8JZIoVleYhp7v948rD5mb/APVj9a1pQ5jjqz5U7HpUEKQQpDEoVEUKAPSn0UV2nnBRRRQAVQ1rUk0yyaZsM/REzjJqG/8AEGnWQdWnV5UJUxpycjsfSuH1S/m1W4M0xwBwqg8AUmykjOuvNvppJJWyZGJavOfGNhHb+JdPWIYL/Mf++hXpsS/MK4P4hbYPEOmTE44IP/fQrNmi3R3MNp5kSt0OKuW9vKuAG/On6RiayjlUgqwyCK0EjBNcbVjvT7FR4Zv7361F9kZzl2J9jWqYlHal2ZXOKmw+Y82+JKqILC0A/wBZcoceoGa6PRoTZxRomRt6Y4xXN+MXF/4w02zBysZYn/Zwc5rsAMD3rrpK0Tjqv3js9C1pbrFtcNiYcKf71bleXvM8EiyxMVdGGCO1drpGvwXUSpcuI5unPRq2T7nPJdjbopFZWGVYEeoNFUSeNyPtcA96vqCsQz3qvdRKZFY845xT47szOFKKB7VmjUniFcT8UNNmntre8hjLeSSH2jJwcYP5/wA67sIAcCrNlDHPctBMoeKSMoynoRTFc8x8C+Of7OhSx1HLQjAR+SVFeoWGp2l8gktZkdT23DNcN4v+GdvCs93pE6wooLGFxhQPbArzK3uJrWQGCV4yOhU4NRKknqaQquO59L+bFjLyIo92FYfiHxbpej20ivcK02DtRSCa8Sl1jU5lKy6hdOp6hpWI/nUFnZS6pdrbRuqu/wDE/SoVLuU66ex1nhC7l13xZcanIPlRCB9W6fyNelAcjPpXOeEvDcfh+2ZPN82WXBdgMDIz0/OulHI5rVKxk5NsimQNGceuaRCCnHepJTgFcdVNVbXhAKA2LMVzc242wXE0Y9Ecj+VFMJ5opAf/2Q==",
#     "method": "FaceContrast",
#     "scene_image": "/9j/4AAQSkZJRgABAQEAyADIAAD/2wBDAAEBAQEBAQEBAQEBAQEBAQIBAQEBAQIBAQECAgICAgICAgIDAwQDAwMDAwICAwQDAwQEBAQEAgMFBQQEBQQEBAT/2wBDAQEBAQEBAQIBAQIEAwIDBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAT/wAARCAHgAWgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwDw23jRd+84YcgAjk+4q5EmXBB5YjbnjOOv9KoliAD94Oc5xyM59vpWlDLGrZm27hnackjB65pO19DKVKnKXqWNitGwKKGkXBYk+ufX3/Sr1qmNqow2jkgnG3nNVhtmi3ggqR1IGKfG6luOAOMsNv8ASuum5crT7HmTwnL70Vr6/wDANNJm3YDdDycjnj/69dTYFXKkHO0FSSe/HQVy0IQhj0brx2rY0258ssOCS2Mdx9aunXgopSOecZS9+Wx0d0NmApUfNuyxxkj+XerFluSTzGO7I55Awc/n/OqYukkYySABhnoMZGRxViI75AQwVBwQWGep7Y/ziqp1uVabGqpOWtM6iO7IBVWUK5CsH4z3yK2LKRyTwNuOPb/GuUiCxIvy7sHOerfpWtBI2cK5Ug5GD0J9PrW/tU3ddTjkpSk39511tOsYbe4245OckVZOo7TtAzzjJ4zXKxy9QeSeSM9eetagdVaIFCwZQwxyv06fStFd6GCVOTa6nV2t0zL1VgWJGRhl5zmtQOxKnJ99ozmuWhuV3LtTaAcFVHLVorfZJUoQAvTGQOnFO8ufQ2aUrwlujoIX2fMrZ4zkHFXhd/vG5yMY5PDZPX/PrXLpcbsBiQpztBGB71caeLaiLuZgCdwGB7Zrb27Sstwily8j2OyS6jwAxA2klSeCM8j+la0F3Gse1iCCMnnG305rz5Z5HPz7sDtgc8n/AOtWt9sdEQKOgzu/Gs41U4naoKLXMjo2uowCEYk9TkYBNSG4LsilhuVCxx2GR1rmorh2cOTznON3tii5vfKcDcTuG0nG4dOgNP283HlRFnF37m3cSooVjjDjCq3ykjFVZXWNg5ZQeuFPIGMCubkuWkO8EccDseOBio3nkkAZyRgZOOp59KmU3HSe5zxpt6NGtNeE7dgBHBBYYP8Anp+VZVxcZ3OSuV5PPIHU8f561jtesuMht4Py4HDf4d6fk3CH7gGCWDHr9P0q/ap+6cThFy5ZFyWVDhyw5PHoPrUb3iBHByWK7cAYB+n86y7hgpf7pA6Z4HHv9cVRMrDD7sHbwTyPwFcUk1HmezPfo4eFRu/YsTzkxuFJUk5yoBC/59KyZZGbIZiw6DOATStcMPlIDL9zBPvj+tV5I3dgiDG8fKMgE9K5ZTklY2UKsIqCtZGVcTiNlHLEtwOoOewqncmQLvRCGOcB1I/z/wDrq9PH9kmVJ1IdMdSG6qCDkexqjeXnmAxxJgsNoYnbgnJ9PatnUsrPdHNZSXLLddjGe5cFV3D3KtgZ9iRVOabewDNnK/LnqvP0pLpJoNsjpgNz7c9P5VSAEznOQ235cn5RUe1k7m8oczi5EzzquCuWG7LE9BimiTKu6gKOuGz157dcc1WctCdpBdV4YKMnt09aaZnKhlwpIwckj8PXtXmVbytGnujtlFqVx91KdsSoABuG4qAfTPH596oTxO0rFTjcg5x0/Efh1q6xKqWCqcckMcZPpVWe5WR3EaMjbcKwG4H1/lWFaK5byer/AK+R0+yqTk5JambJcNxGpUrjaDnBOev8+nSleVlBjGAWBGQvJFNKsCTsBYHPXHTNMkwrq5AyO3DVCp07Wn0HefIoszlWNzkqxYAfNwQ3Bx+HWs5yC0h25YnnB2nnHQZrQnAYiSIdThl6Z96hmjQDzFXYytzjIBz7UOm2+ZbeZ53s7Wmt2TWiRomH4VjkksBjH/66qYXzCIiTg9SOTV+ZlKBhjLKA2cGq6K8asScI68H2GRj9ax5IpuXc7nFrXqMj35kU/MrfecgAr+vvUkMat5iFztGcg8Ecnof604RRgR7GDFiAS3I4B5/z60+NVMrAA8feHZ+AT7//AKqhQhHWO7E5PRS2FVmfEKLtRD95lwTz2/Sip9mwFtp+Y5B+lFJU42tb70VKavqeZeZIFChiM/fJyRnuP5d+1PVmJ3SNhcBTt6j15+lRbRI5bYXVDgqBjdjqCasJufEYjQfwnDc8Z/Ltx7V7rknFLqcdnb3ehqRzhY1jjeTyyuSN3QnrgVchZdy7m2gcglsbTWYigAKRhgcYHPP1q0kBkzztyOpbGc+lJN2Lp1XNe98R11pOgGASAOMk4PvWjaMqSMQRtyDyePw/OuVskGDG2FyCOSCMe1bkG7csZIaMOSdrlSR1xkc9cd6Ss9S6qlFJSWpZcEkOsj7G5wOM55FX4H5+8cdQAefT9azUTO3AC8/KM4Xn0H4Vo28YViCwywBP8XrXWnFN9j5+MXN+0kdHCTIAI3O9RknqMdxjHvWhbozSbzIx2jG0DjPPXvWFA5j+bGNrZBOc9a0LeeXe0kaBgOGHIXjFaQtHWOxrKE5yd9zsBubC7zuIAbBz6df89q24gHRPnDbflHPTFc1FOGC5TlW5zz2rpIHQIhyoOAMdM4HFSk7uS2OlQje72NaOwYqsiyZYnJycDH+f51dRMtxyeMkfeas9JyNoU4GOS4yFyARz/SrfnLGQQdxxliO3oBVKSbsjZuktIdSTCgDKglByQOn0pwGGDKFK9VyCG9azftBUkoSwfnaclQc9OKaLqRc4woJzzwe/H610JTiuZHlyfKuWRtpcOWAIG0ep5qR7khgSSQF6dq58zGUdspgcnr7/AP1/ehnZgCxBA4zjcBQ1KTTYe78KOmFyQNytwcZ759R1qN7sTZG4KVz3xiueaRdxGeOgGMHvT1n8ollJBIzgZArOUm9jt5Wo6G89zEgK+YST1JBznrThKzLvaXapGFVcc1zH2hS7MwGSTng9+vWplvVUkPucBQFHJU9+f0qW7u7LhG/vRNCXzWkALAgdMnOeM8fp+VNLTYZEYqoX5/myM9eD2qjLc7o1TBGeSEbgZ9arR3Eu5wCB/wACznqOfzpptbHRTlUdlLYiu7mRcqO/AZun+eBVBriRsgucAYIHANOnuS7PvQE7iT3K1lC7ijcxkgSEjapGC+TjAzxnqcZFTJJrU3SlzO+w2eSQ/dY5z3Jzx9aIdSZZlDyMpI5yRnuazLnUYI2I+crjHyDjofT/ADxWVNe+XJ5qsjkghegPr7UpOXxI5JRV1bc6Od7m9aWRZFZYiwYyMRJhAB1APOAPrjFZJdvMwGJC85K8rjoR+fpXH3ni8WG4tLsc58yFZHXcCT6delVT4tsjKrQvnzIxMWR1MQyeQe4Ixkgj+IVyXdV3+0bcjWrOw1i4MsMMYYMEUAAKq4JJJyQM9wOTj5Rx1qnAfLBKgFiuMDovX0rFGtx3A80MmOgIJIx61p2kys4y+RjLc4Y9eufTOfw5rSV0mcLmuVd0V5jukYOo+bkYDf1rTs9OSVGdnVGPQAcfj61m3EqsrFGVyxILKCx4rRtbn92sSBmYnoMDA+tZy53H8yZOUnzMxbqArctG28rngqCEI5w2emOMfjUMiLHhtuT6r2HvV/V7po8BSWZgC/GCvQ1zz3kpGNxwQScYAyK8qdOF7QZ6EJyhFS7mkUdgMFiTzhRk/lVKS3l3g5wCckEYIINWVuxEC5O4/dwRkqetMSdXyS/Kk8DPGK5qSiuZS3PWhOTk0xpikXJH1JJI3VHJbOxGSOTkrxx+P41ZaaNsDc3XBUjPrTvP29Nrbu+ATxzUTjUktDaopJafMyXsg5UspyvKsMkD/OcULBKchQRnCgN6kgD6ckCtFLpkQ4VSxzkkA7R7cU6GbLM4AVs5C9M805c9NJy6nBGUZ/CZEVgzJnByeV5xmmfY5In5KjP4Adq6RCXwq9Twozkd6q3dsC4YKSU+8c4yM8jtRJWfNczXNFsrSAIoDcvjggZzj8qKvCAFcNGhLfNz7f8A6/1orm5b7J2OtVIyV3+R5HMvllCgIRhkjIDE8f5H0qWEkOzIdzgcB+c+veqeXdv3eCyjduySDx6VowMPvFcSsuCSPSvdhP3nUo79b9jCM+aOmxKFUKJT87EZKdQM8nH+e1WQ4ZVAHyqMejDn0qtGwyRtGAAM5x6/4VaUhdj8Aqc4Lbc5rVVIxl7RdTz5c+0TThiYNyOhOGBymeOorRs1ZJixYYPQcgEnpxWVBdyISAoO442jkD6H8K11k3lCCVAGRxyOhqG3ud0oxn7sjpI4WKJKc4+U5YBg3IJGD2I4/GriRAuCrDgYUk8D/wDVWPDcOm0MzSIRkgKSBkduPetGKUFiVUqRyMjaPrQtWOMElyLYtP5oIBHzNz8pDBs/StGBzlUJ284K8AZ6flWOWlDK2SScdOTWrFtbYQrFj8xzzjnoPX8K60oxvY5KkE7U49NzdiEigGTauG6buowf/rVr27S7snOCMqvQ9Oc1g2Uoc7XVhg5Xcx4Iya2I7j94NijGMcnp61dNx5FydS3GnGTjK/kWY3Yv1AX/AGeCT7/57VbUNknPBxwBnPX/AD+VZyNwGx958kAAe5+lWN+GBUEKRyRg4rujG0mfPznaKUtkWklZHC5O0tg85A79AaWQu7A5I3AkqpxuwQR2qMhiVYEbc4IPUdecY/r3pVKpliOnQA7Ace/H+FWYuSerLygqCpfKsOCThgcnNKZgM7WJCj7vBB/HrVZrgMvyjG0A/M3P+elUt+A3J6ZJxyMnj+eKhySVonoXiSSSM7Lgkc9ckA8Ec889f0pgkkV8MU2jBGR07etVTPskJKblUfdKA7cnG4H9PxqjJcN5hYfKNvduPwH5U4qaXN3Od3T0NlpNwOWAx8wYHBP+eaVjtBO5CpXPzcjt/wDXrM85xtzuVsjOTjbwfbNSPOAFJICsOMnHHH+NVZbjiue7e5Isu5ThgTnkq2e//wBes6WYpLlpQBnIAYkj9PpVG4voYwwicqeSeikDuRz/AJzXM3/iPT7Jlaebgv8AO7e55wf89aGlJ3kcSUU0nuegC4iaMncCx5bJ5Fc7cyxLOXZRIzdE27mU54x789feuGl8d2CiU2xeXyiUCt+7LdOQc9K8p8TfEm4bG2YwypITttkCsByRubqfxqUozV2en1ue06p4jsYLaa38yMT7WRssoMecgkZ68Hjj39q8i1zxotjcRzC9CKG3KPMyGIPfvjp+deC6l4v1i9lkeR2BldjuwcKCRgcf5zXn3iDVruK3c+YZGPzZdmkOc8evGT61w1uV/EdtP21T3o2sejeJ/ixqty9wix2MSs/kkrF5sqKCTlT6nJzx3rm9K8eW9rCIj5oikz5qIThWYkk8nv1r56m1mciVpGVzJIVKoWDDpuDcAHnoR+tQRX0gDEHAPOR94dun41lJclpQejLjdppn1vp3xXSzdLUX6pDKcFJ/vxjn5gT/AE4r3rw143j1PT4ruG8a5gkBQXIPzOM8j3r81HuIllR3kZwWOzjAH4k+wr1Hw18QrvR4BYxYki3ACMn5IgTliAPzrlqzcLOJ1U+SK16H6P6dco6RSROrrMu/P3yM5P4Vu2sgLOZCqInAI+VgO/NfKfhX4hrLYAwBzIm1RAWx5jkdvTnr/wDqr2CPxfjTYVuSsN88QeSGKXeIiRnaW79hx1x0pOneTkzaMvdTkbGr3qkswZ2Uv800kgRIuuSxYg9gOATkiuD1fWmtoPLju4yC25vLcMScjABHODxn6CvH/GfxBSzuRG9xJMssgjjggLSJEQMlmP3R+ByeODXkV78Q5xOVK7kkPUSEBF7D9arnldyPK95O8dmfVC+Ib4S77e4VVzhomAdR78jrXU2PiBZNgnZQx6kDkevA618lwePtPhtyJ5mFyQXXAaRF54BYV02l+PtMeztrsX1vLHKwQOJhIFJbZ68gHrjNeNK9+bofSRj/AD7n1bFcRTbGjdmBXAOSQT34PT/61TkOjfMxUEZAIIPPf/69eX+GPFFrOVjkvIG+cAQmUbyTzwK9USdrmNCArMpKjao3rySOg9CPy6Uk1ZyXU5mrJKRcjRyuSdwPzA/mcYqRl6Mg25HOVx79B06mmqHGDuPyk8Nls+3T/OKcoLsodDtA3bgPX/JrONtbHU42d49STe8KoVOSxDDGQz/WrFvOs28OXAWXy23IVI+VWyOmR8w5HHUZqtJJHAjq6EoR8ueSTzge2f60+2DBAwAIPPJyRmqjJwXvdTJKMJy8y8skS4DkgEDDYyR7E0VWKJJjPfkqBk89cDP+c0VcZSStHYySlbQ8csolkJwmMDcCTjPTt9anEZDtmPkHPLAdfb/PSqdsxj3BCdxJxkjDc9OfwqyJHAYtgux5xtBH4ivak53XKeZCUW+aXxPfsWRE2CVGQPmwhCeg7kD0pgjfOWJAYcBuSKSKVkKv3xyP6cU9pFkbLEgDgdNvX/69aSU4y5qe737GNm3yrobEEgR8knaOCQePpW5bkTMjhwkKlg6Fc7wQcc4yMHn8KxEQAltqyDrheF6djitKKdmUqBImw/P0BAwCCpGc9a5JQxEY3Vj2HFKpKmuhZWaJFTaxPYZyd3H0rWt2U7SSvHIAJJPP0rAikhdUVY3AxgllAb3yPzrTj25XDA4HQHA9/wAsV3U3zK9RadD5uSSVzrIANykjcd2cCtBGyec4U9OpHX/6/NY6S/KCV6HnGea1YmDZGcbhn5vboKXvRXMj06Scn7R7MgTegBLBMjOMnNbMMZ35DEkjIBGAO+Kw164k3EKSFAOCvPGDW9bMAqkksDxljyeo5ya76alJ3PDxCi/j26evmdPErOu0PsODx03ZP+fyq4iJEpLMCTkgFh1/ziq9ojsWZVB424LYI71eSIgsSMYHzAH7/uffrTaaVzqbu7sppKx2gkBAxPAyent+HX0prg7mYFvU4PFW4o0JLFWBB5BXIPX25NJPGRgIm4c5wu05/wAKp3cVcizcWpfIzWRmwwxjHXHSkaJOQAhcgI0gUByByBn0BJI9yauCNo1GFUc4wDgH9Ki8sl+MYPdq05pWSkctp8quYMqscEEEKMMec5qv5ZLbiSR1OBjae3TmtC7hKBQBncMnvz+VZF7fR2UEssrBFiQszsCQoHJzgfWtk3ynDG9rF57qOOHEjMwAJDsFWQjBPPT36+leP+KPiXp+muUimErZMaRMm4nGM/KT6Z5rz34jfFMQTvY6O8cm1QZpvO4Ut/cA6jFfJniHxLcX2py6jId8rKEaBXOBt4wB2z6isrdDuTUWz6a1v4qzTPax2xP2aZd7z7ysyndyCOvauP1LxlJcMkl3dh4iP3eW3hSPYd/1rwKbXppPKJjaNMYfGSwznpxUsEjzvtAzuUshlYgKcZ54rOUXT+I6XaSsj2GTxHeXMYjs5BCDkeYSFkPHP+ev5Vz9ws8UW555JnlZpGMr73bnJHXPGcfgK5htTW1AjjfzHzhmAKjOOefTt07VHJqaIpnknZ0Khfs0bLJICSeRkg85HUgcVcWnsFNpLk6ou3M/lwsJTnjYdvJHavKPEurzIZlQt5IQ4BkBIwAe568H8q29Y1+3ngc20dxGkchjLXK+UZNo+8g3H5ckjJAJxXjeuakxLKJZAhBzgEZHfIHrmuOpDm17Hs4enam5d0RvqPmjMTBlU8kg4OOCPwINP+2MpVyd27sCMDp/Wuagl3qWx3OSFIyc+nbrWlEBNtA4wTgkbe/P655rk51e63LhGMbI3LW6FwypIiqBgk7tx7ZwK1EsZZ72KewS4a4WMwtFFIziccbQI+mcjqAPvVBoGgTXjpuTCvKIw4Yg+5A68ZzXrugaDJoSDUZzH+6m+zxxyOpkucqpLnHQDfjnn5DWclOUnOO5i6cFLnd7sboV7qXhjUDa3Fy1xNGySmMtuWEsBlM9MjGOM9K7u+8bXEke5ZVUbT5jYPmDjPTH8s15nNftd393PK3KEErt2vGhOAemcZz1rCvdWhiJAkTY4xwHK554IwSOncY6c+uUeeXvdzROUb9jotX1r7W6SMxYjLdSiMeRyDyfWvE/Emv3g1Dy7a4eGEIFEcQHludxPOQeSAPwx61Lq2vEAxxuPMOcjA2j8SM+tee3epCSO5OWa6yUVwRtz2PqcfTHFc9RqL903jycicDZfxCbOyffON20qIzlmZiMAYA45I5OAKxNM1r+zDG0UjWwErTeWhZYg5JJO3P06j8K43e8sxRx8+d7Bww4OCDyOeuPxrQ/coBJMd5VSMBTg89M03LmfKtzlhBvWR9D+HPi/qWn3lkZfsc0C3StKZAVkKDOdp9e4PvX2v8ADT4yaD4puXsrLUNt/F/rLe7kEchQ4yQCckDofwr8nFvkDIsKSFlUMSwKnPfB59R+ddToWoXVlqEF/E7RXkTMYLiF2jmiyOcEdsZyKmUek+h1Ob1ifu/YSJcpG6yI4fnghgc5PataW3jWMEOgYfeU5GTjPfr/APrr88vgz+0La6WbfQPGeoI8BmFrbanK2WUsflRznjHQE8dM+/37pmpWmqWUd5p8wubKZQ0U0R3hs9zz/nFefLmUtNj0IP3Uupi3hSQoMkq0sZII2pjzEL88dFywHOSBWlbOqAqgLhgAT0Vvw7f/AFqQ2olZQ6sNi/u4iNsQLLnJAPXB6np6VPEiIShOH3bs9cHPOOK0cVN3R53JJxS7E+D5gHSQjICnGByM59j/ACoq+salScHcOFzmit40ouN2dh4NICqghwGzxg9ealt2k3MHy2VzhmLE/wCeKdIYkV1OTtBC8EMOQOn50ka5GOgxu3uOPp+P9K6PZK3J1W/oZStpJEwmySvDDJUdCv1rSgtvNQ9RxxxxznnH4VlIAqMBhQuX4A3N+FaVtclUAXnIwoOQB06j8K6o1IQSUepxttu7IFWWFQpcIN5AB4J9xx0q/CUc7CCr5DbiQAfU+/1rKkd5UVn5O8A98cf/AFv1q4hdlBRwWQYAZACvbGa2dRKb5jyVdK/c3lyCPukY9SelXrYhyRxwehOAKy7aSRFUuvzDkc5A71fQFmVkG5iMHJ2jP1q48tSPMzapCLevQ6uAsgyzKwHA2nfj/wCvWtDIzBQQdxyVBGAR1zjvj/Gsi1TBPmsA2AwVWDY6Y5x71u22xsgnafulgOcciohy213PTqTcEmti5C4cbuOPl46nFW4YmeQjPIGFHYcVQRCo2qCc4yeOOxPJx71pQP13AgBdpJI5/wAa9Ki5ci5jxa1Xn22Ojsg4barnJJ4H3m74Hb863hbqRzzg5y3Y1zVrIgZHUfdP3SOOODXSxOsu05JBXqODWtON07mcXuupmAYKkYyvfrmh9u5huXnnHarXkEjeiltpwQvJ/wA81F9mcNgoxJGeRgHv1qlo7HlK/UNqMpVeHYY+YAHPtUTR8HgKQeRnFXkt9hzgnnOBjiopJUkjLgkRsSQzIYioUlTwQDgFTzQ6btqjvak15HMajPDbxPIXA2rvBZsIo9z/AJ6V8cfGT4oX5/4lemPOlnEc3V3YRkzXPOPLBHJHPPHaux+LfxTITVdB8LXsL3EINlLfY3iCQghwoPDFRx6BvXpXyBdS3BgEbStNscGRpZAX5I3HJ69z+FV7KbV1sc7cYqzOV1PUjPKZFmZmY7ywznJJ4JNc1K7yT/aG2F4xtDsQ2Bnpg1ZvtkMzlFOHbEmBlRk5/wAPyrMmll24AAU8nJChiOh6c9qpRcVc5Kbp6rsb0eo2yoFMW6Xd9/8AgXknpuHv245obU5IF8yRkVQp8tU+Zn4ztIHPb6VyZleNyxVV3MACzbdvf6DP+NY+oagyTqqOjuAedwfbwpx6Z5rklaya2PoNLXO0u9dh3qwYxxMgy7tkgnrkf061VXVxCuINjx4+SSRdpfjJxk8Y5x64rze4vEcbm5IbAZwVGee/4HmqQ1pUJBVuBwwA29Pz6+lXypO6OeEVGGmx0etawbg8OEVBtZVIXHBHX/GuCuZZZpDIJS+75AnUYBx3yP8A9VXpobjUFaSNXZZHyFCkqxPTpz2zXS2fhF3gjnVcOCSVY7WxjJPpjJ+vsa5qsofDI66NGc5XitDiIbOaUjyy2GblcbgMnPTv0rqdM0+bzY5JHYKTgrsZACpAONwGe/PTg4Nd7p3hOfMZMGwM5UuUIRTgnBzxzx2717f4a+HL3Eavc2bSbYt0bOASVUg8LnOOvUdq86vVhQTb6nbClOc1Gxn/AA38PLLd2MkkfmwTHCzMuXzjKADH8TYXP/166/xho0sMmoRwReZp2mhpSsRZ7q6lMEMxjiU5+6CAQMfM3HfHrHhbwVcaILS4it5Y4xOuBGWQoWOxcBR3Ljj3rsdQ0CGW0eV7fzJHcsS/zNkgcn9Bz6V5qx8FK97tnofU6k37y2Pzy8QyS6bPcbYRGZIVicDgttdnCscZIAYcZ9fpXl+r6vNHH86xxbwSoGWYY9ea+4/E/wAO1v3fzVgMZRmVFQiRWbdglgvbIPXtXy/4x+Hl5becm5WWIllIV/u7Thfu9cg/55rpji+ZmMqM1H3lotj5p1HWUDLIWy4YKCoPzEnAx37nnpWBcXjlyyspHlgqccZJ/pxXT694avYTPJBCZFXc7eYgQDI57c9+etcWYpUVxMrKRkKMcNj8Kc5U6lpR3MlGSk00Tw6iwZWmcuWPViBgYJ/z9a1mlSVVVJNyso5BJwfmBHPpwOlcYZ2Uq7DYEAUgN6Y7ce35Vqwakqyovy4KEgEgL0yf5GiooxnyxIinzOR0Edo6xiTDAK2d+fmxgdB6g5rbtpjI6IvlZGcs/wAr9COcZ+nNQWupwSwwWzohQny5Gcs3kk91GOvzBqfKi2pEkBLKwyCFJcjIGe3r3pui5LmhsW7WNVdLh+0CdXcP5u87W+T3/wA+5r6z+C3xf1b4ctaabcXUuo6Hd3yyTwTO0j6ejkZMQycbTltvTk8eny3a38duiO27LDd8o+bpn8O3Wt6K8aIJdxMc9QTgY9yPr/OuSSlNX6HXJSajyH7aeHNdsfEukRa1pV1Fd2lxufzBwflJB468Y/KtVy2dhQAN1baARkHpX5ofBT4tXXhW5trKW7uLiwvb7ybjT3cCKFXH+tjLEY5I3c+vFfo/pN9DqtlFNBLG6SrvjdW3/wAjXBycsuaJ3Sp3d1uacOECndyzbVU/KMngZPYe9FQSRmHIyx4/hHX8vpRXpQ0ijzmrOx4a8TFiSu0Z5PGanCgIFO0knnjGOR/npVyK0kRflwxAJO98k1MYGQjzICN3Yqeen+Nb1KnN7reqM2pS22MRIC6qSSCmMMGPY1ZhiCnIOGzkc4zT2j8rKqgI6rzjHb/P1pA77AGOcc571rhpKcpcq2Rwe63yroaNssh2s5BUkjkc/hV1AhJCIinPJ3cn36VlLM0TKqFnOc85wOvSrsUhY7mGOpIwevIPH4VMpte9G1maSTcnY015ZcgOFIBA4A4rSjnJG2PAIXoDgsfrWZEwYcYUDpxg1dtQm7HUnoc8jtWsJXgnIzsk79y/bMWwSjJju4Uvxwc4yD+BrVSRt4ClcdCPSsVP3eCPvZyATjBwc1fi+dwwwBjP3gefQ8Z6AV0UqjdR8ux505KC1Ozty2OcYI+8ecda6GJQ6g5xx0AxXKRSuuAqkjdgA8jj+lbkNzJuCmNFyOkY2r06+ldsJxva5vNSevQ2bGPAWQEHcOh4A/zxXWafpN3csTFhoynmsyEbUUEglgSD24Az/WuNtLmJBl0dWAy5CFhgZJOBzxjtXtPwl0y98U+OfB3g3TZIkvvGfiO28N2Ely3kwJPdsI4mY7ccu0Y+bgbsngGrejuca5r2ZtaD4Lvr6HfFFNkfOyso3MCcB8DOAT2POMHFdBqHw/1HTrYXd3D5dqygxzCWM7iWC42g7gQTzkCv6Gvgt+wH4A8E6XFdfEMTeKtbuIgbvTLa9e20CBjnjMSxyykYXLOQCeAuAK+gP+GU/wBn3IJ+GPh+QAYKXAlvEbpg4kdsEY4Ix1Nc7rU0etChLl5pH8pVn4A1C8Tz4opVhkk2I7xuqscLjGV6HeMHnJHGa+Uf2gvHTfDyS68NaW9vceIokBvlOTLYxuBnIH8RBOB+Nf2J/GT9mz4F+GPh3418aW/hW20IeEfDN54l3acxCYsbaWfYEYkfNsIwB34xX8HnxU8V3+veOfFninV2im1PXdWkmHURQRFmMKKDnhVxgemK9HCJ4ms4w6Hm16fslzWsePXUzXFzNJufzJZDNM0n+skY8sfxNc5qc3kMDI4fJAAHReO4PH5dxW5quqB0VmESso+9wHbPqe9cRqCyXxRmbcoBKnow/D3zXtOEnHVW/I8qdWMpW6+hkXzLK7FXBAPIyADWFeNLIoG5VCEgLyA2fU1climaSaIhl2ZwCR81Yeox+QSrSnzMbvlY4HoPQdf0715GInFvlj0PXpOMXaJxGqXLnMQkw6jLFGPy56dvx/EVyskrh22HcT/GxDcnrnnNaF5dRTSyRsrsxYpuC7t/pk/Tv/8AWpsOkvIzbYWBbuQcAY9DxUuouW8tzzqNKdeXLFGSyXs7BcuctwR8wHOehrpNM8OXN0xZwGCDex2g4wOSee3FdNpegNI8cItZZmYgYjTIQE4yeP5+lfQvg/4Y3d1NBCYPLWZQXBRQSq5JHTryfzryMVmFHDqyabPoMLlFWs1FrY8w8P8Ag2e52GJflZ9oKrtKnnt1xz+te/8Ahz4YSXEaKSd7HgCISEdOMY7f1r6D8EfBnYbS5EUiAvlV8gSRSnGBk9ABg578CvsjwN8LLNjbAW8FvJGpMtwsQbLZPGO/QV81Xx0q/vxeh9dQwFOlHla1Pj/w78EmuIIobi2MayBR5rDywAMdV6Z56gd6+lfDfwKtbSztoB9rnKBj50qCRh5hPAJHQZr7U8O/DLTzDCskCsVILyTxK2/njAI+lejv4e0y0SFYolYJht2QPMwcEZHI6dPpXmVsRJqzeh10qUYvVH5/a18PItJtGt7e3iiKzmR5Bu3qWCqdmc8naowMDJPFedSeFpH8yFozjHAxlhkZ5P5dB3r7u8X2NjeXUolSOOIybQFHCgDBI9+Cc579a+bNato7S5kK7eDtDcYYAnGDge3WvJr1kve6HqUMNCfvHzjrHg1YQ4CgMB8vAUHnofrXhnij4dzXrOIYWLHKSFhlcE9OnccZOO9fZWo2sU0aMQGySWA5YAD/AD+Vc1PpsUuV8vB24AYYxnA6/lWNPGVYvmgzqlhION7I/LvxX8LLrT96zWqFZJCI3bezkHPPT3OP85+dvEPw7Z7m4cqE+bEYC4ZyQDz1wMg+nSv2j1PwLa6nDh44nLJgoUV/LyMcccH8R9a8Z1f4NWcslxC1q77wH84KXKjLAZBPB6/nX0GCzu0W5anzuNymM9Y6fI/GnUfDE7iZYUYPEGjIIyDtJ7/n+dee3tpe2cyxzx4C5G7t1OQfToPzr9efEX7P8BkkksYltJbhwfNcAxzMSCS6DPX39RzXyj8RPgrqWkfaJHsbu65GHt7UrAoOf7rD0z07nNddLMadWVov7zlq5ZOlHmi9T4ysdRlspFRy7o5DOCwYcjqOvOMV6NZailzGsYIZnjxG3UgkYHU1yOt+GrmwEsjWrxJHLtLMpjVcnABz0OeMGs7TtUis5dt1E5gPyOYneJlODnJUhhjI5BzzXqxqRnecu3Q8SrSkpefmemvFOkZlR92W+RHXcCQM4HPTntUlve3cj7ZcwhgdoyFCgdgv1yfxqnZahFqEYeK4DB1yVffJJknH3iDnGe5zU01ud0cpkkGw5Cpxnud3f0qI2loL2cUrnothMIShXBAPBUFQCOOOa+t/gf8AG7/hHtQh0PxDcyHTboiGCSQmVYAB94dSOOuOuK+I7PUnW3jxGzBcAAd/TNdbpmohZo5SSrIQVJGH6cY/xpOk2vZrdHUnduR+41tcwanZWt7a3EV1bTxiS3ubdxJBKh6bTn6fnRXx/wDs7/EXydL/AOEev723NjCd1pukImhZ2OV2HkrznI6UVjyxirS3BSjayPXI9vlNy5ZRkYJ5/DFOSaUuCQWAOMNyR2zn86t4UBgIwx6HAGX6c1SmFyjq+8rHtJZI1BTuOSRkevBFbOPtG/Z7LXU82UnFty2Y+VVIDEAHGMjqPpVIIql1Byc5HGAfepo5Cxj81SUBAbqGKnv15x196l2oT8w43ZGBg1tCM5JOPzOBQi3puiIRlYgxG59uF2cgY4qReACTgr1z39SfyomAhyE5JGdo5x7VAA7su/8AiXB5PHIHQkCsVyuo0j0lCMrs1Ymc4wCAy9Rgjp+NaMG5CSW3hmAAGAB17YqgkTKEKH5eCecYz1rVi2qrEjJwAM9T2/pXS6KlpLZbGbaWxajkLtweF6tjOO2Oc/5FaMeRIuxixB6YG0A+/tmsmHChWJB5weA2BWtaTfvCF4T1wMZOK6OZ6LsZ2lza7dDqbYScMMHauSccj/H8a2oWwdzEbtgBHcfX/CsazmMbNgfKRnGQDnIrVtgN0r7Rkkj7vPr1zit6Uot3e5liW3N3NGCUDBBJOPmII4/T6V6B4Qu72x1vSdT0y7kstV0nVbbVNLnikWOSKWCZJAyk9wFzxz1ry8SOdw27cttPOcV0ulSyW80UkY+c7SNx+Ukc4Pse/tXfzW1R50YXa8j+2v4S+L7b4gfDXwR4ysnEkHiPwxZaorBgTult4zIrY4DK+9WX+FlI7V6AWUEgnGOuegr8nv8AgmZ+0doOrfC2P4ReKtXstL8T+ENQkg0KK/uY7eLVrG4Mc6eU5YBpRPPOpTg7QhAJ3be0/wCClv7bugfsmfBTV7XRr21v/i748sp9C8FaFBdL9s04So0c+pzKDuRIAx2Ej5pCowQGxjGjOrW9nBXb2MfaxhBNdD5e/wCCof7deiWvgzxV8A/hb4i0u51DU7abSPHGtQXiONuzEum2jgkF8kCV+g5QZ+fH8gfjGIySNGGMjQzNcS+YOdwyAwbuQNwx/hXe+KPG994guX1O7ubmS+usS3RkuGuXaYtlirdFxx/kV4/rWpOcoxLHHToecYz+tfV4LLlhbQu3PrtbVGeKxiq6SWi8jgrwSvKXkL7VP1U1Qu7ryIzIu4YGXPp/kkVrXOqQfMkkG3K9sHJ5ySPyrjr/AFFJhLAqJ5YPBAwxzzzW2LqRpQUUtfPU5KdO8nJdTM1C8QwNJ5pUyfKhBGSepzx/hXD3U880pzKznsWILfTnrwfwq/cNJPujRR8v3SRkDPX+VbGjeHZr2RXkgchzwV5YnoeCeOwyR9K+axdWUG51P60PUwWGnUShRWph6VoE15iVIlwGDPI0e4545z2x05x9O9eveG/A11eMZGjBCr82ByoPc9vWvRfCngvPlWxt3kRiH2ohB6AYJ9sV9Q+Efh/BpzwTzwNDiIxmIndCynONynv948evvXx2Y5rCS5aW59llWUex1qLseVeAvh3AZRAlmJDcDMk0igrjPAU4znr09K+y/h18LbaK5t7iW33OwW3hWSPzEIJwRntxkZx/Wr/h3w/a5iEEKrsOxSF2qPw96+kPCulyWL2hYRtEoJkDrlh1xj6HFfOr2ldtyd/mfVOHskklqTeFvA97ElzFcafb2dpFOY7Ly2DtPH97cVA+UZOR65Ney+HvCFvA8Usu9dsgcKrEA4HQjuM0+DUrSCJlcvlTj931znnjv0rM1Px9a6ay/NAryv5cFvJKY5blhg4Rc8nrx7V006cnHQ0qSk3d9T2EzR2UKuAqqi8luAMelcXqmsuS32fks2c8DAzn5cHrz6V55P8AEKaWJI5Aqq8QwjuVJ4Gfr0qK3162ndzIyooX5ixHJOT7ZrmrJRbjMwpUXzGd4iFzdxtIrM77udoy2T6f5714jren3E0kzREukZG4kBiCc5JPrwa9q1C/s3Ty1mYbidro+wr6cjB4wMfWvLtUuooJ5onkXkk/P8pJ5715OKTT5juoOUYuKPOxpryfMzEAcAYGe/pWdPaImVPyshWXK7shlYODwexAP4V0321Iy2GygkPyg43DODWBckyTmVQFGSQQeg6j/PNcUYzV35HqUY+57xSWP7OHDMcEZbg55OcY/HpWrY2kNxIf9HjmBbymJypBwDg++Cpx6EVUmmMmSF5BBU9CO2fX/wDUK1dLBV/3e5ckFwfkGe2Py/SssKpqbb20/M1rpWJrzwfpt3EGeFWbIkYFySGCheOoHAHQDpn1rwTxv4IthFcR/ZI57d2LYaPLMcEbenB5PPuK+ubBoZbcrJgt1AK5Y/161574uhRVk+UsnG1SmfU/0FexCs4tpHkW5vdZ+R/xX+ElvLZ3FsLJWEspmWNYlVWb74V8decZJxnFfn94o8Capot7dxm0CRw5klXbiONQBgsRnsB69q/c7xloMGqvMwBjZ9yqwXaynkA8cAYx7g5r46+IPwxNzJcxzwM9uWDRSxy+dLLkHKtn5gARwOQQetelhMbCKVOq9TPG5aqlHnp7o/NjSbkWRQBf3cpLHaR1IHU/l+XSu1WU4XdJnzEJBbhD04/Wn+NfCk2j6jO1tbyRQFzGIlXYm5eCVU9M4/zmuctbgxyIJPlK4yM5Zfwr35So+zjKk9z5iUFRfLNam4A0Kq28qpILhcEHj6VuWd1byyrEJgkzDKLnbu29Tnp71z6XJk4RVLAemCcdSK0bSXyZDIAVfAG4NgDOcj1rpUVFczPLTlKTjPoet+HtW1bSllbT5WabzdsMqtlonUhsd/bIPrRXNaJeJEuVYkSvuddxAL92I45O0DPfj0orNaKxopRsfrqFZgCWGeeCcUjDzF2cDaOQTgc+9T+dbsqgow2L65J4AoZUibcGxuUZBB2gfXp61jeSnzR2ZwKMeS87lUREABsHA4JGaf5BIyNwYcc8DFW2Efys+4jjaAvPOc/yp/mg5IygQZGOc59RVVZ1FJqe5cPZKP7vfqVXiVUaTJ3IdxGMinr5XykBuQR90AmrjRxOpdABg7drEAk9frTI4ljw20E9eDuA4rkipWTkdyUFIiQqUG3cDjAT6YzVyJCSGBb7uCMgFajVAwkIUswBO0Ebz+JIAAGT+FWoyRwmAQMHdwfyr06P7z3H02MH+8qNvqJHAy7JJFIUnjPQDpz+dXoUQhihCMTwTwE469D09MVSQyMBuQEg85G38auxEqS2Oq8KD1/GvSs0nrqeDKDhK0zatiUAErfMT1AwO/tW9aTJuIyOgzu6HHQZ/OuajufMQYAxnkgc/wAq0oZGUgodvIbg45Vg2DjqCRgg9iaqg5KnepaxpXo865kdjCVckAjjJLAZx35q9FMquArFcDAUDjJ56/pXM28k7KpUJgcOWchvbAA+la9p8sse4gAsNzZznB7V2xnF2S2PPlFRSXU9f8OamLTQde864ukmu7IMLpJvLktPK3NGyOMMPXr6V+WfxA+KPiPxh4o1DXda17V/ENzuewsbrW9Rl1EwQIxVTGzsSMjn054AFfWvx8+LFr4N8AXmi6W0ra/rkDadaSIAqwCRQHYc9lLHPTgV+ZUWpsF/eFyFQKpzk8Dv9cV24KVR1m72jG35nPVlPl5I7o6GfVnSU+VLGih8kbQXJ9yTz7cfjWLqN2bpxukdJMhiY225xjr9e/1rIEsV1LmQgSON6p3IAJIAwP7pPPqax729iEwDPsdeFJfgDtx2r6uOMpRi431PCnGu7XS37lnWEYwNMrLnGMMcEDjOPy/SvO7u4bcAG2AHDKPvE5/+vWhqOsTM0iyFDHGACoPXBPzfqPyrn4Jnu7kOETAYABAG6YwOnPrmvHxmJnUgorY9DDUb1FFvT/gnS6VC11LEifMHZUD4LFcnB4A7DJGevt1r6t+H/g57iSC5kjdoJT5cqtHw4x/D/EMZ615D4D8LyXUyThSu9w+XjCqCxx1x7n8q+3vBOlLY2aFTltwZlZgQCQOnOeo69K+AznGqK9nF+8j9SyXLoU/3rO68OeErDTlhmSELMigMCAwxjggetdu0QXGNqDvgcN1qHSrgSIXcKoBIyR1H+TUt/dwxAgAMTz0wCM18ViHKpNyZ9fBU5WUDrtE1AWfltKR5eQSyqFbHXIyR7Gvb9M8VQSGBbeSNSNrHeoKtgg4ZT27EfrXypaahEoaNhtXOQRwvfr+leh6RrKICGY/wgKDv3cHpxWWFlCjKXN1O6slLZH0RNrjxRqWuIw0pzIoYKoxgnaO34Y4rnNQubS4kWaRYJHiO+KSQBnjYcfKTyOp6V56mtz3DeWQfLL4UtwcDpwRWwJPMiGZQePlPQEf/AKq9SNZxjpseZ7KM5tszb3ULmZ8ROI1VgyuAkmFDfdwwI5GR+PFQf23LBG489ySAWx82cZH9e1WkhidNnGC3JFVdQh09ElbGZcbQSpGAOBjnH4kVzV5yb93YypRkk1HY5jUfE10FQLO+x2yCZNpB6gj0x7VzFxrtxdEkszOeT1c9O5xzVu6W2R/mJxn5T1z1rDllhScFAPLPzZJIJ6dQK5ajbd2XhW3G7LS6hOiMHdsE9CMjnH/1qadZEaMuQG9T94Z44HeszUbmOJCcnk5A3nA44ArkZL7Mu5hlgOepPY1wc9pNM9hQcUprqeqWeoCTDF85+YZXIrqYbqOPy3IOBkAAEDjv7dOteCjWh8hQlQpwQ4Ixgf4ZrootekjjCAuVcYfPykY6dvc04Sg5OHY6asHLVHuNn4hiCsGaMKxKxnB3H29c9Kw9d1y3a3nUosxlRlhYk7UJxyec/hXj02tSkDyCysvIbOCP8/1qSLU2kP7/AJJxubJbHua1klBcyOGUJOTZRv4lnZg6j5upHUGvL/EOgNeEog+XO4rja2eMjP0zXqd4wCFk+YKN2Oo96w7kpOCyJwx2MSu0qwAJAB+o596iEpKXMjmdJyhyyPiD4mfD5LrekVqAys7SvIV8xzhlGWxjAHpX56eKNHuPD2szWc8boUJJDkFMbuDnPcDjjrxX7ca94Vj1e3lztJKbTubBUAjIH4D9K+Avjf8ACyW6N5dW9pHi2jZczqIg4XDsyY5PPT2FfQ5bjqfIqVR/eeVmOXSUPbU1qj4thu0R43Dsqk/NhsDoRgfr+ddKzRyxr5e7OMhsFc9Oa4pLCS1fbLGUJJVCylVfGeg9q6i0EqNEC4EfBK8bsj3I6cetfZUlFR5odf67H53OD3W52WmTmPy1aT94W+Xdktnk4OOeM/pRUMMamXcEKsG3CVVyEA5J9T36UVySo4jT2SVvM9NXtqftMYydpXGCowM8t1P9f0qWMBsqzAbVwEYEdv5fSrqR+aB/eXBA7D+tSJbBnwQCQOSvX3x/WvKvKXyOq/NHlW6GW0Pl7SxDFgNu7gdM/wCfpRt5ypUq2SGQcn5scHv6fhV4xhCpRmcYx8y4APpgdgMdaka2OSF2tgZURAhV9sY/lxXS7RV5bs5LuT5Y9NzmzFzxkE+uB7VJEwUsoCllG44Xd2zwehJ/LNbBhyFEkahxyAgyn6knt3qtPAzDEK7SR83J2/h/hShrJ3OAiG3cSpK4GDsYkn1zVtSqnKHLkchu1VYkKuTk7mPIPKjr0qbyzGAIyWyd2MY5x3Na0fbXk6dr21CaXNtoabPmPcGXcoyFPOSB0qsZnOcgnBwQDwMdajjAlT5kIYsSR/C36c/T2q4IYhhi21u6qp6D3xiimly89Q0lyxkkihE7Kpy6cEEKT16+3bFbNncqrEO5JZgowd2C3HT05+grMym8BArKVAJxjaeauRRFHGFG08ljgnPBH869Ck1K8V8J5jhKb5jqbe6bYVXjjqSFJ59sVHe6p5NrOwJBVQQehPXv27VmRsVbcTk7cY3kAc56A479TXDfELWI9G0K8v5pJFWC3aaOONsNKwBCj8yP8a2pVKdN8qOSrRbk09j5B+M3jhvEnju9j8/z7Tw7F/Y0YMgMplysk7Few5RR6+X2zXj9xetC/mo+VdcIOnT0P9K5jUtWa9v9QvLoCG6v7uS7ufLzku7FjnPXr/KsG41OZlKndIEOE3fLjJPOM4H3uceld9Go1qup1TpwWqO2fVtx3CQxOOhVyGHUfn/jWFf6gh3y+azuy7QxbJGOB9AK5aS7YhQAAc8jPI781k3l7v3AqRtGFYPgt3q7u9zptfQknvZBgSXAdnbAywLnnpXpXhHSYrmRWkIDSLkDjng5I/M9K8e0KGTUbuNBFu+bkDlgAO2favsz4a+FEnEJkco8YDlnQnKscfTt0HrXDmWLp0YNTev/AAC8qy721ZSa931PV/AuiTJaIVXA27wCdox94kZxnpXvWmMbcKWZQVUBsAY4x9c96yNK06CC3RI0YtEuFJOWbk9c/U/pWo+UU7VwWGPlHJ+v51+e18Qqk3Vm9z9MwlCNOjGFPZHQLrbRBRG5wOMjgmq82qSXLGNWXB6Yzu/Ouda2lmUM8TFfvDbyo/T3rUhi8iMEqQfXpkADsPxrn5oyukd9KMlHlaNhBKuG8xhghSBgDJ9c11ekyNHMHaXauMYOMHkda4gXPzDCnGCBjJ4/Grtpdqk3mOGEYG0gYz7ZHXtXL70XzrVHpuLkrQPX01UssSeYuEOODhjgHrnP6VpTeIPLjVUfGE7sNp6D9K8oGpLIwePcFDE8/JjrxVW4vnZwC52g8fMdyj145/EelaupdeRgqCT5ZHocfidPLVZZoFbLEmN84wSB19iP1rK1TxSmGPmbgELHy3Mg49hXlt1dkAquRzk7XJU+4/Ks9rpvM3bm5GCA2QcEHn9K3nWpW0PMjR1vY7t9ZLjd5rOWPHO04PPcZ/A1BJe7oi6EllI4bnk/l6VxkkySYJZkBHrhW9KYb7KNGrNhPuliMmuOVVR0l+B6lOLtqdJe3ckqsS5bLZwTk85z/SuaaWYysnGSOBs5GeetSpeBo2HljJfOduSPxx7dKY867ipUBv4SOT368cV5c588rHuqEVTVtwLFj0GFPQnIb861EuDs3MfmPcgYXr2xnvWYMvj5eMjOeh9v5/nWxbQbiPlHK8BeT/k1UfcfvBebbXQhzuiRo2JcNk9gakj3lzufGRwAev1qybHCA4xjvkAHJ4qdEUgZLDbwMHPHFbOfv8p4yhC2u4yAMQ2TuzkYbt19KlW2UkgA5b0ctjjJ4J+vNNiXYrADCtxjpxn2rTSJCqFSzHHPYfgf89KcpNzscEqDbvD5mJc2EkauM/KwwctsDDtmvJ/E/hCDVI7osX3MjKUUrhwR83Ud8d/avf5LdZEYOqnjIzyDmsDUNJlnEgQKisOrZz3zxXTSfLKKdyMRSgqdkj8ffjR4AutA1WaWysmksXbdHLGir9nJb7jINu3I3HIBBwPQ14Xa3bxSCKUZljOQuOEySckf571+tHxa8H/atPuZzEZEjbNxHt2llHygrjknpX5meK9GtrLVroLGYxCx/g2MQSTg985r6/LsQnT17HgY7DSo1OfoyrYXDuy74jIWIJARQsYxzwMflRVXTbtfMUBnAyCCR0/A/wCeaK9lVKv2bNHz8nNPofuHgKEYg4HyA52njjn8qnTZuJVgSRnnJA6j6ev508p5seGJBXjGMAc5yOPeo44NjHAzuxknIFeY+eT5X0OWU4RvHWwM0aglyuVGQOdzHt2xj1781aSbA+U8N8oAPTtUbWu/PyY+YnIOQfwqzDanbnAXAPGDmlOCW+5hGMOXmVymZgWZRjA4POad5rldvAGc9Oc9Kka3TaGKuDnnIIGec4PegKR2GCAAM4C9e/5frSTSSkwpp1PeexRb5lY/LhRgADsM9vyqmZZAQeCW+U7lwPrzWusEPlsQTxwyspU4456fyqgQpYxopYDoSN3of1xXUpPmcn8LOZ0vsxHRlgMna2QFyFAOCD2pySTgYX7pHGRj1pikjfGUwQ2MbcEcen6/jSYkRirKN2P4u1UpQi7xKUG4qHU6CNlVAScO3XHT6VbFwTkNgnjAHBPGKqR5QAtx/sjkmlZjuD9gueTznnjFclSpKpp2PehFU5NLcc5ZBneM9cbgc56e1fJ37SXi28tNBjsrJnjnurxbaVoMKYEXJ3kkHOcEY/2q+m7qbaMpnnkDoR6cCvz4/aG1eSfxF9lE88lrbQEtCCFjZ+T8wx1GSMn3reM25xiu55s6fNFwpo+YNTvN7PJNI5kkkywzwx5bk/UD8q5x9cWSeSMyAshHHqew4P8AOqms3iFskAHecBT0wP8AP51yZnkLMeQc53buTX01NtwXMeDWpSpStPY7U3u1XnDBmZc7WOO39ayDey3kyIqqPmw218jBIGcnp/8AXrmZ72SEId0khZg3L5VM+o9cZrqvC2myahdechkKIDuwp54HQ4xjJ9e1TWrexg5Lz/IVGhOrNU6Z7R8PPD8txNEEMJMjA+YFLPHnkjpjGO+e/wCf3x4R0K30y1iJ3tI0a4V2C5x1469RxXz78MfB0mLaZo+GBbaw6khvvZ6deg9a+xbC1SGKCEc7VAyVBbnPGAOf/rV+fZtjJV53i99/kfouUZdHD0VdG9aEeXjcMt8wUcKOvatNFTdkgMAuMnPzcdhVGOCQqiqAVU/eXIA4zjOK3re3WSMNIrNjKk844wf6/rXhOLmuaotT6mEI7IgixHuA2hd5O0gkHt/QflTbqNXQKSFIJACgc9zkVotDCq4CbgMckYqq4wzMzYAIzlgB61MlKWvQ3gpRirnNeU8T5ZiUzkHG0ZyTxiplkXBOeTx0IOO39ajuZc58tSQpwFyKryTDAJAyOF9fyrqcptabHHGLkrI2TchY9pJIAxgEYbnNY8l6qSM4fbg4ChycH169+aqXV02AEAbI5AYAp+HrWNLKS+MAckntg59etclNpycT14RT1kdDLfNJxkZJxgbRjrxUYulDBWlVSASFP3j0z9T1rn/PO9gqkfNnjpjHc0yS4LyZA3SL91gfu/pWVSFm7bnpRpyUtDVluiF27iACOV4LnnPH4frURuBGNx3FmI+Q8MOO9Yr3IVkXJyoyCGwoOcdfX/GnmTBVsruPOe/4fnS5XKN3uckYq7l1OihuAQRk5LBMBGwCQD1x0ww56VaQb3AB9s8bgciubhmc+W7MuUbdg8se3T8a07eaTzVPO1j1YbOPWoUpR91nVJxlBdzprWFCFMbfd67uc8kH9c1uWSKjh2+bH3gOcemAf5/SuctrsBwpQ5LkFgcqcZ7+lbS3Ksy7sqSewyB+NXKTbszzOVP3pG08YYBvNUKRk/NtVMe1UJLdklOSzHJ6g/jn25q1HJu2j5NucFXYHeCKjGfOcsFxgqCBxgdv0rJ0pu10RJRjexoCMkAkqFHbGK14LdlCsCGGOhAPT05qCGHehOMnJI28t7fT/wCvW9BBhFGwjAxuYdeaiCtJpHoXuZEUaiRCX5LYYZ6jk+/tVw26OCzDIJySw6YHSr0FluUFwfqgyVq6bXdtByyZAboSPbHtXZFyc+aXQ+eleabPJfEmjQ3Fu58pHXYVdZELow5PI6f/AKq/Lr9oDwUbTUbie2tnjM8heObyyBhiAOOeOMfhX7M31gLi28pYyEb5W2j5hjjIGPavi39prwRJB4YudUCeTb2owZUGXQfKCOQcklgRzX0GUYtzqKC20Pn81wlSdLna03Pyy0m1kguI7e4ERLugkUqJEYnBUDgcZKn2oqz5ojnwE3vC5+ZgQQQ3X8xRX17Te54LlFOx+4iAfMxCkIxGWXGecUycktuRQFPoACev+P8AKlUkqwK7RuwcjGDj8qWCHcXaZiw3sIhGAuwejcDPIPPJ5HSuCVWm212Pn/e5uSOyNmNschRgjGCDz65q1Ekjt8hGB1AGPc8VTYODwowegPrznn8aeAVXJLdSSeSMHsPyrzvekrwPoOZqK5iwEDcblAcbAARnPuelUngCuwHIAyGU5C8A9hV2IJIpWFl3MNxV/lbP5Uv2ZQW3phh3PJP9M/StEqThyv4zPn9662MTyN5bDNgNypHDeuBj9KcYFDjaCHJznoCffmtBIY1wV6gY561XmRxJuVhjqBj5fwpWlHTuYOEuZyitxj27hjJkBj3PDH3pxjyA+RknJOcc57frV7IYL8pJzjjg+9WXt12KwXCk7AcjPQE+/cVME0jvUGoq+5hsFj+aJgwwDyMk/T8aR4yQHLYJ567iO/Na0kIGAmGA9uVPrVSVVAJclivAB5+tRNzi9LWCSvscTr2pf2bp93dlWJggMpEQG75AWzyccY7mvym+KniifVtW1O93zCS6kYSRN+625YLyM8fKeg71+jHxf1620XwveS3EckiXSCzjiQ7ZJJJOAF69snp2r8p/H1+s19cpCiQxrIJPOOC0mcEgDsO34V3UZ02ud3+44pRlNcsXojyS6lmkyNxyWw3Rse4P/wBeqhkJEhDAsM5wQG78/jVOa5kRmVgSC5AbcSeMjg9f/wBVULi4ESHaFG7oHO5hz65z+de1Tq6c62PDnh5OpK/Q2Ii08iptDMMHJ+6OOTkn/Oa+0PhR4Ia5gs3EEIeRVkBMCISVIYHJBHAK4r5w+EfhuTxFqsYmtBJbJgPK0e5EU7gTkjGeBxntX6n/AA58LJDpcMkcMjps+RnQBk2qCOMk42g+/FeDnGZu3s09ttD6bIMHr7Srovv1udf4c0G3022gVQVygEgDZGcYPvjI/wA4Fem2OnmVlUbjg5BAyBnr1pbLTvL8oFCN/TaPlGTuPb3ru9NslDRqQAq4BJYAema+Hq+0m7y6s/SVeMblPTtCJURpvkYgMeMr05rQuNMt7ZGQny9owUDDamK2LvUYdNhW3ieLew3sY+WJOe/+NcBqHiOE+akrwxkDaFL/ADPzXZGhKMVzLToeJCrTd9Se9uo0A24CA8AH+f51iy3SOpZWZsngLkD8DWTe6tbpH52+OUO2xV87bIxC8YHcZrKh1SHYrF4kLjDIjBgCOoH0q3Cd7SR61OpFWb2LM935bMiFQRw2c5OTk81lz3f3SWYfNgZ4ycZOOenvVS7u4ncyF0zxuGcGqE1/DJIAHyQMBlbgfX8qboN9DSNWm7pM05G3qHRgSR8xxyMVVeN2JbOSRkEY46/549etQ21yDkEngHBXBY+wBOM+nNacwVUxjO/ocg5qO9zWNXQ5iZZEJK9FJ4UYDfn/AJ4pgchgQdpYZ6CrzxseWC4LdByRwOMf560xrfYRwCcZ2kkEfWuZ021sW1opJlYYJD5Bz15yP8/4VJtJOCPlYYx1HUYx/OpI484+UDDdAOKufZmClm2/Kcg5yD9Kp0NFykrlTbexKihUXGM4/i6/5/wqZp5EKK+4hAQDk8c9aQTR26hpQNkYaQP5e51AGT05PQ8Vh396iyt+8YK3OQNrNnkduO9bKlJr3dzXngr23OuW9k4EUxK5ywOMjrW3Y3zhmMu9uMjIzx7GvH38T29nJ5LvtiwMnIJ6fh9aE8c6daSNGLkFw3yPvGzkZ6njNKODlJ+0FUzCEZciVz32KcMA6sAVOeeefpWj9rVk2DBJ+9jhTyc9/avnqz8eQO5U3CAhiNqOCT9P1rq4PGmmLAj/AG1S24BkdwJV9cg10VMHNrRHi/Xpa8qPZrO7Ma4Izxweh/L8q62yvYXUAKwZjvy2SM4A4BPHTOB6181z+Mrc7XtZ2kZeoPIHX9KuWnjyaLaQ28p8xDNnHcgf57Vn9RlF8yWpzQxTk7tbn1OtwoBZZNvJTZ94+ueOatRNv4LEMeW+baB+BrxPSfHdtdXkVvOxiaUEw/KfnKhicfQLnn0Neu6XPJfYlRVKgDLEn26Y+nT3rinTqweq0PdpVKc5OMrnWWMYJUcNwoPcnrnNeTftB+FX1z4eavZxogkkeMxGQEITuG5TgZ6c8ele5aPCkyIpjHmIwwSmB7CrfjnQhe+FL+Js7ntmYKFyS2CBjjtnI78VthJuniIt6O/6nPjoU6lCUF/Wh/MlqETaZruoWVxktZ372sqFgPuSd8+2KK6L4maFPoHjPxBZzyyTzpqkhnEhCFmLn5xx3A/HFFfd0oRcFzXufn9SDhUcHpY/bZ0h8v7zF8/MGGAOexoiVNwRmVeCVUnDNgZOPXufpS+SytlkO0kADGMfjThFGWR2SMvFu8t2QMybgQcHGRkHHFcbScEpfL1PKlyOfMvmNKq+CC67T8pHP50u6JVZQ+HJ5CggjsOcYpWbhQyHC43c5x26fhT2twVMiICTyARz7EVTU4I0hJSVkU4hLCEYkruO1cSYI/8ArVLHcPI+1skfdYEZI96nitpC28lwwQjb5aMr4yQCSMjBOeMflTpVhVvmDZIyRgAfTj6kVjK17omKkpNIe0sUSOgPIfLHyipJ+uOarNLC+4EkAnhnB3D29Kf5QYllTJBI5XGfxqJMu/zRqu4YGOCPU85rCbbimzt9nedo7oEniHzKRhTkBjjd+tXRd2+WEkyqWXIDHCHJ6ZwBn6+tU2t4ixRQSFGSSAWPqelMksQQ3yiROhOAQMHPP0OD+FRsatSlotycyxgtiRCScAA4D/Krcf8AfWPqDVO7ngAKl08xcjCnBP1/L9apS2wQcbC20ZGSD0HP6/zqhcL5K5kBIUcY+Y+4P5VpKMEr63ZyKTjvuzwz473kH9h28JijmuPPWVVkcbMYO7aPULur8nPH+s2p1e+USw+TI2YoFHEJARWB+pVj9WNfoh+0HdGO90uOO3nnk+zXF5BIp2+WAyoysexOfyxX5aeMpoL3UZ1MaELMxcsASCTyM10YJQi/f+7puelrFuJybXvmq++RlCkgMGAAw3PNURK6zI7uHiyGClhkjPB/UdKY0oihkVQCACpDDC8n0x0/Osl7oyyFcAvtIIWLCqADjgAA8Af5xXs1JRo07L+tzw3Sk5Lm6M/QT9l7S5tYs7tYYsbLwAKVKgIAvJ6ddrdPav1L8P2P2CzhQJIhRQAhOAuMjKnOfXOfeviX9kDQTP4ZsNSa3BchtxT91EcZVcqMZHy4HB+8a+8gsiIVCK2AcqvIxx7f/W5r4PMKrniZJ7H32V0XHDKf9WLPmIqDcqqQfvknPHrk1j6942tNFsSLVonuW/d7o2DeUePmYfjXL+JtTu7SLbDglmyig+38Xfoe3evC/Fep3zAG3sXuLq5m4jhYmOIbUy3HOSVP/fXWng4OLu2a4mTtdI0te+JuqPcMVuZSQMFwckEnOM9OmDjtmuGuvG+oeYbme5uZAxwUeQkgDuBnpWZp2maldCaa6t54neQho5c+WCAACO3pz9K5XxJoWtGdIrW2nkVht3xk+X0HBr2oVINe8cDheN5HWXXxRCogRySo+UjLDjPX8j+Vcm3xPvRcI0dv5nlMWDIzDd7n8f5Vzr+C9Z+zLKqAsz7WhIJK47mtS18BXsMaT3MQZ8BlZV+RT6H3pKrh7uK3RsqFaVrG7J8RdbuJI508qKRl2yL8xGOg7/rXRab4v1WTazIQd2JAFO4dMkHPvWFaeDpYmWSbDAsMqRggeo454/lXTQ6CsDjy8gFdw6HcPf0NcVSrBpuFzsjhZx9+R6NofiMTlC2VIODvO0n/ADmvSVvkkWPbtAIy2cEqeO9eLWVl5XzICWDZIyOnQ8HjnJ5ruLWSdAsRD4xuYg9OneuGpOC1Peoc9k5HUu5IBGzpkH15/wDrUIN53u4AxtADHAz3P5Vn20v7jfISQOMk5I44qYy7QGA6nORhgB2P8qylGS97oy1Nc1kTNFsBIJG1t2V4A/Gp2vfNRVGQQDyRjrjODj29ayxNIQQvKgYCgZH60hlkyQ2duMkA8j6VUlKCSewRhKepNeSAK0rEhR0H3SMV5nrt5K/mJAzZVSxIBYjsB1/zmuuuXST+I+WoPytxjNc9dWRZjIMMrLhlA5HII9f6Y4rtjUaV4nmVKbnfseIX8V8GZJJrhlePYzb8gdzjj3PWuJvILlHYJPcBOoPoPr7cV9DS6bE6szxqwJPDDGOvTvXP3OiWUjtuiC8DJC59f89a1jiuRa/keNWwkXK0DxuyvtRstqwPKYosmV3PIOMHnPqeB71vabfaldysq3T+SH3lIwoYN3JbqSff0FenReBlvGUMFht2YMmxQxf2OO2PX06V1dj8PrKGQTrbqpQfKI1KliMdfrnP4Uo4zV6I7vqUorllscxoUOoSeWTvZQnlq2cuwO4cnHuf0r0m2srhkVQmG5yQ3P8AnPvXVaL4Yiig+ZFBflSAFI/Dt0P613tn4etXwrLlShBG37w+tZTrKerWi1ClQhTXKr3PNdPWRbiFGSMTQKBDJ5QVxyQ3OD2yM8/pXvnhDxOttLHaXEjFW/iI4bjIBA4HbpjNYUfhOwMkZNuZOMjeCRz/AE4rs9O8CTyItzbJOjK/yMoKpgYwOOD24rCpUhX0l0MZUqlNJp6H0t4eImWDAAViCPL+U4I6816dd6fHcaS8LAOrAqSx+b5uOv49vSvGPBMWpWdoY9TtPLlhmKx8Euwx/XjmvfNEjXUrfyHBHzcMVJIPINcN4xkuXuj1pr3dD+bv9rPwjL4Z+LWuPIC0V/MLuNypVmL7mOR0I5xn27UV9qf8FI/h7NY2mk+IUie1hSdkW+tgDMXaVfkLf7Q6A+hor7DC4iTw8eWSX4nxWKShiJJI+hZbULsYYC9enTjsKppCBKfmOM844IA69q0ygbaCSVJ+YOMjFLHEqvIREpyM5xkNxnGK6JRgrTfxXPm4VZJ2XUUW4w7KwGflVSCW/wAKWKNh8pYnHTJrT2Bh8oG1eARwev8AnpQYwvTcfwNc8qlSbcpdT2+aVOKuZ5tsoq/KMD5nAwT3xVVoBIUUYJABGRkduK0ni8xdoB3Z+Ue+KqujRDcBhgvUcg0pu6SOOOquY6wDJVxjBx04IHbp71RvbUwKzoS24eoYA9sAc+vPvVxp2xsZMEuQMcgHr1p8oWVWDHDKhKjGRJ3C+wOMU5x1utzyJNxtYzIZDgszAZG3kYz0I9KtqJSpUhthySFJx1qZbVzGxChSWIAyABz6de1QtuxsJyAOSBzXHe71R7ijdXexA0axKCC3zLld2SoOAPw+6Dgd81j3MY2MGBI6KB6fXitZlG0Y3MQeFHKjp2rFvGZty7dxxsG4lVHbn9fzpqPJJtbMwVkvU+OfjpZzTG5mW6eRbbTn+RUjEisXLHDJgABWAyeSckmvyO1lla+uyFfAuHQpMoDttYg5GD6V+s3x6Eg0jXkZoiTYuxRlxHkxqRnp0GCP97Nfklr9251W+DISPtDZ3KARycHg13U24xTJcHB3Zg3UsoJyqLhQrjPHA9B9OgrLRvMlKoXDONmUYLgtgAk5OAMgnPbNLqMzRhnjwoJwULZLcAc/kTxTfDbpNrNgsj7Wk1GGLYAWVsyxL098kVvCc1Fvo0dEYe9zdz96/wBmDRDpvw40OaSERynS4onSM5U8Z3YPdt2T3Oa+gXkd5JFQbVKZIPCgdfzHHSuU+GumPp3gnQ4kQJGNOjl5+WViwBBPHoSMegrt7aNGcsUBy2PmGRwT2r4vETVTEyb2ufaUJKnhoRh21OPvdEuL1zI8RKMdqcHac9MZGD2rNXw/ZWpDSKDKrZHILD/P0r0bUb8xYAOSvKcgYI6EY6Y4ri7295YylQMnBPTk9/061vOvJRUI/wBIyjG8tNjlzbW0TSxmJYozIwDGFpQNx2jO1WPvwO1ZsmkwyvtWGPBJztXOfdT/AIiurV4Wy2UO7oc4Hf8A+vVd76ygaXOQVG5gV+bgE8Dqfw9acalm3fQ6adL3mn/X4HE3HhmON/ugiU7lKr8qDGMZ9Risu50MRN/slfnDDcpwQQe3pXYvq8e5gFkZdpZdseMAE46gf5Nc1qerByTFE6xKhaUmMKV55xzj/JqXUk3dbGdOmv4fU566SP5U2KPL+UEL9eT7nNUVUKeQOvB6YqhqOrQxqG3EKZCwHRwO+R26CqdvrEU8mMhRtyMDd+ePzrJV5KmotHsRjyx5WdpFAjlXBxkZIK7t3NaMV20CMJEbDcqvO4fXP1rCXUIgqlWY5BKZGC36U836z8Nt44BJG76fpn8Kwk017ysei4wjFSijoUvXcqCAFA44yT7n9K2I5laFTjZ2JZM/lz/j1rl4JkUKApZ8bsqckVt26OXJww+Xjacqc57dOtJThBb6k2lK3Lr3J1u9uCy7cDGMhQDU6vuXcWABOSRx65qpPEyIMk8nuM+vsPSpSEjUO0pdlXAVQAp6dKtVHa73ZpyxvdGffGPO5QFXGeGzuHb/APVWc8gCccZ4A28DuaZqMvyNIGUHk4IwKxYrxiVRgrKcjCgk/Shq7SMKikpXS0NrzCIPLAAVmBJ9MEHOevVRWXJFG8hPX0PTOO9PuLoRqS5A3ISSWBHX9PpXKXXiCOBztZNzNtO5ue+DjFE+e7YVLq10egaaU3Qrkk7gFB5I9DXo+n2lvKUZyQ68434U/UdDnPevn/TvEEUrRCRt2SC2MDA/D+lejWGvgRqLYxl1HylvnXp3Geee3oauPvRSZ41k3ofRdhYRGNSTHIwPy/NyB6YzWxBpzx/vMsEG4LtUAHPI9B19SOtePWHjl4N++3CSlgAYZA0IBzkFSd3YEYr0bSPFmk6gCHkMM7P5S+YhiZicEHkd8j865lVUX7OJ7lSk1K7PQ9KsFmSPDgMAu/JBHpnp9a918HWpmMVpKUMC4Dq6YIBPOB64zXhukkBAQxMbLn73LD/P867PRvFtp4aujezl3i4SSMNhWyeCWxx65+tbK6fuHnzioo+itT0yIWolhjRdmD8y5YkAd+vb9ak8NX5iu47YsqLKwEbKvQkgDn9PxqX7ak+mTOMlyCF5wGGSQPfjFYOnSJLd2UhdEH2gGLDbHZlGcAA8jAz/AIVMpSTcbHDJNR93Y8G/b98GNq/wC8U6hDF5l7pdumqxyN84hEJDGQDsQCefaivtH4reC7Pxz8GfG+j7EuJtZ8JXWnQoVDku9uyfnls/hRXu5ZWjDD8k3szwcdSqSrXitD84pY1AcdWDbTkVB5kigsqfKqksVQnAHfA/GtiWGRLp0mhmtpEJjkhmUckcHB6FcjhhkEU37PKMOGCE8hkO0t+NfRuXJLkn8X4H51GEk+aOzJorgrFxGo3j7xXB/L/GrCyA7mAdR93qV6/56VZgs/N2iQhcnLZ6r7k4Jq39mIyvylQNo2s2fbjgfn615tVJpc3xXPoWmmlIz45YNoSQfeYAMNwBLEKF45GSwHbrUEiJklgQDxkjk57f59avtbDKpFGQc4JYY21ZlsY1jJZTI5Tjc7bVx2HOO+ahqUbR6or3+m5zktsCWK5ZBzvUfKOB/jUJXAVQBkAgkdSM9xW35TAFpCB3wuNoHXrWKzZlwqsW6ZII9K5Z805cx1wU1KysUWRpQMErgdSKDaSjGxckjJyCP1rUijO4MxOcEEbefSqszNG7c5QLtIznB/z/ACpznzW5N/MxaUnoc9cbIwyk4bcdw2gL2/8Ar1jXSpLG4bk8kYGR9a1b+Qli/Q8YA5HXof8A69Y87MiOdp+6TnHFUqkUrPc51Fq6W58NftI3ken3lzYvthXUNAYkhNsKs4kj3t+CoOOu0/Wvya1gSNf3b7t5EzFnHCnJOD+PNfqJ+1reXEuv2MCW85gOkJDLOkPmCZnedmIJXjClV49K/MHW1R7qdEBiCk7eTJjLV10LKmrm0o6c0jza/mR42wc7WIznKggVvfC20XUPHnhm0MX2o3WuW0X2YNh5f3y/dO046E/h+IwLqKGMSLnEh6KAcsc/5P417j+yr4ej8QfHTwJYRpulS9e/ZXOUIjV+cHvkE/hXdXnai7K+/wCR5dHldSPN3X5o/ot0rSjBoWnwBSogs4kOckZVVyAfwI71TuHFu4AO0owyVwc+uB1/SvUG0pYLG3ijRRtjBYhfmJ2gZx+dcBrNmPOUhHDplerbeevHTJ46818Gk5Sc5b3v+J+lU6cfsrSxwep6gWlZYXEi8KwkJXJI56c9a5i+u4g8SykMM5bHBBxx3ra10LbIXVT8nXI/DPPvXimt6/5LTuC3lxqTJIozHGAOrHsK0UvaSbOmnSi9eqOzutUlcSQQtscnakmQdg4HTkHv+lZD39rpaG61jVo1O7afPcQhsgkBR36fQ18s+O/jVcaU66ZoOJb1mxdXLKDBbg/3T3b9OK4/SYNT8UTWd7faldaibmQTq0szHy8kBlA7YwRxit4UIyd2zqqVYx+FH0/4i+Nnw+8P2zyXd7Cr5CxPJDtR3YcfN1P4V5Fqn7Tnw/likgmuLa3mAyj20nnecCOcjORXmXx78PKvgvzrazt7i4tbhFldwxNkgIzIhJ+926cjP1r4OurWK4s/nJiZfmEyYBfOOM/gTXXDC0viqXOR46s5Wp/kffln8VdC8TiSbT7yMBZSFQvsDdcHBwex/Kun8MeK7e6vEhjuYgZm8pFVhKz8EgAde36V+WVhPcRXccSGZY94A2OUx3DZAzn/AAr23Q/EGp6Dd2d/pVxPJcRukjmZi8bDGGH1OevtWlSnCCutjhhia80nNan6it5otdrF41ZfLwg2uu5ThlPXIzmn2jTvLtBIDLwp5OBxn+VYfw88Rr4q0DT9TP3Wt1iclt7+YuQ4PHY16TBaOGLLHlX6Z749f1rwajjHZnvUruCUy9pNjPkMzF2BGMjIH4f5616RaaY84j2jBx0VefrWFodhNK6/KGiPy8nkfUfiK9T0y0RSIwhJUbRgevPWsXKVlbY6ItxlrocLfaXIkioocDdhmIwMjOfp9Kybqz+RkEm1hweMkcfX/OK9l1OziZTujCgDJJwuenSuB1PTThni27So+6ckcdvTrWPtJQ0Z3xlFu61PFtTWVN6CTdglG3Nkj1xVC2dFIGVUp1LfLmuy1C0MTGRlYKz5IznDHrXM3VusrMTE6x44ZRgH2+tdVOolaTsU1B3ucb4m1qGCyuZsrF5C4c55dumBjv1/KvDj4ge9nYHfjOFZfT3rP+Il7rMviW70q0WePT7KJJFEUhKXTMNzMR7dMVjaPqjRMY5LRY5AAGdkLY44JHH8/Wvaoyp1I3keDioVfac1INe+Jlx4PurbFtLdGdiotuVZs5IIJzgZDfkfSufT9prXYL6N10xbGzhG8+Wd8kpGcK5I5B6EjHU1kfFxm1HTYL6zhWa+tXVZWRW2xwjghBnk5OcnpzjFfOlxY318sPzyRBHyVAKFh6E/56V2RjhqmnbueW3ineEunqfYel/tEa94s1LzoxJpyQlYo4Wh3CdlYYAA9TgGvaPCnx2t7rVLXR9YWWynnORcqxW3jKjoxzlemQeMZHNfEHwu0yefxJG07MlrpzC5eIKSHcH5c+wIyce1fRF94EsvEt8upTwzQyg5DW0pjifOPvKP5/WvOrrDpts9OlUquWqP0n8E/ESRDDFfX632myoFtrvzFfYG5UB/4h25OR6mvoWIabq9si3KiSAlSwLFGAXkHgj+dfjv4P07xrot5Ho9lc3t3YLMJ4IGRmVRnO0Ac9ug/rX3L4B1L4iXNtDcXVjczWQBEKXELI+wDDAjjHTvziuCq4OdofCVO/Iktz780fxeZIks43MysEhUsApB+7lunHTmu30ZBcXNoi+XLItwsiGQ4NtnhinXnaSPevnvwnNM8dvNJbNEzASNkfMCe361754ZnQXURwQQc9xkg8ZOc0NRmlHotTjkrO259peFtPivtG+x3bDIgkgdI8P5mVAGcf7xH0oq78Nt2p20MG4HzLn7MFORlgnmOSwHTBH5UVVPEShddOnQiSjGTi4/19x8Y+Pf2b/jL4IXV5/Evw68fR2ulRvJFql14TvYFa2Ds8YlcxABgrbec8gfMc14Ha232uET2gLwrw+PnaNskYbHAIIIP0r+3m6+MHwcubWaO6+JXw4lsnixcrc+MdKktXjYYIcGYqVIPfjmv5hP27fhl8LtH+OninxZ8ENT0eXwjqYtrjVtK0e9gn0SLUHUi7msjHlQrEJIVU7SZm2hVCiv0PE04L3os/KKNeSqukvvPgyG2KZLxrI+chGkKBiPujI5Ayf50427Lg4KgjAUcfzrSKzhxkB1LnCnkAfXHpVkRQujl1AIJAy2MD0FeVK0XzRO+MdeZ7mCEcEgdAev+fpUUxwNoOPUA4zWxIAm5V2gFf4BgH/PSsG7RhuY/NleAMgn6UpzcjaC3RlmAFXcuuwvtGThvUDp71nNFiQjBBzngf1qaeVgwwGIBBVdgG3HuB396giuHZcOAGIzuPUegrCUm9vmSrQt32NOKMEqHI2rjgAntjmsfUoQjOVcbWPGRg8Ec1eaSQHlgseDhsZPuB71RnAuGbByABty3XjNcLcb83RnppSTaRzEsSODIpyV4YE/Kcc4qhcsgjZZN+QpKGJVPbpk47+hrUubN4g2ACCckA7iv0x9a5y/leFCdpzGuVB535Gcc9quLUZOL3OSFKfs76HwV+0xcXLeJ7HTrWNrhRpv77ZIpkgLhigZT1zvc5JwAor8vvGFqtpd3sAkaEsxAkjC7kPDDkdeCOfev1a+N9ol7qDXzRmS7lI3MFLLhfMBVTj25HsOK/MD4kQFdfu9rD7O67oWVGBQDcrBlIGDlPyI/HvwqNsRCy1PGJIWlkKxlj8xYyzOzk5y3XOeK/QX/gnh4QGr/HIautuXXwl4dnu1ld9pMtz5cLMTjLBUkkwpOATnHOa+FBG4kCRxlmLcdFX169vWv03/AOCcgu7f4maxCqGGO40ETucFTPmRYyMn2UdfSpxdvYNvs/yZ2YS7rxS7r8z9w3sS1rCwBchTuOOCPp+FcJqunM7M+wcg9B0+n69a9mtbVTbAFCoUbRhvmbAwcZqP/hHBeu6iIkN0YrjJOe/4V8k9VbsfXQUY00o7nxD4u0jVrtpI7FAsn3RgncT26d6+ePEHwM+KHiNLr7ZYXUFpcDCJNMI2eNTks0YOSOhwa/Wu28CaPY/6XcWMEl2B8zsgLt12545xmub1998zBIgq7SAMhRwegH5flWiTaumSqUpK7PyBf9la3gtppNXvZ2uceZFHCGKljnrkZrJj+FmueFUtfsVuzxc/MjhhEeuTnpnnrX6Y6xYwySt5kC5DZ6Eg9elcDqWnWjO+63UdAVCkg++CfbNUlJK73OmnBpn5veNdM8S3mn3Wk3thdTRXEZhNsF2mUHjIYdR618o3fwV8RT/6OLaWJUbzBGYdwkXn5QODx6+1ftFf6Bp95FKj2keWXYshH7xB144rnZdB0+LCxWsW9UGGMAd1GfU1aryjFQaO14aEtUflDo/wB11pIn+zw+Vv/efaEeNmUHnBx2r3Lw98BrWOVCW87OSY44NyKSMAHjoOa+138OAq6xR4EhCnZDktW/pfhhbEghC4ZQdxTbg91/T3rnqTmk7vc1WFVkzhPA3w7h8OaRBpdvEiJGxlISPZtL/MQMe5/Ou/tdBkjnO5WZACcY6Y6dq7e2jWB0TyQQRhmPT+VTXaNFIPKJYOoy6gjqOQf15rhSclZbrc9WCsrSMbSrExuBFGWGQWwOnp/OvS9HtPtU/EW3I3FiuM/p60/wAL6JM/lvtXadsjEjAUHGOfX2+te0+HPDkNzqMUJjfEhwWEe5emeT26d66o2Z5NSDd2eEeIbKeHClN2B02kEj1/SuUFv5sbdPlG5lK4I/ya+wvHHgzyba2Z7bKqSqyAdscBv8968E1Tw6kCybF2Scktt+7WsqdPZI48M1E8H1PTI5C25M84JC9KxJdDkdvLAPl8MFC4UZHX616drOnmNwERgGOA68sMVkTQOUVVGOMZIzn8K5FG7uj3LzaujxDVvhrp8xnvooLQ300Yj86VfMYKuSFHpgZxXAy/DO3ZZE8hEdl+eUW/zntn/OOlfUMScGN4h1K8KML9R6du9Rz6bDuV1UbwCAu3p7fqa6oymouEWcLouS5mfEEvwm1K6SeJYFi2SMgnmX92y84OMZ71x0fwPnhmktzZESs5EcrqRF/vL7HrX3+NPJLOYcBnBwQdv+TUq6VbmQq8Z3q3IyNpzz2479ulVCdZ6y2IqYSMldf1+B8c+FfgBJFKstuRFPI5FwyxgJIcnAJ9P/r19SeD/g1Yx2sdtqsMbSkkyfZ5GIcnpz1444FeiabYRwvEsajJPyo2VAOTwePb9a9J0qJQ2NoBI+6Bx6cmurm1c0zieC93mX9fgR+FPhboenG1dLG3lntpFeGeeJXkQjkYJ6Y/pX0ppuk2aaetvNDAdwOSka8Y45I78HivMLGcxGNVX5gcnJGDwQf516JZaovlICQFwQSOQK45WtzHS8M3JtG9a+GIEDS2oUrgZTeNzegI68GtvSbF0mTau0K2crVDR7zrJvUb1wBux37139jFFOqtEpE4OXULw2e/+fWstXZxOedHk0Pqf4I2tw0iFJI1kMhKRuMlyVIY+3y559qK6v8AZuto7zXZbO8tDG8UCmzuE/eSOZDtkGOg49DkiilKm5pNI55Q55N3PyRFjZSqClqrRpgKMAnp/dzzVqErEDFFFFbKRtby1WNmGRkE4yfpntVSF5FxsyAOQSM5+tacRDffhz3LgryT06479ea/QfrE4ppbH5hFJOyNazY7FjkLBN3yk/dJPf8ASp5bZTkKAvbjqPpUFqhbDyHbtHCEHafTmrOWZxxtAAxggg9/8K85NPc7XFcqMue18zhJGAC4ALFj+ZyfTgelYtyiwBkkRnOwgHPKkg4I+h7H0rppisa+Z82V5IUZrndSJnbIIRcfM7dienTPoac6jimRRpc/ociwWR9qqM7uSRn8jWbOY0dyyk4wAPuhs5OelTTuSzqCwKyFMKwHTHI9uf0qjKHGScD3xgmudyS1CGHklZA9xNI4TJAJLK2CNuc8frVcO6TFFIDFeWyavSkRQk43EjAPvWbKQxYqCCTlgVwwI9Prn9K45VZKNrHtRocsnFle5nuFT5mKNnGF/irjdZYpGXDbvM++rNhgcEdfyrcvbyRiyBSWAABBI24rC1K3ZlVXxuYbshunepVVJXluEKb+FdD5q+LWmM2iNfRqqGOcydNyqT0OewJOCPb8vy3+LljHBrEgUOzSx+cCVxhHVR17fMsgx14Ffs94tsPtelS2UiM8ciqhA2qq7W3DJ/Cvyw+OuhpNrEsK2s0c+nq1qCY1Axu35DZ5yrjv0xXdhK8ZS5U9THF07U7xep8l2KLNK8e2PzEYtl2IJA+nHv0r9Uf+Cbjo/wAQfE8N2oac6NHEpJCmFI3LJtwBnPn/AJg1+Vg83TbqWIoVcnyy7A5Gcc5/L86/Tj/gmvqLSfFTxZDN+8I8Oo8Eqpv3sZIQc46YH5ZrrxspLCuXr37GODivrMH1T/U/dkSp5yREg/LyEOSBkgZOOpweBnj9e2tJoViGCnyr83GG7/4V5s/yzJKW+VHBKMuCemfqOPWt9bxYYGKuAXX5R0x7/wA6+RqTemm5+h0Epxu9i/e3ysj+UvC8jOcnsOf8K881HO6Q4Chh94EFQc88fWpJtaJleN1GcHO4/KOvP+f61yepX6qW2tuUgZCNwxOAOM8fnXQ5csVbYinSg4vc5rV0lc+YqF2U9Rhl+mB9f1rh720kkLM0YDgcLtxjNd5NMwidggdSnAz82M59M1lSbpRloVRM5yBkc+5qVKLjzdClSja8b3POLqAAMvRwSuF5zjoeD/I1QWxMznA524yQASPfPWux1WOLzFiiUK8uVRgp5xkkE4x+dLZ2TEgyFi2eh6CsJVItJo9Syc25GFb6WIgGzvb+HuBntV+LT5kOHVSPvdQCe5wK7BbKOEeYqou/r8xxWfdnaWMZQrgggkBeOvPvmsXBOXMelGCsnLboY/8AZ8EsKsQRhdzFVA79M/Sr9lpkDuqsA5ByA2CTj1JIHT+VZklwIwjI3yHDbcjC+34Zre0w+bsd1IBIDEcnGcE1q4216HBKKseseHtNj2RIW4cgAAA8DmvevCenpa3NuVjEjuwCBhtAzwMn05rxTwwhZINqgkndkAZ9P8ivpbwlEIbq3TaX3AKSq7sEY5x+f5GinHoRKg2nOPU6rxjoFreaQuSouCEKgn5S2VDH8ia8H1fwJavbTu0bGYRlmC/LtI6YB+nevrLX7GSPT42eMiKQjaSvK8cc9u1eY6rGhiaPYhXBH97IPGcD060VLuV0clBOLbkfBXiLQpYJZC6IFDYCcZ69QK4OW1gWYIyrzyGOB9fr3r6S8Zacd00hieNo2YNFt5GMnHHHIxjFfP8Aq1s0hk2jYw+ZeeG+vFTJOyaPThCLbkcnJZRKTIAdwORtPHFMTT/MyVBJAICkZwP8mqwvVmR4mOHjUq2Qdoxx1rY06UxSgNtyVywByMHBre2mm558oxaSprXqMW1lw8RQlf4sg5/A9qkWxiBdijKwH3flP8x/nmu/ghinyTHHkkA8ZJLMAD07kgfjUs9jGgdfKDIe6rzjvXJFp/Fuj15KUFanqkcHaQKpLqQMDBx257+/Sumsp2ilJIRlIATa3zZ6nNOt7OCIf6vcCAPmXJXOKvCyhI+QkMDk8YFbKsrXexF5NJ9TXt5iFVyAT1J9B7mul0+9hddpbGwAFe5964mJJUQBkJj6AgE/5zTobja+AGU4JC45IHFRUk+VN9RSlLc9c029WORGLrtBIUDuemDXuHhecSzRJgOXACnOduP8+/SvmXRZZVVXeNZQ5DAA/jyPpX0F4Ju1N5bMLiOOQnCEnciHoM8fhTtKVO0Njx68pRT8z9R/2X/Cxu9Xg1O4kCQ6dmcRrFzOSrDAf25yBRXr37OItE03TpiirHe24SaWDKxK6owJ6/dJJ5I6tRXE5VIJRieYlGTdmfzu28+YwHBYqowT69+1bUDSOh4KqRggg/pxXPWzxyRKqKSTgNn5cdT1xj/IrprMySq8YG0jBJI4IJ5PT8fwr7fmUneT94+ChBRbS2HwyMnA3sF9yw9hk/54q2r733KAWAw4DYHGcY/WoYATncpxGdo2ggNjIyf1rZgiG3ftAAwAI1G5x3znA/OtpzfJzPcyjHWy2M5mWQNmNQwHzZH1rltSLCQKgwSpAcDI5wRk/rXYXrEIfKHTr8uGPb8f/rV55qk8jMysjbTjgqTk/WuOpONlJrVnZThztJGI6kFiXJb8yfwqOdSAF3qVHHqQTQTtQbgc9CByaiZ8LsLZBwdozXmzbuz3qVDkirlQxrtIZw/y5DA8VnTgoDtLMSegxznir0krthRGAAOcDGRx3/Cs+Z2ZgABkHqOmOO9ccrN2PQcU3aJiQWw5mkUtt6AHDHPXOeAOvUis248qS5EZOQBkAdD0xxXQZdMk/dPC8kdjWBGGl1EuchkiCFjuO4AkjjoOWbJrbmUaljy401axia9aSLZXDfJs8kg7wONwwDz6bgfwr4L+O3hBbi2m12PIe3VjeLj/AFyoDggAckD0I4Tv2/RXXLYSWriSBZU2kfKPvqMjH86+c/FWiR3mn6jGLJppShwm5uVHVdvTlcjGOc124WvCk1PrcyqUJzvKNj8WdfsAlxcSmHBJKjzFBIG4nbjrwSeo7V+h/wDwTbEGm/FLUrRo2mTUvDMyxsVKrBJ5iOc8Y3bY8jPYmvmz4g+A2t9XvLyFZJrCSV7iNDEIjCgADqOBkhldiOSAa+mf2C7u2074yWWmkRRC+8O3cdvITtkeUMpIYH+LG8D2r28RUhOhL0Z89RoVfrClbZo/bjVLjyp3cssao3ygHGe9YcutCTbiQnDYJPAbHpTfE1wyPImSwJ3bV4B5rzt7mVWVUDAhupyRzmvjoNvSZ+rYP3o3e51d5eRynzAxGRkYJA5GOlZpEjO5Dtgnn5ioP+IplsjuiOAx4ySRxn61qxxAA7yWz3UdP0qrqTcex3wlOVosxorZ5kWIyDoduF5A7c/56UuoWUrBYkJ2hQMclfatS2i8r58A+u44yBmrJkUMOAc+nT9P881ryxUnc4YxbWpxk2ksqgumWAwCOh69D0qSKwjjG5wGyAShOD7iupmYMSGChc7RtzgZJ5z2rCu3MZcnaqLzkHcTXJUVpabHXGHMrszNTkuDA+yHarDCNyevv61xt/OsIJclQcFsDqT9a6C81HeTGkhEYbO3OFNeReL9fjsUeIfNICHBHCD15oTT0id3Io01Jbs6SS9a6lEMEoRQRuOc4B6DB/zxXpej2RuIEUSAbQGLbcDpgYx9K+fPCt3qHiK8EdlaspgUbiWG1z656fhX1XptlJp+lW/nQqbn7PztG1WbHALE+vGamUp6J7HTOMJaRvzdTrPCjiCeATHKqwAyQFbt0xX0ZomoWttdW8s7uqZBKxn5zyPb/Oa+ZdDkkS4SdAEaM+Y0bPkRnn8PXnGetdNP4ruLeUSO8Z2ZUbDtxjkYx1rb3OZx6mSg4xWmh9veI9Tt59Ittt0DAABtwASFHHGeK8ovNShIEUUifMCASfu56Z9P/r14K3xKvbu3Ft57CMMOM43c9OtA8UmcBTKqIDuKkdOtVfl93oY+zp8zvt0J/FMqvdSeYwkLsW4UDsB1/D9a8C8RWEtsZJkSRly2Co3EgDivU9R1ATTqWJJY5DD7g9s/561ci0n+1YzbmNAzAPG4yT0I4Y8g+wyOawfLJ2ZHsWnzM+EZNZjt7plZDiVyjEj5kOemMfX8q7fRb+GVFbKt82RyCD2rB+OPga/8EvH4jRZJdKlugl4+3yzDvJALY7buMnpmuB8MeII7nabZn8ongfxAjqP/AB4c+9egrctonHSs1eR9TWl1DBsZGxK3Jx1TH/666i2mSQAuwKEEAHjB5weB7mvJdHllKbpN2OFjYnOQM121gZGZJB5ny87cMEPOe1cjpKK53uz26iTailsdBcafHgvGxUf3QN3XPSmRWk0agovTkjGCP0q5E4C4fBG0Nt6jt2rQjnjDKuSAww5A6+1RyzjrI8+qlLQqwW9w6EGJtgbGWXjp/wDXqhcQrHOSiv6fMAvp0HPfNdokwKKDGGXbszk/KcYGcf54qVNMiuGZgqluGXaMj3oV7XZw1Oam/dvqc/payxJ1OD1UkdDn/wCtXsvgpJftELup+8OFO3rkmuMsdGdtwCnKg5HUD3PtXtngHw7LNcxLIyYLhioBYgd/rjNaxneKsediJ3VmtT9ZP2frxl8FackYkUQMyLuJLsp5yB1wT3oqL4OeXYaLb28L+ZLDCFIYCNSPUL09fpxRWfI5+80cDjLmdmfA+i/8ExP2vZGuI5vhpYWBtiUZbrxXprC5PP8AqmWYqRx1zj3rprP/AIJi/tbvtA+HemWxkw4N34y0gRLx0IW5Lg8+n5V+nHhT/grF4B8Z393puhfA74s3V1p0uzUFjOnXS2w5IOYpnByBkZwCO9dBqH/BT/wjp1/a6ZN8C/i19uvH8u3ttunidycAAp5pIzkYHWv1+lS9tFOhSjZet/8A0pH4/N1Kb552/r5n5mL/AMExP2t1XY/grw6m5gjGDxlp0iKCSCx3Sjjvxk+xq7J/wTB/aziOE8LeF7uIpuJg8YWkUgOThcSFef0561+nmtf8FM/Duhy6dFc/BH4iO9+N3lR6hYG5h6ZzEGLd++Oo9ao3H/BUbwda2k11P8FviRGYmA8h7qwSdge4Qvu/IHtV+yxTV/Zxv/XTmPUli7u7f4f8E/MiT/gmP+1oscd0/g7QzDEWEthF4t01rycYYLg+bjqVPDdiK8G+JX7Bf7VvgizudT1P4Oa1f2cKmSd/DWo2PiiWJACSxitJZXGNhzuxjj1Fftlbf8FQ/CN5bm4h+C3xDij8jzlk1DUNP023fgEhZJHGT1+6DnH5efXH/BWXSdUknsPCvwQ1+fUI45PNk1fxVbW9naspAViY4X3jr8uVJ7GuerhKtWlyVoKyvtp09WbUcwlTnf8AT/gn80YwwmjkilguYJnt7i1uUMN1bPGxVkkjPKsCpyD0qpNCu0g4xt3Lj5h9fzHSvcfjDM/iDxp448aPaw6RqOu61deINU0tZcW6C4mLs8HGCQ24uBg8NxxXhcm/aHXa6nq4bkg18HmOGlhqvJHY+uwNeMqSm97HOyZAbZgYIPoT3P8AWs6VgWCALtJ5C9Qa0ZYi4JHDDsSQx+nb864LW9dtdLI81JhMWAKKhcMCRz/6EPwrjlFJts5pTklzM7SeYiN3AO1TtI28Mc4zn0rL05jNeTGQjCBQgDbmyRg5x0HH61m2etR3sYA87YyghCh7jIOKtWMqpdrFiYibcokJ3KDhjhjnIz0GB6fjxxUrNzPbpyU25M2byO4mt5oFkA4Zot5wpO35Qw+veuA1XRWxcSKMjacsOWXbk8duMV6DMrKDGhJz90MSx59zVa9t8WMisDukBUbSHA3AjoR7iqhKSeiNKik3rsfI3inwFp9yk0jWyS75GcxbFJ3sTkjjoeh9fevLvg14YPgD44aL4oy0VnLq6WlzbBAItPSULGoj6fefbnI/iNfaD6AiCNVVwCOGYbhjJIHU9OnrxXmmveCLq81eK6tFeG4t7qCcOEKb3idJY3XjnBVee5BrshXkoNzd07mfs+WV/M+zdbvEmlR1BdHAw+eOnHNczGyPcA4QL3+XPbFWpboXtnCyRFF8gHeMjOAF4z+PSqUIWMksNx5x3xwev6fnXFJqfu9jrwfLyXZvxOEjOAGLH1OCPp0rTtgskbOdmQRjI5H+fSsD7cBahiiZU/KvlnJ59eg609btGX5WKsTheCp/D/GsJae70PcopySR0El4kaE7TlVwABwcZphu0KAFeQMjGAefUVyDXLAsQuBu5PXn3NT+fJw27CEBSBjJHSjScV5Hor4lGG50MzxGDssjr2GAe/8ASuW1VisO35snjIxn1wf1q35wMYO5uV4YcqMdaxNRvFaJ1CnzAMrxx/8AWrSfv6zInzqfvbnDalfrB5isxjIU7cqfQ8k/lXzr4s1wTzzQI7jaCjebyF5PIOOnGfzr13xFdNIHDkgqc7cd/rj2rym70i3u76I3MIl8yaK3G9Qy5lkCDIxggFgTnIpR5LJ9TeXwpPdH158BvCFnb+FrDVLq2V7nUIFuZJnyM7h8gBPYLgV7L4lhtorZSAIti4UCTcmfy9q5Tw34gtdN0a3s/LjhSC3RIQnCjAAxtA4xXP8AiLxfDcwSRvOiKu5gJH247kCrcZqS5jNQt77W5jz+NH0+WSNFBUnaGBw5wcY5+pqpP4ujkR3ncRxj96753DGCTwOeO/0rxTUPEtrLc3SPcwZiY5JlA8vt1z/n1punXKXMnzXRZXB53Blx1AzWyhTjFT11Cdr2Tuex/wBuoyobW6jZJQHEq5AA/GtKDxUkK7WcZzg7e/0rxqe9FqojSTgD5GA+UVTi1BjJ80hzjOGUAflW6kua55t5cqUlp0t+p9DDxEk6jyyoJYcscMT9K9O8KauxeJbhw6svDEcL6AfT+lfGz+JbTTnSW9vVjRnwMtwM969S8MePdIJhIvojG6/KrTBXYgckDOayqUeZcyO+MZykodT6Z8a+HtK8Z6BqGj6jDHcW9zbNGTgOhJUgEcY64P4V+WFnYzeEdYv9FdJw2k372eZUKG5VWZUlwRna4UEHJ4Pev0RtfHEHkmCKVHWZN2C24oCPX8a+VfiFYxXniu51OIrvuLWGR4w2QcM4JYccnsfTNZRlOMm+pCpfb0v18i/oOqiaGPe4AYYOUIAP48dMV6bpl6qRH5sjGd2MjFeSWUPkhEXkEgZx93I7cV22msYQMkED5ssckY9BWd3F37nRyTpS549T0YXkkjq2diqflK5Xj6Z+lbUTLJESXOVwRg56jNcSt2WwoPGehBAz69K0Yb2ZQygDBweBgcdajlS0ex3VGm7s6KyuwojVmcjPLDknkg49a7LQb4PcvGdgUjcNy4Yc4/zxXlkF6rLHhlAXkgsMjrzXb6BIDcIyn5gOd3y5BI6c89K1ur2ifJVnUtZbH0HpNgbmTdCgAckn356cV9D/AA505vtUANisKsDEzMSx5BwwPucfnXmvw6toriW3ilUAbgGJ5K/59a+r/DmkW8N4vlq4ULhdgGPTH6n8qz5G0olVqid09z6B8ARm2t8KjKOADkYb5W980V0Pg+yigtN0hDPn92jEkYPGfTPzH3GKK7KeDjOPM/zPJq4uVGbhLf0/4J8L/wDBOb/go/8ADr9nPwlf/Cz4y+D7uPRr/Wn1nTviD4b0w6tqiPMAJYNThXM0kabcxSJuZQzKVI5H6/wf8FQv2K5DDLD47m/efKZT4Rv42iHfdmDOK/i5g8RSRoWRmUryR1yMdCP89K6jT/FIkG2ZY+Dk4zgn3GfavqsLjVTT01/rzPzCvhvaNW3uf2iyf8FKf2HpRvf4u6LKyEBkfwzqTSR56bi1sMZ+tVf+Hl37CtxObN/i7pklzji3/wCEI1u4X8ZVsTEPxf61/HX/AMJBa3ES5jLo7ASqyArgEEHGecdce1aEXiC0V2j+UAr/AHDuP4A/WtFmlFd2/T/gnq/Uqb91/mf2FSf8FIf2ETEYL74yeHoUIBFtceD9YuVOR0KpYsB2+9jrx3rMi/4KRf8ABP2KNoovi34aih+bEK/D3Woomz14/s/bz79c1/INHqccslwWXbFPgMoQDfg5y30qyuqpkIriVeGO4sUYgKOFJ46dsfSh5vQd07r5f8EKWW8sbQvb5I/qI+Iv7ZH/AAS78XaHrUep3XgTxHqGoWEpjW2+FWo2Op3bTRthRef2fG0TSBmUys4xuJLcV/NP4vtvC1n4n8Qp4OvReeFZtXubnw+qmZzp9q08hitmeQBnaNdo3Hg+/WuDcwMmSi7vNMgVQOW9Txj/APVT97sylcYx93OAPxx0rix2PhiIrkWvU2weF9lUfNfp1OjBjYKd2CDkLmvPviZGLXwjql/o+jW+o+IINjWpltzOZFLgMgCfvGPIwAcDJPse3jkgwruCfdcgZOR/WklWNj5ZbDEEgHHI6/oB19q+VdOSk2/hPsa1NtKK2PJvh9cT6vosM2o6VBZTrEkTMEZDNJ0ICsdw4289812KWEUN1vEaMrLkBmIZWByCPXPvWukYgwWycYAAXgDOB+VVLpkaVJ1BwowWwfYDit4yinzQWjPPhaHutkkcHnysfLVQD8xXAAz2FT3MMCowJyM8KRtwOc5PTjGaW2Iy2SzbzhsH5D17+1U7raA6MVZXwvJBAycYI+tKSka6OVupiXFkwXCZQZDI4JLrhg68+5UfUZrPvbVpJ4pVbYU28p8sgwwbAPTBAxj3rqTFvswcbgi5xuLsMcY5PT+Vc/KjSSBUQrs+Z35VQB056c5A/GtITd21v1ucTUW+WWyOtt5DLaqVK7lABXH3RnqB9M/jT0lCROkoBZzlW5Kr68Umn26vYPndgkqxWTDgDHIPXPPWqc8yAqpKllbaQV2g9B07muSonLVHtYOTenQuSXe2MpgOM4POO9UVu0yTkAA87R90/Wm3ckXljYAGYkAFcY/z61gzTDlQNhBByO+Mj+tcja2Z9fh3yaLc24z5u5Q+ATu3Kw/DJ7VeS68pGhZ0PO4BkAcH69f8muZs7qOJcyM7Pt4Y9uewx/nirEtwjckMr+hXYT2yB+P61tGTjozmhJqV3ubU14YIiy7W3HdwMt2x0NYWoXTSIzEbcAE7QATnt+lMZmySeVznBOMfpVOch4ydzbyfmyfl79O/6VDlG9j13Na1KhxmposrOHBG5uGxnjnvXG3tpMClxbloDDOk3nqucMpyP616iLSK4lLHBCnHI4POP61pXWkQG0aIR8eX024THfjFZwUJRujpmuaKcehzY8XEaerRb2dYwIzIxRn7YPtxXz18QvEfiHU5Uihn+yeU2XWC45ky3c9Dx7Vr6us9pqFwsLTQ7XdUjbBCdAeOfTIxjrXL3gFwFWQEkElmTDHv7fWuuMWuVnOql9JLU8008agjZuJDM8khJcvvznpk469a9AsNYuLQxF5mOMDHTbjjArDjtGMuxcgFsYIxjnjHvW/eaSiRQyNEpc5/i24PB/PrXc6nLpI8GGs+WJ20OuNLbBgxY5ycDJaue1TxBduc27MkyjuMnk4BNc/YXEtu0kUjMwAJHGQBntV5Lc3EygBSQpRHzggAk49CMkn/APXQmo69zpVCpFOVtDP1Ke+vXUyzuzMRlI2IjY9On69an02G5s545PM8t1+UtHMzNgjn1HXHeuqm0ryVGASRzgHgfSs+2huVuQY1xtcFlIyTjrXHUqNR5Oh63O4v3T2bRPFL6fp6b5GkJiCiTGZPrj25FaVo0mrRvcSMWaRsAScHAAwM/iPzrzdILiW2RoJJMLIAyMWRVweTt68fTmvSPDsbxWuZTuYksOcEZABzx7CspXUdtDmc7y5Uy6YjEFDgBs9cj/PrWhbSIGDMAdv8Bbrn/wDVUMxZlOVGM8jOeaYhAOAvzDktgbh+Z/QUNzlrZaHI1JtKJ0qTIR8oyP4eM7ccVftrjLMMkcYJbpWHBIhUl/kXkbV6kfSp0hZ5cxligGTg4I7fX0/wrNOUXdnVV9pTlZ2N9LiEyYV8MDg54LemP8nrXo3hO58y68o87VC56ZyQQP0ryqZlQRgMRkDaeSx4Peu38MySpdoqg/Oodi3BGD/9emmrnDObSdj7/wDhR5j4CIruqLmQ8SICcfLnuen0FfZOjqRJbyfIo2B22OCDg7TnH+7n8TXwz8MtSSGG280n5iNr7zIBgFcfmCfyr7V8JXUcscMqlHDKBt9fw/Go5+aXoc+I1nz9T6c8I6OdQtCyszyPEzIn8Q2rvO3rzhTRSaDdi00d53fyI4o3laRW2MoC5Jz9KK+ly/GU1h1F9PI+Mx0Knt+ZSSv3P5uY/gd4VkBdrnVlTrJGl8FXbyNu/ZvGfY/jW3D8CfCTIIlfV4ItpEYi1Ft8JPoWBzjJ4bI9q9xs9KjfbGIRuPLY5yfrXQ2+jBHUBSoJ3HanuK6Y007NnyN0npsfPtp+z54chZZINR8QFnbMiS3sUiHgYGPLwBx0XFb0H7OvhV7lXl1bX5JAvybbmBYwMYII8oj154PP419IW2kjCIIizOMKAvJ/CukstEZHLGIZI+QouSOuaVSFyaav8J88Qfs8eFxA4bUdfjwu0mG5iYL3z88bc9PyqGy/Z08IXMjk+IfFVvICFQRyWbLxnlgYSeeK+s10d5EdWQjcpyCM5P1o0fw2Ypp3njJU8Rlmwckjp+HFeZyW0k3c9+nJ312Pm8fs0+E5IEifxD4p8xV5eOW0QngDJPkDJ71aH7NHhTySF8Q+LFG4N5jyWu4kA/8ATE9fQccdK+vLXSVXZmPeynJOOfXr7VtjTYvLQPGHXJYIU+7zWcoST0bO5VGtI7HxTF+y14eiVJbfxf4kldyCIri3sWC9c5Pkgn+fvU0n7Lnh15g//CX+JYXC/KFSw28jn/lhnp7nt9a+zf7GWUK0UYx0K52lef8AP51cOkA7G8j5lbjgdKcqNSTtJ6Lz/wCAYc11zI+Jn/Zg0VrVYl8Wa7FIpOQYLS4kuSCT1aMADHoDwKzn/Zf0GVZYm8c63btgqsMumWs65wcEMIwSemMKeg4NferaFCxRngi3jodgLKO+1uoz04qvNoFsekKbucZH3TTVKSe/9fcYuorXlsfBNh+zZpjXcVg/jbUBtdoHc6bGolwHKyMdvBOVGAVzt684rWl/ZMtbh8Dx3qaKnyo66XakyjOeQVzxgCvq3WNKfTrtLxYoGjjlU3BbGI0ZlV2H+1tJx71r6dtuVOI9hJGAFyT+NYKlVi7xd/69D041YybUdkfGyfskyNAFXx/KEUERi40JC45IGfLkAPT2PIrJf9k2TzWUeOZCwU4P9jRxWxx6rln556EYr78tNPLjAUcDgN2/zmqM+kzx3DH5Tkc4bDY9gPwrujSk23c8X2javHY/MzxB8H9S8AyXiXniGHW7Z2MkZhtPsjQZGQrL0zhV59xXg2rLJFMdhZNpY4xk+or9PPjN4Tlm8N6peB4oXgUTrIYg4kkYiJAy9wxdF5zjr2Ffmp4wgNrcN5fmbQzA7tyY5/u5weveuKrSaV0fS5ZVuuXr/wAE5bzZmDlmOSSc87T6jHT/APXVU3R6zdSNuCcflTCzFVI6Y9wRgYqvJGrEknnGa8ic1B2e59xRhJxTZML1127SeDwAcq1a4uVeLoFZhjryfp/niuOEjRkgyHIJUZFX4b1kljDBzkHPVlGPfp+fpVyb5UaKVlZGwHC5Yg7uOoyTyM/lk0SBVRiOB646VSkmil+Vw3zIMbXMbDI/vDkH3HNQS3TBxHuBVhg7m3Dt1J5/OtYuy5TkhOpBO1rM1LJUZmA2gA8vwT19P6V20FlHcwtHJIxyB9xMsPQ/pXGWnlxHG0YJ4API9q6y1uJB8qAMMdyRUWukkejOSUjyTX/BcUeo3M02/bL+8GCGDc8t7V5XrXhmeJ5Ps6N5ZOUbZtPHrX1BfR/bW3vGSyIMhWYE4PfB5HPQ8e1YU+nQM3zxjGORGvJ7ciuhQlZROXklUso7ny3DpkaBGmysgbnHAyPSrGphUiTbulHV8cMnBz9frXrPijQZHkszaQJArz/vpTDu3KByOOR1yM15N4skeyMVpaJJKVb983+rcAkAk84PGcD3rWNF6Nno4KlKlze0WrXQ4plkZ8IpODxkEg9vSumtXaKOI+X5bYJJZcHPHaskadezwm4VWEaIZWLYR8Dnhc54/pTftcwkjyDGoGSzEkuD+VdMoJO7BU048zPQxsnt1Oxj8gQZUbzxg57Z5rZ0TQ/OneVIwPlKF2HzAdwPTPtVfw2Pt1rEBGs3lEeaSpHlDtkZ6dBXqmmKsDLGsG0bcthdn/1qwqUW0pwPNxNKT97oZa6RDFGVWPryGYcZq1bRiFzkBQWwCTwMA44/z0robuGKMgq25WODxwO+PfvWRIo3bVxjJIGMVjyte8tznp+5KVgWUMGXOWlOC2MAkkAAfj61Xkl2sN3J/jOc46d/8KjnmRsQqNhQDcSu3kjgA1WlBIXBJ4IOGyTjvisnB6qx61KtyK0d2aNvMGAbhlA6gZNa8NyhVsDoOg5Y54rlbN2XcpccqOvB6Yq+JzF8uSDkZIyRx3qU50/dZ5NRtvne7OlV4nkQs6HzJCAyEOwI6jI6c46/lXo/h8Fp0QfMEXKyEDg9lIzk/ljjmvK7JVk2uIlQud7KRhmIABOOOcAfgK9X0GUB1wiq0YB5ON3v19qp/DynNWg2rxPqTwbcyQRxFSqDdu2hhjtk47ccfhX2T8M555Lq3jkJ+zvHlCFO3ghjk5x0zx/Kvgfw1qZjMQwArMc7edp59v8AOa+2vg44urm2ZZgFjbfjJLEA9h9BUUrx22OavT0v1PsXxt4gtvDHwu8X6zIYUi03wtc3gZ2AQFYXPzH60V8l/t9eP4fh9+yf441BXeK5161j8P2UZH726e5kEbqoGSflLHjsO/QlfWZPh5Sw8p2Wr7Hxma16EcQoVHql0PA7DSg7KY0CuDtZyhIzgHr9CO/eu70/w40hjfDhyOuzaW59Opr6K8P/AAfkvYmzbxwApuWJ1C7gNvUAZ7fXivVdN+FFsrQWb2m+Un93tBAPIGAAAMcj86v2c6a12eh89z05O8tz4/stFFtKECbyylXDZXbng4P0z3FdNHpLGPCKB8vzEKD1/wD1V9iWXwKRXjZ7bKkk+WQGJO055A7cda6iL4C+cVH2OTDLgKI9pwV69v7p9evFafVmnpuc0Z2Vz4TaHYnkFQZZGwCFBY4PQCr+l6dJPGZBkDJBDKAFxwea6/8AbK+Ht/8ADT4OeKPEvh5107VbKBIoL7eC9szTKAUU/eIGOc4xnrX4raR4r+NktvMyfErxWFkYOc3wKIOcY+Tj7x4Ga4cZB0IKTdn5/ofqfAvh9m3HVKrLK6kFyW+K/V+SZ+2ltZQxRgGJS2MAtFnI9f8APrVmOxRsssZPH3gOAOOcflX422/jT4420RWL4i68jSAKZZmjuHABxlQyEbjz1GKjHxD+OsG1P+Fi+IZHB2k/ZLGN8EDGCsIHpXkxxdO1lufrL+jtxXJX9tTuvOX/AMiftAttDGihSBMDyCvylQBj8etTPaAIH3rjsByOT0r8Uz8UPjkmU/4WD4ieNxscTW1o8inOTtcw7hxxnOPapP8AhbvxmtAw/wCFia/IhGdklhYTvGBzw7QFvxJNT9cXXYmX0feLVe1Wl98v/kT9r4YMhRlTnJznJH1qOWGJlYBiHUE4KEKfTmvxHf42fGvgt8QtYMfQbNL06N14IHIg5/HNMj+P3xogXD/EDUZDuK/vtMssEcYxshU8YPfHPSlDGQ1T26F0vo8cXTk37al/4FJfnE/ZG90yzu7a4trseaksbLtC7gxwcAj6gVz2gLby3kmnKyC5txllXJOCMg56fh161+O9x+0P8a4Izjx/fSEKQvmaPYzKpBwMBoSB1ArnI/2gfi/Bd/bR4yuzeM3zyrZW1qkhwAC6xou4gKFGQQO3PNbLEJux5NbwC4tpO0p0rdPef/yJ+75tJLdizxnA6sAeO9VRGZ5JnjcOIgC4B+7kkfzB/Kvw9l/ac+PxiAt/iPqG4jhJdMsDCvPQnyC5GOOTSx/tKfHhWMqfEW4jLxhJcaJp5kbGTtDGE8AkkemfrmpV56J25UYv6P3GVOnz05Umn/ef+R+xni/w5b6/aC0vAjW0jgSRMBtkypAPPTGchhgg4Nflr8WPDw03XNStVS4WGC5eFDPEY2cA8MM9VOOG7461xMf7TX7QL58rxrAT94rcaPbSBwTwpbZkYBPTn3rStPHXibx3HdP4ouLbUNV2f6Xdxotos6jiICMZ+6MrnODx0rGpjVHRvQ8rHeEnFfDdOOYY6MOW7Wk3fRX25f1PGro+QyowdcsQS3SjaxUEEZ6Dcfw7V0eu2apNygWZJMbSOG4PP+fWufIbcBgkeoGR+PFefPkfwnPSqOL5JrXYyZ7XdIpBxIgyu0kqAwx0ztJwe/SplxGDnJJGAw4/H0q0nmQurbMMTlQw5AqKdi78j5jkj+6OeapxWxEHJ6paGSWZYkAYM2c9RkfhWbeXT+anzDGQMKCioOOv9ce1WLiQxocLuBXDgLyPpWTKYidzMVz8zEHk47H9apvl0OGyeh2cV7GkSkBGz91hy4461uWmqKihdxBIxuJyOleVTXyxsMyhUDYBLAH8u3SqbeNdMtFmaW7iKW8ZkZdwDtj+Ec4zSjUi0md8qNTnb6Ht9vebt580D5SvPJ/H/Gsy81rTdOV5LiaNFDbXZjtIJz/ga+a9d+O3hixtmk0/U4p50iYiFCM7gMjJP5fjXietfGg62yCcT7JD++CrtgAAwoUf5616VOonDlS2M6d4Ttf3bn0z4t+J/mXRhtIp2totyxMm3ErKcZPt0x9K8cufFct7dSSzbg5Ytl33DJ7AdcDivN4PFv2iVwGfy2BCxFSdwzxnNRXOomVsqHQ7iSCu79av2l1dbH2WHdOdkk7eR75pXiTTp4WgkWSNxGCDlWRj7D3ritY112uXSJoyEfbmMZZfbj+Vee2+sG3jaQyOXY7RmM/48dazbnU7NA3m3Lbm/eDYMsxz0xnqaIzT99na6cY6M9h0bxtfaTIJIZQ6MB5kJIAP1x06167o3xWs3SOLypRdOQpVuYVyePmr4+tvFljDFPDbwtdTlANsv8JGew5/yKqWfjB5HltbaynSYDH2jaQB04HbjnHFHNKonzbGGIpqMLR2P0Jg8a2N+8VskZaQgl5ZNqwpgZ59M8gVI9/DcxOyHypUBVyH3LnoCDjoa/O6bxhrumXKyxXVzMUPMJbDEZyMnv3rqtN+I/ji9jYRM8cM8ylQImZ8KcFQeOvH+TUzXLHmjpY+Fq0p1JNx+Z9l3t/Z2qGSe4SJicAyOBuY9gKdZXxuFZwu6NzhXT5gfoe3/wBevlO81DW7i6ga7dpnikEkaOTtV/UgHnr+td54d8Tajaq8F0ZGKPvJC4XnPBH515fO3Nym9WdUIxirwPdJN4miEchCtn8/c/8A6q1rVWcksC5wBtx179R9K4XS9Ue+e1EbYQkM4KZcc/d59sivSrKB8IQMZHzE8H6frWcUua7ZnOXNJvqbWmQSYJdicnCqf4ME9Pzr0LSUZGILAk9Bt5IHoe/WuXsLYDkgMpOVA4Iz3/WursUdpowqDcn3XJCk5Pqcccc1uqfMtiqk0rpbnsmgSoqoGyW3BwW2jGSSOPxP1r7O+DmoRieGP92wZwg3Nh1BDcDn618R6OxJiRiI2LBN+SGGOmMfUfmK+sPAF1baTpV9rd4WistDs3vri6ZhGnyoWbcf9kDPFaUqKb5ev/BOHFtKN1/Wh8k/8FW/jGl/L4E+Eq3Qkg063Pim9VDllmO6KBG5wAB5h7nJFFfkf+0n8XL74s/FXxf4yneeS3n1CTTdCU5EcNnA7LGwyM/Py3vnqetFfo+XYVUcHCKXQ/JszrKpjJykf6APh34WgKNtsVdjsZtmFH0PX1r1nQ/hQJphG8KBFKnLLuDFeRkY56Z6HmvobRtBtYY9xhChMheO+c5x+NdNbWUUJbYABnIIHze+TWjo803Oex4salNKx5vYfDKxgVjKkZcAIDgjaO+OOPTv1610cXgjTUUqsSElMZKgnPr0+ldwSWAAXj2FSYA6AD8KmMYOFlsdsqs9mfjp/wAFX/DsGkfs5TuF8ttb8Xado0QiAjD7rgTOCOpykDd/4j1r8HvDvhWGKwgLgBQuF8xA+eDk4xj16+lfvV/wWM1dbf4P/CTQSqsdc+LMc8gkXKCO00+5ZiG7NmZcdjX5MeE9KaSzsY7W0F5MyokECReZPI3IVVXuTjPHrmvguM8wo4WjDCwb5opyfa1n17/I/wBBvom5ZTxPCOLzGW6nNO+2jR5fYfCtNU0DXPEyXax23h+GK4uLQWzSy3HmEghXGAu0FW5ODn8/PbvRNNtgtwYJCGIQERyOilsAZABx1HXGK/Vfw5ZNpWhv8N5xogu/FOmXF3rp+wfbDbCa2kjiKOcLlWiGThj8p6ZBrwjQmg+H/ibWIPFthpl5LEjWqWMFrBf2cieaxjn2MApDhcbWA6HpyK/HsLxbH2tdSV2tvRf8HqftuGx/tq+JgoX5VeCUvijqrr3VbVNddNeqPivW/BwtdGsNYe1YxajO1tEfLbgoCTzjGMgrye3vXDyeGpJmVTYPnjIaEnA5OTwfX9a/Xzx98TvDNp4X0KyvdKtpbXX9Hzo1h/Y1qscOxI2+5t2oTvTABI44r548F+C/DFzYa1rvivVDK9xqogi8kXBa3M5LIAsYyzfMP7wUDnAHOGG42Tw9WvVoyVtvPfb06nLQzPEVKFWtiMPyqN7K972vptvofA3ij4XappFlDqV1aqtjcwwywyiNon3znasTIQGDggcY6OvArgLjwFfySWivasovh/owK5D/ADeX6+uPzr9FvjgfCr6YNEg1GZ9dV7a/tInsbhbQFVUoJJljaMZjJJViCAytgZBrkIPhpoyTaTqHie9EMtrYWlrYwW0zJFNdPPLL5RVVDHLPGNwIBHU9a56PGsqeF+s4hWlJu1k3te3VfN/gePTz2FHCe3xEdZN2VtfI/PbxZ8OdQ8NXCQ3qoftOZLeSBt8brtBI5weC2Og6V51L4VumczLDNIjH5o4YZJpH542hQT3r7S+M1jol3rkMdjeM8tkJbO4hdSI4W3KylQ3JLD+IZGFHPNcz8PJNP03VjFLFDJJeNDZiSRQy25aXarDdwOXGTxgCvosDxFiKuUvHunefK3a1tr/oevHEVqmV/X1T96zdnp3PnS6+Hetaatu80QeK7hE0KxRyu8S4GRJ8gUHJ6AnoeeKq23hOW8lMMMbs2AEUALlumP0/Wvsnxl4pk0ewnttRs3tbu4vZrHTgqHMwj5E3OeNoPrnA454878DaXcXOu2syxF4zMk1wxGYo1EiE7pCMDOcevOe1cmS8TV8VRqVsZBR5dmrtPXz/AKZw5PmNTGYeVTFU+W2zT3/4Y8Xh8NtFI1s0TmRCVbcMEHkH+td9oPgq7tL027XEEbS2yzshByEYMygkgf3ScD0613154cjj8Zara2MYCXGuFbQne8TPOsUhbedx2+bO4J7bW6Ace7aR8LYbq+1W7vdXhsSujx29tBE0TsyNFMJJHGQ4EbHIJ5xnPpU5vxTDAQpVJ2tPyb7dD0s8r4ZYJYeuk41E01a+6sfF3ibw/cJJFcSQx+TJAGSRSdxOOAOoIIGeuea82uLLyZnUllGSVPQg19fan4Ut1eXQopBM1mXht5zCYVBQj5lUjjIOMEf0r568SaF9jnljfLSRsVYnPK5GAB0Oc5r7XJcb9dwsa0GtUntbc/iTjXh2eRZlJ00/ZyfMna2+pw0kcbNkyklD/GjKwDAH7xXafwJqnJCzMx3BiDkAt0H0q/tRmOFCgHgdNv41AygFsZJPfoTj3ruqJqN4niUqyn7vYx5VwvzAEYyQDgN+deZa5NNHMxViFzwoUBQM8dO/+NetiJpI5DsDKoJbOMk+36/lXl2uW4a8cKxzuJAGMgDHB455yalSbsVzyqK0NjynUprmRtyvJkfKoR9u4EcnA/Af/rNcLf8Aha6v7adFklgikyd6HdLk16/d6dgo6LuB4IwS316Ugg8kbXXKv2x+X41b5eXsZJaXifImqfCHUbm5ie0cyoWP2md1KhFA64xjPFU4/A+o2M4j2PLarwk7KSGwPSvtuzsVkUoYhsHONnXjk/hitGfwrYXiRs6KgjBICxhRk1cK0oxshc0k7o+MtM0ZUuFAJL5ClTyoxn/HtXpVp4IgvAJWJLMMAjGB9eK9duvhdpTSm6gmnhmOGCR42Oc8sc9Cfals/Dd1ZEoJi3lnCqH2pjoNx9TitadRuKZ7GExMV8R5RL8NWkZWkuFS22jei/LIM49/cU5fhnYRMHBLDdlDKnmMD0/nXuX2WeOPZKsYAbK45J+nIpfs1w8n7gKAV5AQKoxnJ/8ArinOpJK8Uez7ahK84NfdqePWPw802yc3M1lBI6ncrmPqff1qbU/DUGx/sdskbO2XWKPg8fy/xr042F9JKsZDeVkD7uVXJwK6PTNAty8pnfzuBsG0KVPfJ5z/APWrF1Fzc0jlq4qjVi4QV9Ox846f8OrzVJFY27W6yEqJJIiRn2H1r1DS/AUOmW0aSsjTwjA2geWeep9+P0r1JrM/KtuiqqN8oxgjr/jWolrLsQkKvO1juHUf/rqqtaVe0mz5dwjB3lueUPo6um0wxqd2BIqgsp6/1/WsmTw43mNIkhQqMtgZyOvXrXtV3ZYi8xEG1U+YH7x9OK59bRnYl418wkhsLhWBPGeP51hazcludDqcvxbGRoEYiMa8bYVC5xkke/v3/CvaNPljmRCvGV6P8pbFed29kFk2siqRgYXAJxng8dM13dghUJGqjlSFJGABx3qqdpbnLUrXT5Uzq7ZSyqAQAPl5UlhXaadas7IQ4DkYU4OT1I+nauS0tGwoZN/zYYgFgc8GvVNHsvLKMuS0mOAM/TAr0aNnZHh1pyk+a2vXQ7XQ9GupvshixJKdsaRN3OB/+r8a8X/bS+Ot18LPhx/wr3wrcBfFPim3Y6osbFlsLdE/eu/fLFtqg9QT7g+xav440X4a+GtR8X+JLm3sotMgaS2ilJDSS7SUGOp55yPSvwK+L3xb174jePfEHirVbppk1W5cWcBJCWtvk7UCk9eck+uea+hyjBKpVVersunnfQ+cznMIRpuFN+91MzU9dvNXP2i6EKs0QUiICKMAADIHUdM0V5rcauEZVO8xk425IVc9aK+sdVJ2Z8XNTnLnvuf68MUaRgIvyjHOMAVKB8xCnjHXrRuBUjofT8aVAQSSCOO9RTlCTcoHBLm+0WxgYXPIGaU8An0opjuAG9QPpmoO0/FL/grzcx3Vp+z7oMoWRG8U6tq8ymPdhYrGJBk5wAS69vxr87/AFxb6NNp+pCNZJbRvtUCMeNyqcAdOuWH41/Rn8WfgF8HPjZd6dd/FHwjL4luNEhkt9KLazqWlJaiUqZAi288aktsXJOSQg7VwFp+wr+y5bSwXVr8NWhmgYSQu3inWJWQg7gcPdMOvPPrXynE3DM88k/ZTtK3K7vS3l2erP6Y8HPHrh3wy4LrcMZll9WrUqznNzg4JWkrJWbT0W769kfltqUy2Gqa1r/2WKS907wMt/AXO5NyNdyBc4BGc7OD0H5fONr4r01fFuoeLNb0JtdEpLTaQipeRuSiRxhVkG3auwt3OSTX9CWp/st/BjUbeeC68O6i0VzarY3CR+I9QjWeFclYmAmHyjJOOnJ9a4+0/Yn/Z/wBMMjaR4f1vS3lx5jQeJry63YJYcTvIBgnOAAK/NaPhJHCynD22rW9797LY/Q8B9JvhLD4etGrgq7lOPLGyirR10b57rfofhV8Q/iZpPiDS5dMuvhvf2FzdaUE0zVLiO0vn0iKZngSUc7oCpD8JyuMkDAwngXUtOsvDMtrLbTyPq99cXMchjQwW4ttOjlJOWJABiY8DOWJ9K/ZH4i/sbfAe40HWY7tvE9tK2jTRRqNaWZWVA8oTY6Fiu5zkKQf3h5FfzLfBf43eLPFfxh8VfDWfQifDWh3+q6foN/bWbN5MJurrT0uLlyCQXVPLJBAODmvms/8ADmrlOS1ZYeSkldyfN2XRP9D1eHfHDh/iK+U4ahUpyk1um99FrzPW/l5nv3xzn0/T7vwvp5F0J7m+/tKZ7dzG6xRwxIgZyVOxvMVmwccDpwK7i1htrrTHa5WS4uI/s32aS63meJ44YrgSqzDJz5keMZxtPOa5D4seH49S8caNrGs3CNpt7NaeFoYjMY0EZJeWUnPygqSCTj/Vjrwa9Ajl0+/htZtNkglEkR8ncxVmVD5TEKeSB5TLux0B5wTX4zj6tOnl9HDu7lFu/r19T9LzGvh5ZbQjG7bb1Phr4tw26eMfKhiSJYtOjkuJoY9nnyyvI2Hf+IhcHJyRvFX/AIe+DdE1G7Go6tdTmO0lSY2MLLCbnByAxb7y5HReTtIzUfxf0+bT/G11FOIZbm+so9UVoHLiGJnkto0JIDAgWu7HT5yBWV4HWc63Zfui/krNcuxUtsSKF3JLfw524ye5xX6nhW58HU1hari+Xddd9L9Ox9VQpSnwxTp0J2XLv9+mp6D8RNJ0Lx/p2oeK7eW/sh4cWUw2sjAhTADFMGQblO7Y5Dbt3zDnAxVXTc6b8Ob6OG58uZrGW+hmdcAEKoRiRkhMhc9sE1yOqyzpo+hx2lw9rZ6vPe3V40bfJcr9pcANxkgHGdvXAHPFd49vZ6zot3p9gXvYv+EXtrC5MNsxl82aSSOQKu0HARIu38fOK+Rw1LF4fArmleDd99Ek7/nc8jCYTFYTCpTleLfqkk+9luzk762Emk+DL21aSC9ine3vrzT2aEzMgM0J3qFJyCo/4Ea+iNL8OBru41GaW5lkltV02OSaTzbR42hR2xGcjAaWQHI5Kt15rxzX7O10E6P4VtWll1G3EWsy3DwB0hWVCnlPnPUqy4xlduflyAfoPRNQuhE9u0cUSw+ILKysZGXcZ1Vba6u15B6RtJFyOpxXDm9R1KVOcNm2dGYUp1KcJx2voeD/ABSs5bPxrc2VmgiSezhviQio0hkDJnb2H7oDIABwa8i+JegRabcWweaPF5YLPIhwzROVCs24nkMQ2BjgAZPTPsOuajcePfHkt1Hbn7PYb9Hmlj/dwJbWs8odw33Rklzu9XHpX5oftL/tX6FpfxPkj0OGTVfDlnAdPlS1ljE900EjIzRAgHbwzDnBJJHXJ/UeBaOa5hCjgMOtIK877JdNT8u8YM3yrKsgoUswcfrH2YprmfNp69b9FbqdvNBtkfaBHsXBBOM8/Ssok7mGRgngDr+NZXh7xxoPjjS7bWvDt+t9Y3cYckfLPbPjDRyr1V16FTzWlJKqFmkjdlC8FULbuOnFfpVXD1aEnTrqzXY/lmOMwtT+E38/Mo3t2YomVJWQldoK5jYZP/164+W0Msm8lyzHrnkfma3bsNNlyPlyMAHOP88VHEoc4IPAx8wx/npXO5KTszuhU5fci9TJNmFwvlrluMOODT/7Miz85j3AZIcfKvpjiuja1XO7IJ24wH5P6e9QCNPMYFQ27CjceeegH+e9cNTmhK8tmejGrK13sYUMMUaBAV35JGzaCf0zitYWzEbmII5IUjOP85pWtIm2SNFGWj3eWx6ruUhsduQSPxq9C8SMySKzkDhVHHB/z2rojUnsiIVLqz39BkdsoiDbssF/iOee4Ht/hWFcQxCSQ53MGyQVPHfk11FxFNMI5DtSMfu41yASQATx17frWdd28sNuTh2aTjpnqQK1hLlVn1O6nBuV4o468EcpXeoy3yBwOV+h7VnrbQoSRIFJH3SeD6Vqvbz4YlVxnGAoOP8ADp69qhEchGChI/vYJxWrfIlYUY1HqlYSz2OuQwQbsOSoXcR6810lpGio21iwbjOzDIfr0rAsElUOJEJQn5AAeldBa27KwchsbuQVyR+FKpLRNnHXjNu76m5bqWVmKMoHOQPnY57VJdTSR4UQkhhgtnJfB4rUsoWdgWUrsGAM8GtJrMOThFJIzs2ZDf5/pXFBKV5o6Zyv7qZgS2rtbK+MAgFkZcZ69f1rP+yM7lYxgKu4jBA+grt1s2mj8podmB8r8gDAPHA9qLLSyZcMjHI4IGc/jV86ilTl8jnk0lrucI9pK7xPgo6HO719QTXUaXAjOiNIDLsMmzByFyBkdutdJJo0QUDy1b5s/MApHOa17KyWHaqoucbSw9DXoU6aur7Hz9ao6SunoaWm2pCRlGAyR947RivXNG0uWK2huPKkm8sNPKqLu2hcnPHtmuAtUe1iknVVgiQeY80xCJgdTn065NL8JfipFrXj6LQbeM3HhmW3uIm1NIjKbi4RsFMZwExvwf8AZ/GvXy3AyxM3KmtOup5maZl9Xg3FXf8AwD8jf2z/ANqR/H3jm78C6TNLY+HPC0nlTWbkpJqc5yQ7qcFRgdCM4avhF/E00rbpH8uMk8IDI4+mOe3pX3P/AMFEP2dNF8D+PL74s+A7y31Twj4t1KRPEFvDdRyXHhjUmcK8U+G+VHJymQACCvPFfmw97BYnySUu2dNwkhIfy+2054z1r7PDQo0YKED4SriamIvOW7O3i1ktwCW2sQrAZDn7vIOO+KK86luLiRlYHAC/wjaQOx4orrMlTqLdH+z7VjIPQg1wtt8TPh1emFbLxt4Ru3nUNFHbeIrKaRtwyMASe/auhg1vSJmPlappsit8ylL2N8j8G9xXLSwuIheU42+//I8WWNw7ko86v5Nf5mjTADvY9eMcCo1uI5AGhkjkU/xIwYfpUijLFuhIHPr/AJzW8lVTurWOSFSE21F7FpgpXkkYOc4yK/nf+Kv/AAW517Tfjh46+H/wp+F+keJfCfgzX7vwpaareveTaprtxZzNDcToIiYxHuhkIUhSFIJY1/QVr9x9j0TVbv8A59rGS46Z+4pb+lf5mniSa58SeOPGuvvqusWJ1Dxvq2pK+k6jNp0gW4vp3xgMCoKkrg8/Mck8114PCqtTlVavbT8Dvr4tUasab6n9P+q/8F0viNp95Bp178I/C2mj5hqEt9HqgntsbTkbSEAAD7txGOueDX7rfsv/AB4i/aQ+C3g74uafp8Wmf2+lzFc2MbvLbLJbXU1qXiLANsfyQ67uQHwc4yf85R9HaKSe5i1/xMYRERJHeatc3kcpyPvJvYANgR8ADkZB5r/QC/4Jj+Hz4d/Yl+A9m8TRtc+Fn1EhgRvE+oXskbH3KFCfrWOLVKlGNlZs6qblOm5vY98+NMmlWXg3X9e1K1zqljotxFZX0cTsbRZAvmqCPlGQmDuyfTrX8XP/AATd8T3Xirxv8dPE11LPc27QHyBO+ZIUm1S7mHB6blIJAwc9q/sP/bb8QN4W/Zj+M+vwzra3GhfDTW9Ztp3fy0iks9KvLqMlu3zQLX8Y/wDwTCkg0vw78adXvBLCtxDYxq20yCb5JZnVfVizjaq8kdvXx85owrZJXhJatxS+e/4H6L4e4ihh8wqSqN3tH8z3C9/aAT4l3ep6X9mitH8I6/d2huYSAs7RzzwRsELEkiNMEtg8txXVW3xHuorqS9hX7K/9lJptkI2CvaAGcO8eCcbhIO+QQc9BXgvwz/Yw/bE+267rHh74Ja1rWlavq0+oW88Gq2cdy8Mk8kwc25l8w8TDqvJOK+jH/Zd/aA0q1WTW/hN4/wBLkIDkzeHbp0wD8w3KjDv14HIr8ZzbgHCYqq6vIpKX95b6X0t5H+g3B/EnAM8koYPEYyl7RKzi5xTV7XveXf8A4Y8r8ceIH8UaxLq7XBjuZNOi06JyFkSERmSRWKtkHDTPweoHarWleKo9G8P69plshiv9cihtk1NLeJZbONGLSBTj+MFlxjAzWrdfCr4h6azpd+DvFcADlUNx4bvolcZ4IPknvj2965u4+H/jOVmMfh3WZlUgYi02eVnz6KFyDkkc45xTp8Lung45bTpv2cel3/kfZPOOFPqsMJSxlPkWyVSG26+15lXXdbsL3SvD2laatzCugWUtnM8+0GdpZFkLLjk9DzgZrq/AHxAfwXJdzCzj1JrqJFWKSTyVj2ls/NgnkHHQ/hmuXbwF4tDywt4e1pJVTAjGkXTSE5IwVEZ5GCcf/Wqq/gXxfaB7ufSLq1t1BkllvYHshGi/ecq6ggDIGegLCuSfB9KWGlhalJyhLR6vvfpHQ7K+O4TqYT6vicXS5Ov7yG2/SR1k3jCTWvEtxruqQxW9vc3qSm2hwXigVow0YY9W2q2OnzNmvUb/AOLyG9kbTLGBLGysZYdPdIsXFzczQlWnlViNgBbkJ82VPLA5r52SfT7eS1s5D/aN5MNxttPR7p42CklSQu0HGepGBXoFtZxaZfeHtM1PQvEFvrfirVv7J0HTbnTEkEjhkjMlwwf5It0qEMOWAbgYOO2PhosRSpOVBqEdI+9bT9fuPzLiPxa8I8hoeylmEZzpqyhT9+Wzsvd7tWu36nrfwv8ADsGoeC/GGp6zbRvp+pxPo025ykl0JWDyHg/cYmQEnrjvmvzv/as+A3w41+wnNh4Y0jR9QFuVstT0mxjsr1ZFUKoJRQWxsH3gR9a/U3x3qq6Bb2PhfT4BZWWn2kcM8cA+zxvcH55iUXAb5zuJOfmYk818f/FvSI9R0ppiX3xxyMp8vzFb92xUAdix+X3yK/RcgyqnktJQo3vaz100P4k8SeMavHufVM1pQ5aF/cT+JRiuVL7le3S5/M5pnxs8X/s+/FjV9ASGO80mGcHV9OWQbbyHOFlIOAJsc5GOuCK/T/4c/GXw38UNDGreHdStprUBfOtidl7A7D7rITx0PXuK/Gf9sYyab8ePFMZJVBaQLFsHzDI53c8dAP8AgPevXP2FtUK6x4yhT5muYbaRGVVVITHufk4+8TITjnPrxXRnFKFTD+3+0tT4jKKv7+NF7M/X1b9HjWJAzORhn4A/wq/bRISxExLMMAEgD/PWvKrfV2txsO5ogAAzLiRiTznGRW7a6yokVhJ1wQCcZr42aU7H2sPcdonfKAo4znHIJO7Haodo3uGbl+FDkFTntj/PSqtvqMc0ZL/eI4IIy3WpYopJDu3M5xkgfqCP89Kfs5K9zppVUulzYJVECgjcOCAeT6cf41qWMKSyKzxoxHykgZbGeMn8axFEiyEkMCvUEYJHUZNdTp4GFIfgnB55Oa5I0+V8y2PfjLmba2NwaVZbRI6RHyh1AVypIHQj64OKJNPsmikUhRwAvIz3FNWfy1ITncMbcYI6HHHWp4U83c2SODyV46ZwOeo/rWqn7qsEKvs0nHc5d9ItixwAQRhiP4vr7/41Tl0PYw2KRG3XJBI59f8APSuim2RyyKWUAnBwMD8aSVI1XexySMrg8D2rSHK3d7nowxKnDmqbrp/TMCPR4Vi3napC9+B9P1q7BbxxuY0VGGMgjpnHOKes/wC8WMMNvRucrzzn3q3CgMoO9gxx1OIx0/E9xjp+NDUVsefVr+1pqNiaCEf6t4wq4wWGRn2z0/8A1VYPlo22Mb3GOhy2Mf8A1v1qdlKEM3I9uee9Rm38yXcp4YZORyKG4pXR5dR8ur6mza2Y8hAcMWAJVh6881tWenQwsbiTaqqejLtY4GcD9Pb+VUrCJTEom+UIuAGHP4flRqWtxWUDRRocv8qbW69Mk1nbndzjlD3Uo7FfVGDTqUclWYkrGmMZ9T+JFXLd44kd5Mqq/MS33Rjk4rg38QW1v5lxeTiGFGzJK5ysfXP/AOqvH/E/xKe/a5j029MWnQEqLlPkMnGTnv0IOPet6TfMreX5nFWhywc/J/kc/wDGn4632t3cfhDwq80NjZTmLVLuOMxPd7M/Ie4Xjp3r1H9kxJ5PEMTTNbpaW8i+WxuMyK7byVCYPy8n5iwOQBivzX+F/iafxX+0vqvw4vLi7u7PxddJNps8ahXtWWNpplwd2DtyuenyDj0/q1/Zt/Yj+F1x8P8A7Snhs2viCHTxdQau1zIGeXaXG/btJycdDx0r9KyFKlSftNnt82fm2dYunUmox/I/mk+LesLpv7VfxQ+FuuGDUvBPjzWsahb3zmWzgXULbz4Z4znCiMuAHHTrnjNfmt8RPA158PvHuveEdWXyGtLx5dIuHIVL6zaRhBLuwNxIBUn+9Gw65x9r/wDBQO2u/C37Y/ivT4ppLeKGysUDQkiQKsUajnP3lCg/Wv0E8B+Lv2YviN8EfAfhX9pD4aL4l1trRtN0vx/Y20R8SR/Ki+W98HinReBIFMjISfmXjn6KWFpzpKdn30/X+mcc66gldaH891zdG23RbEYofKDHO4YJB/zn1or9cfiJ/wAEzvAvjGc6j+zd8e/DljHds0kHgv4wZ0C7sSWLmGO/iik887nKqDGv3T8/BwVMMFUlHm/X/gGf1ui9b/gz+7Pwp+wn8BdQa0gtPjFq2sX+dkX2PV9KN4525JCom7PJ5ySMY6V19x/wTj+F6tFJpfxV8d6NIMlbyx1uOG4iIIOVlGMYPODnoOle0eCtA+DHhK4OraL4Rj0zUY4mxeoJ7p4wwIbbvZuSMj5RnBxnmvbdL8G/Dfxrpq3zWU13bTsVMEmoXunKzKTuZrfenOSeSpBzXsPiziCL5vrUvujb7uWx8TS4I4WqRaeFS06SmvxUz5b+FH7DV/8ADHx5ovjPTP2h/il4n0uwuTdz+Hdc1x7rSrxSjADYkgQjJQ/OrcL+I/QoSKoCFwMALnpWL4e0DSPC2k2ug6Daiy0uzLi2tvPkufK8yR5n+dyzHLux5J68cACuB+L+u+J/CfhiTXvDl/p8M9vcwW00OoWjXAb7RPHArIRIoypkB2kHPPI7/P5vnmMzOqquYT55RVk+WK0/7dUV+B9FkeSZdlcZ0MvhyRk725pS1/7ecrffY9Kn+zTQSW8rpJFPG0ci7uGVgVYcdMg1+ZEv/BG3/gnRfTTXs/wDM1zdyNPczn4ieJ0aaRjlnKjUAuSTngY9q7K5+MPx0IjFt4k8LfJuZ2ufDjNuBwRkLOAccjtmuU1L46ftJQR7rXxB4ATYuCT4VubjzScDp9sG3v0LZyOlebRzqthZNUajjffluvyOyWX06i5pxuzk/EP/AASN/wCCb3g61XxNc/Ba8sbfQ3F/Itr451+/afacBWjlu3JGWA2rivrz4f8Axb+H2heHdG8FfD/wX4sTw34S0yDRNK0/StDkmg021gQRwRjHYKmASedp5JzXxVqn7Q/7TLWywx6n8OLtkA+XUfDl4YpzxliFmbHr0P1rEi/aP/aRskkiurf4eXJlO9pbDRbyNEAUnAQyqSfy6+3LxGd1a0I89Rykv5rv7hUcLCnsreh6T/wU7+J0UH7BXx91iWw1HQZNR+HuqaRbWmtQC1uZTd2c1qQ0W7ONsjHGeQTX8UX/AATi+PGr+I/j74O+ENmLK90rxx4g07RdcjsoQ2kyeWyvLerIw3AxxKBgDaTAcnGMf1GftKW/xP8A2vvhT4y+CfxB1DT/AA54R8b6Yuj3eq+H4JjqemDzEZpYllJj3lA6jI4L5JIG0/nl+y3/AMEcvhv+zB8TdG+KWhfFjxzr99oolNrZaxptgrN50E8OVmhVShHmhs4JOCOM1nLG5ficulRxj/fdFZ2/U9GLxlDFe0w+ita/9WP6W9M1Ky0bTLb+xobCKeO1WJI4SE+6uArlTkAng9xmvR/A+uS6n9obWEjtpFTPkiUzxHDEH73XIwfxr8x/gH4C8R+ANb8UJaeIvH/xNvPEl4l3BpupTy6mNFUPI2Izu2Ip81R/CAFXgDmv1P8ABPwwuktVu/FLi2e4CyGws7g7owR92WYYIbLHOw4+UfMcmvLhRpqKp0/e87WDmkm5VNH5HjPxzs9En07StR/tEWIstWhkvI4o3VLmIzRBlZQM4A3cqBkZHeu0v/H37POl2yDVNa+HtpKiZSCWG0W7kDDcuIyu4kg5H+9nmvcbjwf4Wns5dObS7C7t5/luI7yCO8WcZziQuCW5APzZ5FfkR+2R8N/2ZfhXrS+IbrWdWbxdql0ZLjwdp2qiHSLddoRXaOLbKj7miIjDktkkrzmvawmWRqyUKja9LP8Ay+88atms6OlNvTza/XU9e+N/7U/wx0bwzqOh/B2w8P6p4tvo5LUeIpNDiGl+HVKbjOA64ml+ZQiKCgI3OcAK34h/FbxBa3c9/rPj7WNV1/VWO63a81gaRoIO0uRJEDt4O0/KrDHvivNfij8ZPBHg6HUr3UJX0qzkZ5tP0uSSQGd5CI5JJ2Dbj97AUFztRQAM8fln8R/2rbbUdQ1S8fRrLxehuGi0+HXXns9A0+AEgRw2TqdxOFJd8M5JJxwB7NDKHRVsPG8u79NthTzHF1HzSlo+mv8Anufqf8OviR8JrOY6xqviPw/4as7a8MgsLBFS31efGWyRE0kiLkhpCArMrHOBx758NEHxZ+MknijQvFlrqXhHwhox1YCxZHgEzBrWKFjHwP8AWPL+9y3y8DaDj+a7V/2r/Fc5S103wb4YMG5beG0hRrd4A5EflxnOxV+bAHTA6V+vXwW+P9/+z58ApF0rwtDc+OvGm3X9fMqBbTTwQkcVqpBDFVicbjgYOcdSRyYnC4qk7Vfi7XO6hX9pN8q0Pp74zai114puPLLoEmMUePlWT7uW5554/ADrXj3jW2P/AAjcplcO5gUgdNhZhg49v0xXzdoH7Yvhzxhq8qePY28L3v2lR9qWKW+0+YuCW5C5TacZGCORz2HXeO/2ifg7/YMvl+MILhZEaESQWdwYIXKnAZmQKpIDEbmxwK8OvSqRqLnWp61CdoqMj+Yz9u+wu7X9oLWpmAjg1HSYTGASWkaOSVXIxxj507/4Vf8A2L7+50fxl4gtzI5S90VLox9Y/MjkKq27JxlSRjjhPaov2x9ctPGPxNt/EWmDzrRbeewlnUBzd7JtySfKSOc9cnvjPbnfgXqY0vxfp00ghRGQRMSxR8MyIcgHkAMWwc8A8V5ubxTw0oPtp9x7uUpLHRaP2Us8X1tHLGFUvCHKFNyowJzwcjsKyZGurS4Ab54xkq+wjIHGP17Vj+FNZS4ggO75Wh38HKgAEgD+X4127xxXaBdwJbBUlQAMDFfnkW4vkkfplN3vG2iRWs/FEcLeWzMDnrg5BPXrXeWfiW23xKJTkjG8A7c+/wCXWvJb/TJ4kf5o3jz8rLhymOmOKo2moSwyqpTDLgMVGI+D1GP5AV1xvzWjqYKSb5enQ95ivUuSJDIoJPK9GNdLa6hFHGEDbTgAHHP1r5/h8RPGwYKY9p+bByTn8PeuptvESTqgVyjlcnPBJHf2zXRVSueTaTeh6y104cHzdpZs5B34rXF/IiALKdrA4Oegz2/SvJo/Etn5aJKxeUNjKsMVsw+I7YlUWXcjfcDEK/0x+H6UQ5OVQ6+ZspSirNHpbRZQyqxYZ5H3WGO9M8zeMB9y4PBO4VzT+IowhjD4U4J5yBx1FMj1i1hy6yli5y+0lh+XQfWuWc5aRZ7rvdo6RJoyyheG7npzzVtLqRWGw5GMcDIPA7VyQ1qxIdtkZfqrMSu3rTE1+3ebLTKEA+fkYUjv+VS1CWhSbku56PHO0ilpHGDwBtDAAVorKgCtEyk4wWA2/nXld1480azjXFynL7CxUsScHoQD+eK851b4m3KNLHYedDGJdySq4CzKOjdcjnPBHp0q5wTSi9Hcyi5xm3JaM961PxbZ6ZDI1wxxGCSFI7DJ7/r7ivFvE3xIDmc2M8Ut3JGHgiJ+RAeBn8s/WvDtc8V6lqE7mSWRUcYcAlWkLfe3H/CsS2gvr64WTAhhYCMzM21SM857nGM4FWotysc83JLXY79Nd1PxHfC1uxKsCJvmKHZaqQfvE5wSRnA68flwPjPV7LwvZXLgRxWMCGaYO4VYgAoLHPGOFGT7VtXuoJpEAWGdAQpkLgg7ieCSO3oAeeK+bPG8upfEy9sPh7pEks1/4iv47Aw2y/aHYO4GWxzwvzHB7cnmvWwFKVeoqcVZf8E8PMJqnQk723/I+vf+CZ3wLuviZ8aL74y31iLjSNIju49Iu5YTi8mnl2ltx6KsbOoIr+yD4WzWXhfwSsl6osCLYTNC3zbTyGycYxgDmvyn/Ym/Z8tfgt8O/COhRRukVjpaR3QQKY5S2wu0jY5PyZzn15xX3B8R/HtnYaBe2CXCxu8flrBvxIDtYqCo7fLnJ9K+zwlGVOdpeS3Pz7ETUpup1Z/G7/wUN8JT/E//AIKE+NtLsnEel6tfRR+fHJviiVHZp40YeixsAe9fU3jn9nnR9M/Z41fxFY3F9BD4f0RdQMDOZ1eJZIJJJgSNythCcZxgV5bIYPGn7RfxK8YvClxPF4surOIthvKjVpY/kbHVmQd+jN61+k9l4K1P4j/s9+J/B+nQ21xd+KfD97oM+nm+islUSW0kARZHXaMO33m4JA+lfZYetOmoxi7LT8z47EqM5+0qX8j8c/BPxlsvDdxp8M8F3N4ZjRMTIj3l1EOGDque2SxxjODgc0V9v+Fv+CXXxN1TTreTUPip8FdFvUJC6LeXd9czB0+UJKsUTx5IBOI8gbGyBwKK9mOJwVtZ6hKpK/urT0P7p4Nf0CPy7a60o27xyKrFpgGO3DqdyvznrgnPy817H4R17wKLYRpexabcmXfJbXWpbfNbaihgrPgDaigbT/CRjivE9P8AFKJGWl0i0ILApJPbjDAY9R14/wA4r1Lwze+Hbu6hur7RtJhvQ4isriOzRpl3kAlW25GSzDg9B9a+ScOa1zyo1KUJbn0TbtG0cUiPlGUMCTuzx614P+0jqAtPBFnZIuZNa8QWsCMTgJ9mLXmQO/8Ax749ea92tkUwoiqQFGBjvjIr5a/aku1Gn+ELLzQpk1W5vNgcK+6G28teP+3hh+NeBjOb2soy3X+R9NT5asVKmfBvxb+L1v8ACjRItcu9OvtZWe/tdMt9P00r9uupbq4ht0CBiF+UzBjk9Aa93tfhL8ftRtI7k/D/AEa2FxAsq2d74mtor2AOoOyReVDjoQDwc8nrXxN8bFj1zxr8AfC9zC17Br/xv0O1vbfy/NV7ZLq3a4z2wBgnOeFPHFftR8Xfj58IfgZ4fbX/AIl+OtE8MQHMVna3M5utUvZAHwkVnEGmcZQgsq7VwcsK4cPgVXjF2vJ/8MejKsqdNcx8RzfBD43rHJLP8PdPiYA+WkfiqwnZjzwBvX2xk15CtxrEPiPXvCHiHw63h7XvD0NvPeWstzDdiRLnd5TRyRsVbhSTz2q3cf8ABWTwDr13PpfgbUPCry2arHe6n4nttQ0m3kzkNNAHXy2jOMgiQnDLkDIr4++KP7bPw/svEPiTx9PrGgeJvEGtwWtndWGhTBQwtg0EHlqWAAG5ixLc5Y5649BZNe8HCSn+Hl0F9cVlKTVj680rw3qevzta6LYG+vywRLaHYJHyQvJYqqgdyzAAAknive9K+Ffw68JwWuo/GX4k+HNEUZaTR18QRaZYRYPyrNeblYnG0sqsFByMsOT/ADBfHP8A4KweKfB+najpPgq8h8PeJLiR44L7S76a3jsuN4wQSJMAMoDjbkAlSOD4l+z5rXiD9oPRNU+JHxV8TeKvF9/faxNDp9trut3FxY2KKUYtDEXMZDluy4XylAAOSfYwnDOIhD2mJVvmfP1c0ppuNHU/tX8LfHH9mjRIp9I+HvxJ+EXmPJ57Wmj+J7Bbi4dgPnkKuS7EDl2JPFWv+Fk3PiV5U0nxHot0srs1jJpzyTwooUH95IoIOGJyATwB3OB/Hb4rvtA8DKbHw3ommQ3MkAj/AOPWMSBlKnc0yrvJYbc4OOTgV5xpet/EKS4lk0HX9c8M311tENx4c1y601rZFGHXdGed23zCHB+9wfSpZRGnopP+vQ6aOKjVvJqx/Xz8YP2ln+CPw08Xar4u8U6Fb6mbaaw8O3cLpZym4dRHGib40DOp8yQ5+6iFiw4r+Tv40ftU+DrM6je6ReS/ED4hX+qXt/c+JdTkebTLeWR3kkMlw4BmkDFEzFuBIdiwwAcvxD8M9S8ZR2mqfEPxT4i8W3ltAIWfxPr99rSxsR0SN3KY+Yru2jhm7Zr8uvix4yS58Z6no2hARaT4auG0qI+X9m3yx/JMYogQFUHcnTJ2ZAAr6DKcBCFL2knds4sbifaz5afwruJ8Ste8Q/EjV5vE3i7V7i+jS5luLSCVjDp1mGVVCRwA7eAvDNk4bivDdc1GFovscRUFCc4I3vnjk49qzfFPi28sNwaaWaMjKwBwIFwMnjgEnPNedWutPqt20pwQV3Oi8IADgAde30716FScoN2Mac6k5J1LWWx778IPh6viXW9P1G7SNojqcVhpFrcF3i1C5Ykl3jVcFIFPncnqnY4r9RvidJFpXg6wsYYkcrZx21w8khimKhAXcMAf4lUbc9zX52/ssa14i134teE/Dmm6bZTaPp6G9vp5lht10mGESzDyTtyHmdBG+3kpMSewP6L/ABItZ9XuzYTKogjt1h8rIJblmJz7btvPZRxXk4iUnJKT0OeMkpX6M/PW8WaW6laOVZt8pTzEGGXAClSOOQcg/SuH8aTXk+h3entK8UO0h40DIJMjadwP4YPSvobxP4WtdEvpEtlJyS7FApXexyQGB56jr6V454+ik/sWYhCiBl86Uj7gLDA455O0fjXjVaMKiuz6+liOSEVD4WfnT490ye93iPMrxDKKqg9s/Lzjp0/+uK4jwai22uIZWYNACcB9mTgqBkdOufwr6I1qwnnF6YZCFUnymGNygBQOCOTkV4BbpNouvSrdMC6vksDywba3PTHX9BXzub0OWClBd/yPpsqqNVlOS7fmfpV8OvECXmnWbhgghgVQjuN4IAPJzyAGHNe9WMsjIsiyDarDAPIYHPTt2/Wvif4W6szR28EbM0UoUlThywfB4PbHHftX1voN8DGysgKnBCk/KPTHoOBX57WpKMuaK1ufp+GqRnCz7HXWU6XReKUAKwwBINikcEnJBHr71WuNIi8t5oNsgYFtwO0IA2OQQD+Y71BYlZC+FAHmbgAM4yMcf5710cIXDLlSANrKWGOQOCPow49DVzeqseZbTzODaGWEtx8o4Az8hrUtrqEAox2yDhQRjr0x611F1ZW7qoVeW+95a7u38qyn0NQfMOCw5UdMnsKL80b2LUpqKTJFb5gGIBPQA5IA6U5HR5QyMCY8gHI3LkFSP1PSnLaOpU7SQVCBfvAYpJ7DKnyw6SOCF2DcSTwOKzfwpHWlbWIjXc6ZjlnfG/Py8Nj61Rl1S7tzu3GSIHg9znPX8qkFs8MI+0lmk+6zbCCetUrllkR4hGwRlJBTk/QZ/wAaIK7szi505a7l6HVby4DNHKYzjl1AdxkEHg5H6dayZ754rjyGu5naQYWNckHrnd27Hr6VU0611BI5IwXO9sE4A2rzgfT/AAq4uiSPKJptikfKG4dsAcd/w/P8dVC10tzuUX8UEZ9zeRxplzITuOGYbhk9MVCxlnUIIGIzlpCCVXPQHsB7107WdlHFsnET5I/1gwCfT6Y7Vj319bxggBUIOCRFjgdOn9aaWiiy5zVrIqLp0CNvk2MQckcEH9frWFqeuR2KlFkjiWIMF2qAOTknn0/xrO13xJFYDO58sf3YUZ2+u79fyrxPxR4qjubaWS2kHmQIzyJLKpkfaMkAZIJ61UMPJuMY7XJr1oUYy51qkWte1y4upTb2c5dZmz5YYyK5JJzk89lGM8bfavSfgYt1pHiuPV7azTTtbjK29lqzR7/squcy7QcrkgLnr0FfIEGs6xdXsdtpyMbm9n8i1jhAMpeTK/LkEZ5PT0NfpV8JfCreHvDenR3UU95qLWokuLzUB5lyM5J3H7oJwcA84I96/R8ryqMaCqW1fn/wD8qzjOKk5+zg9H/Xc/Xz4A/tU3+m2kPhHxtqGmXsF1Ktpp3iCRVsZ4JHIRYplXapDMThupB5zxXf/ErxjPHa6rqjTK4gtZZpLl84jRY2IGPTAr8XPG3im80uFYbAHJkBwjlWUoQyurDoQQOgNfRPj79r74fR/AnWGvddz4wl8PyabJpd0pS+ll2mIOOqsHIBBBOd1erCjOlOzV1ofNzrqcb9T4H8G/E3wb4M1bW9R1y4uZNV8ReIbnUryO3tZJhbgzyEAlFbHLck1+sfwc8c+HPEGhaXdeGdatXjW08+SG0uEMoyFZhIgOeBgEEHGD3Ffzl6XfXbX0upXZkurm8uDcyl3Plw7zkhV7DkdK+r/h54hvPC93ZeIdB1W60fUbc/a7S8sIh5hkHLKVx84YbwUIwQe+a7uRpqNPbzOao4u86nxfgfqr4quP8AhFPFwuLeWVdL1ib7bDMJBKRK7M7wvG38PIZcDv2wKK89uPiFp/i/SLK7a6MmqwRJJfac0JjS4Uxxv51q5AWT5S2VzuVkYYAwXKmUoxfK9zKEZTjzR2P7X/D922oQ2yL4Ym1O0EQMtxaXdtbAHjkmWaPOf9kk17folppqS20iaRJCEKbc+Wvk/MBnAbGB1OCfunGa/O20+O3hy8uLfSdC8R6TDIs6x3M8+vLplnp0YIDvMoYSfKAwAVDzjpXk3xe/bG8X+DtVHhb4YazbX9ssJj1HxXfxpcWyMUDN9gDfO20kDzWwuRgA9alUq1Wbgo2dup89orOT0uftlqfifw74Z0xdT8Q63peh2BQObrVLyOziO4A8FmGevavzM/ab/aG+G+veIdPHhzxJBq1poFjd/b7xInttPinZo/3Zml29BDywBHQ9CCfyS8W/tBeJvFuuzS3954k+Iutw2vkLCJTe2NsET5I5JpXVUQ9T5QkK54XPB8S+JVh8U77QJdY1/RfFElhcwLcy+F7DQNUtvD0O53KPNcmGOSYEbcq6lQAgwepKeRSr1ObEytfotP8Agm0MzjQpqMEew/Gf9vNNAmhX4WTG+8f2bsNM1DR/Dya2NH3Mom2Syw5DBRnhhkryOMj8VPjz+0T8avHPxE8Qah4817XPGXjGzn/eal4p8U3OoiNHVZIoUiQFYhGu1WjA2gjC4AxX3j4O8B+J9Z8Oa/rOhaQ+k2Gi2775WshpNjNdSlUgi3MqkEtIpz1OCcGvEdG/Y78MXN5feIPG3jfU1mu7x9RvrHTTDDayvJK7hTNJE0zggnOOmcZPf6nLMDgsDFxUForJ7vz1Fi8xrVnyt/d/w+p+dF344+OV9by3OreN9D8HaM6iTVzpGiJIZggxxNMGcnhQMY5fGDwK4Hxn8eBZJBZWtyt+yWYD67e6i+q3t06jDsUbeQPlZsR7VXdgAZr9RfiN4f8AhlbabL4e0rwvpn9nQIbYQtZCUXA6NuypzuHUnlhnPWvkr/hm/wCEfifUrl5fCg0ud1Pkz6dcS24tNxJzFHu8tcZGPlxx0r0PrODSfutWPMTqp87e5+cwutc+JOv2OmorTXWqamq/aV4SFXUIzNIfugLuPSv6PPBeg6N8J/hH4V0WwlNq+kaYgKxyAK2VLgy4OSevX0q3/wAE0/8AgnD8HPEvxkTxDq0es67o/hdP7dmg1C43QyyqrJEjtGEwokaMlSDuEXUDFftx+0l+zL8APEGhXmkR+BNH0y8MLC2v9OhNndwOxAc7kHzAhjkNnH8OCAR4eJxmGdSNJt2PTgpu0mtz+bzUfEy+IfFLw+Z573F0VXynZkT5TnJJP93PA7175oz6bocFtFGgluzHln+9Jls53HnHJI/CsW++AHi/4PeI9buD4V8Qaro11P5tl4lt9Mn1DTo7bgRh5V3FcBgG+Uc9zXq/wy+EnxJ+JmtxW/gzwHrut5dDJcy2E9pZrhhvPnsoQAYGQxXgcVvOkpL3bcve4+dP3Tyv4q+NU8FfCT4heOb421umhaBNJAPmkU3Fwy2lkNpxyZ54BjI5ORX4JaC9/wCIL+a8lE97c305nkcK81zfXFw25jjBYksz9Rzkfh/Q5+3j+y98SdI+GegeBPENxpGlt498RJFdw6JetdzLFZqLtfNJiUDEgiY7d2GjX5uTXyn8KP2XvBfwaik1qdX1nxE0Bij1bULc7LWMrtZbeNmZVLjcrMBuOcZAJB78O4YfD3i07/PY8jmi5NPc/I7XPg/8UtennuNM8C67Np0PztNKbaxMgzyyLNMjsOc8Kc+tYug+BP7Bu5NK1WV21K/Cu1vHF5psEXzCRJhSo6MM5OWBGSBmv10+LGvW2h+G9Y1CIzwSR28kVikUG6aaeTckK8HcBl0BxjjPPSvz6i0y4s7aXU7xHS5vvnmn8truYsdz7XKqcYLEjcR7CrwzjiLzirGc6k4ytHY+yP2EfhTqet+P9ZtvCum3Os3sGibpNPsLJJdRkkuHReZOCFAWMkuQqqq81+rOs/sGftD6lNPfx6N4P023niLLDqmvznUxuUD5fKt3QHBxww+nNVf+CBlj593+0Jrl9brdS+bpNvY3k0GGiTdcKiKcDAAjKnHdK/oA8SyxSPPujV5FUhQwyo4wc96+ZzCvKji5QSV9D6vDU3OOj3P5Dfjr+yn8bvhvHcatr3ha31SxjG9p/C162piEoSWDRyxxOW2AthAQeBnNfnv8TLW4u/DWr21iskt8bZmjt1k+zSM8Zbaj7gu350C/NgDIr+y/4l6ImsQ3tpfWa3GnXDNGYmjLxMpyuD6cY9DzX5Qfto/s9/DjTvhT4q8c2HhzTrLXtOjF99us40tbo7ZUlwZIwshGFb5WYhj1BrjrYiU9WtRUsNUhFdl5n80a+CfHcugrrZ8I67Jpcsjn+1beKDUNPkVXaNnHlyNJt3I4yyjgZ9K+ZvG2lT2mp2t5JDLEjFo2Dx+XKHUgkOCM9NoH+7X9N/7Pvhq11L4E+CL8LDLHeW97LPCoVo4pBqF4Dnj+IZbkZ+cetfnL+3n8JfDuleG7vxZouk29hq2nTRG4ms4PKSePzo9wfAwzlMgHI6kHPFfNVG6jnGS2v+R9pllWUYqS+F29dz4F+GWrx/utisqq65I42jOBhv8AP0r7K8N3aMhCyMXxuYEjIBGR0JHrX58+E9XaxKuiuATvwRgt34/DH0xX2H4D1fzYYQxZjcgMS6gqmdoUE9eo/DNfF4+DUmnuff4CpJpcx9M2EzrGkgYZbByxJxn8a6BJUDADBLHLEqg38AZJAyeMVxGlSp5PI/iIJHOef/rV0iXT74wABGNuQy9ffoe2a8NxbilLofTe7y3ga8dyyqQQpOepTGM/WpzNn5CQS3IHUY7/ANKxoXWRTlj8o+UHoD7cU1bkiYkBi4GDkcY4PA/z0reMYpaHArJWkdHbqwI3NFsLDIGQ/Q5ye31FaLzRIchgW+oJH4jnv+lcguoyqzK0bbd3JLYBHNI+pBSQD1Pyle3NaQ5ZO3Y3i4xhqb120TRqp2tuPbmsx5Uc7AkY2jHA+f8AzxWE2sNEDJtJIXAycjJGDxjHr1rNbVpDK8m3huvy5B/StJ05SnzrqcM7WU5HUNcRLlYygYEqcY3cZ71nteACTBGCOA2Np9c8Vzc2qIhIywMzEA+U7jLc/NgcDPc8Vzd5qvlAhpmRiflGxgDkZODj6Uowtq0aOS5eY6K+1GCKQ+ay5UFt2Bt+vX3rzPXfEgIkMJwM5ErseAGA4598DPrXPa9q9xNcpLLPMUEP2doRGgT7zndwMkgMAAT29+fKNeuZbhTBuxvw5yxGMMGXocHlee1duGpyqPmt/VzmrYuFOF2Wte8V3V4DZ2xEruzLJIVykancMj346D6+leeXcIhjlmvJyTlmWNGwGOCMY6k8EYHPNdVYafHEk15dTrDFbQmaXchZkCruOB3ODkDua6z4KfBrx5+1P4y/4RT4VWE1raWEn2jxBrmrQM0NhBuAGWAK73zhVPPX0r6zLcvlTSxNVJX8/P0Pic8zhzk6FPTz+R0PwH+HkOs6kni28sJIoraTbpclxja7N1kVccdQA314r78gnitLGSFIwCcKXQghMAEdsjhh+dejQfsT/GH4UeGLWyvrWw8VWUNu3myeGHnl1KzTAyTE0afMiF2wrFiUwBzXmEmk3KOsf7xrQuA0sqHZJhgG3ZOS2FPXJJHNfY01Hk/d7HxU2nO73ON8QWLyxtdyMjQOzCF5GGEO7kYPPGO4r4R+Mlt5urQSKN9sJUgmdObMOMEJnoSTkDpnB9q/S61+CnxK+K2owWPgTw7eazEyk3t3co1jpUDcKHEzDYOABgEk9q87/aT/AGP/AIl+APh3bR33hyCC/ufENpdG6bUYHtZJ94kWEOG34YK3LAfdx7iKdSDtpr1N8S4xnbqfm1ZweY8O6RBHuBkGQqsCc9fXnrXvvh/XND0+0iguruO0l81FhNzLttAWKA4PbrzgdqG/Zp+Mlhp8+onwgLyGzJeZNJ1WzuZ49rEMUiaVHfHX5FOfQV5r9ltrmZbHUojHeWj7pLGdWtZTglSp6Y6Z4PbgmuqDc1aBxSbb21PtbwRf3OovZvAS5YkRS206yQxgll++SvykZGACfmAxRXkXhDWJ/Dtkl1phFq9nA1xNbSyl1jAyxILE5yMYP+FFZ16M1U2+8qhWSppSWp9L/AHVdbvPH2nR3Nvr3i3U9x+yaXbCXVdX1udz5UcCRAkybi5+8CvygnkDH9Yf7Mv/AATp1v4meHbTxR+0RHe+DbNJEbTvh54f1QCURqA3+nXEY2/MTnZExwQDuGOfgj/gi9+yZLc2l1+0F4xtVt2uL5dM0FrqAP55SUCMwgg4QsFfe2CdwPAGR/TtB4hbSNONtbxhlCgBm+VTjjj36CvQzOslXcaOklZXPncPG1NJrQ8i0P4Afs/fBrw7BpXg/wCHvhnT7ixDPp17JpsGp39vNJ9+4E1yJGMp5O5iSSOcjiptN8C2niWVLq+gjltiNrJLBGscig4yURQvA6AACpryTVPEV+odGkiRsso579s+vtXrdisGl6eiyMI1igMkzEY2hF53A9sd68/nqOXO5Ny73MbQUFG2h+S3/BSHUdD8Iaf8P/hvoNhaWI1iWbxPrbWKCKdYLVWS2EhXAAaR92CDzED2Ffgl8UfFVpptvLbpcyAPE7AEqyjywDwCOSe2K+0P21fju3xN+NHxA8Q2d2t1pNhcHwz4Zkify0extCsW8EcjzXDueefM4r8fPiL4rvtR1KW3cyq0T4ALFRg4bAPoc/XmvSh7elh1zPff5kwp3qOKWiBNU+0zXM0hYxs26LdgHGQOccZJJP5fU+peE9JivbYzw7zdMu2OFV3hju4HrzxyOma8L0SxkuFi80OctxnDL3wP/wBdfeH7LPw/m8d/FHwN4S+ytJb33iCCXUZGkEcSwRBppQxwRjZExIwfvfnyOdaN5Rasz0Xyr3T94P2FvgpL8F/gdB4h1KBU8QeOIxqlzIw2usILGCMgjOACx/4Ga6XxZJPrGsPG8m8CQjAAO4kj5gDxngV9EeKJ5NK0XTdJtX8uz0uxjsYYInwoRIwirgYyF2/T+njWi6ZLq2rq3kM+ZduQpxycdfXA/OvOvKU3OJSaWrPcPhV8OdHfTopLzTrSSTYG23cAmETEk5G4n0J2jgZ4Fer6slpoVm1ppdtBZfxEWkawgn1wB14/DNaHhKzi0vRI1cRwBY/m6hgQWwefbHfvWfr5tpwZCV2nq2eApxknNXOp0b0MvZxnL3UfiJ+33q9vrXxF8F+H5oWkXQtDm1iSXed5ku2WPAOODtiY5/2q/Nnx3qcewWaovkQKqREqoIORxnnjJxk8k9a+x/2rfEtv4h+JvjzWJLm2Uafqsvh3RmtnV99rZDyVk692jLgr1DHjivzQ8UeInkupYWmmmXeSGZ2Ytz647YGK9CnCSw8YFP2ftJJ7o8g8f/D7xn8SLzR/Dnhi40iziuNUVtTv9T3NHaWq5LmJQpLSkhQvAXBOWGBn7I+Hvwm8LeAPC1pof9kw3t8qLNqOq3EX2q91Kcgb5G4OR0RUwQqoqgYFch8K0gmea+uos+QqrHuUGSSRscAHAx84Oc9K/T/9lr4c+E/El5YeP/ibeJceG9K1IR6L4L06L7XeeJrxZDHGkqhQzQh1bdjIPlYz1roeJdCio32/4c5adKUqj5T3b9iH4TT/AAw8Da94puPD50K88eTxXltHJYJp3m2UO6OzLKoAO/8AeShj8xFwOAMV9Z6h9ito573VLm1s4ip3z3NysESDPOSSOM+nqK5bxV8TvGPi4afdXFzo3wu8NWlr9lsbPUbT+1tSkRX8tPs+mxRggGNeGkJChSdhB+X5G+Mf7QXwu8J3ML6vqdr4kubGRvLPie6jvZQ/7sN9n06NiBGxCkNJ5WMdCOR5NerLEVHVqbs9DB4eo3yrpb8z2nxJ448GM01vbNea2BI0Uj6Xpc93bEj5SgdlUN1PKZHHB6V+fv7VElh41+DPxM0MwX2mxSaFLIPtli1tdROiO8b7cn5VcRk59Dnqa8U8fft3asLu+g0DSNS1TT7e8P2K91HU5NDiBTutnbOIwgIBXLE9Dx3+QvHP7dNhqmmaxoGqeEdajl1qMxO+ka+8ltEWYF5JTJ5TDO1+hO7PII6+VVg3JJdD6uKST5jm/wBjfxK138PL/wAITzkTeHLqSSCOQguIZJG3AHkEK+4g+jj8eu+JnhXQfE0WoaNr8Fjqlhq8X2WW0uoVKzgqHKlDg5BXIIx90d6+eP2ctejsviXaWVk8Ulpq808LIJRJFbwSWrgRswJAPmRptHPzSe4rQ/bG8Wav4N8S/C6/0ewa8hTxDcavrNrC/wBnkubaygQtsfgbwsjkDoSMEc15+LVqza2f9MnDtU6fkfkL8fvhNL8D/iHFpFowk8Ia4rXHhuYkl7Z4xme1djjhMMygFvkkUcdK6jwRrFvLAgV0V4woxHtQyZ78DPGMfh719o/tE+HNK+PlhY6XpcN5o+uaXpb+I7R9V077JLau0KfZVcspZo2LuHC8DDDPPP5f6DrV7o8mzakc0bm2mSU48koSrEAjPXPYdjXgYzDurFStofX5TXpygqc+mq+8/QHRtQCWyli2W5AXGBkDk+/H6CuwjlVo1fJbHUM2McED+lfN3hXxpbzQ28dw0YkdDhVbczEFsE/hg17RpOrRTY5BBBJxggD/AD6//q8GpTcbp7H28KsZxjKDOmhnO0EtyWyNp696vwXigs0iDIOAxyGGPbODWOk0IUiEh+eFBPX6/hUM0hU7sMF/i25wSSD2xx0rSMLN8h5sWpTfNude9xCwOzkgZB3gL6d/zqlNCvzkSKxxu4I2jrwDXKTXsh2s29TkMBuJBx0BHTt39apXGrNbbVd94kUkghWwBjvj3H51koXWm56U5cquzdnTZHuMhKnhkYBh3yeneqMtyqxu289cAk7WHbof88Vyk3iJBAzbVV1GTkEcAjJ4PUjPXIrnLrxRJ5bqsiMJFz93k9R39we3etOWUppW2PLnWhZXWx0F1cyImY5gzg4ySO/P6A1yupXqxsBM5aTBxk4Kn8B3/pXL33iZxkny+flTL5MZxjPXHbvXE33iVpfPLKxdE3HuWbngdOOn512xpTSSS3OSVWL9+R2Gq3yT4RWOVY4OflyOP8/SmeCfAHiX4heKrDR9LhLSXpIe4nQyafYwofnmfB7BuB1Yn6mrPwv8Ea18R9XsooLa7i0hLwR6hqRgd4EReHSKTBBk5TgE4BzX3x4y1nwz+zp8NLa18GWNtdeMNevV0izMCfb9TgiYEmSTgszKegwASw4IFexluE5F+9Wq2/4Pkceb5gm3Spv3j5c+IXwxtJNetPhX4a0ybUjHb266vf2MuzULm4IG8KuDk7SuRg9enFf0FfsUfBP4WfAT4f2Hh/TpNM0XXdZijv8AWpbi5VrwyyISgfcQxOA3Psfavwt+B/xZ8IeBfiho+tfFHS9Y1nUdRha80cWW19RtLwH5ZrhA3zh0J46KcHjBB/YDQf2xfhIEtbnXPB+oLarblP7Z1bQLbWGhVW/iiG6XABzlQQc98ce5LEuSVOeyPhG01rufq83gWHUdPS803UraRHG5MsJRJkY3AgHg5wMjvXzrc/sA+C/GHjZPGGvSXtihmW51DRdOuEXTtYlUkmWVVXgsdu7aVDEHI5Ncz8M/2qP2dPGlrHcfDL4teGdKvJdguLOPxAdLmt5flJjl0y5KhCQgGfLUsF74yPu/SfH9zqMNjNoqaNrAuIk8xpL5IFui21Q0RQso3fMeex6VcKrTvSejG6ULaIztN+D+jeGLOGw0HSYLOwgTaIooth+UAZPPPbqa/P8A/wCChPg+/t/gm2rPbjy7TxTZuqhS0rFW2rx/wI+1fqfpPjG3V7uLWNGvNKuYVPmKoXUrIgNkMk0ROc+hUNwcgYOPjL/goXLp+v8A7N2t/wBjXtubhtUspYJg6gKouYgxOenGRz05rqjVTfK9zOUarm+XY/G3wRuciW+cpE2JI0Mm88ndtPXIPCnOOteT/FX4JeDfF00s13pCWGoXBMsGs6cTbXmSvDjacE56hh/COua7DSNWeyghIjMyJGAGzuJABXOfwBrpdR1/T9RtRE0xjmiVW2yJJGT0PDFdhHY4Oevpx6HtZwSlDc8OtTgqj5T89/FXwO8QeEIHuNNe68WaRsZJEWBLfVrVQAcNEgCypjI3L8xIIKd6K+7VvEgMLzJHNbi8EE+XKtBGzgGQKBufkgbRnrk4AJorohjarjeok39xtGlNx9zY/sM+Fvgqw8KfDL4beGtGIsNJ0TTIJIbayiFtHKBCyoSOezAn3Nes6trEjeRDbJJJLt2lSd+cY5wBz0/Wvxo1/wD4KBXVtNc3fgTSLi+gNjFZ2F34lu5LXSLJIo0/1VohViSxYFiFPyD1wNT4Rf8ABRzx1Je3TeKvA2i6tLasPKuLHUX062XjPIdXJB7c8etRKlXm3Nrr1PIhZQSWx+53hGwuobSO6uY4yZE3hGjG/jjJHavB/wBtDxxP4D/Z6+JOuaXJPDq0+gPplgYc4ilunjtkce4acY98Cvzov/8Agqb4vGpG1t/h9pMtqXMbw2urSQyq2CDiYxsrAYIJ2jpX5Vf8FQf+Cpfjo+CLT4a+HbPR9A1bW/M165jtrqTWb+yijD/ZTJEUEYbLGVc5GYlO0hhiMPhK1XEKDWu51VGuTmex83+N9QvbWKWe6v1YS7mlZkVEy+edwHqQBgCvizWNUudR8S3CW06ThZBumOSiAqoweM9uOudw+tfm74q/a4+MlxeG5uPEMOojBiaK+hY206hmO1oUKqDkliVAPQZIAruvhx+1zY2dxG3jbQ7uadW3NeaMyvBOGVcERM27cDvJByMKD7V6uJnKM2qm/kcVFQa5j9WPCenxulssitJlFyqEh2IXkDpgn/PrX7yf8E0PhXpES678TdQW2VVjNloZvZE8+CUARTSpu6HZlMqQfmPJya/l88O/tXeHNShgPhjRdWvrieELZwTwpbRmQnbtbfh+vA2jnj1r9OfDHxI8bWfw80rSrrxDrmkXTWe+/h07U57eAvKTKVCA7fk8wKHUbjsHpXPJVZU+SOiZC0lzM/px8WalGVnIlWSJWZU2N5qnnjp9O3rWX4DmkbUdyqrBmH3lIzk+nbiv5rvhz+1L8W/hbqs7x+ItT8X6JHI6nw/4jvnvEZS3HlzuS6kYGOcYB65r9Y/2ff8AgoH8JvEFpYWnjiWXwT4gMS/aYrqOW4sJXAXPlzqhBHP8W0jB4IGTwypyi7WOiMYtabn7JGC8ubWNUn8tMDKoQM+2a8l+O3i1vh38LPGPijzxb3OnaX9m09mDSAXN4RbW+MdfnkX2Gc15tbftr/s6WUK+d45jv5QSsNnpVnLeT3BXqFyqqSACfvY4PNfib/wVl/4KeWOp+EPD/wANPhDaXtgt5cPqOta1rFtEt+jIWFskUSO6IRtaYMW3cp8oOdsUMPWrVPZ043f4fed0pxpLXc8E+LviBlmmub2S3hu52IeKSUb3kLHzCq7snmQ+/rzXxvqd/wCbPIyzQzBv3rGOXAjTqDj068+lfi/8Uvid4t8U65eahq3iPWdYuWutsct9fyyyRqVQt5YZyAOeoHJFeh/sv2fjj4kfGTwz4WXxN4nu/DdrDJfeLY7nUp5rCPToF3eTI27btkYIiqwI3BO1ejiKVWnGKk1p/kRTjGVz9irfxLd6N4YtoNOu7aLVblfssErsfLh3F8zOT1IGeccEZ7Yr9M/hR+1R8Hv2e/gR4G0XWNVsdS+KniDTZdQTT2kij8TEz3EpIFy3+ojbcyjDCXaq5TkMPx2+LniC38O+FPEmoaC9pYjRNFnuI1ntUt4oYLdJGmlWPAHG2bacYJUe9fiH4a+I/i74gfFm48S6lrU9yto8moaZp4nkFrCATHEm5gAw/eM27k5/CsMRGc6aSfqeThKb9q1FaI/q68fftNeNPGaGTUvGNnoVg6tmz0vVPIManBxPdM/mzOAMGRiMncdozivijx/8dvhp4ViuYJ9fk1G+urlmuhpiPqVy8hyzF2bBJBJJbJXrznNfmNeXl5eQSgm7YXQYSh76Z1TcBnaN2FJ7kAdKw9cgWO2gjZiZYYjs8wljtJz+pyPw5rgo0XC8W/1Ppp1oU6iUH959UeKf2p9At7CWLQdGvNWl2kG41ACxRDkH7oB3DGefYda+S/FH7TEkj3b6n4atVt1jdnmgvSJoV2gn5PLAJyDj61gyW5awkkXaGxlgx+8OPb6/lXhPxHis7fQdVu51ViLVkUgszZPyxKAP7zsinpgMeaylSUqnvndDEupdacp0umfE3W7bULDxt8PfHGsaYVvhqVq0N89sYHjcnZIiuOhQnGSOcjNfoN8QPj9P8YPAngjW9UtIJJNMtbmO71OWF4XmeWDypYyrMccwueTz0wQM1+MfwV8T6RF4p07w74pihl0bV7hdNiN5ElzZ28hLAK0ZUqAcgljxkY5JFfrV4S8It4c8JL4aLW13YyzvNESvlqsb/OEwOMAk+3PSrrYelJ87XvI89WUv3f4n6J+HfDa+KfCvg7Ub9k/tq08JJa3twkaxCcSxI5PBxtyF4wCCDwK+A/iN+yNN4w1rWNU0G+Ojavcr5ir5X2qwvZhvUNIh5GRjcy8nHatzQ/iR47+G/iHSriC8vzoUdqlhNpMV8slk9svDboiSu5VPBIJBA6Gvtj4aa3F8TNEk8VeH4ZlaGdLaVJIhCZMkM316sMcdPfFfPV4SdSUWtEe/hcS6Wsd/+CfhPqmk+Mfhn4pvfC3i/TJtL1mxmMiLKjC2vY8nbNbSHG5Djjrgda9q8JeNjI0MBkA+Xc8jtjOAcBT15r6x/bA0ax8S3lppGsaPJ/aGjW4lt76FUivLWVyr7fOGSEYYyvGcnI4GPz3hQaXcS20TOJIGChiux5MfxYHvkfhXkY7CuEFVS0f+R9Tl2ZVMTUlTurq3TzPs3RtZW7RWibd/CWDYFdINSRt0bICxHUnI9SOnevm3wr4mEKxwzO7tvBUbiw5//V19K9dg1ETKjJIOBnOMhq8OULRuj6OlVtouhp3EkjwmSRViOcABgMkdcAc45rkr+8Cl3eTJQcL165x39q6We6KQ7mAdGAB4zt65wPy6+leda3OZnLrG4VRzxgDp/n8q3j7ySOKVeDheW3oYWp6x8oVZCilthZuMjB5HP061xN/rbwqzC4OFO0l2wDx2yR1PFd/4P8B658TdeTw9pd5o+nSNhpLrU7sxvCgI3TLGOXCgZ4xk45Hb6z0/9mr4aeDrzTr55p9e160dbiW81edZbQOu7mO3XbEvzE9s/KOeor1MHlsqtva/meHjc3oU5csLv5f8E+E9H8NfEDxmYf8AhG/DGs6xbXRWSKeGIW1mBwrfPIwPBGCMV9ifDv8AY08TSx2/iDxzpWr6jK0AltPDlgpNix4YC5m4V2wpUIzBQc5zxX2HoXxI8NeF4kuL3RLNNK0oCS9vmle5uZ/JViz7ApJKjcdg+gFeyap+1T8Lrfw1r91p13qR1DSdLk1FbGHTmt94jQlSJXCxqCSozk4BPB6j6HD4elSgqcVotPPU8atmFbESutEfGmv+LB4D0G80HQtG0nTfEUCG0j0pYI47TTshUaWUoNryhkZcAkHywc18teI7zxNc6Xf3dlLLqnif7NM1pdyIs86XEjBd8OQVXCs+OwpfFPx08O32r614h168t9S1bU7x57iy0xvt5VlyqxIVyMAkjnoQa+dbz4keINU1PzrKS7sLFhn+zHuWwo37iWkQ4PC4Cjgc9etdroKEUnsjyazqud4b36n178J/gvcWATxL40luNT1u6AdLi/YTtbjALLG5xgHpnHOOgzXrHxQ8QR+FvCOt6qF2i00uRowBhUwpUYHbGVr5f8M/tMT+HrO0s/FUMl9YQYilu7ZQ15bgKQTtC/PjA6kE14l+0n+154Y1jwRqOgeGk1OfUNVQ2sc32N4IIUBQur5jwcggAcfezu+XBumoXemonUVnDqfOIkkgvBOjz21+JPtRvI7iXzQ7FiGLbvmOc/p9K+k/hb+1b8ffhbMjeCPjL4u0dImEiWV1q5u9M3ISARbSlo8YJGCCMA8V+cV5421W7YHMjbl24GN3OeA2Mjjj+tZ7a1eTybnTbtyykE+vauqNJNe6c3M4aVduh/UZ8F/+C1Pxg8OwWdj8WPCeleN4IdjT+KPD9x/wj1/OP+WiyW6/unI42hUQcHIOeP0H+I37ef7PH7TXwM8R+G9P1zT9D8V31kl3Do2vrBoWpXTZjlWEOX2OWKYyGzzzjBx/EFY+ItZtiktpqeoRhGKyWpu5EikwFO4Y78n06V6f4K+LPi3R7yZLrUhfadMu57PU1M4Rl2BSkh5/hHB45J60lTjFX6mdRuommrJn9DFhqd14fsTMbiTVtKRvtMMUmHvo0CjzFLHCsFCkrsY7scZrpdH8S+HvF9vdRwu8Vzbr5d1aXcZt5Y1ccEbuGU4ccHseK+Bf2bvjPbeP7a8tb/UL3To/D9tFDcaVdr9u0qSGQSENDOSzxldjNsAC5YcHkL9cS6dCTBe2Jhae+t2gsNRs5S1pMI958uQrnjd8u7BILAH0q1BVLTkctSEqTVN7I7jU4rjT5tNk0pw/k30IuFlugEWHcochSPm2jBwOcZx05K5S2u5p0NpIGF4FVmhKliELIu8Hpt3IwoqKlOHNZG6qr7T1+Z9zRTNLptoGjFtE8SkiVvLYc4PGM9c9q7vSpItLsZEt7olXIkZoz5fmEjHbr0A5rjooH1V43mVClvgRx5BY44IA7gg4x6U/Ub4WUPlAYVEYnjaEx6D/AA9K+ipuUYuUep8h7Nzdo9C3e6xb6XaXut3si21hpsMmpX85Td5UUas0jcewNfzYftJ/GDV/HnxN8deJRerdLc+I7iPTleX7VDaWMLmOCOPGRkRxrjBxnjNfrz+1p8YZfDfwZ8W6ZpcaSXHiCzbwwzH5mjS9V4mZQOwU53HoT7iv52da1cxXE8Rd2mYjcdnygEuuQfXINd1CSoxaqbnJCjKau/UytZ1RppWbIOXOSuCCeeg6Dqa2/C9m88gllYhc7gMnLc56/ifyrmjZpcSIyMRDKcknlx3OeuT/AI16T4ds4lnjt2XCSKQNuSV9+D6ivIg1UquXQ+jqVKdOPv8AXyPtn9lDwo/if4jeGo7lSdH02YarJsjGxvszGQByRyoIjyB13Y4yK/bnxJNbyxx+RsWOC28sRwoY1kAxgnnr/QV+dv7DHg+3hsdU8SW6Qma0jOjWhPykrvUzEKRxlgQTjkgc19yaxMywtCiMXUMGZeFOcZGfwIrtxVSNRpR6HlUW5HEyXMbzlWIjDSYOSByT79//AK9ek+ENEW5uEmOx0hcMGJ3Ek5wMenTOfQV5NM0cLrKUJKtvwoyx+le3+F5hYpDcDeMqHVS2N3cZ7fhzXL7Ny96W51SlyycbnvdnqVrpOkz318q28OnWU2oTyLHtKRxwvJJj6heSME561/PD+0V8Wrz4n+OvEPiZ7qJba5uXg0yxt/ng0+2hAhtxlQFLmONSzNuYknkDiv17/aQ+I8mg/Bvx1PZ3T22rXulrYacsc4tPMMl1bRyq0pUqgMczDJ554HUj+dbWb64s0+yghShbzChDZPHOcH14zXoYFRjGVSW+w582ja0Ob1m68ySQtICXkwH2lcjoOPoP0r9U/wBhPw7pvhL4dal42eOa98QeMr9rQSwKDBaW9qzxQ2+MDazuNzM7AMJI/u4Jb8ir2cyu7tvG593TOSe57dPXNdxoHxJ8f+GdDvvDfhbxbr/h/RdW3f2lY6RqcthFeB0EbhjGQwDhRuAI3YFefiJzrJqmzup04TVraH27+2H+0PodvpPiXwJoFza6z4t1qA6Zqt3pl+sen+F9PG15YvMXcstxKDIjKuQN8oLZQCvzq+CcU1z4xuERnjiGmSTeUADu2yoACcbsDjofSuA1+5ksttvChEZycKpYc5PB6/X1967/AOBV8q+LLgSIyyJppeJ1iJLAyxhgwAz1C9q55xq0Y8jW5xKUGlHax90IkuI4iCx+6zA45BHT17/lVDXyu5GCgnyREyMSxUgk7s54zuPHSuj0yeSbYDCFTJdm2kSDrz9fakudKivi6pIzvHgq0+UCng9BzgEY+ledUiou67nu005txlt0PM7iLytOlZyiEqxBDEs3HyjGO5wOB/FXzJ8ZZ/I8N3vm7l8+aKCMKwLsfNQ4GDngAnnHSvtabQILiIrcoQ0a4TaxIX+79cYFfHH7R1iNP0vTAYh5dzfSYceqq5GPUfKc/Wk3GUnKWw2qfK4u94nw8JxHcNKGICSGSMgZJOeCD6jg8c1+t/7GPxg1D4l6U3w2155tS8Z2svn+GGu7pDf67G5YC3VyQzsjbQgYkkOBk7QK/JV4EjQFhhWA4PTHOcj8q3vBnjPxN8PvFWk+MfCmovpPiLRLuO/0nUbeUxyQPFKsi9DyMp+GcjkA1m3a7ielTnTl7q2R+6njPT9XtbjV9L8V2tzpfiGxRre102QZADACKTjKlTvySvXb16V90fsKar4d8NeBPGum65qdnJPp+pR6hb2kiAtJby2sbb1ycZEkUytjnI5C5Gfzp1r9tHwL8ZfgxpvjDxDaTaB8atJs10bVdIi0+S607xPcTLDFDdwXCIyqSXjkZHMYXDYJBUD5Z8J/H7xJ8IdXfUdFgTUX1IvLqlvdXDQpfJI0jmJnzz8zFvmyBgYAzxytcyu3qXFzvaHU/Yn4jx2HjrxBrutPbJFFf37TW8e0gRxIFiiBXJGSsYcgEgFyM18efFX4KjV4JL/SSIdWtS0kTKgQSKACEOOCuQ4wwP3z0IrtPg3+0foPxOex0y90u58N69qcKvFZO5u7G6dhuVI5x1LAEgEDt1zge/3ccc8qxMB8ynDZ2kEY4/X9K7VTUoXtucKcsPUU5qz6fI/IzTbm6ttVOnzBYb2CUw3Fu7AFSMgjPBx/jXteh6jvYoZCBGPmQj7pra/bA+A95q3he58ceCp1sPEeiIbuRFGyTVogYW8k7QMnKnbnI5AOM5H47Wnxq+KejSfZ4vE6Mscn723ltklQYIAAbbu6Dt6Dn1+XxeTVatdzpSV30b2/zPo8LxHhuR0qibkt7LT8z9m7jXEEWWlUqvyj59mOOP1wM+4rwD4nfGVdBifT7FreS6kjKF4pFnEC/KMuuQxJyMbSOlfEekfGb4h6yVF5rh2B13Rx20USNyRnO0n359KztY1e71G7aWWXzXf5pNygZJ5OTgZ7Hqa1wOSV6VVutZxW2prjc9hKl7PDX17rp953Wp/FDxff32n6rp+s3ujX2mOz2d7pVy1vfRsdwJ35JAIPQH8TXoXgf9rL4z/Di9vr/TvFP/CRT6mq/abPxlaJ4j09GRzIrRRTbgrksQzD7wwDnAx8z3EzxeWYUcNgbxjKVXaSVlZ2IOzqxwrDoMgY/GvoFSpU42S3Pmp4jm0Z9ieI/wBun9pvxWo0+bxnpGlaeyNHLFp3gjRrONAygElhaBjgbsZOPnPXjHIXnxB8XeJLR4dV8QXl+k4VpAJ2t0lZc/M0aBV6+2OOlfMVndtJOu4ttZwCCSxJ/r/9avoHwRpxv3hnuRtEZUqiAKCoO7a2APpn0oUYxVpFe2XPJS3R6D4Y8NTpYPcAkunyIFdESEkqCW3YzgOGOCTXpl5/Z2nWvmQlGVIhJLKeWJA+Yljzj26DtVCxhtY7ZbeCNo06MOfvYALdT/dH4CvOvEMlx9qa2WQsn8D5wAMDg1SUG+Zi9vSq6xu2UfGevLqsawWc8gBU+aiKQT6ZIwcH0zXzT4pW7e5EMzv5aru2tyr9R0/CvrLwv4MbUEEj87nCncxVcnjORzzj6dK8d+M/htPDWv2tvGy+Xc2IcL5gfJDMxx7/AD/lipdreZS5HJzm9Txi2jFvEdzbsjcwK59f845q0GGwHjOMZbgdRQF3RL8imNCMjPJ5PUDpyBUMU5EwWRBIhwDkY2jjGOnSocU1dbnZLEKMn+GnUmgTIRw/PXA4Q55JNbZiOxEjP31yRjdjtwc5FY1qiyOzsjAtypGQq8Y5H/6q0EczSBYufLByQSCO/rXcloovoeFKcZr95uux9y/svyR2Vn4oe4cwwt9khM2/ac7Zs9ecHHHuxr688LfEZfCl99iC3BsdQRZ2tow0lvayDMZkVMhQzhVDHqdi+lfDv7Oria28V24mb9zBaTPEzFpFYmdUGOykAkEcHPevp61hLSw3HysUICO6nC4Oeh68+1ZSu+W+5NRydNSe59raX45txbG6hhjvIXwzyCL9/Fu5O3K56jpn8aK5fwXY2Or6R5E8GGMeWKfIMkBd2RyOOmO4HvRWtmna9jNOMveluf/Z",
#     "seqid": "744970ea9186456dbed13a3e9c6e9634",
#     "sign": "BDAFC9DA9A4824C76328B6249A1E5A90",
#     "timestamp": "1665545799517"
# }
#         params['id_card_side'] = id_card_side
        params['method'] = 'FaceContrast'
        params['scene_image'] = img_data2
        params['idcard_image'] = img_data1
        params['facesImage'] = str([img_data1,img_data2])

        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/FaceContrast'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def idcardTemporaryOcr(self, img_path):
        ''' 临时身份证识别服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'idcardTemporaryOcr'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/idcardTemporaryOcr'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def expressBillOCR(self, img_path):
        ''' 快递单识别服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'expressBillOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/expressBillOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def licenseCensor(self, img_path):
        ''' 证照质量检测服务API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'licenseCensor'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/licenseCensor'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def mask(self, img_path):
        ''' 口罩识别服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'mask'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/mask'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        data = result['data']
        print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data'] = self.decrypt(data)
            f=open(img_path.split('.')[0].split('/')[-1]+'.txt','w')
            f.write(str(result))
            f.close()
            print(self.decrypt(data))

    def remake_detect(self, img_path):
        ''' 活体翻拍服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'remake_detect'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/remake_detect'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def sealOCR(self, img_path):
        ''' 印章识别服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'sealOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/sealOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def elecMeterOCR(self, img_path):
        ''' 电表识别服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'elecMeterOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/elecMeterOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def EntrustOCR(self, img_path):
        ''' 表格识别服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'EntrustOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/EntrustOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def multiFace_detect(self, img_path):
        ''' 多人脸检测服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'multiFace_detect'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/multiFace_detect'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def fiveSenses_detect(self, img_path):
        ''' 五官检测服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'fiveSenses_detect'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/fiveSenses_detect'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def face_detect(self, img_path):
        ''' 有无人像检测服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'face_detect'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/face_detect'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def block_detect(self, img_path):
        ''' 人像遮挡检测服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'block_detect'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/block_detect'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def hat_detect(self, img_path):
        ''' 免冠检测服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'hat_detect'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/hat_detect'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def exposure_detect(self, img_path):
        ''' 图像曝光度过高服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'exposure_detect'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/exposure_detect'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def clear_detect(self, img_path):
        ''' 图像质量清析度检测服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'clear_detect'
        params['image'] = str(img_data,'utf-8')
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/clear_detect'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def face_audit(self, img_path):
        ''' 人像质量稽核服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'face_audit'
        params['image'] = str(img_data,'utf-8')

        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/face_audit'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def detection(self, img_path):
        ''' PS证件篡改识别服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'detection'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/detection/detection'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def signature(self, img_path):
        ''' 电子签名服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'signature'
        params['file'] = str(img_data, 'utf-8')
        params['file_type'] = 'jpg',
        params['location_flag'] = '1',
        params['custName'] = '',

        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/signature'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def poseDetection(self, img_path):
        ''' PS证件篡改关键点检测服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'poseDetection'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/poseDetection/poseDetection'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def UIMCardOCR(self, img_path):
        ''' UIM卡识别服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'UIMCardOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/UIMCardOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def notification(self, img_path):
        ''' 告知书合规性稽核服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'notification'
        params['file'] = str(img_data,'utf-8')
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/notification'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def authorization(self, img_path):
        ''' 委托函稽核服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'authorization'
        params['file'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/authorization'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def offcial_letter(self, img_path):
        ''' 公函清晰度识别服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'offcial_letter'
        params['file'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/offcial_letter'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))


    def resBookLicenseOCR(self, img_path):
        ''' 户口本识别服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'resBookLicenseOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/resBookLicenseOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def BankCardOCR(self, img_path):
        ''' 银行卡识别服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'BankCardOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/BankCardOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def enforce_lawOCR(self, img_path):
        ''' 证据调取通知书识别服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'enforce_lawOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/enforce_lawOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def Side_detection(self, img_path):
        ''' 侧脸检测服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'Side_detection'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/Side_detection'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def Sunglasses(self, img_path):
        ''' 闭眼及墨镜检测服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'Sunglasses'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/Sunglasses'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def entrust_letter(self, img_path):
        ''' 短信公函识别服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'entrust_letter'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/entrust_letter'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def mulidCardOCR(self, img_path):
        ''' 多身份证识别服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'mulidCardOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/mulidCardOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def EntrustOCR(self, img_path):
        ''' 表格识别服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'EntrustOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/EntrustOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def bioassay(self, img_path):
        ''' 疑似翻拍接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'bioassay'
        params['file'] = img_data
        params['file_type'] = 'jpg'
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/bioassay'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        # print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data']=self.decrypt(data)
            # print(self.decrypt(data))
            print(result)

    def HK_Macau_permit(self, img_path):
        ''' 港澳通行证API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'HK_Macau_permit'
        params['image'] = img_data

        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/HK_Macau_permit'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        # print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data']=self.decrypt(data)
            # print(self.decrypt(data))
            print(result)

    def deiver_license(self, img_path):
        ''' 驾驶证识别服务能力API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'deiver_license'
        params['image'] = img_data

        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/deiver_license'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data']=self.decrypt(data)
            # print(self.decrypt(data))
            print(result)

    def deiving_license(self, img_path):
        ''' 行驶证识别服务能力API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'deiving_license'
        params['image'] = str(img_data,'utf-8')

        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/deiving_license'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data']=self.decrypt(data)
            # print(self.decrypt(data))
            print(result)

    def biopsy(self, img_path):
        ''' 静默活体检测服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'biopsy'
        params['image'] = img_data

        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/biopsy'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data']=self.decrypt(data)
            # print(self.decrypt(data))
            print(result)

    def pig_detection(self, img_path):
        ''' 猪数量检测服务API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'pig_detection'
        params['image'] = img_data

        params = self.getSignParams(params)

        # method = 'GET'
        path = '/pig_detection'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data']=self.decrypt(data)
            # print(self.decrypt(data))
            print(result)

    def InvoiceOCR(self, img_path):
        ''' 发票识别服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'InvoiceOCR'
        params['image'] = img_data
        params['file_type'] = 'pdf'

        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/InvoiceOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data']=self.decrypt(data)
            # print(self.decrypt(data))
            print(result)

    def workerwear(self, img_path):
        ''' 发票识别服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'InvoiceOCR'
        params['file'] = img_data
        params['file_type'] = 'jpg'

        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/workerwear'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data']=self.decrypt(data)
            # print(self.decrypt(data))
            print(result)
    def HandwriteOCR(self, img_path):
        ''' 手写中文识别服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'HandwriteOCR'
        params['image'] = str(img_data,'utf-8')

        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/HandwriteOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data']=self.decrypt(data)
            # print(self.decrypt(data))
            print(result)

    def ClassifiterAddress(self):
        ''' 地址城乡村识别服务接口 '''

        params = {
        "Timestamp": 1528787199,
        "seqid": "26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
        "text": "河北省邢台市平乡县大东门",
        "prov":"河北省",
        "city":"邢台市"
      }
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/ClassifiterAddress'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def HistoryChangeAddress(self, img_path):
        ''' POST地址变更服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'HistoryChangeAddress'
        params['text'] = '浙江省丽水市青田县石溪乡'
        params['seqid'] = '26f2739a-6e0f-11e8-bc7a-58fb8443ee27'
        # params['text'] = '浙江省丽水市青田县石溪乡'
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/HistoryChangeAddress'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def AssociatedAddress(self, img_path):
        ''' POST地址联想服务接口 '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'AssociatedAddress'
        params['detailAddress'] = "金湖"
        params['divisionAddress'] = "北京昌平区小汤山镇"
        params['limit'] = 5


        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/AssociatedAddress'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def FuzzyAddress(self, img_path):
        ''' POST地址消歧服务接口 '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'FuzzyAddress'
        params['prov'] = "集美"
        params['city'] = "福建"
        params['district'] = "厦门"
        params['community'] = "集美大学"
        params['town'] = ""

        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/FuzzyAddress'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)
        print(self.decrypt(result))
        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def StructuredAddress(self):
        ''' POST地址标准化服务接口 '''


        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'StructuredAddress'
        params['prov'] = ""
        params['city'] = ""
        params['text'] = "海南海海口府路28号"
        params['uid'] = ""


        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/StructuredAddress'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        # print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def AnalyseAddress(self):
        ''' POST地址识别提取服务接口 '''


        params = {"text": "他家住在福州市玫瑰小区8栋5单元,每天办公地点在福建省兴港大厦8楼1号","Timestamp":"1528787199",
            "seqid":"26f2739a-6e0f-11e8-bc7a-58fb8443ee27"
            }


        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/AnalyseAddress'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def checkCameraImg(self, img_path):
        '''摄像头巡检服务接口API'''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['DID'] = 'test'
        params['project_id'] = 'test'
        params['province_code'] = 'test'
        params['imageContent'] = str(img_data, 'utf-8')
        params['seqid'] = '1626340993.8476272'
        params['file_type'] = 'img'
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/checkCameraImg'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        # print('入参:', params)
        # print("result", result)
        print('result', result)
        if result['code'] == '10000':
            result['data'] = self.decrypt(result['data'])
            print("result", result)
    def nucacid_vaccine(self, img_path):
        '''核酸疫苗查询识别服务接口API'''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {
            "uid": "1",
            "timestamp": int(time.time()),
            "seqid": "8f43ee27",
            'image': str(img_data,'utf-8'),
            "DID": 'TEST',
            "project_id": '1',
            "province_code": '800',
        }
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/nucacid_vaccine'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        # print('入参:', params)
        # print("result", result)
        print('result', result)
        if result['code'] == '10000':
            result['data'] = self.decrypt(result['data'])
            print("result", result)

    def health_code(self, img_path):
        '''健康码识别服务接口API'''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {
            "uid": "1",
            "timestamp": int(time.time()),
            "seqid": "8f43ee27",
            'image': str(img_data,'utf-8'),
            "DID": 'TEST',
            "project_id": '1',
            "province_code": '800',
        }

        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/health_code'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        # print('入参:', params)
        # print("result", result)
        print('result', result)
        if result['code'] == '10000':
            result['data'] = self.decrypt(result['data'])
            print("result", result)

    def stroke_card(self, img_path):
        '''行程卡识别服务接口API'''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {
            "uid": "1",
            "timestamp": int(time.time()),
            "seqid": "8f43ee27",
            'image': str(img_data,'utf-8'),
            "DID": 'TEST',
            "project_id": '1',
            "province_code": '800',
        }

        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/stroke_card'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        # print('入参:', params)
        # print("result", result)
        print('result', result)
        if result['code'] == '10000':
            result['data'] = self.decrypt(result['data'])
            print("result", result)
    def decrypt(self, text):
        """
        解密消息
        :param text: 加密文本
        :return:
        """
        try:

            cryptor = AES.new(self.sKey, AES.MODE_ECB)

            plain_text = cryptor.decrypt(base64.b64decode(text))
            plain_text = bytes.decode(plain_text)
            # print(plain_text)
            if plain_text[0] == "{":
                if plain_text[len(plain_text) - 1] == "}":
                    return json.loads(plain_text)
                else:
                    return json.loads(plain_text[: plain_text.rfind("}") + 1])
            elif plain_text[0] == "[":
                if plain_text[len(plain_text) - 1] == "]":
                    return json.loads(plain_text)
                else:
                    return json.loads(plain_text[: plain_text.rfind("]") + 1])
            else:
                return []
        except Exception as e:
            # print(e)
            return []


if __name__ == '__main__':

    appKey = 'c2c0187368e39d1f5ec4fdbbdbeea9c5'
    # appKey = '1d83f2b7c1f86ca6611fed3bbac861bd'

    # appKey = 'c9dd7ae9dc095aa3685fcdbd567972e2'

    # appKey = 'f0069b68a4fb240916fbfaf6e558c55a'
    # appKey = '1083e1f6e0882d4bd3e3f6dbfd769794'

    appSecret = '70143ee6ad33da364952edf9dea5b4c2'
    # appSecret = 'd7a51ecd65103927efd34e4d307ffae5'

    # appSecret = 'c241957b02e7658d65ff3fa51cbfc7da'
    # appSecret = '36a8f2b25df51c1c825d25365bca605f'
    # appSecret = '1e0726083e1d22992ba2767c767b5407'

    sdk = DopAPI(appKey, appSecret)
    start = time.time()
    # 单张测试
    # sdk.LicenseOCR('/home/linyicheng/wanghb/AI_EnterpriseLicense/docs/11月号百问题图片/07668983989.png')
    path='/data6/linyicheng/hbw/'
    # for i in os.listdir(path):
    # sdk.BusinessLicenseOCR('yyzz.jpg')       #营业执照
    # sdk.HistoryChangeAddress('0.jpg')
    # sdk.AssociatedAddress('人脸识别-人证稽核-真人图.png')       #地址联想服务接口
    # sdk.FuzzyAddress('人脸识别-人证稽核-真人图.png')       #地址消歧服务接口
    # sdk.StructuredAddress()       #地址标准化服务接口
    # for i in os.listdir(path):
    #     print(i)
    # sdk.generalOCR('yyzz.jpg')               #通用文字
    # sdk.AnalyseAddress()          #地址识别提取
    # sdk.ClassifiterAddress()          #地址城乡村识别服务接口

    # sdk.idCardOCR('sfz.jpg')                #身份证
    # sdk.PRCorganCodeLicenseOCR('0.jpg')     # 全国组织机构代码证识别API
    # sdk.autoCodeLicenseOCR('0.jpg')  # 基层群众性自治组织代码证识别API
    # sdk.foreignOrganLicenseOCR('0.jpg')     # 外国常驻代表机构登记证识别API
    # sdk.PRCmedicalOrganLicenseOCR('0.jpg')  # 全国医疗机构执业许可证识别API
    # sdk.PRCCodeLicenseOCR('0.jpg')          # 全国统一社会信用代码证识别API
    # sdk.ElectIncOCR('dzfp.pdf')                # 全国电子发票识别服务接口API
    # sdk.socialOrganLicenseOCR('0.jpg')      # 社会团体法人登记证书识别服务接口API
    # sdk.doorPlateReco('door.jpg')              # 门牌识别服务接口API
    # sdk.creditCodeLicenseOCR('0.jpg')       # 统一社会信用代码证书识别服务接口API
    # sdk.ruralCollectiveLicenseOCR('0.jpg')  # 农村集体经济组织登记证识别服务接口API
    # sdk.publicInstitutionLicenseOCR('1.png')# 事业单位法人证书识别服务接口API
    # sdk.nonEnterpriseLicenseOCR('1.png')    # 民办非企业证书识别服务接口API
    # for i in os.listdir(path):
    #     print(i)
    # sdk.LicenseOCR('yyzz.jpg')    # 证照识别服务接口API
    #     print('=================')
    # sdk.letterOCR('95.jpg')    # 委托函识别服务接口API
    # sdk.businessLicenseOCR('0.jpg')    # 营业执照识别服务接口API
    # sdk.Face_similarity('人脸识别-人证稽核-真人图.png')    # 人脸比对接口API
    # sdk.FaceContrast('/data6/linyicheng/Lx/Face_contrast_idcardY/test/idcard_image/1.png','/data6/linyicheng/Lx/Face_contrast_idcardY/test/scene_image/1.png')    # 人证合规性稽核服务接口API
    # sdk.idcardTemporaryOcr('sfz.jpg')    # 临时身份证识别服务接口API
    # sdk.expressBillOCR('图片1.png')    # 快递单识别服务接口API
    # sdk.licenseCensor('0527.png')    # 证照质量检测服务API
    # for i in os.listdir(path):
    #     print(i)
    # sdk.mask('drl.jpeg')    # 口罩识别服务接口API
    #     print('=================')
    # sdk.remake_detect('0.jpg')    # 活体翻拍服务接口API
    # sdk.sealOCR('1.png')    # 印章识别服务接口API
    # sdk.elecMeterOCR('0.jpg')    # 电表识别服务接口API
    sdk.EntrustOCR('bg.png')    # 表格识别服务接口API
    # sdk.multiFace_detect('1.png')    # 多人脸检测服务接口API
    # sdk.fiveSenses_detect('1.png')    # 五官检测服务接口API
    # sdk.face_detect('0.jpg')    # 有无人像检测服务接口API
    # sdk.block_detect('111.jpg')    # 人像遮挡检测服务接口API
    # sdk.hat_detect('111.jpg')    # 免冠检测服务接口API
    # sdk.exposure_detect('1.png')    # 图像曝光度过高服务接口API
    # sdk.clear_detect('kz.jpg')    # 图像质量清析度检测服务接口API
    # sdk.face_audit('q.png')    # 人像质量稽核服务接口API
    # sdk.detection('0.jpg')    # PS证件篡改识别服务接口API
    # sdk.signature('sign.png')    # 电子签名服务接口API
    # sdk.poseDetection('1.png')    # PS证件篡改关键点检测服务接口API
    # sdk.UIMCardOCR('0.jpg')    # UIM卡识别服务接口API
    # sdk.notification('202211211736221.jpg')    # 告知书合规性稽核服务接口API
    # sdk.authorization('95.jpg')    # 委托函识别服务接口API
    # sdk.offcial_letter('gh.jpg')    # 公函清晰度识别服务接口API
    # sdk.resBookLicenseOCR('hkb.jpg')    # 户口本识别服务接口API
    # sdk.BankCardOCR('yhk.png')    # 银行卡识别服务接口API
    # sdk.enforce_lawOCR('3.png') #执法平台
    # sdk.Side_detection('111.jpg')#侧脸检测
    # sdk.Sunglasses('0.jpg')#闭眼墨镜
    # sdk.entrust_letter('委托函1.jpg')#短信公函
    # sdk.mulidCardOCR('mulidcard.jpg')#多身份证
    # sdk.bioassay('0.jpg')#活体照疑似翻拍
    #sdk.EntrustOCR('0.jpg')#表格识别
    # sdk.HK_Macau_permit('hk.jpg')#港澳通行证
    # sdk.deiver_license('jsz.jpg')#驾驶证
    # sdk.deiving_license('xsz.jpg')#行驶证
    # sdk.biopsy('0.jpg')#静默活体检测服务接口
    # sdk.pig_detection('0.jpg')#猪数量检测
    # sdk.InvoiceOCR('2.pdf')#发票识别
    # sdk.workerwear('1.jpg')
    # for i in os.listdir(path):
    #     sdk.HandwriteOCR(path+i)
    # sdk.checkCameraImg("0.jpg")#摄像头巡检
    # sdk.nucacid_vaccine('nucacid.jpg')#核酸疫苗查询识别
    # sdk.health_code('healthcode.jpg')#健康码识别
    # sdk.stroke_card('green_test.png')#行程卡识别
    end = time.time()
    print('耗时：', end - start)
    # def test():
    #     sdk.FaceContrast('0.jpg')
    # for i in range(10):
    #     t = Thread(target=test)
    #
    #     t.start()

    # print('分析用时（秒）:', result)
    # 批量测试
    # path = '/home/linyicheng/wanghb/AI_EnterpriseLicense/docs/11月号百问题图片'
    # path = '/home/linyicheng/wanghb/Dcoos_test/gd_test'
    #path = '/home/linyicheng/wanghb/Dcoos_test/business_154'
    # path = '/home/linyicheng/wanghb/idcard_ori_200'
    import time
    #
    # for pic in os.listdir(path):
    #     pic_name = path + '/' + pic
    #     print(pic_name)
    #     start = time.time()
    #
    #     # sdk.BusinessLicenseOCR(pic_name)       #营业执照
    #     # sdk.generalOCR(pic_name)               #通用文字
    #     # sdk.idCardOCR(pic_name)                #身份证
    #     #sdk.PRCorganCodeLicenseOCR(pic_name)     # 全国组织机构代码证识别API
    #     sdk.autoCodeLicenseOCR(pic_name)         # 基层群众性自治组织代码证识别API
    #     #sdk.foreignOrganLicenseOCR(pic_name)     # 外国常驻代表机构登记证识别API
    #     #sdk.PRCmedicalOrganLicenseOCR(pic_name)  # 全国医疗机构执业许可证识别API
    #     # sdk.PRCCodeLicenseOCR(pic_name)          # 全国统一社会信用代码证识别API
    #     sdk.ElectIncOCR(pic_name)                # 电子发票识别服务接口API
    #     # sdk.socialOrganLicenseOCR(pic_name)      # 社会团体法人登记证书识别服务接口API
    #     # sdk.doorPlateReco(pic_name)              # 门牌识别服务接口API
    #     # sdk.creditCodeLicenseOCR(pic_name)       # 统一社会信用代码证书识别服务接口API
    #     # sdk.ruralCollectiveLicenseOCR(pic_name)  # 农村集体经济组织登记证识别服务接口API
    #     # sdk.publicInstitutionLicenseOCR(pic_name)# 事业单位法人证书识别服务接口API
    #     # sdk.nonEnterpriseLicenseOCR(pic_name)    # 民办非企业证书识别服务接口API
    #     end = time.time()
    #     print('===============================')
    #
    #     print('耗时：', end - start)
    #     # sdk.perLicense(pic_name)
    #     print('===============================')
