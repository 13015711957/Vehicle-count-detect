# -*- coding:utf-8 -*-

import os
import numpy as np
import pandas as pd
# import cv2
import base64
import requests
import json
import time


def businessLicenseOCR(data):
    url = 'http://10.142.157.211:5107/ocr_API/LicenseOCR'


    r = requests.post(url, json=data)
    # print(r.text)
    res = json.loads(r.text)
    return res


if __name__ == '__main__':
    path = '/data6/linyicheng/hbw/证件图片/'
    # img_path='kz.png'
    for i in os.listdir(path):
        img_path=path+i
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())
        data={
                "seqid": i,
                "image": str(img_data,'utf-8')
            }


        res = businessLicenseOCR(data)
        print(res)
    # img=res['data']['mask_result']['image_result']
    # image_data = base64.b64decode(img)
    # with open('kzres.jpg', 'wb') as f:
    #     f.write(image_data)



