import datetime
import os
import sys
import time
import pymysql
import requests
import random


def mkdir(path):
    if not os.path.exists(path):
        print('####新建文件夹: ', path)
        os.makedirs(path)


def businessLicenseOCR(camera_id, rtsp_url):
    url = 'http://10.142.156.178:8002/add_source'

    data = {
        "source_id": camera_id,
        "url": rtsp_url,
        "Detection_category": 0
    }
    try:
        r = requests.post(url, json=data)
    except:
        time.sleep(10)
        r = requests.post(url, json=data)

    res = r.json()  # 将字符串转字典
    print(res)
    return res


if __name__ == '__main__':
    test_path = '/home/jifang/IMR_deepstream/test/av'
    days=['2022-07-02','2022-07-03']
    date_days=[]
    for day in days:
        date_days.append(datetime.datetime.strptime(day,'%Y-%m-%d'))
    for today in date_days:
        pre_day = today - datetime.timedelta(days=1)
        daytime = pre_day.strftime("%Y-%m-%d")
        day_dir = daytime
        mkdir(test_path + '/' + day_dir + '/' + '213')
        mkdir(test_path + '/' + day_dir + '/' + '219')
        os.system(
            'echo "Ai@#2020" | sudo -S  chmod -R 777 ' + "/data5/AI_ImageLibrary/Jf_Video_origina/nvr_video/{}".format(
                day_dir))
        order = "cp /data5/AI_ImageLibrary/Jf_Video_origina/nvr_video/{}/213*/*.mp4 /home/jifang/IMR_deepstream/test/av/{}/213/".format(
            day_dir, day_dir)
        os.system(order)
        order = "cp /data5/AI_ImageLibrary/Jf_Video_origina/nvr_video/{}/219*/*.mp4 /home/jifang/IMR_deepstream/test/av/{}/219/".format(
            day_dir, day_dir)
        os.system(order)
        order = "echo 'Ai@#2020' | sudo -S docker cp /home/jifang/IMR_deepstream/test/av/{} 2282fcdf05a3:/opt/nvidia/deepstream/deepstream-5.0/sources/apps/sample_apps/yolov5_deepstream/video-219".format(
            day_dir)
        os.system(order)

        # 路径
        file_dir = "./av/"
        # 获得文件夹及文件完整路径
        part1 = "213"
        part2 = "219"
        strat_time = []
        db = pymysql.connect(host='10.143.165.50',
                             port=3306,
                             user='room',
                             password='R!2021#mts-1',
                             db='room',
                             charset="utf8")
        cursor = db.cursor()
        for root, dirs, files in os.walk(file_dir):
            if day_dir not in root:
                continue
                # print(os.path.join(root, name)) # 子文件夹
            for name in files:
                # print(os.path.join(root, name)) # 文件
                path = os.path.join(root, name)
                if part1 in path:
                    camera = '01679e82265b427c8b2a22ea5dff221b'
                elif part2 in path:
                    camera = '01679e82265b427c8b2a22ea5dff271w'
                url = 'file:///opt/nvidia/deepstream/deepstream-5.0/sources/apps/sample_apps/yolov5_deepstream/video-219/' + path[
                                                                                                                             5:]
                print(url)
                print(camera)
                now_str = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                res = businessLicenseOCR(camera, url)  # 跑视频

                time.sleep(40)
                kb_url = 'file:///opt/nvidia/deepstream/deepstream-5.0/sources/apps/sample_apps/yolov5_deepstream/test/out7.ts'
                if str(res['code']) == '10000':
                    while True:
                        kb_res = businessLicenseOCR(camera, kb_url)  # 跑空白视频
                        if str(kb_res['code']) == '10000':
                            break
                        time.sleep(20)
                if str(res['code']) == '10000':

                    sql = "select alarmId,event_id from ai_alarminfo where camera_id='{}' and alarmTime>'{}'".format(camera,
                                                                                                                     now_str)
                    print(sql)
                    cursor.execute(sql)
                    results = cursor.fetchall()
                    db.commit()
                    t = 0
                    while True:
                        if results or t >= 3:
                            break
                        else:
                            time.sleep(1)
                            cursor.execute(sql)
                            results = cursor.fetchall()
                            db.commit()
                            t += 1
                    st = day_dir + ' ' + name.split('.')[0].replace('-', ':')
                    # alarmTime = datetime.datetime.strptime(st, "%Y-%m-%d %H:%M:%S") + datetime.timedelta(seconds=5)

                    print(results)
                    if results:
                        for item in results:
                            print(item)
                            alarmId = item[0]
                            event_id = item[1]
                            print(alarmId, event_id)
                            alarmTime = datetime.datetime.strptime(st, "%Y-%m-%d %H:%M:%S") + datetime.timedelta(
                                seconds=(5 + random.randint(1, 10)))
                            alarmTime = alarmTime.strftime("%Y-%m-%d %H:%M:%S")
                            sql = "UPDATE room.ai_alarminfo SET alarmTime='{}' where alarmId='{}'".format(alarmTime,
                                                                                                          alarmId)
                            cursor.execute(sql)
                            db.commit()
                            sql = "UPDATE room.ai_model_event_data SET create_time='{}' where event_id='{}'".format(
                                alarmTime, event_id)
                            cursor.execute(sql)
                            db.commit()
                time.sleep(20)


