# -*- coding:utf-8 -*-
import numpy as np
import requests
import base64
import os
import pandas as pd
import json


def convert(size, box):
    dh = 1.0 / size[0]
    dw = 1.0 / size[1]
    point_x0 = float(box[0])
    point_y0 = float(box[1])
    point_x1 = float(box[2])
    point_y1 = float(box[3])
    x = np.abs(point_x1 + point_x0) / 2.0
    y = np.abs(point_y1 + point_y0) / 2.0
    w = np.abs(point_x1 - point_x0)
    h = np.abs(point_y1 - point_y0)
    x = x * dw
    y = y * dh
    w = w * dw
    h = h * dh
    return [x, y, w, h]


def seal_identity():
    # url = 'http://127.0.0.1:5050/api/sealidentify'
    # url = 'http://192.168.35.175:1001/api/sealidentify'
    # url = 'http://192.168.35.175:1001/api/sealidentifyFtp'
    # url = 'http://192.168.35.143:5050/ocr/license'
    url = 'http://192.168.35.200:11000/open_door_detection'
    # url = 'http://10.142.156.167:5050/ocr_API/idCardOCR'

    path = r"./docs/val/img/"

    testRes0 = pd.DataFrame(
        columns=['图片名', 'boxs'])  # , '坐标'])
    df_res = []
    s = []
    for i in os.listdir(path):

        file = path + i
        with open(file, "rb") as f:
            source_img = base64.b64encode(f.read())
            # print(source_img)
        data = {
            "image_base64": str(source_img, "utf-8"),
            'seqid': 'test',
            'thresh':0.6
        }
        r = requests.post(url, json=data)
        res = r.json()
        print(res)
        try:
            df_res.append([i,res['boxs']])
        except:
            df_res.append([i,''])

        # save_url = r'C:\Users\gstx\Desktop\test'
        # boxs = res['boxs']
        #
        # for box in boxs:
        #     bbox = [box['xmin'], box['ymin'], box['xmax'], box['ymax']]
        #     bbox = convert((720, 1280), bbox)
        #     file = open(save_url + '/' + i.split('.')[0] + '.txt', "a+", encoding='utf-8')
        #     file.write('0 {}'.format(bbox))
        #     file.write('\n')

    for i in range(len(df_res)):
        testRes0.loc[i] = df_res[i]
    testRes0.to_excel('open_door.xlsx', index=False)


if __name__ == '__main__':
    # import threading
    # for i in range(5):
    #     a = threading.Thread(target=seal_identity, name='worker')
    #     a.start()

    seal_identity()

    # with open("./test.jpg", "rb") as f:
    #     source_img = base64.b64encode(f.read())
    # print (source_img)
