# -*- coding:utf-8 -*-

import os
import numpy as np
import pandas as pd
import cv2
import base64
import requests
import json
import traceback
from threading import Thread

def businessLicenseOCR():
    url = 'http://10.142.157.211:5128/Face_API/FaceContrast'
    #url = 'http://10.142.156.177:5070/ocr_API/idcardTemporaryOcr'
    idcard_url = 'img/人脸识别-人证稽核-身份证.png'
    scene_url = 'img/人脸识别-人证稽核-真人图.png'
    print(idcard_url)
    print(scene_url)
    idcard_image = cv2.imdecode(np.fromfile(idcard_url, dtype=np.uint8), -1)
    scene_image = cv2.imdecode(np.fromfile(scene_url, dtype=np.uint8), -1)
    idcard_image = cv2.imencode('.jpg', idcard_image)[1].tostring()
    idcard_image = base64.b64encode(idcard_image)
    scene_image = cv2.imencode('.jpg', scene_image)[1].tostring()
    scene_image = base64.b64encode(scene_image)

    data = {
        "timestamp": 1528787199,
        "seqid": "26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
        "idcard_image":  str(idcard_image, "utf-8"),
        'scene_image': str(scene_image, "utf-8"),
    }
    r = requests.post(url, data=data)
    res = r.json()
    return res


if __name__ == '__main__':
    res = businessLicenseOCR()
    print(res)
