# -*- coding:utf-8 -*-

import os
import numpy as np
import pandas as pd
# import cv2
import base64
import requests
import json


def businessLicenseOCR(data):
    # url = 'http://134.128.231.106:5062/img_register'
    url = 'http://10.143.165.93:5062/img_register'
    # url = 'http://0.0.0.0:5062/img_register'

    r = requests.post(url, json=data)
    res = json.loads(r.text)
    return res


if __name__ == '__main__':
    # idcard_url = r'E:\ffcs\code\test\1.jpg'

    # df_res = pd.DataFrame(columns=['图片名', '人脸类型','耗时'])
    # result = []
    # path=r'C:\Users\gstx\Desktop\dikuimg/'
    # path=r'/app/fjaiplat-file/jifang/test_face/img/'
    # path=r'/project/test/img/'
    # images=os.listdir(path)
    # image = cv2.imdecode(np.fromfile(url, dtype=np.uint8), -1)
    temp=[
        # ['testLXY', '李贤勇', '835', '351000000000000000160981', '351221000000000004895344'],
        # ['testTYT', '田玉婷', '835', '351000000000000000160981', '351221000000000004895344'],
        # ['testSRJ', '师睿骏', '835', '351000000000000000160981', '351221000000000004895344'],
        # ['testCLR', '陈玲榕', '835', '351000000000000000160981', '351221000000000004895344'],
        # ['testZY', '张烨',    '835', '351000000000000000160981', '351221000000000004895344'],
        # ['testZJC', '郑久传', '835', '351000000000000000160981', '351221000000000004895344'],
        # ['testZXQ', '郑晓倩', '835', '351000000000000000160981', '351221000000000004895344'],
        # ['testYSX', '尹书鑫', '835', '351000000000000000160981', '351221000000000004895344'],
        # ['testDLCZ', '陈楠', '835', '351221000000000004895344'],
        # ['testDLWCR', '翁长荣', '835', '351221000000000004895344'],
        # ['testDLWXZ', '吴晓鑫', '835', '351221000000000004895344'],
        # ['testDLWZZ', '翁昕泓', '835', '351221000000000004895344'],
        # ['testDLXF', '薛峰', '835', '351221000000000004895344'],
        # ['testDLZHW', '郑华伟', '835', '351221000000000004895344'],
        # ['testDLZJZ', '郑建钊', '835', '351221000000000004895344'],
        # ['testFJCYH', '池雨荷', '835', '351000000000000000160981'],
        # ['testFJCZY', '陈正宇', '835', '351000000000000000160981'],
        # ['testFJYZ', '杨洲', '835', '351000000000000000160981'],
        # ['testFJZCZ', '郑朝晖', '835', '351000000000000000160981'],
        # ['testFJZLW', '张林文', '835', '351000000000000000160981'],
        # ['testFJZM', '詹敏', '835', '351000000000000000160981'],
        # ['testFJZML', '郑美玲', '835', '351000000000000000160981'],
        # ['testIODCY', '陈尧', '835', '351221000000000004895344'],
        # ['testIODGL', '甘霖', '835', '351221000000000004895344'],
        # ['testIODJRQ', '江仁齐', '835', '351221000000000004895344'],
        # ['testIODLXF', '林晓芳', '835', '351221000000000004895344'],
        # ['testIODTL', '唐磊', '835', '351221000000000004895344'],
        # ['testIODXL', '徐磊', '835', '351221000000000004895344'],
        # ['testIODXL2', '薛翀', '835', '351221000000000004895344'],
        ['test', 'test', '835', '351221000000000004895344'],

]
    # for i in temp:
    #     print(i)
    #     for j in images:
    #
    #         if i[1] in j:
    #             url=path+j
        # with open(url, 'rb') as f:
        #     a = base64.b64encode(f.read())
    data={
        "operatorid": '228f01e2584040a194ddfea82d2030ca',
        "province": '835',
        "group_ids": [
            '351221000000000004895344'
            # i[3]
        ],
        "image_base64": ''


}
    # print(data)
    res = businessLicenseOCR(data)
    print(res)
