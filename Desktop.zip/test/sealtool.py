# -*- coding: utf-8 -*-
import math
import cv2
import numpy as np


def seal_mark(img, x1, y1):
    # 图像中心
    h, w = img.shape[0], img.shape[1]
    x = int(w / 2)
    y = int(h / 2)

    # 半径
    r = int(math.sqrt((x - x1) ** 2 + (y1 - y) ** 2))

    def getx(y0):
        return x - math.sqrt(r ** 2 - (y - y0) ** 2)

    x4, y4 = x, y - r
    y2 = int(y4 + (y1 - y4) * 2 / 3)
    x2 = int(getx(y2))
    y3 = int(y4 + (y1 - y4) / 3)
    x3 = int(getx(y3))

    x5, y5 = x + (x - x3), y3
    x6, y6 = x + (x - x2), y2
    x7, y7 = x + (x - x1), y1

    point_size = 1
    point_color = (0, 0, 255)  # BGR
    thickness = 4  # 可以为 0 、4、8
    cv2.circle(img, (x, y), r, point_color, 0)
    cv2.circle(img, (x7, y7), point_size, point_color, thickness)
    cv2.circle(img, (x6, y6), point_size, point_color, thickness)
    cv2.circle(img, (x5, y5), point_size, point_color, thickness)
    cv2.circle(img, (x4, y4), point_size, point_color, thickness)
    cv2.circle(img, (x3, y3), point_size, point_color, thickness)
    cv2.circle(img, (x2, y2), point_size, point_color, thickness)
    cv2.circle(img, (x1, y1), point_size, point_color, thickness)
    cv2.imshow('image', img)
    cv2.waitKey()
    return [x1, y1, x2, y2, x3, y3, x4, y4, x5, y5, x6, y6, x7, y7]


def res_points(img, X1, Y1, x1, y1):
    res = []
    res.append(seal_mark(img, x1, y1))
    res.append(seal_mark(img, X1, Y1))
    return res

# image_file=r'\\192.168.35.126\public\0 印章识别\印章-真实\1/100040000009031343_0__1南京钵育学院.jpg'
# img=cv2.imdecode(np.fromfile(image_file, dtype=np.uint8),-1)
#
# X1, Y1, x1, y1 = 137, 554, 232, 473
# print(res_points(img, X1, Y1, x1, y1))
