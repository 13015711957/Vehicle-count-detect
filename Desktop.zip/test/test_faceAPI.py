# -*- coding:utf-8 -*-

import os
import numpy as np
import pandas as pd
import cv2
import base64
import requests
import json
import traceback

def businessLicenseOCR(image):
    url = 'http://10.141.254.124:8086/notification'
    # url = 'https://openeop.dcoos.189.cn:8000/serviceAgent/rest/openapi/pig_detection'


    image = cv2.imencode('.jpg', image)[1].tostring()
    image = base64.b64encode(image)


    data = {

        'seqid':'111',
        'file': str(image, "utf-8"),
    }
    r = requests.post(url, json=data)
    res = json.loads(r.text)
    return res


if __name__ == '__main__':
    # idcard_url = r'E:\ffcs\code\test\1.jpg'

    df_res = pd.DataFrame(columns=['图片名', '人脸类型','耗时'])
    result = []
    url=r'gzs.jpg'

    image = cv2.imdecode(np.fromfile(url, dtype=np.uint8), -1)

    res = businessLicenseOCR(image)
    print(res)
