from itsdangerous import json
import requests
import pymysql
import datetime
import time
import argparse
import os


# 启动拉流
def pullStream(channel, starttime, endtime, cameraId):
    url = "http://10.143.165.50:9075/camera/download"
    headers = {"content-type": "application/json"}
    requestData = {
        "username": "admin",
        "password": "12345",
        "ip": "10.140.21.5",
        "channel": channel,
        "stream": "rtsp",
        "port": "8000",
        "starttime": starttime,
        "endtime": endtime,
        "cameraId": cameraId
    }
    ret = requests.post(url, json=requestData, headers=headers)
    if ret.status_code == 200:
        text = json.loads(ret.text)
        print(text)
    return text["key"]
    # 视频默认保存在/data5/AI_ImageLibrary/Jf_Video_origina/nvr_video/


# 查看拉流进程
def check(key):
    url = "http://10.143.165.50:9075/camera/downprogress?key=" + key
    headers = {"content-type": "application/json"}
    ret = requests.get(url, headers=headers)
    text = json.loads(ret.text)
    while ret.status_code == 200 and text["message"] == "录像文件正在下载":
        print(text)
        time.sleep(5)
        ret = requests.get(url, headers=headers)
        text = json.loads(ret.text)
    print(text)


# 查找动检结果
def connectSQL(camera_num, select_time):
    create_time = []
    db = pymysql.connect(host='10.143.165.50',
                         port=3306,
                         user='hkd',
                         password='H!2020#kdts-2',
                         db='hkd',
                         charset="utf8")
    cursor = db.cursor()
    sql = "select * from ai_dynamic_inspect_record where camera_num = '{}' and  create_time like '{}' order by create_time;".format(
        camera_num, select_time)
    try:
        cursor.execute(sql)
        results = cursor.fetchall()
        for row in results:
            create_time.append(row[3])
        return create_time
    except:
        print("Error: unable to fetch data")
    cursor.close()
    db.close()


# 处理动检数据
def processingData(create_time):
    res = []
    temp = []
    for i in range(1, len(create_time)):
        if temp == []:
            temp.append(
                (create_time[i - 1] -
                 datetime.timedelta(seconds=3)).strftime("%Y-%m-%d %H:%M:%S"))
        # t1 = datetime.datetime.strptime(create_time[i], '%Y-%m-%d %H:%M:%S')
        # t2 = datetime.datetime.strptime(create_time[i - 1],
        #                                 '%Y-%m-%d %H:%M:%S')
        t1 = create_time[i]
        t2 = create_time[i - 1]
        deltaT = t1 - t2
        if str(deltaT) > "0:00:10":
            temp.append(
                (create_time[i - 1] +
                 datetime.timedelta(seconds=5)).strftime("%Y-%m-%d %H:%M:%S"))
            res.append(temp)
            temp = []
    return res


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="从NVR拉取视频")
    parser.add_argument("-id",
                        type=str,
                        dest="id",
                        default="213&219",
                        help="机房编号，默认昌平213和219")
    parser.add_argument(
        "-t",
        type=str,
        dest="time",
        default=str(datetime.date.today() - datetime.timedelta(days=1)) + "%",
        help="需要的日期，日期后要加个%%，默认前一天")
    args = parser.parse_args()
    if args.id == "213":
        create_time = connectSQL("01679e82265b427c8b2a22ea5dff221b", args.time)
        res = processingData(create_time)
        for i in res:
            print(i)
            key = pullStream("46", i[0], i[1], args.id + "-" + i[1])
            check(key)
    elif args.id == "219":
        create_time = connectSQL("01679e82265b427c8b2a22ea5dff271w", args.time)
        res = processingData(create_time)
        for i in res:
            print(i)
            key = pullStream("41", i[0], i[1], args.id + "-" + i[1])
            check(key)
    elif args.id == "213&219":
        print("213&219")
        create_time_213 = connectSQL("01679e82265b427c8b2a22ea5dff221b", args.time)
        res_213 = processingData(create_time_213)
        print(res_213)
        for i in res_213:
            print(i)
            key_213 = pullStream("46", i[0], i[1], "213" + "-" + i[1])
            check(key_213)
        create_time_219 = connectSQL("01679e82265b427c8b2a22ea5dff271w", args.time)
        res_219 = processingData(create_time_219)
        for j in res_219:
            print(j)
            key_219 = pullStream("41", j[0], j[1], "219" + "-" + j[1])
            check(key_219)
    os.system("sudo cp -r /data5/AI_ImageLibrary/Jf_Video_origina/nvr_video/{} /home/ctff/ws/nvr-video/".format(args.time.split("%")[0]))
    os.system("sudo chown -R ctff:ctff /home/ctff/ws/nvr-video/{}".format(args.time.split("%")[0]))
    os.system("zip -r /home/ctff/ws/nvr-video/{}.zip /home/ctff/ws/nvr-video/{}".format(args.time.split("%")[0], args.time.split("%")[0]))
    print("Down!")
