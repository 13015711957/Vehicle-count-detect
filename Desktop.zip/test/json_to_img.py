import base64
import json
import os

import cv2
path=r'C:\Users\gstx\Desktop\sign_img/'
for i in os.listdir(path):
    name=path+i
    with open(name) as f:
        jsonData = json.loads(f.read())
        img=jsonData['file']
        img_data=base64.b64decode(img)
        file=open(path+i.split('.')[0]+'.jpg','wb')
        file.write(img_data)