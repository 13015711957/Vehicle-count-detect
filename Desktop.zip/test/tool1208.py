import cv2
img=cv2.imread('111.png')
print(img.shape)