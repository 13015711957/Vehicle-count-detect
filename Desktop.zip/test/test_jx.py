import os
import numpy as np
import pandas as pd
import cv2
import base64
import requests
import json

def sign(fileName,imgString,user_name):
    url = 'http://134.225.124.4:8386/signature'
    data = {
        "fileName": fileName,
        "USER_NAME": user_name,
        'imgString': imgString,
    }
    # data={"fileName":"882112255369226",
    #       "USER_NAME":"刘莎莎杨尚先",
    #       "imgString":"http://134.224.120.77:8080/group1/M01/37/F5/huB4TWHGmceAd0_oAAUpFShr-fA916.pdf"}
    r = requests.post(url, json=data)
    print(r)
    res = r.json()  # 将字符串转字典
    return res

if __name__ == '__main__':
    path=r'E:\ffcs\code\test\20211228验证样本-非过户双签名.xlsx'
    ex=pd.read_excel(path)
    df=pd.DataFrame(columns=['fileName','imgString','user_name','state','value','label'])
    result=[]
    for i in ex.itertuples():
        fileName=str(i[1])
        imgString=str(i[2])
        user_name=str(i[3])
        label=str(i[6])
        print(fileName,imgString,user_name)
        try:
            res=sign(fileName,imgString,user_name)
            print("res:",res)
            for i in res[fileName]:
                result.append([fileName,imgString,user_name,i['state'],i['value'],label])
        except:
            result.append([fileName, imgString, user_name, '', '',''])

    for i in range(len(result)):
        df.loc[i] = result[i]
        print(result[i])
        print('======')
    df.to_excel(r'20211228验证样本-非过户双签名_new.xlsx', index=False)