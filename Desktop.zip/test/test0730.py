import os
import time

import numpy as np
import pandas as pd
import cv2
import base64
import requests
import json


def businessLicenseOCR(source_img):

    url = 'http://10.142.157.211:5106/ocr_API/publicInstitutionLicenseOCR'
    url = 'http://10.142.157.211:5102/ocr_API/businessLicenseOCR'
    url = 'http://10.142.157.211:5107/ocr_API/LicenseOCR'
    url = 'http://10.142.157.211:5109/ocr_API/nonEnterpriseLicenseOCR'
    url = 'http://10.142.157.211:5116/ocr_API/PRCorganCodeLicenseOCR'
    url = 'http://10.142.157.211:5115/ocr_API/PRCCodeLicenseOCR'
    url = 'http://10.142.157.211:5101/ocr_API/idCardOCR'
    # url = 'http://10.143.165.21:32500/ocr_API/idCardOCR'
    # url = 'http://10.142.157.211:5112/ocr_API/socialOrganLicenseOCR'
    # url = 'http://10.142.157.211:5108/ocr_API/creditCodeLicenseOCR'
    # url = 'http://10.142.157.211:5117/ocr_API/autoCodeLicenseOCR'
    # url = 'http://10.142.157.211:5122/ocr_API/expressBillOCR'

    # source_img = cv2.imencode('.jpg', source_img)[1].tostring()
    # source_img = base64.b64encode(source_img)

    data = {
        # "seqid": '210118_class_177',
        # "image":  '',
        "image":  source_img,
        # 'request_man': '1',
    }
    r = requests.post(url, json=data)

    res = r.json()  # 将字符串转字典
    return res
if __name__ == '__main__':

    # path = r'/home/linyicheng/wanghb/AI_EnterpriseLicense/docs/test'
    path = r'/home/linyicheng/wanghb/data/0831福建AI统一社会信用代码图片_1'
    # path = r'/home/linyicheng/wanghb/AI_EnterpriseLicense/docs/business_154'
    path = r'/home/linyicheng/wanghb/AI_EnterpriseLicense/docs/广东号百/business_repetition'
    path = r'/home/linyicheng/wanghb/AI_EnterpriseLicense/docs/img_class_error'
    path = r'/home/linyicheng/wanghb/AI_EnterpriseLicense/docs/广东号百/OCR抽样统计-10月图片'
    path = r'/home/ctff/wanghb/AI_EnterpriseLicense/docs/11月号百问题图片'
    path = r"0527.png"
    # 营业执照
    # df_res = pd.DataFrame(columns=['id', 'pic_name', 'text', '统一社会信用代码', '公司名称','类型', '住所',
    #                                 '法定代表人','注册资本','成立日期','有效期限', '经营范围', 'timeSecond'])
    df_res = pd.DataFrame(columns=['图片名', '签发机关', '有效期限'])  # , '坐标'])

    id = 0
    result = []

    res = businessLicenseOCR('')
    print(res)
    imgnames = os.listdir(path)
    # for img in s:

    for imgname in imgnames:
        # if str(img) in imgname:
        if imgname !='00179609d8394c8f8c75d0eb251c73a9.json':
            continue
        print(imgname)
        url = path + '/' + imgname
        with open(url, 'r',encoding='utf8') as f:
            image = json.load(f)['image']
        # print(image['seqid'])
        # break
        # break
        # image = cv2.imdecode(np.fromfile(url, dtype=np.uint8), -1)
        # -1 读取彩色图像  0 读取灰度图
        # image = cv2.imdecode(np.fromfile(url, dtype=np.uint8), -1)
        # h, w, _ = image.shape
        # res = businessLicenseOCR(image)
        # print("res", res)
        # if res['code'] == '10000':
        #     try:
        #         if res['data']['words_result_num']==2:
        #             result.append([imgname, res['data']['words_result']['签发机关']['words'], res['data']['words_result']['有效期限']['words']])
        #     except:
        #         pass
        # time.sleep(500)
    # for i in range(len(result)):
    #     df_res.loc[i] = result[i]
    #     df_res.to_excel('idcard_v1.0.xlsx', index=False)