# coding=utf-8
import time
import uuid
import hashlib
import base64
import requests
from Crypto.Cipher import AES
from urllib.parse import urlencode
import json
import os


class DopAPI(object):
    def __init__(self, appKey, appSecret):
        self.appKey = appKey
        self.appSecret = appSecret
        self.sKey = appSecret[: 16]
        # self.base_url = 'http://10.142.101.156/openapi'
        self.base_url = 'http://10.128.86.64:8000/serviceAgent/rest/openapi'
        # self.base_url = 'http://10.128.86.64:8000/serviceAgent/rest'

    def getSignParams(self, params):
        ''' 获取签名所需参数 '''
        params['timestamp'] = int(round(time.time() * 1000))  # 毫秒

        src = str(uuid.uuid4())
        seqId = src[: 8] + src[9: 13] + src[14: 18] + src[19: 23] + src[24:]
        params['seqid'] = seqId
        sign = self.makeSign(params)
        params['sign'] = sign
        return params

    def makeSign(self, params):
        ''' 签名生成算法 '''
        paramsStr = 'appKey{}timestamp{}seqid{}'.format(self.appKey, params['timestamp'], params['seqid'])
        paramsStr = self.sKey + paramsStr + self.sKey
        paramsStr = paramsStr.lower()
        return hashlib.md5(paramsStr.encode('utf-8')).hexdigest().upper()

    def getRequestString(self, scriptName, params, method):
        ''' 调试用，程序中可不调用 '''
        url = self.base_url + scriptName
        info = '==========Request Info==========\n'
        info += 'method: ' + method + '\n'
        info += 'url: ' + url + '\n'
        info += 'query: ' + urlencode(params, encoding='utf-8')
        info += '\n'
        return info

    def generalOCR(self, img_path):
        ''' 通用文字识别API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        params['method'] = 'generalOCR'
        params['imageBase64'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/GeneralOCR'

        result = self.decryptApi(path, params)
        print(result)
        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))
        # print(data)
        return self.decrypt(data)

    def expressBillOCR(self, img_path):
        ''' 通用文字识别API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        params['method'] = 'expressBillOCR'
        params['imageBase64'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/ExpressBillOCR'

        result = self.decryptApi(path, params)
        print(result)
        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))
        # print(data)
        return self.decrypt(data)

    def LicenseOCR(self, img_path):
        ''' 证照分类识别API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'LicenseOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        method = 'GET'
        path = '/dcoos/LicenseOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def BusinessLicenseOCR(self, img_path):
        ''' 营业执照 '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['DID'] = 'test'
        params['project_id'] = 'test'
        params['province_code'] = 'test'
        params['method'] = 'businessLicenseOCR'
        # params['timestamp'] = '1528787199'
        # params['subscribe_level'] = 'b1'
        params['uid'] = 'a4e10d87d5a914a80581f622aafcbc90'
        params['image'] = str(img_data,'utf-8')
        params = self.getSignParams(params)

        method = 'GET'
        path = '/businessLicenseOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        # if result['code'] == '10000':
        #     data = result['data']
        #     print(self.decrypt(data))

    def idCardOCR(self, img_path):
        ''' 身份证识别API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'IdCardOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        method = 'GET'
        path = '/IdCardOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def perLicense(self, img_path_1, img_path_2):
        ''' 人证稽核API '''
        with open(img_path_1, 'rb') as f:
            img_data_1 = base64.b64encode(f.read())
        with open(img_path_2, 'rb') as f:
            img_data_2 = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'FaceContrast'
        params['idcard_image'] = img_data_1
        params['scene_image'] = img_data_2
        params = self.getSignParams(params)

        method = 'GET'
        path = '/dcoos/FaceContrast'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        # if result['code'] == '10000':
        #    data = result['data']
        #    print(self.decrypt(data))

    def decryptApi(self, path, params):
        ''' 解密消息 '''
        params = self.getSignParams(params)
        url = self.base_url + path
        headers = {
            # 'Authorization': 'TYDIC_DCOOS_AUTH appkey={};sKey={};timestamp={};sign={};seqid={}'.format(self.appKey, self.sKey, params['timestamp'], params['sign'], params['seqid']),
            'Content-Type': 'application/json;charset=UTF-8',
            'User-Agent': 'Java DopAPIv1 SDK Client',
            'Accept': 'application/json',
            'X-APP-ID': self.appKey,
            'X-APP-KEY': self.appSecret,
        }

        print('url:', url)
        # print('params:', params)
        # for key, value in params.items():
        #     print(key)
        res = requests.post(url, headers=headers, json=params)
        # res = requests.post(url, headers=headers, data=json.dumps(params))
        # print("res", res)
        # 这里要补充结果校验
        return res.text

    def decrypt(self, text):
        """
        解密消息
        :param text: 加密文本
        :return:
        """
        try:

            cryptor = AES.new(self.sKey, AES.MODE_ECB)

            plain_text = cryptor.decrypt(base64.b64decode(text))
            plain_text = bytes.decode(plain_text)
            # print(plain_text)
            if plain_text[0] == "{":
                if plain_text[len(plain_text) - 1] == "}":
                    return json.loads(plain_text)
                else:
                    return json.loads(plain_text[: plain_text.rfind("}") + 1])
            elif plain_text[0] == "[":
                if plain_text[len(plain_text) - 1] == "]":
                    return json.loads(plain_text)
                else:
                    return json.loads(plain_text[: plain_text.rfind("]") + 1])
            else:
                return []
        except Exception as e:
            # print(e)
            return []

    def PRCmedicalOrganLicenseOCR(self, img_path):
        ''' 医疗机构识别API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'PRCmedicalOrganLicenseOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        method = 'GET'
        path = '/dcoos/PRCmedicalOrganLicenseOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def autoCodeLicenseOCR(self, img_path):
        ''' 基层群众识别API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'autoCodeLicenseOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        method = 'GET'
        path = '/dcoos/autoCodeLicenseOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def PRCorganCodeLicenseOCR(self, img_path):
        ''' 组织机构识别API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'PRCorganCodeLicenseOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        method = 'GET'
        path = '/dcoos/PRCorganCodeLicenseOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def PRCCodeLicenseOCR(self, img_path):
        ''' 中国统一社会信用代码识别API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'PRCCodeLicenseOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        method = 'GET'
        path = '/dcoos/PRCCodeLicenseOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            print(self.decrypt(data))

    def mulidCardOCR(self, img_path):
        ''' 多身份证识别服务接口API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'mulidCardOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/mulidCardOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        # if result['code'] == '10000':
        #    data = result['data']
        #    print(self.decrypt(data))

    def elecMeterOCR(self, img_path):
        '''电表识别服务接口API'''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'elecMeterOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/elecMeterOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)
        # if result['code'] == '10000':
        # data = result['data']
        # print(self.decrypt(data))

    def UIMCardOCR(self, img_path):
        '''UIM卡识别服务接口API'''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'UIMCardOCR'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/UIMCardOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)
        # if result['code'] == '10000':
        #    data = result['data']
        #    print(self.decrypt(data))

    def workerwear(self, img_path):
        '''工装检测服务接口API'''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'workerwear'
        params['image'] = img_data
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/workerwear'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)
        # if result['code'] == '10000':
        #    data = result['data']
        #    print(self.decrypt(data))

    def signatureOCR(self, img_path):
        '''电子签名服务接口API'''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'signature'
        params['file'] = img_data
        params['file_type'] = 'img'
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/dcoos/signature'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print('入参:', params)
        # print("result", result)
        if result['code'] == '10000':
            result['data'] = self.decrypt(result['data'])
            print("result", result)
            # print(self.decrypt(data))

    def camera_inspection(self, img_path):
        '''摄像头巡检服务接口API'''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['DID'] = 'test'
        params['project_id'] = 'test'
        params['province_code'] = 'test'
        params['fileurl'] = 'https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fwx3.sinaimg.cn%2Fmw690%2F001eQwOply1h36xst38xjj60u01emq4d02.jpg&refer=http%3A%2F%2Fwx3.sinaimg.cn&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=auto?sec=1658045304&t=01f38bc14c05be4585081daa73c93146'
        params['uid'] = 'test'
        params['seqid'] = '1626340993.8476272'
        params['deviceId'] = 'test'
        params['Timestamp'] = 'test'
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/camera_inspection'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        # print('入参:', params)
        # print("result", result)
        print('result', result)
        if result['code'] == '10000':
            result['data'] = self.decrypt(result['data'])
            print("result", result)

    def checkCameraImgv3OCR(self, img_path):
        '''摄像头巡检服务接口API'''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['DID'] = 'test'
        params['project_id'] = 'test'
        params['province_code'] = 'test'
        params['imageContent'] = str(img_data, 'utf-8')
        params['seqid'] = '1626340993.8476272'
        params['file_type'] = 'img'
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/checkCameraImg'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        # print('入参:', params)
        # print("result", result)
        print('result', result)
        if result['code'] == '10000':
            result['data'] = self.decrypt(result['data'])
            print("result", result)

    def pig_detection(self, img_path):
        ''' 猪数量检测服务API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'pig_detection'
        params['image'] = str(img_data, 'utf-8')

        params = self.getSignParams(params)

        # method = 'GET'
        path = '/pig_detection'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data'] = self.decrypt(data)
            # print(self.decrypt(data))
            print(result)

    def kitchen_analysis(self, img_path):
        ''' 明厨亮灶服务API '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'kitchen_analysis'
        params['timestamp'] = '1528787199'
        params['DID'] = 'TEST'
        params['uid'] = '1'
        params['project_id'] = '1'
        params['province_code'] = '800'
        params['Imagetype'] = ["010"]
        params['seqid'] = '26f2739a-6e0f-11e8-bc7a-58fb8443ee27'
        params['image'] = str(img_data, 'utf-8')

        params = self.getSignParams(params)

        # method = 'GET'
        path = '/kitchen_analysis'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data'] = self.decrypt(data)
            # print(self.decrypt(data))
            print(result)

    def picToText(self, img_path):
        ''' 数字生活ocr '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'picToText'
        params['imageType'] = '10003'
        params['requestId'] = '01e516ef-f76e-4c8e-8018-8305614a87fe'
        params['imageUrl'] = "https://preview.cloud.189.cn/image/imageAction?param=E49AA92538A5F1DB87331D344FADBC4483B832D536A4FA8535BA5B77642FCE9535EFA3EB3C075A53F498D7ABCBB8D734F5451AFA5C46422377154758F7DB0049950311874BFAB480621F6D87939FC7EC81807F18162209CD9E16FAFF205F758CD3D814C711F3A9A8B6015A7870BA419BDE2AF448"

        params = self.getSignParams(params)

        # method = 'GET'
        path = '/picToText'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data'] = self.decrypt(data)
            # print(self.decrypt(data))
            print(result)
    def delete_task(self):
        ''' 告警事件任务删除服务接口'''
        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'delete_task'
        params['userId'] = '98431325'
        params['secretId'] = 'a455xcoc78d1'
        params['taskId'] = '123'
        params['Timestamp'] = '1528787199'
        params['seqid'] = '26f2739a-6e0f-11e8-bc7a-58fb8443ee27'
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/delete_task'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data'] = self.decrypt(data)
            # print(self.decrypt(data))
            print(result)

    def create_task(self):
        ''' 告警事件任务创建服务接口'''
        params = {
            "userId": "98431325",
            "secretId": "a455xcoc78d1",
            "Timestamp": 1528787199,
            "seqid": "26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
            "taskId": "123",
            "event_type": "0001",
            "strategy": "1",
            "result_receiver": {
                "type": "HTTP",
                "uri": "uri",
                "method": "post"
            },
            "event_define_message": "event message",
            "alarm_start_time": "2020-08-20 08:00:00",
            "alarm_end_time": "2020-08-20 20:59:59",
            "camera_type": "realtime",
            "cameraId_list": [{
                "camera_id": "01",
                "camera_uri": "uri"
            }
            ],
            "event_config": {},
            "alarm_strategy": 0,
            "alarm_rate": 10,
            "track_strategy": "FINISH"
        }
        params['method'] = 'create_task'

        params = self.getSignParams(params)

        # method = 'GET'
        path = '/create_task'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data'] = self.decrypt(data)
            # print(self.decrypt(data))
            print(result)

    def search_task(self):
        ''' 告警事件任务查询服务接口'''
        params = {
            "userId": "98431325",
            "secretId": "a455xcoc78d1",
            "Timestamp": 1528787199,
            "seqid": "26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
            "taskId": "123",
        }
        params['method'] = 'search_task'

        params = self.getSignParams(params)

        # method = 'GET'
        path = '/search_task'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data'] = self.decrypt(data)
            # print(self.decrypt(data))
            print(result)

    def fire_discern(self, img_path):
        ''' 火焰识别 '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'fire_discern'
        params['image'] = str(img_data, 'utf-8')
        params['timestamp'] = 1528787199
        params['seqid'] = '26f2739a-6e0f-11e8-bc7a-58fb8443ee27'
        params['uid'] = '1111'

        params = self.getSignParams(params)

        # method = 'GET'
        path = '/fire_discern'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data'] = self.decrypt(data)
            # print(self.decrypt(data))
            print(result)

    def staffquitpost(self, img_path):
        ''' 人员离岗 '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'staffquitpost'
        params['image'] = str(img_data, 'utf-8')
        params['timestamp'] = 1528787199
        params['seqid'] = '26f2739a-6e0f-11e8-bc7a-58fb8443ee27'
        params['uid'] = '1111'
        params['work_area_list'] = [{'x':1,'y':2},{'x':1,'y':2},{'x':1,'y':2},{'x':1,'y':2},]

        params = self.getSignParams(params)

        # method = 'GET'
        path = '/staffquitpost'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data'] = self.decrypt(data)
            # print(self.decrypt(data))
            print(result)

    def fall_detection(self, img_path):
        ''' 跌倒检测 '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'fall_detection'
        params['image'] = str(img_data, 'utf-8')
        params['timestamp'] = 1528787199
        params['seqid'] = '26f2739a-6e0f-11e8-bc7a-58fb8443ee27'
        params['uid'] = '1111'
        params['work_area_list'] = [{'x':1,'y':2},{'x':1,'y':2},{'x':1,'y':2},{'x':1,'y':2},]

        params = self.getSignParams(params)

        # method = 'GET'
        path = '/fall_detection'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data'] = self.decrypt(data)
            # print(self.decrypt(data))
            print(result)

    def gathered(self, img_path):
        ''' 人群聚集 '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {}
        # params['id_card_side'] = id_card_side
        params['method'] = 'gathered'
        params['image'] = str(img_data, 'utf-8')
        params['timestamp'] = 1528787199
        params['seqid'] = '26f2739a-6e0f-11e8-bc7a-58fb8443ee27'
        params['uid'] = '1111'
        params['work_area_list'] = [{'x':1,'y':2},{'x':1,'y':2},{'x':1,'y':2},{'x':1,'y':2},]

        params = self.getSignParams(params)

        # method = 'GET'
        path = '/gathered'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data'] = self.decrypt(data)
            # print(self.decrypt(data))
            print(result)

    def get_feature(self, img_path):
        ''' 人像特征提取 '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {
            "userId": "98431325",
            "secretId": "a455xcoc78d1",
            "Timestamp": 1528787199,
            "seqid": "26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
            "taskId": "123",
        "type":"FACE",
        "veision":"1"
        }
        # params['id_card_side'] = id_card_side
        params['method'] = 'get_feature'
        params['image'] = str(img_data, 'utf-8')


        params = self.getSignParams(params)

        # method = 'GET'
        path = '/get_feature'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data'] = self.decrypt(data)
            # print(self.decrypt(data))
            print(result)

    def create_feature(self, img_path):
        ''' 人像创建 '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = data = {
    "userId": "1",
    "secretId": "",
    "Timestamp": 1528787199,
    "seqid": "8f43ee27",
    "group_name":"group_test",
    "type": "FACE",
    "version": "1",
    "feature_list": [{
                    "featureId":"123",
                    "featureData":"featureData",
                    "name_type":1
    }]
}
        # params['id_card_side'] = id_card_side
        params['method'] = 'openapi/create_feature'
        # params['image'] = str(img_data, 'utf-8')


        params = self.getSignParams(params)

        # method = 'GET'
        path = '/create_feature'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data'] = self.decrypt(data)
            # print(self.decrypt(data))
            print(result)

    def delete_feature(self, img_path):
        ''' 人像删除 '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {"userId":"1",
        "secretId":"",
        "Timestamp": 1528787199,
        "seqid": "8f43ee27",
        "feature_list":["0007"],
        "group_name":"group_test"
        }
        # params['id_card_side'] = id_card_side
        params['method'] = 'delete_feature'
        # params['image'] = str(img_data, 'utf-8')

        params = self.getSignParams(params)

        # method = 'GET'
        path = '/delete_feature'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data'] = self.decrypt(data)
            # print(self.decrypt(data))
            print(result)

    def delete_index(self, img_path):
        ''' 人像库删除 '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {
            "userId":"98431325",
            "secretId":"a455xcoc78d1",
            "Timestamp":1528787199,
            "seqid":"26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
            "group_name":"group1"
        }
        # params['id_card_side'] = id_card_side
        params['method'] = 'delete_index'
        # params['image'] = str(img_data, 'utf-8')

        params = self.getSignParams(params)

        # method = 'GET'
        path = '/delete_index'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data'] = self.decrypt(data)
            # print(self.decrypt(data))
            print(result)

    def create_index(self, img_path):
        ''' 人像库创建 '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {
            "userId":"98431325",
            "secretId":"a455xcoc78d1",
            "Timestamp":1528787199,
            "seqid":"26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
            "group_name":"group1",
            "version":"100",
            "massage":"the description of group1",
            "type":1,
        }
        # params['id_card_side'] = id_card_side
        params['method'] = 'create_index'
        # params['image'] = str(img_data, 'utf-8')

        params = self.getSignParams(params)

        # method = 'GET'
        path = '/create_index'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data'] = self.decrypt(data)
            # print(self.decrypt(data))
            print(result)

    def search_index(self, img_path):
        ''' 人像库查询 '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {
            "userId":"98431325",
            "secretId":"a455xcoc78d1",
            "Timestamp":1528787199,
            "seqid":"26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
            "group_name":"group1"
        }
        # params['id_card_side'] = id_card_side
        params['method'] = 'search_index'
        # params['image'] = str(img_data, 'utf-8')

        params = self.getSignParams(params)

        # method = 'GET'
        path = '/search_index'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data'] = self.decrypt(data)
            # print(self.decrypt(data))
            print(result)

    def search_feature(self, img_path):
        ''' 人像查询 '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {
            "userId":"98431325",
            "secretId":"a455xcoc78d1",
            "Timestamp":1528787199,
            "seqid":"26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
            "group_name":"group1",
            "featureId":"0100",
            "name_type":0
        }
        # params['id_card_side'] = id_card_side
        params['method'] = 'search_feature'
        # params['image'] = str(img_data, 'utf-8')
        params = self.getSignParams(params)
        # method = 'GET'
        path = '/search_feature'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data'] = self.decrypt(data)
            # print(self.decrypt(data))
            print(result)

    def register_feature(self, img_path):
        ''' 人像注册 '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {"userId": "1",
        "secretId": "",
        "Timestamp": 1528787199,
        "seqid": "8f43ee27",
        "group_name": "group_test",
        "version": "0",
        "type": 1,
        "data": [{
            "image": str(img_data, encoding="utf-8"),
            "featureId": "0007",
            "name_type": 2},
        ]}
        # params['id_card_side'] = id_card_side
        params['method'] = 'register_feature'
        # params['image'] = str(img_data, 'utf-8')
        params = self.getSignParams(params)
        # method = 'GET'
        path = '/register_feature'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data'] = self.decrypt(data)
            # print(self.decrypt(data))
            print(result)

    def car_recognization(self, img_path):
        ''' 车辆违停服务接口 '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {
            "uid":"98431325",
            "timestamp":1528787199,
            "seqid":"26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
            "deviceId":"123456",
            "Imgtype":"10,11,12",
            "area":[100,90,50,33]
        }
        # params['id_card_side'] = id_card_side
        params['method'] = 'car_recognization'
        params['Image'] = str(img_data, 'utf-8')

        params = self.getSignParams(params)

        # method = 'GET'
        path = '/car_recognization'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data'] = self.decrypt(data)
            # print(self.decrypt(data))
            print(result)
    def electric_vehicle_detection(self, img_path):
        ''' 车辆违停服务接口 '''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())

        params = {
            "uid":"98431325",
            "timestamp":1528787199,
            "seqid":"26f2739a-6e0f-11e8-bc7a-58fb8443ee27",

        }
        # params['id_card_side'] = id_card_side
        params['method'] = 'electric_vehicle_detection'
        params['image'] = str(img_data, 'utf-8')

        params = self.getSignParams(params)

        # method = 'GET'
        path = '/electric_vehicle_detection'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data'] = self.decrypt(data)
            # print(self.decrypt(data))
            print(result)

    def pat_timephoto_video_task(self):
        ''' 时光缩影宠物视频推送接口'''
        params = {
            "uid": str(uuid.uuid4()),
            "requestId": str(uuid.uuid4()),
            "DID": "DID",
            "userAccount": "user",
            "serviceType": "serviceType",
            "videoUrl": "",
            "fileName": "20210630093558-20210630094058_ALARM.ps",
            "flag": "{'faceExactMatch': '1', 'intelligence': {'ifFace': '0', 'ifPerson': '1', 'ifPet': '1'}}",
            "fileId": "662221_18351922520_3TPB03514400GCC-1625016958000"
        }
        # params['id_card_side'] = id_card_side
        params['method'] = 'pat_timephoto_video_task'
        # params['image'] = str(img_data, 'utf-8')


        params = self.getSignParams(params)

        # method = 'GET'
        path = '/pat_timephoto_video_task'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data'] = self.decrypt(data)
            # print(self.decrypt(data))
            print(result)

    def pat_timephoto_compose_task(self):
        ''' 时光缩影宠物视频合成通知接口'''
        params = {
            "uid": "29d38d17-399f-43e3-8293-b8991fd5fed7",
            "requestId": "29d38d17-399f-43e3-8293-b8991fd5fed7",
            "DID": "6SDCA33471TU9XR",
            "userAccount": "18171789513",
            "serviceType": "tyai_timephoto",
            "startTime": "202111170000",
            "endTime": "202111172359",
            "interval": "60"
        }
        # params['id_card_side'] = id_card_side
        params['method'] = 'pat_timephoto_compose_task'
        # params['image'] = str(img_data, 'utf-8')


        params = self.getSignParams(params)

        # method = 'GET'
        path = '/pat_timephoto_compose_task'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data'] = self.decrypt(data)
            # print(self.decrypt(data))
            print(result)
    def timephoto_compose_task_common(self):
        ''' 时光缩影通用视频合成通知接口'''
        params = {
            "subscribe_level":'b1',
            "province_code":'11',
            "project_id":'11',
            "uid":"身份识别码",
"requestId":"请求编号",
"DID":"设备编码",
"userAccount":"用户账号",
"serviceType":"业务类型",
"startTime":"202105080830",
"endTime":"202105081630",
"interval":"20",
"callback_uri":"http://xxxx",
"accessKey":'1',
"secretKey":'1',
"endpoint":'',
"region":"xxx",
"bucket":"xxx",
"verison":'100'
        }
        # params['id_card_side'] = id_card_side
        params['method'] = 'timephoto_compose_task_common'
        # params['image'] = str(img_data, 'utf-8')


        params = self.getSignParams(params)

        # method = 'GET'
        path = '/timephoto_compose_task_common'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data'] = self.decrypt(data)
            # print(self.decrypt(data))
            print(result)

    def timephoto_video_task_common(self):
        ''' 通用时光缩影视频推送'''
        params = {

            "uid": str(uuid.uuid4()),
            "requestId": str(uuid.uuid4()),
            "DID": "DID",
            "userAccount": "user",
            "serviceType": "serviceType",
            "video_uri": "",
            "fileName": "20210630093558-20210630094058_ALARM.ps",
            "flag": {'faceExactMatch': '1', 'intelligence': {'ifFace': '0', 'ifPerson': '1', 'ifPet': '1'}},
            "fileId": "662221_18351922520_3TPB03514400GCC-1625016958000",
            "seqid":'11',
            "subscribe_level":"bl",
            "province_code":'1',
            "project_id":"project_id",
            "timestamp":"timestamp",
            "version":"1"
        }
        # params['id_card_side'] = id_card_side
        params['method'] = 'timephoto_video_task_common'
        # params['image'] = str(img_data, 'utf-8')

        params = self.getSignParams(params)

        # method = 'GET'
        path = '/timephoto_video_task_common'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data'] = self.decrypt(data)
            # print(self.decrypt(data))
            print(result)

    def timephoto_face_insert_common(self,img_path):
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())
        ''' 通用时光缩影人脸下发'''
        params = {
                'project_id': 'test',
    'province_code': 'test',
    'subscribe_level': '0',
    'uid': 'test',
    'timestamp': str(int(time.time())),
    'seqid': 'test',
    'DID': 'test',
    'face_id': 'test',
    'image': ''
        }
        # params['id_card_side'] = id_card_side
        params['method'] = 'timephoto_face_insert_common'
        # params['image'] = str(img_data, 'utf-8')

        params = self.getSignParams(params)

        # method = 'GET'
        path = '/timephoto_face_insert_common'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data'] = self.decrypt(data)
            # print(self.decrypt(data))
            print(result)

    def timephoto_face_delete_common(self,img_path):
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())
        ''' 通用时光缩影人脸删除'''
        params = {
            'project_id': 'test',
            'province_code': 'test',
            'subscribe_level': '0',
            'uid': 'test',
            'timestamp': str(int(time.time())),
            'seqid': 'test',
            'DID': 'test',
            'face_id': 'test'
        }
        # params['id_card_side'] = id_card_side
        params['method'] = 'timephoto_face_delete_common'
        # params['image'] = str(img_data, 'utf-8')

        params = self.getSignParams(params)

        # method = 'GET'
        path = '/timephoto_face_delete_common'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data'] = self.decrypt(data)
            # print(self.decrypt(data))
            print(result)

    def update(self):
        ''' 店铺更新能力'''
        params = {
            "timestamp": 1528787199,
            "seqid": "26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
            "token": " token",
            "UID": "594a5998b2e48e08088259ff",
            "SID": "594a59cf59594868fdf33dc2",
            "name": "Store A",
            "externalId": "string",
            "version":100
        }
        # params['id_card_side'] = id_card_side
        params['method'] = 'update'
        # params['image'] = str(img_data, 'utf-8')


        params = self.getSignParams(params)

        # method = 'GET'
        path = '/store_api/store/update'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data'] = self.decrypt(data)
            # print(self.decrypt(data))
            print(result)

    def list(self):
        ''' 获取店铺清单能力服务接口'''
        params = {
            "timestamp": 1528787199,
            "seqid": "26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
            "token": "user token",
            "withZones": True,
            'UID':'1',
            "SID": "594a59cf59594868fdf33dc2",
            "version": '1'
        }
        # params['id_card_side'] = id_card_side
        params['method'] = 'update'
        # params['image'] = str(img_data, 'utf-8')


        params = self.getSignParams(params)

        # method = 'GET'
        path = '/store_api/stores/list'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data'] = self.decrypt(data)
            # print(self.decrypt(data))
            print(result)

    def camera(self):
        ''' 编辑摄像头'''
        params = {
            "timestamp": 1528787199,
            "seqid": "26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
            "token": "user token",
            "UID": "594a5998b2e48e08088259ff",
            "SID": "594a59cf59594868fdf33dc2",
            "CID":"fdffsfssgggeeg",
            "MAC": "da:66:1f:ef:b7:30",
            "name": "Camera A",
            "status": "enable",
            "cameraSN": "12032432423123",
            "description": "string",
            'version':100
        }
        # params['id_card_side'] = id_card_side
        params['method'] = 'camera'
        # params['image'] = str(img_data, 'utf-8')


        params = self.getSignParams(params)

        # method = 'GET'
        path = '/camera_api/edit/camera'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data'] = self.decrypt(data)
            # print(self.decrypt(data))
            print(result)

    def cameralist(self):
        ''' 获取摄像头清单'''
        params = {
            "timestamp": 1528787199,
            "seqid": "26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
            "token": "user token",
            "UID": "594a5998b2e48e08088259ff",
            "SID": ["594a59cf59594868fdf33dc2,1111"],
            "zoneId": "1",
            "version":"100"
        }
        # params['id_card_side'] = id_card_side
        params['method'] = 'cameralist'
        # params['image'] = str(img_data, 'utf-8')


        params = self.getSignParams(params)

        # method = 'GET'
        path = '/camera_api/get/cameralist'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data'] = self.decrypt(data)
            # print(self.decrypt(data))
            print(result)

    def delete_camera(self):
            ''' 获取摄像头清单'''
            params = {
                "timestamp": 1528787199,
                "seqid": "26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
                "token": "user token",
                "UID": "594a5998b2e48e08088259ff",
                "CIDs": ["5a005de382933ad8f389603f"],
                "deleteWhatEver": False,
                'version': 100
            }
            # params['id_card_side'] = id_card_side
            params['method'] = 'camera'
            # params['image'] = str(img_data, 'utf-8')


            params = self.getSignParams(params)

            # method = 'GET'
            path = '/camera_api/delete/camera'

            # print(self.getRequestString(path,params,method)) # 调试用
            result = self.decryptApi(path, params)
            print("result", result)

            # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
            # data = result['data']
            # print("data",data)
            if result['code'] == '10000':
                data = result['data']
                result['data'] = self.decrypt(data)
                # print(self.decrypt(data))
                print(result)

    def add_camera(self):
            ''' 添加摄像头'''
            params = {
                "timestamp": 1528787199,
                "seqid": "26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
                "token": "user token",
                "UID": "594a5998b2e48e08088259ff",
                "SID": "594a59cf59594868fdf33dc2",
                "MAC": "da:66:1f:ef:b7:30",
                "cameraSN": "12032432423121",
                "description": "string",
                "dataStreamType": "normal",
                "zoneId": "string",
                "name": "Camera B",
                "type": "flow",
                "equipmentType": "common",
                "status": "enable",
                "version":100,
                "cameraUri":'112'
            }
            # params['id_card_side'] = id_card_side
            params['method'] = 'camera'
            # params['image'] = str(img_data, 'utf-8')


            params = self.getSignParams(params)

            # method = 'GET'
            path = '/camera_api/add/camera'

            # print(self.getRequestString(path,params,method)) # 调试用
            result = self.decryptApi(path, params)
            print("result", result)

            # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
            # data = result['data']
            # print("data",data)
            if result['code'] == '10000':
                data = result['data']
                result['data'] = self.decrypt(data)
                # print(self.decrypt(data))
                print(result)

    def chart(self):
        ''' 客流报表能力服务接口'''
        params = {
            "chartType": "line",
"interval": "1d",
"aggregations": [
{
  "_id": "SID",
  "values": ["the-sid-1","the-sid-2"]
},
{
  "_id": "zoneId",
  "values": ["the-zone-1"]
},
{
  "_id": "personType",
  "values": ["customer"]
},
{
  "_id": "gender",
  "values": [0, 1]
},
{
  "_id": "ageRange",
  "values": [5,12,6]
},
{
  "_id": "faceExpression",
  "values": [2,4]
},
{
  "_id": "visitSum",
  "values": ["*-2","2-*"]
},
{
  "_id": "visitCountOfDay",
  "values": [ "*-2","2-*"]
},
{
  "_id": "visitDays",
  "values": [ "*-2", "2-*" ]
},
{
  "_id": "duration",
  "values": ["*-180000","180000-300000"]
},
{
  "_id": "polygons",
  "values": [
    [
      [1, 2],
      [3, 4],
      [5, 6],
      [7, 8]
    ],
    [
      [1, 2],
      [3, 4],
      [5, 6],
      [7, 8]
    ]
  ]
}
],
"filters": [
{
  "_id": "SID",
  "values": ["the-sid-1","the-sid-2"]
},
{
  "_id": "zoneId",
  "values": ["the-zone-1"]
},
{
  "_id": "zoneScope",
  "values": ["the-zone-scope-1"]
},
{
  "_id": "personType",
  "values": ["customer"]
},
{
  "_id": "gender",
  "values": [0,1]
},
{
  "_id": "ageRange",
  "values": [5,12,6]
},
{
  "_id": "faceExpression",
  "values": [2,4]
},
{
  "_id": "visitSum",
  "values": ["*-2","2-*"]
},
{
  "_id": "visitCountOfDay",
  "values": ["*-2","2-*"]
},
{
  "_id": "visitDays",
  "values": ["*-2","2-*"]
},
{
  "_id": "duration",
  "values": ["*-180000","180000-300000"]
},
{
  "_id": "polygons",
  "values": [
    [
      [1,2],
      [3,4],
      [5,6],
      [7,8]
    ],
    [
      [1,2],
      [3,4],
      [5,6],
      [7,8]
    ]
  ]
}
],
"excludes": [
{
  "_id": "SID",
  "values": ["the-sid-1","the-sid-2"]
},
{
  "_id": "zoneId",
  "values": ["the-zone-1"]
},
{
  "_id": "zoneScope",
  "values": ["the-zone-scope-1"]
},
{
  "_id": "personType",
  "values": ["customer"]
},
{
  "_id": "gender",
  "values": [0,1]
},
{
  "_id": "ageRange",
  "values": [5,12,6]
},
{
  "_id": "faceExpression",
  "values": [2,4]
},
{
  "_id": "visitSum",
  "values": ["*-2","2-*"]
},
{
  "_id": "visitCountOfDay",
  "values": ["*-2","2-*"]
},
{
  "_id": "visitDays",
  "values": ["*-2","2-*"]
},
{
  "_id": "duration",
  "values": ["*-180000","180000-300000"]
},
{
  "_id": "polygons",
  "values": [
    [
      [1,2],
      [3,4],
      [5,6],
      [7,8]
    ],
    [
      [1,2],
      [3,4],
      [5,6],
      [7,8]
    ]
  ]
}
],
"withRecordIds": False,
"countingBy": "daily-visit",
"sumByField": "string",
"start": "2021-12-12 09:26:21",
"end": "2021-12-12 10:26:21",
"visitTimeQuery": "all-day"

        }
        # params['id_card_side'] = id_card_side
        params['method'] = 'chart'
        # params['image'] = str(img_data, 'utf-8')


        params = self.getSignParams(params)

        # method = 'GET'
        path = '/flow_api/flow/chart'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data'] = self.decrypt(data)
            # print(self.decrypt(data))
            print(result)

    def summary(self):
        ''' 客流统计能力服务接口'''
        params = {
            "uid":"946464654",
            "timestamp": 1528787199,
            "seqid": "26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
            "token": "token",
        "UID": "594a5998b2e48e08088259ff",
        "SID": "594a59cf59594868fdf33dc2",
        "zoneId": 3600,
        "personType": "vip",
        "start": "2021-12-12 09:26:21",
        "end": "2021-12-12 10:26:21",
        }
        # params['id_card_side'] = id_card_side
        params['method'] = 'summary'
        # params['image'] = str(img_data, 'utf-8')
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/flow_api/flow/summary'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data'] = self.decrypt(data)
            # print(self.decrypt(data))
            print(result)

    def personnel_get(self):
        ''' 客流统计能力服务接口'''
        params = {
            "timestamp": 1528787199,
            "seqid": "26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
            "token": " token",
            "id": "unique-id",
            "UID": "594a5998b2e48e08088259ff",
            "SID": "594a59cf59594868fdf33dc2",
            "version":'100'
        }
        # params['id_card_side'] = id_card_side
        params['method'] = 'get'
        # params['image'] = str(img_data, 'utf-8')
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/personnel_api/personnel/get'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data'] = self.decrypt(data)
            # print(self.decrypt(data))
            print(result)

    def personnel_list(self):
        ''' 人员库查询'''
        params = {
            "timestamp": 1528787199,
            "seqid": "26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
            "token": " token",
            "UID": "594a5998b2e48e08088259ff",
            "SID": "594a59cf59594868fdf33dc2",
            "type": "staff",
            "page": 1,
            "limit": 30,
            "version":100
        }
        # params['id_card_side'] = id_card_side
        params['method'] = 'list'
        # params['image'] = str(img_data, 'utf-8')
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/personnel_api/personnel/list'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data'] = self.decrypt(data)
            # print(self.decrypt(data))
            print(result)

    def total(self):
        ''' 人员统计'''
        params = {
            "timestamp": 1528787199,
            "SID":'777',
            "version":'100',
            "seqid": "26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
            "token": " token",
            "UID": "594a5998b2e48e08088259ff",
                "SIDs": [
                    "594a59cf59594868fdf33dc2"
                ],
                "personTypes": [
                    "staff"
                ],
                "departmentId": "string",
                "search": "Bob Dylon",
            "searchBy": "name"
        }
        # params['id_card_side'] = id_card_side
        params['method'] = 'store'
        # params['image'] = str(img_data, 'utf-8')
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/personnel_api/personnel/total'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data'] = self.decrypt(data)
            # print(self.decrypt(data))
            print(result)

    def faceDelete(self):
        ''' 名单删除服务接口'''
        params = {
            "uid": "26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
            "seqid": "26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
            "groupId": "group1",
            "faceList":[{" faceFeatureId ":"1"}]
        }
        # params['id_card_side'] = id_card_side
        params['method'] = 'faceDelete'
        # params['image'] = str(img_data, 'utf-8')
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/faceDelete'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data'] = self.decrypt(data)
            # print(self.decrypt(data))
            print(result)

    def faceSet(self):
        ''' 黑白名单设定服务接口'''
        params = {
            "uid": "26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
            "requestId": "26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
            "groupId": "group1",
            "faceList":[{
            "faceImageFileId ":"111",
            "fileUrl":"url",
            "namelistType":"0",}
            ],
        }
        # params['id_card_side'] = id_card_side
        params['method'] = 'faceSet'
        # params['image'] = str(img_data, 'utf-8')
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/faceSet'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data'] = self.decrypt(data)
            # print(self.decrypt(data))
            print(result)

    def analysisService(self):
        ''' 人脸/车辆解析服务接口   '''
        params = {
            "timestamp": 1528787199,
            "seqid": "26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
            "deviceid": "xxxxxxxxxx",
            "fileurl": "https://xxxxxxxxxxxxxxxxxxx/xxx.jpg",
            "Imgtype": "00,01,02,10",
            "groupId": "group1",
            "passerby": "0",
            "version":100
        }
        # params['id_card_side'] = id_card_side
        params['method'] = 'analysisService'
        # params['image'] = str(img_data, 'utf-8')
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/analysisService'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data'] = self.decrypt(data)
            # print(self.decrypt(data))
            print(result)

    def sceneRecog(self):
        ''' 图片场景类型识别服务接口 '''
        params = {
            "timestamp": 1528787199,
            "seqid": "26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
            "uid": "11111",
            "imageUrl": "asdasdasda",
            "version":100,
            "requestId":'111'
        }
        # params['id_card_side'] = id_card_side
        params['method'] = 'sceneRecog'
        # params['image'] = str(img_data, 'utf-8')
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/sceneRecog'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data'] = self.decrypt(data)
            # print(self.decrypt(data))
            print(result)

    def fireProtect(self):
        ''' 森林防火 '''
        params = {
            "timestamp": 1528787199,
                "seqid": "26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
            "deviceid": "xxxxxxxxxx",
            "Imgtpye": "0,1",
            "fileurl": "https://xxxxxxxxxxxxxxxxxxx/xxx.jpg",
            "version":100
        }
        # params['id_card_side'] = id_card_side
        params['method'] = 'fireProtect'
        # params['image'] = str(img_data, 'utf-8')
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/fireProtect'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data'] = self.decrypt(data)
            # print(self.decrypt(data))
            print(result)

    def resultPic(self):
        ''' 明厨亮灶结果推送服务接口'''
        params = {
            "uid": "26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
            "Timestamp": 1528787199,
            "seqid": "26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
            "deviceid": "185309624863ELLK24333K36XY",
            "userAccount":"111" ,
            "Imgtype":"01",
            "fileUrl": "http://11",
        }
        # params['id_card_side'] = id_card_side
        params['method'] = 'resultPic'
        # params['image'] = str(img_data, 'utf-8')
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/resultPic'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data'] = self.decrypt(data)
            # print(self.decrypt(data))
            print(result)

    def avatar_delete(self):
        ''' 删除人员头像照片能力'''
        params = {
            "version":100,
            "timestamp": 1528787199,
            "seqid": "26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
            "token": " token",
            "id": "111",
            "UID": "594a5998b2e48e08088259ff",
            "SID": "594a59cf59594868fdf33dc2",
            "FDID": "605c652e73d47dad41dd5f1c",
                "avatarIds": [
                  [
                    "123",
                    "877"
                  ]
                ]
            }
        # params['id_card_side'] = id_card_side
        params['method'] = 'avatar_delete'
        # params['image'] = str(img_data, 'utf-8')
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/personnel_api/personnel/avatar/delete'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data'] = self.decrypt(data)
            # print(self.decrypt(data))
            print(result)

    def avatar_add(self,img_path):
        ''' 添加人员头像照片能力'''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())
        params = {
            "version":100,
            "timestamp": 1528787199,
            "seqid": "26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
            "token": " token",
            "id": "111",
            "UID": "594a5998b2e48e08088259ff",
            "SID": "594a59cf59594868fdf33dc2",
            "FDID": "605c652e73d47dad41dd5f1c",
            "avatar": "111",
            "mergeOverScore": 0.8,
            "imgb64":str(img_data,'utf-8')
            }
        # params['id_card_side'] = id_card_side
        params['method'] = 'avatar_add'
        # params['image'] = str(img_data, 'utf-8')
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/personnel_api/personnel/avatar/add'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data'] = self.decrypt(data)
            # print(self.decrypt(data))
            print(result)

    def avatar_update(self,img_path):
        ''' 替换人员头像照片能力服务接口'''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())
        params = {
            "version":100,
            "timestamp": 1528787199,
            "seqid": "26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
            "token": " token",
            "id": "111",
            "UID": "594a5998b2e48e08088259ff",
            "SID": "594a59cf59594868fdf33dc2",
            "FDID": "605c652e73d47dad41dd5f1c",
            "avatar": "111",
            "mergeOverScore": 0.8,
            "imgb64":str(img_data,'utf-8')
            }
        # params['id_card_side'] = id_card_side
        params['method'] = 'update'
        # params['image'] = str(img_data, 'utf-8')
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/personnel_api/personnel/avatar/update'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data'] = self.decrypt(data)
            # print(self.decrypt(data))
            print(result)

    def personnel_delete(self,img_path):
        ''' 删除人员资料'''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())
        params = {
            "version":100,
            "timestamp": 1528787199,
            "seqid": "26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
            "token": " token",
            "id": "111",
            "UID": "594a5998b2e48e08088259ff",
            "SID": "594a59cf59594868fdf33dc2",
            "FDID": "605c652e73d47dad41dd5f1c",
            # "avatar": "111",
            # "mergeOverScore": 0.8,
            # "imgb64":str(img_data,'utf-8')
            }
        # params['id_card_side'] = id_card_side
        params['method'] = 'delete'
        # params['image'] = str(img_data, 'utf-8')
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/personnel_api/personnel/delete'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data'] = self.decrypt(data)
            # print(self.decrypt(data))
            print(result)

    def personnel_new(self,img_path):
        ''' 新增人员入库能力服务接口'''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())
        params = {
            "version": 100,
            "imgb64": str(img_data, 'utf-8'),
            "timestamp": 1528787199,
            "seqid": "26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
            "token": " token",
        "UID": "594a5998b2e48e08088259ff",
        "SID": "594a59cf59594868fdf33dc2",
        "FDID": "605c652e73d47dad41dd5f1c",
        "name": "string",
        "type": "stuff",
        "externalId": "string",
        "description": "string",
        "avatar": "string",
        "phoneNumber": "string"
            }
        # params['id_card_side'] = id_card_side
        params['method'] = 'new'
        # params['image'] = str(img_data, 'utf-8')
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/personnel_api/personnel/new'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data'] = self.decrypt(data)
            # print(self.decrypt(data))
            print(result)

    def personnel_update(self,img_path):
        ''' 修改人员资料能力服务'''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())
        params = {
            "version": 100,
            # "imgb64": str(img_data, 'utf-8'),
            "timestamp": 1528787199,
            "seqid": "26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
            "token": " token",
            "id": "unique-id",
            "UID": "594a5998b2e48e08088259ff",
            "SID": "594a59cf59594868fdf33dc2",
            "FDID": "605c652e73d47dad41dd5f1c",
            "name": "Bob Dylan",
            "attributes": "string",
            "type": "staff",
            "phoneNumber": "string",
            "description": "string",
            "departmentId": "string",
            "contactId": "string"
            }
        # params['id_card_side'] = id_card_side
        params['method'] = 'update'
        # params['image'] = str(img_data, 'utf-8')
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/personnel_api/personnel/update'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        if result['code'] == '10000':
            data = result['data']
            result['data'] = self.decrypt(data)
            # print(self.decrypt(data))
            print(result)

    def get_store(self,img_path):
        ''' 获取指定店铺信息'''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())
        params = {
            "timestamp": 1528787199,
            "seqid": "26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
            "token": "user token",
            "UID": "594a5998b2e48e08088259ff",
            "withFaceSearching": True,
            "SID": "594a59cf59594868fdf33dc2",
            "version":100
            }
        # params['id_card_side'] = id_card_side
        params['method'] = 'store'
        # params['image'] = str(img_data, 'utf-8')
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/store_api/store'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        try:
            if result['code'] == '10000':
                data = result['data']
                result['data'] = self.decrypt(data)
                print(self.decrypt(data))
        except:
            pass
    def add_store(self,img_path):
        ''' 店铺添加能力服务'''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())
        params = {
            "timestamp": 1528787199,
"seqid": "26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
"token": " token",
"UID": "594a5998b2e48e08088259ff",
    "name": "Store A",
    "externalId": "string",
    "regionId": "string",
"solutionVersion": "2",
            "version":100
            }
        # params['id_card_side'] = id_card_side
        params['method'] = 'store'
        # params['image'] = str(img_data, 'utf-8')
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/store_api/store/add'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        try:
            if result['code'] == '10000':
                data = result['data']
                result['data'] = self.decrypt(data)
                print(self.decrypt(data))
        except:
            pass

    def NotUserInfo(self,img_path):
            ''' 非电信员工信息及附件同步接口'''
            with open(img_path, 'rb') as f:
                img_data = base64.b64encode(f.read())
            params = {
                    'idcode':'111',
                    'number':'123',
                    'file':str(img_data,'utf-8'),

                }
            # params['id_card_side'] = id_card_side
            params['method'] = 'NotUserInfo'
            # params['image'] = str(img_data, 'utf-8')
            params = self.getSignParams(params)

            # method = 'GET'
            path = '/RegistWork/NotUserInfo'

            # print(self.getRequestString(path,params,method)) # 调试用
            result = self.decryptApi(path, params)
            print("result", result)

            # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
            # data = result['data']
            # print("data",data)
            try:
                if result['code'] == '10000':
                    data = result['data']
                    result['data'] = self.decrypt(data)
                    print(self.decrypt(data))
            except:
                pass

    def rtspinfo(self,img_path):
            ''' 非电信员工信息及附件同步接口'''
            with open(img_path, 'rb') as f:
                img_data = base64.b64encode(f.read())
            params = {
                    "Province ":  11,
    "dcId ":  10000,
"roomName":  "xxx",
    "roomNum":  1,
    "cameraNum":  "01679e82265b427c8b2a22ea5dff221b ",
    "rtspUrl": "rtsp://10.143.165.50:555/xxx",
    "action":1

                }
            # params['id_card_side'] = id_card_side
            params['method'] = 'rtspinfo'
            # params['image'] = str(img_data, 'utf-8')
            params = self.getSignParams(params)

            # method = 'GET'
            path = '/StreamAnalysis/rtspinfo'

            # print(self.getRequestString(path,params,method)) # 调试用
            result = self.decryptApi(path, params)
            print("result", result)

            # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
            # data = result['data']
            # print("data",data)
            try:
                if result['code'] == '10000':
                    data = result['data']
                    result['data'] = self.decrypt(data)
                    print(self.decrypt(data))
            except:
                pass

    def UserInfo(self, img_path):
        ''' 电信员工信息验证'''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())
        params = {
            "prov_id":"835",
            'idcode':'111',
            'number':'123',
            'name':'123',
        }
        # params['id_card_side'] = id_card_side
        params['method'] = 'UserInfo'
        # params['image'] = str(img_data, 'utf-8')
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/RegistWork/UserInfo'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        try:
            if result['code'] == '10000':
                data = result['data']
                result['data'] = self.decrypt(data)
                print(self.decrypt(data))
        except:
            pass

    def ai_data_feedback(self, img_path):
        ''' AI场景数据准确性反馈服务接口'''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())
        params = {
    "uid": "身份识别码",
    "requestId": "请求编号",
    "DID": "设备编码",
    "userAccount": "用户账号",
    "serviceType": "业务类型",
    "feedbackData": {
        "fileUrl": "反馈的文件下载地址",
        "feedbackType": "0-准确，1-不准确",
        "extendData": {
            "videoQuality": "摄像头巡检质量结果",
        }
    }
}
        # params['id_card_side'] = id_card_side
        params['method'] = 'ai_data_feedback'
        # params['image'] = str(img_data, 'utf-8')
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/ai_data_feedback'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        try:
            if result['code'] == '10000':
                data = result['data']
                result['data'] = self.decrypt(data)
                print(self.decrypt(data))
        except:
            pass

    def retrieval_feature(self, img_path):
        ''' 人像检索（1vN）服务接口'''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())
        params = {
        "uid":"58fb8443ee27"	,
        "Timestamp":1528787199,
        "seqid":"26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
        "userId":"98431325",
        "secretId":"a455xcoc78d1",
        "featureData":[1,1,11],
        "limit":1,
        "threshold":0.1,
        "group_name":"group1",
}
        # params['id_card_side'] = id_card_side
        params['method'] = 'retrieval_feature'
        # params['image'] = str(img_data, 'utf-8')
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/portrait_task/retrieval_feature'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        try:
            if result['code'] == '10000':
                data = result['data']
                result['data'] = self.decrypt(data)
                print(self.decrypt(data))
        except:
            pass

    def vehicle_task_create_index(self, img_path):
        ''' 车辆布控库创建服务接口'''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())
        params = {
"uid":"58fb8443ee27"	,
"Timestamp":1528787199,
"seqid":"26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
"userId":"98431325",
"secretId":"a455xcoc78d1",
"group_name": "group1",
	"version": "1",
	"massage": "the description of group1",
	"type": "VEHICLE",
}
        # params['id_card_side'] = id_card_side
        params['method'] = 'create_index'
        # params['image'] = str(img_data, 'utf-8')
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/vehicle_task/create_index'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        try:
            if result['code'] == '10000':
                data = result['data']
                result['data'] = self.decrypt(data)
                print(self.decrypt(data))
        except:
            pass

    def vehicle_task_delete_index(self, img_path):
        ''' 车辆布控库删除服务接口'''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())
        params = {
"Timestamp":1528787199,
"seqid":"26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
"userId":"98431325",
"secretId":"a455xcoc78d1",
"group_name": "group1",

}
        # params['id_card_side'] = id_card_side
        params['method'] = 'delete_index'
        # params['image'] = str(img_data, 'utf-8')
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/vehicle_task/delete_index'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        try:
            if result['code'] == '10000':
                data = result['data']
                result['data'] = self.decrypt(data)
                print(self.decrypt(data))
        except:
            pass

    def vehicle_task_search_feature(self, img_path):
        ''' 车辆布控库删除服务接口'''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())
        params = {
"Timestamp":1528787199,
"seqid":"26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
"userId":"98431325",
"secretId":"a455xcoc78d1",
"group_name": "group1",
"vehicleId": "0100",

}
        # params['id_card_side'] = id_card_side
        params['method'] = 'search_feature'
        # params['image'] = str(img_data, 'utf-8')
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/vehicle_task/search_feature'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        try:
            if result['code'] == '10000':
                data = result['data']
                result['data'] = self.decrypt(data)
                print(self.decrypt(data))
        except:
            pass

    def portrait_task_search_index(self, img_path):
        ''' 车辆布控库删除服务接口'''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())
        params = {
"Timestamp":1528787199,
"seqid":"26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
"userId":"98431325",
"secretId":"a455xcoc78d1",
"group_name": "group1",


}
        # params['id_card_side'] = id_card_side
        params['method'] = 'search_index'
        # params['image'] = str(img_data, 'utf-8')
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/vehicle_task/search_index'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        try:
            if result['code'] == '10000':
                data = result['data']
                result['data'] = self.decrypt(data)
                print(self.decrypt(data))
        except:
            pass

    def vehicle_task_delete_feature(self, img_path):
        ''' 车辆布控库删除服务接口'''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())
        params = {
"Timestamp":1528787199,
"seqid":"26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
"userId":"98431325",
"secretId":"a455xcoc78d1",
"group_name": "group1",
"vehicle_list": ['0','1'],
}
        # params['id_card_side'] = id_card_side
        params['method'] = 'delete_feature'
        # params['image'] = str(img_data, 'utf-8')
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/vehicle_task/delete_feature'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        try:
            if result['code'] == '10000':
                data = result['data']
                result['data'] = self.decrypt(data)
                print(self.decrypt(data))
        except:
            pass

    def vehicle_task_create_feature(self, img_path):
        ''' 车辆布控库删除服务接口'''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())
        params = {
"uid":"58fb8443ee27"	,
"Timestamp":1528787199,
"seqid":"26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
"userId":"98431325",
"secretId":"a455xcoc78d1",
	"group_name":"group1",
	"type":1,
	"version":"100",
	"data":[{
			"car_text":"闽A 12345",
			"vehicleId":"001",
			"name_type":0
			}]
}
        # params['id_card_side'] = id_card_side
        params['method'] = 'create_feature'
        # params['image'] = str(img_data, 'utf-8')
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/vehicle_task/create_feature'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        try:
            if result['code'] == '10000':
                data = result['data']
                result['data'] = self.decrypt(data)
                print(self.decrypt(data))
        except:
            pass

    def getSDInfo(self, img_path):
        ''' 工单无人员信息推送接口'''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())
        params = {
	"PROV_ID": "JT",
"DC_ID":"10002",
"ROOM_ID":"213/215",
	"FLOW_ID": "590007526998",
	"SYSTEM_ID": "AIGL",
	"SUBMIT_TIME": "2020/11/30 16:46",
	"SUBMIT_STAFF": "小李",
	"SUBMIT_ORG_NAME": "云化推进处",
	"TELPHONE": "12345678901",
	"EMAIL": "123@163.com",
	"SERIAL": "ROOM_ENTRY_20201130_791",
	"TITLE": "工单标题",
	"WORK_START_DATE": "2020/12/1 12:30:20",
	"WORK_END_DATE": "2020/12/3 12:30:20",
	"COMPUTER_ROOM_SITE": "昌平",
	"EQUIPMENT_SITE_NO": "云计算",
	"EQUIPMENT_SITE_FLOOR": "1月2日",
	"EQUIPMENT_SITE_ROOM": "107",
	"EQUIPMENT_SITE_RACK": "B11",
	"SYSTEM_NAME": "集中MSS系统",
	"APPLY_CONTENT": "工单申请正文内容",
	"JOB_TYPE": "1",
	"SYS_STAFF_NAME": "小刘",
	"SYS_STAFF_TEL": "12345678901",
	"SYS_STAFF_EMAIL": "123@163.com",
	"ENGINEERS_STAFF_NAME": "小明",
	"ENGINEERS_STAFF_TEL": "12345678901",
	"ENGINEERS_STAFF_EMAIL": "123@163.com",
	"ENTRY_TYPE": "1,2",
	"ENTRY_STAFF_LIST": [{
			"UNIT_NAME": "某公司",
			"STAFF_NAME": "小刘",
			"STAFF_TYPE": "1",
			"TEL": "12345678901",
			"CREDENTIALS_TYPE": "123456789012345678"
		},
		{
			"UNIT_NAME": "某公司",
			"STAFF_NAME": "小王",
			"STAFF_TYPE": "1",
			"TEL": "12345678901",
			"CREDENTIALS_TYPE": "123456789012345678"
		}
	],
	"ENTRY_EQUIPMENT_LIST": [{
			"ENTRY_MAKE_MODEL": "品牌/型号A",
			"ENTRY_EQUIPMENT_TYPE": "设备类型",
			"ENTRY_NUM": "数量",
			"ENTRY_SERIAL": "序列号"
		},
		{
			"ENTRY_MAKE_MODEL": "品牌/型号B",
			"ENTRY_EQUIPMENT_TYPE": "设备类型",
			"ENTRY_NUM": "数量",
			"ENTRY_SERIAL": "序列号"
		}
	],
	"OUT_EQUIPMENT_LIST": [{
			"OUT_MAKE_MODEL": "品牌/型号A",
			"OUT_EQUIPMENT_TYPE": "设备类型",
			"OUT_NUM": "数量",
			"OUT_SERIAL": "序列号"
		},
		{
			"OUT_MAKE_MODEL": "品牌/型号B",
			"OUT_EQUIPMENT_TYPE": "设备类型",
			"OUT_NUM": "数量",
			"OUT_SERIAL": "序列号"
		}
	]
}
        # params['id_card_side'] = id_card_side
        params['method'] = 'getSDInfo'
        # params['image'] = str(img_data, 'utf-8')
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/room/workinfo/getSDInfo'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        try:
            if result['code'] == '10000':
                data = result['data']
                result['data'] = self.decrypt(data)
                print(self.decrypt(data))
        except:
            pass

    def getSDInfoHasPic(self, img_path):
        ''' 工单无人员信息推送接口'''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())
        params = {
	"PROV_ID": "21",
"DC_ID":"10002",
"ROOM_ID":"213/215",
	"FLOW_ID": "590007526998",
	"SYSTEM_ID": "AIGL",
	"SUBMIT_TIME": "2020/11/30 16:46",
	"SUBMIT_STAFF": "小李",
	"SUBMIT_ORG_NAME": "云化推进处",
	"TELPHONE": "12345678901",
	"EMAIL": "123@163.com",
	"SERIAL": "ROOM_ENTRY_20201130_791",
	"TITLE": "工单标题",
	"WORK_START_DATE": "2020/12/1 12:30:20",
	"WORK_END_DATE": "2020/12/3 12:30:20",
	"COMPUTER_ROOM_SITE": "昌平",
	"EQUIPMENT_SITE_NO": "云计算",
	"EQUIPMENT_SITE_FLOOR": "1月2日",
	"EQUIPMENT_SITE_ROOM": "107",
	"EQUIPMENT_SITE_RACK": "B11",
	"SYSTEM_NAME": "集中MSS系统",
	"APPLY_CONTENT": "工单申请正文内容",
	"JOB_TYPE": "1",
	"SYS_STAFF_NAME": "小刘",
	"SYS_STAFF_TEL": "12345678901",
	"SYS_STAFF_EMAIL": "123@163.com",
	"ENGINEERS_STAFF_NAME": "小明",
	"ENGINEERS_STAFF_TEL": "12345678901",
	"ENGINEERS_STAFF_EMAIL": "123@163.com",
	"ENTRY_TYPE": "1,2",
	"ENTRY_STAFF_LIST": [{
			"UNIT_NAME": "某公司",
			"STAFF_NAME": "小刘",
			"STAFF_TYPE": "1",
			"TEL": "12345678901",
			"CREDENTIALS_TYPE": "123456789012345678",
			"FACE_PIC": "base64编码"
		},
		{
			"UNIT_NAME": "某公司",
			"STAFF_NAME": "小王",
			"STAFF_TYPE": "1",
			"TEL": "12345678901",
			"CREDENTIALS_TYPE": "123456789012345678",
			"FACE_PIC": "base64编码"
		}
	],
	"ENTRY_EQUIPMENT_LIST": [{
			"ENTRY_MAKE_MODEL": "品牌/型号A",
			"ENTRY_EQUIPMENT_TYPE": "设备类型",
			"ENTRY_NUM": "数量",
			"ENTRY_SERIAL": "序列号"
		},
		{
			"ENTRY_MAKE_MODEL": "品牌/型号B",
			"ENTRY_EQUIPMENT_TYPE": "设备类型",
			"ENTRY_NUM": "数量",
			"ENTRY_SERIAL": "序列号"
		}
	],
	"OUT_EQUIPMENT_LIST": [{
			"OUT_MAKE_MODEL": "品牌/型号A",
			"OUT_EQUIPMENT_TYPE": "设备类型",
			"OUT_NUM": "数量",
			"OUT_SERIAL": "序列号"
		},
		{
			"OUT_MAKE_MODEL": "品牌/型号B",
			"OUT_EQUIPMENT_TYPE": "设备类型",
			"OUT_NUM": "数量",
			"OUT_SERIAL": "序列号"
		}
	]
}
        # params['id_card_side'] = id_card_side
        params['method'] = 'getSDInfoHasPic'
        # params['image'] = str(img_data, 'utf-8')
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/room/workinfo/getSDInfoHasPic'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        try:
            if result['code'] == '10000':
                data = result['data']
                result['data'] = self.decrypt(data)
                print(self.decrypt(data))
        except:
            pass


    def helmet_suit(self, img_path):
        ''' 安全帽'''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())
        params = {
            "project_id": "test",
            "province_code": "840",
            "subscribe_level": "a1",
            "uid": str(uuid.uuid4()),
            "timestamp": "1528787199",
            "seqid":"e90a6da5-4c89-4074-8d82-42493542aa0b",
            "image": str(img_data,'utf-8'),
            "image_url": "",
            "width": 1920,
            "height": 1080,
            "image_type": ["002"],
            "config": {'002': {'Area': [{"x": 0, "y": 0}, {"x": 300, "y": 0}, {"x": 100, "y": 300}, {"x": 0, "y": 300}]}},
            "DID": "3SXB024451F59DW"}
        # params['id_card_side'] = id_card_side
        params['method'] = 'helmet_suit'
        # params['image'] = str(img_data, 'utf-8')
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/helmet_suit'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        try:
            if result['code'] == '10000':
                data = result['data']
                result['data'] = self.decrypt(data)
                print(self.decrypt(data))
        except:
            pass

    def cold_chain(self, img_path):
        ''' 冷链'''
        with open(img_path, 'rb') as f:
            img_data = base64.b64encode(f.read())
        params = {
	"project_id": "1",
	"province_code": "800",
	"subscribe_level": "a1",
	"uid": 'string',
	"timestamp": 1528787199,
	"seqid": "26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
	"image":"/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAIBAQEBAQIBAQECAgICAgQDAgICAgUEBAMEBgUGBgYFBgYGBwkIBgcJBwYGCAsICQoKCgoKBggLDAsKDAkKCgr/2wBDAQICAgICAgUDAwUKB ……/4Q+z+COm+LLTxnZzXIvRqEutX9lLa",
	"image_url": '',
	"image_type": ["001","002"],
	"Area":[
		{"x": 10, "y": 20},
		{"x": 100, "y": 200},
		{"x": 10, "y": 200}
	],
	"DID":"3TPCA444744NHLK"
}
        # params['id_card_side'] = id_card_side
        params['method'] = 'cold_chain'
        # params['image'] = str(img_data, 'utf-8')
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/cold_chain'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        try:
            if result['code'] == '10000':
                data = result['data']
                result['data'] = self.decrypt(data)
                print(self.decrypt(data))
        except:
            pass

    def image_push(self, img_path):
        ''' 推图'''
        with open(img_path, 'rb') as f:
            img_data = str(base64.b64encode(f.read()),'utf-8')
        params = {
	"seqid": "b7f8fe4f57944d98bb9ad60f48c934ef",
    "timestamp": "1644491601",
    "token": "",
    "version": "test",
    "UID": "test",
    "SID": "shop-1",
    "image": img_data,
}
        # params['id_card_side'] = id_card_side
        params['method'] = 'image/push'
        # params['image'] = str(img_data, 'utf-8')
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/image/push'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        try:
            if result['code'] == '10000':
                data = result['data']
                result['data'] = self.decrypt(data)
                print(self.decrypt(data))
        except:
            pass

    def bodyattr(self, img_path):
        ''' 人体结构化'''
        with open(img_path, 'rb') as f:
            img_data = str(base64.b64encode(f.read()),'utf-8')
        params = {
	"project_id": "1",
"province_code": "800",
"subscribe": "a1",
"uid": '111',
"timestamp": 1528787199,
    "seqid": "26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
"image": img_data,
"width": 1920,
"height": 1080,
"Imagetype ": ["001","002"],
"Area":[{"x": 10, "y": 20},{"x": 100, "y": 200},{"x": 10, "y": 200}],
"DID":"3TPCA444744NHLK"
}
        # params['id_card_side'] = id_card_side
        params['method'] = 'bodyattr'
        # params['image'] = str(img_data, 'utf-8')
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/bodyattr'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        try:
            if result['code'] == '10000':
                data = result['data']
                result['data'] = self.decrypt(data)
                print(self.decrypt(data))
        except:
            pass

    def IdCardOCR(self, img_path):
        ''' 身份证'''
        with open(img_path, 'rb') as f:
            img_data = str(base64.b64encode(f.read()),'utf-8')
        params = {
            "project_id": "test",
            "province_code": "test",
            "subscribe_level":'b1',
            "uid":'test',
            "timestamp": "1528787199",
            "seqid": "26f2739a-6e0f-11e8-bc7a-58fb8443ee27",
            "image":img_data
}
        # params['id_card_side'] = id_card_side
        params['method'] = 'idCardOCR'
        # params['image'] = str(img_data, 'utf-8')
        params = self.getSignParams(params)

        # method = 'GET'
        path = '/idCardOCR'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("result", result)

        # 这里要补充结果校验， 看返回值的状态码是否是10000，是才进入下一步，否则要raise exception
        # data = result['data']
        # print("data",data)
        try:
            if result['code'] == '10000':
                data = result['data']
                result['data'] = self.decrypt(data)
                print(self.decrypt(data))
        except:
            pass
def thread_call():
    # 批量运行身份证
    # j = random.randint(100000, 200000)
    # for i in range(j):
    while True:
        # time_now = time.strftime("%H:%M:%S", time.localtime())
        # if time_now == "23:59:00":
        #    break
        pic_name_1 = '/home/linyicheng/wzy/电子签名.jpg'
        # pic_name_2 = '/home/linyicheng/wanghb/Dcoos_test/face_2.jpg'
        sdk.checkCameraImgv3OCR(pic_name_1)
        break


if __name__ == '__main__':
    import random
    import threading
    # appKey = 'c2c0187368e39d1f5ec4fdbbdbeea9c5'
    # appSecret = '70143ee6ad33da364952edf9dea5b4c2'
    #
    # appKey = '387b9ee5c61433a78bcda90c763b1eef'
    # appSecret = 'ffad49d40d57753b5338ad1d8591e47f'
    #
    # appKey = '1d83f2b7c1f86ca6611fed3bbac861bd'
    # appSecret = 'd7a51ecd65103927efd34e4d307ffae5'

    # appKey = 'c9dd7ae9dc095aa3685fcdbd567972e2'
    # appSecret = 'c241957b02e7658d65ff3fa51cbfc7da'
    # # #
    # appKey = 'f2b853867f56c44c817bb42cb07db14e'
    # appSecret = '734d02d088103d6afc7109af1045f544'
    appKey = '963fdb361bcf382435e029dcf5c51d2e'
    appSecret = '592cbb24a11aef8a05cb1bb5f8045a3a'
    sdk = DopAPI(appKey, appSecret)
    path='/data6/linyicheng/hbw/营业执照/'

    # for i in os.listdir(path):
    #     t1=time.time()
    #     sdk.BusinessLicenseOCR(path+i)#营业执照
    #     print(time.time()-t1)
    #     print('*************')
    sdk.IdCardOCR('1.jpg')
    # sdk.bodyattr('1.jpg')#人体结构化
    # sdk.image_push('1.png')#推图
    # sdk.cold_chain('1.png')#冷链
    # sdk.helmet_suit('1.png')#安全帽
    # sdk.getSDInfoHasPic('1.png')#工单有人员信息推送接口
    # sdk.getSDInfo('1.png')#工单无人员信息推送接口
    # sdk.vehicle_task_create_feature('1.png')#车辆添加
    # sdk.vehicle_task_delete_feature('1.png')#车辆删除
    # sdk.portrait_task_search_index('1.png')#车辆库查询
    # sdk.vehicle_task_search_feature('1.png')#车辆查询
    # sdk.vehicle_task_delete_index('1.png')#车辆布控库删除服务接口
    # sdk.vehicle_task_create_index('1.png')#车辆布控库创建服务接口
    # sdk.retrieval_feature('1.png')#人像检索（1vN）服务接口
    # sdk.ai_data_feedback('1.png')#AI场景数据准确性反馈服务接口
    # sdk.checkCameraImgv3OCR('1.png')#摄像头巡检v2
    # sdk.camera_inspection('1.png')#摄像头巡检
    # sdk.kitchen_analysis('0.jpg')#明厨亮灶服务API
    # sdk.pig_detection('0.jpg')#猪数量检测
    # sdk.picToText('0.jpg')#数字生活ocr
    # sdk.delete_task()#告警事件任务删除服务接口
    # sdk.search_task()#告警事件任务查询服务接口
    # sdk.create_task()#告警事件任务创建服务接口
    # sdk.fire_discern('fi.jpg')#火焰识别
    # sdk.get_feature('1.jpg')#人像特征提取服务接口
    # sdk.create_feature('1.jpg')#人像创建
    # sdk.delete_feature('1.jpg')#人像删除
    # sdk.delete_index('1.jpg')#人像库删除
    # sdk.create_index('1.jpg')#人像库创建
    # sdk.search_index('1.jpg')#人像库查询服务接口
    # sdk.search_feature('1.jpg')#人像查询服务接口
    # sdk.register_feature('1.jpg')#人像注册服务接口
    # sdk.pat_timephoto_video_task()#时光缩影宠物视频推送接口
    # sdk.pat_timephoto_compose_task()#时光缩影宠物视频合成通知接口
    # sdk.timephoto_compose_task_common()#时光缩影视频通用合成通知能力
    # sdk.timephoto_video_task_common()#通用时光缩影视频推送
    # sdk.timephoto_face_insert_common('1.jpg')#通用时光缩影人脸下发
    # sdk.timephoto_face_delete_common('1.jpg')#通用时光缩影人脸删除
    # sdk.car_recognization('car.jpg')#车辆违停服务接口
    # sdk.electric_vehicle_detection('ele.jpg')#电动车检测
    # sdk.staffquitpost('1.jpg')#人员离岗
    # sdk.fall_detection('dd.jpeg')#跌倒检测
    # sdk.gathered('1.jpg')#人群聚集
    # sdk.update()#店铺更新能力
    # sdk.list()#获取店铺清单能力服务接口
    # sdk.camera()#编辑摄像头
    # sdk.cameralist()#获取摄像头清单
    # sdk.delete_camera()#删除摄像头
    # sdk.add_camera()#添加摄像头
    # sdk.chart()#客流报表
    # sdk.summary()#客流统计能力服务接口
    # sdk.personnel_get()#获取指定人员资料
    # sdk.personnel_list()#人员库查询能力
    # sdk.total()#人员统计
    # sdk.faceDelete()#名单删除服务接口
    # sdk.faceSet()#黑白名单设定服务接口
    # sdk.analysisService()#人脸/车辆解析服务接口
    # sdk.resultPic()#明厨亮灶结果推送服务接口
    # sdk.sceneRecog()#图片场景类型识别服务接口
    # sdk.fireProtect()#森林防火
    # sdk.avatar_delete()#删除人员头像照片能力
    # sdk.avatar_add('1.jpg')#添加人员头像照片能力
    # sdk.avatar_update('1.jpg')#添加人员头像照片能力
    # sdk.personnel_delete('1.jpg')#删除人员资料
    # sdk.personnel_new('1.jpg')#新增人员入库能力服务接口
    # sdk.personnel_update('1.jpg')#修改人员入库能力服务接口
    # sdk.get_store('1.jpg')#获取指定店铺信息
    # sdk.add_store('1.jpg')#店铺添加能力服务
    # sdk.NotUserInfo('1.jpg')#非电信员工信息及附件同步接口
    # sdk.rtspinfo('1.jpg')#启停待分析视频流服务
    # sdk.UserInfo('1.jpg')#电信员工信息验证
    # 单张测试

    # sdk.LicenseOCR('/home/linyicheng/wanghb/AI_EnterpriseLicense/docs/11月号百问题图片/07668983989.png')
    # print('分析用时（秒）:', result)
    # 批量测试
    # path = '/home/linyicheng/wanghb/AI_EnterpriseLicense/docs/11月号百问题图片'
    # 批量运行营业执照
    # business_path = '/home/linyicheng/wanghb/Dcoos_test/business_154'  #70张
    # 批量运行身份证
    w = 1  # 线程数
    th_list = []
    # while True:
    # for i in range(w):
    #     t = threading.Thread(target=thread_call)
    #     t.start()
    # th_list.append(t)
    # for t in th_list:
    #    t.join()
    # j = random.randint(100000, 200000)
    # for i in range(j):
    #     time_now = time.strftime("%H:%M:%S", time.localtime())
    #     if time_now == "23:59:00":
    #         break
    #     pic_name = '/home/linyicheng/wanghb/idcard_ori_200/1588878169.jpg'
    #     sdk.idCardOCR(pic_name)


