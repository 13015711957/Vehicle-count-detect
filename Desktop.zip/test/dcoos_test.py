# coding=utf-8
import time
import uuid
import hashlib
import base64

import pandas as pd
import requests

import json
import requests
import time
import base64
import rsa
import Crypto.PublicKey.RSA as RSA
from Crypto.Hash import SHA256
from Crypto.Cipher import PKCS1_v1_5 as Cipher_pkcs1_v1_5

# 公钥加密
def encryptPassword(password, publicKeyStr):
    # 1、base64解码
    publicKeyBytes = base64.b64decode(publicKeyStr.encode())
    # 3、生成publicKey对象
    rsakey = RSA.importKey(publicKeyBytes)
    # 4、对原密码加密
    encryptPassword = rsa.encrypt(password.encode(), rsakey)
    return base64.b64encode(encryptPassword).decode()

class DopAPI(object):
    def __init__(self, appKey, appSecret):
        self.appKey = appKey
        self.appSecret = appSecret
        self.sKey = appSecret
        self.base_url = 'http://10.128.86.64:8000/serviceAgent/rest'
        self.token=self.get_tokern()

    def decryptApi(self, path, params):
        ''' 解密消息 '''

        url = self.base_url + path
        headers = {
            "Content-Type": "application/json;charset=UTF-8",
            "X-APP-ID": self.appKey,
            "X-APP-KEY": self.sKey,
            "Authorization":self.token
        }

        res = requests.get(url, headers=headers, params=params)
        # print("res", res)
        # 这里要补充结果校验
        return res.json()

    def get_tokern(self):
        post_url = 'http://10.128.86.64:8000/serviceAgent/rest/dcoos/oauth/token'

        now_time = str(time.time())
        key = now_time[:now_time.find('.')] + now_time[now_time.find('.') + 1: now_time.find('.') + 4]

        publicKeyStr = 'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDJ5Rz2ZDw+nXWB+Qe76M68uDM3xv/4fyWIdv1BLqKFJ277DgPMXQ3pPdZk6n4bK+Rn0ow7QeV+rSnz8C+GOTTa0AfDAWmujgAsSg9Ayj/cNm+VRTbe2GQr0GFxVIaU9epAC5sQ2EbsAhOS12+dqMzsMR5sY02cOLfk1aDfIgvq0wIDAQAB'
        temp_passwd = key + '&&Haha_3325'

        password = encryptPassword(temp_passwd, publicKeyStr)

        post_data = {
            "X-APP-ID": "9c7154c13070173025eb08888d287756",
            "X-APP-KEY": "c74d705abbc8886de963ac7304d7a3b9",
            "Content-Type": "application/x-www-form-urlencoded",
            "username": "yvonneason",
            "password": password,
            "grant_type": "dcoos_pwd",
            "client_id": "27b822f4-c17c-491b-9c7b-eb621ac4805d",
            "client_secret": "123456"
        }

        r_post = requests.post(post_url, data=post_data)
        res_post = json.loads(r_post.content.decode())
        repost_url = 'http://10.128.86.64:8000/serviceAgent/rest/dcoos/oauth/token'
        repost_data = {
            "X-APP-ID": "9c7154c13070173025eb08888d287756",
            "X-APP-KEY": "c74d705abbc8886de963ac7304d7a3b9",
            "Content-Type": "application/x-www-form-urlencoded",
            "username": "yvonneason",
            "password": password,
            "grant_type": "refresh_token",
            "client_id": "27b822f4-c17c-491b-9c7b-eb621ac4805d",
            "client_secret": "123456",
            "refresh_token": res_post["data"]["refreshToken"]
        }
        re_post = requests.post(repost_url, data=repost_data)
        result_post = json.loads(re_post.content.decode())
        return "Bearer " + result_post['data']['accessToken']

    def get_version(self,appid,province):
        params = {}
        params['province'] = province
        # params['appId'] = appid
        path='/dcoos/app/{}/subscriptionList'.format(appid)
        result = self.decryptApi(path, params)
        # print("result", result)

    def find(self,apiid,appid,component,startime,endtime):
        ''' 调用量查询API '''


        params = {}
        # params['method'] = "find"
        params['apiId'] = apiid
        params['appId'] = appid
        params['component'] = component
        params['startTime'] = startime
        params['endTime'] = endtime

        # method = 'GET'
        path = '/dcoos/find'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        print("调用量result", result)
        return result


    def subscriptionApp(self,apiid):
        ''' 查询API被哪些APP签约API '''

        # self.token= self.get_tokern()
        # self.token=res_post["data"]["refreshToken"]

        # print("result_post:", result_post)

        params = {}
        # params['method'] = "subscriptionApp"
        params['apiId'] = apiid
        params['verNum'] = "V1.0.00"


        # method = 'GET'
        path = '/dcoos/app/subscriptionApp'

        # print(self.getRequestString(path,params,method)) # 调试用
        result = self.decryptApi(path, params)
        # print("签约result", result)
        return result['data']

    def get_list(self,appids):
        params = {}
        params['appIds'] = appids
        path = '/dcoos/app/list'
        result = self.decryptApi(path, params)
        # print("result", result)
        return result



if __name__ == '__main__':

    df_res = pd.DataFrame(
        columns=['APIname','APIID','name', 'APPID', 'APPKEY', 'username','usernameCn', 'email', 'mobile', 'province',
                 '成功','请求无效','登录失败','无法找到','资源被禁止','超时','内部服务器错误','网关错误','超载或系统维护'])
    appKey = '9c7154c13070173025eb08888d287756'
    appSecret = 'c74d705abbc8886de963ac7304d7a3b9'

    sdk = DopAPI(appKey, appSecret)
    apiids={
        # '7996745672264187918': 'POST营业执照识别服务接口',
        # '7996745672998191173': 'POST身份证识别服务接口',
        # '7996745672343879692': 'POST统一社会信用代码证书识别服务接口',
        # '7996745673224683570': 'POST事业单位法人证书识别服务接口',
        # '7996745673056911391': 'POST证照识别服务接口',
# '1364043121190785024':'活体照疑似翻拍服务接口',
# '7996745672578760723':'POST通用文字识别服务接口',
# '8022677675673395201':'POST人证合规性稽核服务接口',
# '1390209669449375799':'人像质量稽核服务接口_福建',
# '1398099816677077009':'UIM卡识别服务接口',
# '1344211759742992384':'快递单识别服务接口',
# '1372806979978879071':'表格识别服务接口',
# '1369950100739154010':'电表识别服务接口',
# '1397077745787265107':'电子签名识别服务接口',
# '1390208991665795121':'图像曝光度过高服务接口_福建',
# '1390206323422388237':'免冠检测服务接口_福建',
# '7996745672478097440':'POST人脸比对接口' ,
# '1375276317028003840':'ASR离线服务接口',
# '1355063872783400960':'口罩识别服务接口',
# '8025654772483424257':'POST临时身份证识别服务接口',
# '1435884170582548493':'证据调取通知书识别服务接口',
# '1390131051536003145':'图像质量清析度检测接口_福建',
# '7996745672998191173':'POST身份证识别服务接口',
# '1390145739540652105':'人像遮挡检测服务接口_福建',
# '1435878518279757917':'多身份证识别服务接口',
  '1402102912765927437':'公函清晰度识别服务接口'

}
    # apiid='1344211759742992384'
    # apiid='8022677675673395201'#人证
    # apiid='7996745672998191173'#身份证
    # apiid_old='63794'#人证
    # apiid_old='52753'#身份证
    compoent='1001010001'#集团EOP网关
    compoent='1001020001'#数据EOP
    startime='20211208000000'
    endtime ='20211209000000'
    # sdk.get_version('8024900024498585600','集团')
    result = []
    for apiid,apiname in apiids.items():

        appids=sdk.subscriptionApp(apiid)

        # new_appids=[]
        for appid in appids:
            try:
                r=sdk.find(apiid,appid,compoent,startime,endtime)
            except:
                continue
            if len(r['findResult'])>0:
                app_info=sdk.get_list([appid])
                data=app_info['data'][0]
                sums = {'sum_200': 0,
                        'sum_400': 0,
                        'sum_401': 0,
                        'sum_404': 0,
                        'sum_405': 0,
                        'sum_408': 0,
                        'sum_500': 0,
                        'sum_502': 0,
                        'sum_503': 0}
                for i in r['findResult']:
                    sums['sum_' + i['response_code']] = i['sum']
                result.append([apiname,apiid,data['name'],data['id'],data['appKey'],data['creatorUser']['username'],
                               data['creatorUser']['usernameCn'], data['creatorUser']['email'], data['creatorUser']['mobile'], data['creatorUser']['province'],
                               sums['sum_200'],sums['sum_400'],sums['sum_401'],sums['sum_404'],sums['sum_405'],
                               sums['sum_408'],sums['sum_500'],sums['sum_502'],sums['sum_503']])
                # new_appids.append(appid)

    for i in range(len(result)):
        df_res.loc[i] = result[i]
        print('==========')
        print(result[i])
    df_res.to_excel('调用详情.xlsx', index=False)
