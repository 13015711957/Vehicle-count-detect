import os

import numpy as np
import sys
import cv2
import tritonclient.http as httpclient
import base64
import pandas as pd


def get_box(triton_client,image_url):
    model_name = "end2end"

    input_base64_matrix = []
    #print(base64.b64encode(open("00003.jpg","rb").read()))
    input_base64_matrix.append([x for x in base64.b64encode(open(image_url,"rb").read())])
    #input_base64_matrix.append([x for x in base64.b64encode(open("00007.jpg","rb").read())])
    #print(input_base64_matrix)
    input_base64_matrix_len_list = [len(l) for l in input_base64_matrix]
    max_len = max(input_base64_matrix_len_list)
    input_base64_matrix = list(map(lambda l:l + [0]*(max_len - len(l)), input_base64_matrix))
    input_base64_matrix = np.array(input_base64_matrix,dtype=np.uint8)
    print(input_base64_matrix.shape)
    shape=cv2.imread(image_url).shape
    print(shape)
    # input_param = [(854,1093,x) for x in input_base64_matrix_len_list]
    input_param = [(shape[0],shape[1],x) for x in input_base64_matrix_len_list]
    input_param = np.array(input_param,dtype=np.uint32)
    print(input_param)

    input_size = [[160,320]]
    input_size = np.array(input_size).astype(np.uint16)

    inputs =[]
    inputs.append(httpclient.InferInput("ensemble_input_base64", list(input_base64_matrix.shape),"UINT8"))
    inputs[0].set_data_from_numpy(input_base64_matrix)

    inputs.append(httpclient.InferInput("ensemble_input_base64_param", list(input_param.shape),"UINT32"))
    inputs[1].set_data_from_numpy(input_param)

    inputs.append(httpclient.InferInput("ensemble_input_size", list(input_size.shape),"UINT16"))
    inputs[2].set_data_from_numpy(input_size)

    res=[]
    outputs = []

    outputs.append(httpclient.InferRequestedOutput('ensemble_output_flag'))
    outputs.append(httpclient.InferRequestedOutput('ensemble_output_vec'))
    outputs.append(httpclient.InferRequestedOutput('ensemble_output_quality'))
    outputs.append(httpclient.InferRequestedOutput('ensemble_output_of_bestface'))
    outputs.append(httpclient.InferRequestedOutput('ensemble_output_of_unresize_box'))
    outputs.append(httpclient.InferRequestedOutput('ensemble_output_of_best_arcface_vec'))
    results = triton_client.infer(
        model_name=model_name, inputs=inputs,  outputs=outputs, headers={"test": "1"}
    )
    ensemble_output_of_bestface = results.as_numpy("ensemble_output_of_bestface")
    print("ensemble_output_of_bestface.shape",ensemble_output_of_bestface.shape)
    print("ensemble_output_of_bestface",ensemble_output_of_bestface)
    res.append(ensemble_output_of_bestface)

    ensemble_output_quality = results.as_numpy("ensemble_output_quality")
    print("ensemble_output_quality.shape",ensemble_output_quality.shape)
    print("ensemble_output_quality",ensemble_output_quality)
    res.append(ensemble_output_quality)

    ensemble_output_flag = results.as_numpy("ensemble_output_flag")
    print("ensemble_output_flag.shape",ensemble_output_flag.shape)
    print("ensemble_output_flag",ensemble_output_flag)
    res.append(ensemble_output_flag)

    ensemble_output_of_unresize_box = results.as_numpy("ensemble_output_of_unresize_box")
    print("ensemble_output_of_unresize_box.shape",ensemble_output_of_unresize_box.shape)
    print("ensemble_output_of_unresize_box",ensemble_output_of_unresize_box)
    res.append(ensemble_output_of_unresize_box)

    ensemble_output_of_best_arcface_vec = results.as_numpy("ensemble_output_of_best_arcface_vec")
    print("ensemble_output_of_best_arcface_vec.shape",ensemble_output_of_best_arcface_vec.shape)
    print("ensemble_output_of_best_arcface_vec",ensemble_output_of_best_arcface_vec[:10].flatten())
    res.append(ensemble_output_of_best_arcface_vec.flatten())

    ensemble_output_vec = results.as_numpy("ensemble_output_vec")
    print("ensemble_output_vec.shape",ensemble_output_vec.shape)
    print("ensemble_output_vec",ensemble_output_vec[0][:10].flatten())
    res.append(ensemble_output_vec[0].flatten())
    #print("ensemble_output_vec",ensemble_output_vec[1][:10].flatten())




    return res


if __name__ == '__main__':
    try:
        # triton_client = httpclient.InferenceServerClient(url="127.0.0.1:18000", verbose=False) #工作站上run，请求工作站服务
        # triton_client = httpclient.InferenceServerClient(url="127.0.0.1:41000", verbose=False) #工作站上run，请求工作站服务
        triton_client = httpclient.InferenceServerClient(url="10.143.165.45:31005", verbose=False) #工作站上run，请求集群服务
    except Exception as e:
        print("channel creation failed: " + str(e))
        sys.exit()
    # boxes = get_box(triton_client,"002.jpg")
    df_res = pd.DataFrame(columns=['pic_name', 'ensemble_output_of_bestface','ensemble_output_quality','ensemble_output_flag','ensemble_output_of_unresize_box','ensemble_output_of_best_arcface_vec','ensemble_output_vec'])
    result = []
    for img in os.listdir('docs/img/'):
        print(img)
        if 'pdf'in img:continue
        boxes = get_box(triton_client,"docs/img/"+img)
        result.append([img,boxes[0],boxes[1],boxes[2],boxes[3],boxes[4],boxes[5]])
    #
    # for i in range(len(result)):
    #     df_res.loc[i] = result[i]
    # df_res.to_excel('1xc_ensemble.xlsx', index=False)

