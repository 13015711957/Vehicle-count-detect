import json
import requests
import time
import base64
import rsa
import Crypto.PublicKey.RSA as RSA
from Crypto.Hash import SHA256
from Crypto.Cipher import PKCS1_v1_5 as Cipher_pkcs1_v1_5


# 公钥加密
def encryptPassword(password, publicKeyStr):
    # 1、base64解码
    publicKeyBytes = base64.b64decode(publicKeyStr.encode())
    # 3、生成publicKey对象
    rsakey = RSA.importKey(publicKeyBytes)
    # 4、对原密码加密
    encryptPassword = rsa.encrypt(password.encode(), rsakey)
    return base64.b64encode(encryptPassword).decode()


def get_company(uid):
    post_url = 'http://10.128.86.64:8000/serviceAgent/rest/dcoos/oauth/token'

    now_time = str(time.time())
    key = now_time[:now_time.find('.')] + now_time[now_time.find('.') + 1: now_time.find('.') + 4]

    publicKeyStr = 'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDJ5Rz2ZDw+nXWB+Qe76M68uDM3xv/4fyWIdv1BLqKFJ277DgPMXQ3pPdZk6n4bK+Rn0ow7QeV+rSnz8C+GOTTa0AfDAWmujgAsSg9Ayj/cNm+VRTbe2GQr0GFxVIaU9epAC5sQ2EbsAhOS12+dqMzsMR5sY02cOLfk1aDfIgvq0wIDAQAB'
    temp_passwd = key + '&&Haha_3325'

    password = encryptPassword(temp_passwd, publicKeyStr)

    post_data = {
        "X-APP-ID": "9c7154c13070173025eb08888d287756",
        "X-APP-KEY": "c74d705abbc8886de963ac7304d7a3b9",
        "Content-Type": "application/x-www-form-urlencoded",
        "username": "yvonneason",
        "password": password,
        "grant_type": "dcoos_pwd",
        "client_id": "27b822f4-c17c-491b-9c7b-eb621ac4805d",
        "client_secret": "123456"
    }

    r_post = requests.post(post_url, data=post_data)
    res_post = json.loads(r_post.content.decode())
    repost_url = 'http://10.128.86.64:8000/serviceAgent/rest/dcoos/oauth/token'
    repost_data = {
        "X-APP-ID": "9c7154c13070173025eb08888d287756",
        "X-APP-KEY": "c74d705abbc8886de963ac7304d7a3b9",
        "Content-Type": "application/x-www-form-urlencoded",
        "username": "yvonneason",
        "password": password,
        "grant_type": "refresh_token",
        "client_id": "27b822f4-c17c-491b-9c7b-eb621ac4805d",
        "client_secret": "123456",
        "refresh_token": res_post["data"]["refreshToken"]
    }

    re_post = requests.post(repost_url, data=repost_data)
    result_post = json.loads(re_post.content.decode())
    # print("result_post:", result_post)

    headers = {
        "X-APP-ID": "9c7154c13070173025eb08888d287756",
        "X-APP-KEY": "c74d705abbc8886de963ac7304d7a3b9",
        "Content-Type": 'application/json;charset=utf-8',
        "Authorization": "Bearer " + result_post['data']['accessToken']
    }

    get_url = 'http://10.128.86.64:8000/serviceAgent/rest/dcoos/app/list?appIds=' + uid
    r_get = requests.get(get_url, headers=headers)
    res_get = json.loads(r_get.content.decode())
    # print(type(res_get))
    
    if len(res_get['data']) == 0:
        return ''

    if res_get['data'][0]['creatorUser']['usernameCn'] == '许爱文':
        new_url = 'http://10.128.86.64:8000/serviceAgent/rest/atomapi/atom/getAtomInfoList'
        new_headers = {
            'Content-Type': "application/json;charset=UTF-8",
            'X-APP-ID': "c2c0187368e39d1f5ec4fdbbdbeea9c5",
            'X-APP-KEY': "ef4eefedda0b4f45ccd6ef82e0aa44b6",
        }
    
        new_data = {
            "startDt": time.strftime("%Y", time.localtime()) + '-01-01 00:00:00',
            "overDt": time.strftime("%Y-%m", time.localtime()) + '-30 23:59:59',
            "companyId": "15d23bac955c4752a2f03a3ff2bae3b5"
            #"companyId": "ce5a6f8afa6c877616c6ae7abcbcbfd0"
        }
        datas = json.dumps(new_data)
        res = requests.post(url=new_url,
                                headers=new_headers, data=datas)
        res = json.loads(res.text, strict=False)
        if res['code'] == 200 and len(res['data']) > 0:
            for userinfo in res['data']:
                if uid == userinfo['xAppId']:
                    res_get = {'success': 0, 'code': '0000', 'message': '', 'data': [userinfo]}
                    
    return res_get


if __name__ == '__main__':
    uid_list = [
        '0',
            '07bcf8acc225cf58bc30793819b1925f',
            '0bfd2699ef62d0a7037cad524f150a0c',
            '0fd126f7867600f223993ebad6aeee6b',
            '10f2b206dba116578df441d8cda76c9e',
            '16e5b780d585d89ddbc9f1e7aeb878c8',
            '19b19ec579544a20513b0a0a970a2eb6',
            '1c7473745459042d39b8c3236c7d6ff1',
            '1cb25112e6b36038bd83e38891f85f46',
            '1df3c60c603e4015d118931a2774b277',
            '1eed2a7cfee72c4f18dd34a40b085920',
            '321eab027feaf82e0bbd0530c69b10e1',
            '348b4053083cc1d22d8e004a7b71bd71',
            '4cccde02483d7702eb16816b329b1d10',
            '4eaac6ce4955fa36f86c81112477972c',
            '506',
            '56b12ee3137e10426e50392ae743126d',
            '5aadaed47dc3160857e5f1affd1f21a7',
            '5d969290a79ce42375da49fa881f5286',
            '5e6f9dd60508e39e4465a973923e93b3',
            '617',
            '6e8d0d93cd1df076d6c852127fb5c685',
            '7467d2a5609db3ac20558c4776457fca',
            '80d7b8db65d0d132751aee0e19b5d6e9',
            '8e18ec40e8c76c85a886ed5bdedf3a67',
            '8e97d98bacd4c54eaa3826b4e72d311d',
            '94bdeae3aea4424473b8b1dab34b4b26',
            'a56d9b7c6f174077085f2edfd45eff08',
            'a784f3c54e37e8ac27bb0e85b05bb9cf',
            'a9db36ae363ecfc1ddf9e3e6ed649cda',
            'aeaa25998957c8d26ea5c4a0c333626e',
            'b30a43fd5f605e7862f0fdb2dd5480ad',
            'b858d89bec62d797f94862c2aa6687e3',
            'c73536992b9132c20ee5b3910009d4a5',
            'ce5a6f8afa6c877616c6ae7abcbcbfd0',
            'ce684b3cddc0df486ef4a6ad3de2b2e1',
            'dd601d8bb474046347823dd80a1fd6dc',
            'e010e5621dfbd5e79ff5071ae86cde87',
            'e049ff6e6c66ef159546768a2a4b232c',
            'e0b865c64f5fdbdd7da6868662c3b37b',
            'e1af620b17d7db787e0e9d2a1e75b839',
            'f1ac558a52e528f09e47d6b636c932d7',
            'f51ddcbe16bec8c241d43b7e0806b788',
            'f5a127b96581085eefe599025d8ec90f',
            'fb9321bd5e460398b57dc37a6cab8b11',
            'ff1c59548d02ba608cf470da9a5de5cf',
    ]

    for uid in uid_list:
        print(uid)
        result = get_company(uid)
        print(result)
