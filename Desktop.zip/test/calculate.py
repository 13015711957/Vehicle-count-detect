import pandas as pd
excelfile='111.xlsx'
df=pd.read_excel(excelfile,sheet_name='Sheet1')
'''读取标准数据'''
bz=df['result_biaozhun'].value_counts().to_dict()
zc_bz=bz['正常']
gb_bz=0
mh_bz=0
zd_bz=0
ps_bz=0
xh_bz=0
for k,v in bz.items():
    if '过曝'in k:gb_bz+=v
    if '模糊'in k:mh_bz+=v
    if '遮挡'in k:zd_bz+=v
    if '偏色'in k:ps_bz+=v
    if '雪花'in k:xh_bz+=v

def read_col(col):
    temp=df[col].value_counts().to_dict()
    zc = 0
    gb = 0
    mh = 0
    zd = 0
    ps = 0
    xh = 0
    for k, v in temp.items():
        if '正常' in k: zc +=v
        if '过曝' in k: gb += v
        if '模糊' in k: mh += v
        if '遮挡' in k: zd += v
        if '偏色' in k: ps += v
        if '雪花' in k: xh += v
    return zc,gb,mh,zd,ps,xh

def com(a, b):
    res = []
    for x in a:
        if x in b:
            res.append(x)
    return res


def read_col_right(col):
    right=col+'_right'
    df[right] = df.apply(lambda x: com(x['result_biaozhun'], x[col]), axis=1)
    res = df[right].value_counts()

    zc_right = 0
    gb_right = 0
    mh_right = 0
    zd_right = 0
    ps_right = 0
    xh_right = 0

    for k, v in res.items():
        if '正' in str(k):  zc_right += v
        if '过' in str(k):  gb_right += v
        if '模' in str(k):  mh_right += v
        if '遮' in str(k):  zd_right += v
        if '偏' in str(k):  ps_right += v
        if '雪' in str(k):  xh_right += v

    return zc_right,gb_right,mh_right,zd_right,ps_right,xh_right

'''读取yitu数据'''
zc_yt,gb_yt,mh_yt,zd_yt,ps_yt,xh_yt=read_col('result_yitu')

'''读取our数据'''
zc_our,gb_our,mh_our,zd_our,ps_our,xh_our=read_col('our_result')


'''读取yitu正确的数据'''
zc_yt_right, gb_yt_right, mh_yt_right, zd_yt_right, ps_yt_right, xh_yt_right=read_col_right('result_yitu')

'''读取our正确的数据'''

zc_our_right, gb_our_right, mh_our_right, zd_our_right, ps_our_right, xh_our_right=read_col_right('our_result')

def read_data(cols):
    results=[]
    for i in cols:
        zc, gb, mh, zd, ps, xh=read_col(i)
        zc_right, gb_right, mh_right, zd_right, ps_right, xh_right=read_col_right(i)
        results.append({i:[[zc,zc_right],[gb,gb_right],[mh,mh_right],[zd,zd_right],[ps,ps_right],[xh,xh_right]]})
    return results

def divide(a,b):
    if b==0:
        return 0
    else: return a/b

cols=['our_result','result_yitu']
print(read_data(cols))
text=read_data(cols)
df_res = pd.DataFrame(columns=['统计', '正常', '过曝','模糊','遮挡','偏色', '雪花'])
result=[]
z=[zc_bz,gb_bz,mh_bz,zd_bz,ps_bz,xh_bz]
result.append(['标准',zc_bz,gb_bz,mh_bz,zd_bz,ps_bz,xh_bz])
for i in text:
    x=[]
    for k,v in i.items():
        print(k,v)
        for j in v:
            x.append(str(j[-1])+'('+str(j[0])+')')
        x.insert(0,k)

    result.append(x)
    x = []
    for k, v in i.items():
        print(k, v)
        for j in v:
            x.append(divide(j[-1],j[0]))
        x.insert(0, str(k)+'精确率')
    result.append(x)

    x = []
    for k, v in i.items():
        print(k, v)
        for j,o in zip(v,z):
            x.append(divide(j[-1], j[0]))
        x.insert(0, str(k) + '召回率')
    result.append(x)


for i in range(len(result)):
    df_res.loc[i] = result[i]
    print("===============")
    print(result[i])
df_res.to_excel('res.xlsx',index=False)

