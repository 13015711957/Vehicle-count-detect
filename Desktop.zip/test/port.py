# !/usr/bin/env python3
# -*- coding:utf-8 -*-

"""
批量测试端口号
"""
import socket

def get_host_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(('8.8.8.1', 80))
        ip = s.getsockname()[0]
    finally:
        s.close()
    return ip

def is_port_used(ip, port):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.settimeout(1)
        s.connect((ip, port))
        return True

    except socket.timeout:
        # return "timeout"
        return "连接超时"
    except socket.error:
        # return "Connection refused"
        return "连接被拒绝"
    finally:
        s.close()


def for_port():
    # hosts为IP列表
    hosts = ['192.168.35.225', '192.168.35.226', '192.168.35.200']
    # port_list为端口列表
    port_list = ['5432', '1935']

    host_ip = get_host_ip()
    print("host_ip:%s" % host_ip, "\n")
    for target_ip in hosts:
        print("target_ip:%s" % target_ip)
        for target_port in port_list:
            # telnet(target_ip, target_port)
            connect_status = is_port_used(target_ip, int(target_port))
            print("target_port:%s status:%s" % (target_port,  connect_status))
        print('\n')



if __name__ == '__main__':
    for_port()