import os
import cv2
import json
import base64
import requests
import pandas as pd

url = 'http://127.0.0.1:5082/Face/biopsy'
image_path = '/home/wanghuibing/wanghb/silent_bioassay/docs/zc'

df_res = pd.DataFrame(columns=['pic_name', 'result', 'prob',  'timeSecond'])
result=[]
for file_name in os.listdir(image_path):
    source_img = cv2.imread(image_path + '/' + file_name)
    
    source_img = cv2.imencode('.jpg', source_img)[1].tostring()
    source_img = base64.b64encode(source_img)
    
    data = {
        "image":  str(source_img, "utf-8"),
        'seqid': 'test'
    }
    r = requests.post(url, data=data)
    res = json.loads(r.content.decode('unicode_escape'))  # 将字符串转字典
    print(res)
    if res['code'] == '10000':
        res=res['data']
        result.append([file_name,res['result'],res['prob'],res['timeSecond']])
    else:
        result.append([file_name, '', '', ''])


for i in range(len(result)):
    df_res.loc[i] = result[i]
    print("===============")
    print(result[i])
df_res.to_excel('0729_zc.xlsx',index=False)

